import{w as s}from"./index.279db187.js";const a=s({}),e=s({});export{a,e as s};
