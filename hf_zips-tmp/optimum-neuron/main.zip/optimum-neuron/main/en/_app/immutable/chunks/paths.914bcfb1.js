var s;const a=((s=globalThis.__sveltekit_2g7j5o)==null?void 0:s.base)??"/docs/optimum.neuron/main/en";var e;const o=((e=globalThis.__sveltekit_2g7j5o)==null?void 0:e.assets)??a;export{o as a,a as b};
