import{s as ae,o as te,n as nl}from"../chunks/scheduler.8c3d61f6.js";import{S as ne,i as oe,g as u,s as M,r as y,A as Me,h as w,f as s,c as i,j as le,u as m,x as h,k as ee,y as ie,a as n,v as r,d,t as c,w as J}from"../chunks/index.da70eac4.js";import{T as se}from"../chunks/Tip.1d9b8c37.js";import{C as B}from"../chunks/CodeBlock.a9c4becf.js";import{H as sl,E as pe}from"../chunks/getInferenceSnippets.39110341.js";import{H as ye,a as Hl}from"../chunks/HfOption.6ab18950.js";function me(Z){let a,p;return a=new B({props:{code:"JTIzJTIwcGlwJTIwaW5zdGFsbCUyMGZ0ZnklMEFpbXBvcnQlMjB0b3JjaCUwQWltcG9ydCUyMG51bXB5JTIwYXMlMjBucCUwQWZyb20lMjBkaWZmdXNlcnMlMjBpbXBvcnQlMjBBdXRvTW9kZWwlMkMlMjBXYW5QaXBlbGluZSUwQWZyb20lMjBkaWZmdXNlcnMuaG9va3MuZ3JvdXBfb2ZmbG9hZGluZyUyMGltcG9ydCUyMGFwcGx5X2dyb3VwX29mZmxvYWRpbmclMEFmcm9tJTIwZGlmZnVzZXJzLnV0aWxzJTIwaW1wb3J0JTIwZXhwb3J0X3RvX3ZpZGVvJTJDJTIwbG9hZF9pbWFnZSUwQWZyb20lMjB0cmFuc2Zvcm1lcnMlMjBpbXBvcnQlMjBVTVQ1RW5jb2Rlck1vZGVsJTBBJTBBdGV4dF9lbmNvZGVyJTIwJTNEJTIwVU1UNUVuY29kZXJNb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIyV2FuLUFJJTJGV2FuMi4xLVQyVi0xNEItRGlmZnVzZXJzJTIyJTJDJTIwc3ViZm9sZGVyJTNEJTIydGV4dF9lbmNvZGVyJTIyJTJDJTIwdG9yY2hfZHR5cGUlM0R0b3JjaC5iZmxvYXQxNiklMEF2YWUlMjAlM0QlMjBBdXRvTW9kZWwuZnJvbV9wcmV0cmFpbmVkKCUyMldhbi1BSSUyRldhbjIuMS1UMlYtMTRCLURpZmZ1c2VycyUyMiUyQyUyMHN1YmZvbGRlciUzRCUyMnZhZSUyMiUyQyUyMHRvcmNoX2R0eXBlJTNEdG9yY2guZmxvYXQzMiklMEF0cmFuc2Zvcm1lciUyMCUzRCUyMEF1dG9Nb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIyV2FuLUFJJTJGV2FuMi4xLVQyVi0xNEItRGlmZnVzZXJzJTIyJTJDJTIwc3ViZm9sZGVyJTNEJTIydHJhbnNmb3JtZXIlMjIlMkMlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmJmbG9hdDE2KSUwQSUwQSUyMyUyMGdyb3VwLW9mZmxvYWRpbmclMEFvbmxvYWRfZGV2aWNlJTIwJTNEJTIwdG9yY2guZGV2aWNlKCUyMmN1ZGElMjIpJTBBb2ZmbG9hZF9kZXZpY2UlMjAlM0QlMjB0b3JjaC5kZXZpY2UoJTIyY3B1JTIyKSUwQWFwcGx5X2dyb3VwX29mZmxvYWRpbmcodGV4dF9lbmNvZGVyJTJDJTBBJTIwJTIwJTIwJTIwb25sb2FkX2RldmljZSUzRG9ubG9hZF9kZXZpY2UlMkMlMEElMjAlMjAlMjAlMjBvZmZsb2FkX2RldmljZSUzRG9mZmxvYWRfZGV2aWNlJTJDJTBBJTIwJTIwJTIwJTIwb2ZmbG9hZF90eXBlJTNEJTIyYmxvY2tfbGV2ZWwlMjIlMkMlMEElMjAlMjAlMjAlMjBudW1fYmxvY2tzX3Blcl9ncm91cCUzRDQlMEEpJTBBdHJhbnNmb3JtZXIuZW5hYmxlX2dyb3VwX29mZmxvYWQoJTBBJTIwJTIwJTIwJTIwb25sb2FkX2RldmljZSUzRG9ubG9hZF9kZXZpY2UlMkMlMEElMjAlMjAlMjAlMjBvZmZsb2FkX2RldmljZSUzRG9mZmxvYWRfZGV2aWNlJTJDJTBBJTIwJTIwJTIwJTIwb2ZmbG9hZF90eXBlJTNEJTIybGVhZl9sZXZlbCUyMiUyQyUwQSUyMCUyMCUyMCUyMHVzZV9zdHJlYW0lM0RUcnVlJTBBKSUwQSUwQXBpcGVsaW5lJTIwJTNEJTIwV2FuUGlwZWxpbmUuZnJvbV9wcmV0cmFpbmVkKCUwQSUyMCUyMCUyMCUyMCUyMldhbi1BSSUyRldhbjIuMS1UMlYtMTRCLURpZmZ1c2VycyUyMiUyQyUwQSUyMCUyMCUyMCUyMHZhZSUzRHZhZSUyQyUwQSUyMCUyMCUyMCUyMHRyYW5zZm9ybWVyJTNEdHJhbnNmb3JtZXIlMkMlMEElMjAlMjAlMjAlMjB0ZXh0X2VuY29kZXIlM0R0ZXh0X2VuY29kZXIlMkMlMEElMjAlMjAlMjAlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmJmbG9hdDE2JTBBKSUwQXBpcGVsaW5lLnRvKCUyMmN1ZGElMjIpJTBBJTBBcHJvbXB0JTIwJTNEJTIwJTIyJTIyJTIyJTBBVGhlJTIwY2FtZXJhJTIwcnVzaGVzJTIwZnJvbSUyMGZhciUyMHRvJTIwbmVhciUyMGluJTIwYSUyMGxvdy1hbmdsZSUyMHNob3QlMkMlMjAlMEFyZXZlYWxpbmclMjBhJTIwd2hpdGUlMjBmZXJyZXQlMjBvbiUyMGElMjBsb2cuJTIwSXQlMjBwbGF5cyUyQyUyMGxlYXBzJTIwaW50byUyMHRoZSUyMHdhdGVyJTJDJTIwYW5kJTIwZW1lcmdlcyUyQyUyMGFzJTIwdGhlJTIwY2FtZXJhJTIwem9vbXMlMjBpbiUyMCUwQWZvciUyMGElMjBjbG9zZS11cC4lMjBXYXRlciUyMHNwbGFzaGVzJTIwYmVycnklMjBidXNoZXMlMjBuZWFyYnklMkMlMjB3aGlsZSUyMG1vc3MlMkMlMjBzbm93JTJDJTIwYW5kJTIwbGVhdmVzJTIwYmxhbmtldCUyMHRoZSUyMGdyb3VuZC4lMjAlMEFCaXJjaCUyMHRyZWVzJTIwYW5kJTIwYSUyMGxpZ2h0JTIwYmx1ZSUyMHNreSUyMGZyYW1lJTIwdGhlJTIwc2NlbmUlMkMlMjB3aXRoJTIwZmVybnMlMjBpbiUyMHRoZSUyMGZvcmVncm91bmQuJTIwU2lkZSUyMGxpZ2h0aW5nJTIwY2FzdHMlMjBkeW5hbWljJTIwJTBBc2hhZG93cyUyMGFuZCUyMHdhcm0lMjBoaWdobGlnaHRzLiUyME1lZGl1bSUyMGNvbXBvc2l0aW9uJTJDJTIwZnJvbnQlMjB2aWV3JTJDJTIwbG93JTIwYW5nbGUlMkMlMjB3aXRoJTIwZGVwdGglMjBvZiUyMGZpZWxkLiUwQSUyMiUyMiUyMiUwQW5lZ2F0aXZlX3Byb21wdCUyMCUzRCUyMCUyMiUyMiUyMiUwQUJyaWdodCUyMHRvbmVzJTJDJTIwb3ZlcmV4cG9zZWQlMkMlMjBzdGF0aWMlMkMlMjBibHVycmVkJTIwZGV0YWlscyUyQyUyMHN1YnRpdGxlcyUyQyUyMHN0eWxlJTJDJTIwd29ya3MlMkMlMjBwYWludGluZ3MlMkMlMjBpbWFnZXMlMkMlMjBzdGF0aWMlMkMlMjBvdmVyYWxsJTIwZ3JheSUyQyUyMHdvcnN0JTIwcXVhbGl0eSUyQyUyMCUwQWxvdyUyMHF1YWxpdHklMkMlMjBKUEVHJTIwY29tcHJlc3Npb24lMjByZXNpZHVlJTJDJTIwdWdseSUyQyUyMGluY29tcGxldGUlMkMlMjBleHRyYSUyMGZpbmdlcnMlMkMlMjBwb29ybHklMjBkcmF3biUyMGhhbmRzJTJDJTIwcG9vcmx5JTIwZHJhd24lMjBmYWNlcyUyQyUyMGRlZm9ybWVkJTJDJTIwZGlzZmlndXJlZCUyQyUyMCUwQW1pc3NoYXBlbiUyMGxpbWJzJTJDJTIwZnVzZWQlMjBmaW5nZXJzJTJDJTIwc3RpbGwlMjBwaWN0dXJlJTJDJTIwbWVzc3klMjBiYWNrZ3JvdW5kJTJDJTIwdGhyZWUlMjBsZWdzJTJDJTIwbWFueSUyMHBlb3BsZSUyMGluJTIwdGhlJTIwYmFja2dyb3VuZCUyQyUyMHdhbGtpbmclMjBiYWNrd2FyZHMlMEElMjIlMjIlMjIlMEElMEFvdXRwdXQlMjAlM0QlMjBwaXBlbGluZSglMEElMjAlMjAlMjAlMjBwcm9tcHQlM0Rwcm9tcHQlMkMlMEElMjAlMjAlMjAlMjBuZWdhdGl2ZV9wcm9tcHQlM0RuZWdhdGl2ZV9wcm9tcHQlMkMlMEElMjAlMjAlMjAlMjBudW1fZnJhbWVzJTNEODElMkMlMEElMjAlMjAlMjAlMjBndWlkYW5jZV9zY2FsZSUzRDUuMCUyQyUwQSkuZnJhbWVzJTVCMCU1RCUwQWV4cG9ydF90b192aWRlbyhvdXRwdXQlMkMlMjAlMjJvdXRwdXQubXA0JTIyJTJDJTIwZnBzJTNEMTYp",highlighted:`<span class="hljs-comment"># pip install ftfy</span>
<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">import</span> numpy <span class="hljs-keyword">as</span> np
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> AutoModel, WanPipeline
<span class="hljs-keyword">from</span> diffusers.hooks.group_offloading <span class="hljs-keyword">import</span> apply_group_offloading
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video, load_image
<span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> UMT5EncoderModel

text_encoder = UMT5EncoderModel.from_pretrained(<span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, subfolder=<span class="hljs-string">&quot;text_encoder&quot;</span>, torch_dtype=torch.bfloat16)
vae = AutoModel.from_pretrained(<span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, subfolder=<span class="hljs-string">&quot;vae&quot;</span>, torch_dtype=torch.float32)
transformer = AutoModel.from_pretrained(<span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, subfolder=<span class="hljs-string">&quot;transformer&quot;</span>, torch_dtype=torch.bfloat16)

<span class="hljs-comment"># group-offloading</span>
onload_device = torch.device(<span class="hljs-string">&quot;cuda&quot;</span>)
offload_device = torch.device(<span class="hljs-string">&quot;cpu&quot;</span>)
apply_group_offloading(text_encoder,
    onload_device=onload_device,
    offload_device=offload_device,
    offload_type=<span class="hljs-string">&quot;block_level&quot;</span>,
    num_blocks_per_group=<span class="hljs-number">4</span>
)
transformer.enable_group_offload(
    onload_device=onload_device,
    offload_device=offload_device,
    offload_type=<span class="hljs-string">&quot;leaf_level&quot;</span>,
    use_stream=<span class="hljs-literal">True</span>
)

pipeline = WanPipeline.from_pretrained(
    <span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>,
    vae=vae,
    transformer=transformer,
    text_encoder=text_encoder,
    torch_dtype=torch.bfloat16
)
pipeline.to(<span class="hljs-string">&quot;cuda&quot;</span>)

prompt = <span class="hljs-string">&quot;&quot;&quot;
The camera rushes from far to near in a low-angle shot, 
revealing a white ferret on a log. It plays, leaps into the water, and emerges, as the camera zooms in 
for a close-up. Water splashes berry bushes nearby, while moss, snow, and leaves blanket the ground. 
Birch trees and a light blue sky frame the scene, with ferns in the foreground. Side lighting casts dynamic 
shadows and warm highlights. Medium composition, front view, low angle, with depth of field.
&quot;&quot;&quot;</span>
negative_prompt = <span class="hljs-string">&quot;&quot;&quot;
Bright tones, overexposed, static, blurred details, subtitles, style, works, paintings, images, static, overall gray, worst quality, 
low quality, JPEG compression residue, ugly, incomplete, extra fingers, poorly drawn hands, poorly drawn faces, deformed, disfigured, 
misshapen limbs, fused fingers, still picture, messy background, three legs, many people in the background, walking backwards
&quot;&quot;&quot;</span>

output = pipeline(
    prompt=prompt,
    negative_prompt=negative_prompt,
    num_frames=<span class="hljs-number">81</span>,
    guidance_scale=<span class="hljs-number">5.0</span>,
).frames[<span class="hljs-number">0</span>]
export_to_video(output, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">16</span>)`,wrap:!1}}),{c(){y(a.$$.fragment)},l(t){m(a.$$.fragment,t)},m(t,b){r(a,t,b),p=!0},p:nl,i(t){p||(d(a.$$.fragment,t),p=!0)},o(t){c(a.$$.fragment,t),p=!1},d(t){J(a,t)}}}function re(Z){let a,p;return a=new B({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwZGlmZnVzZXJzJTIwaW1wb3J0QXV0b01vZGVsJTJDJTIwSHVueXVhblZpZGVvUGlwZWxpbmUlMEFmcm9tJTIwZGlmZnVzZXJzLnF1YW50aXplcnMlMjBpbXBvcnQlMjBQaXBlbGluZVF1YW50aXphdGlvbkNvbmZpZyUwQWZyb20lMjBkaWZmdXNlcnMudXRpbHMlMjBpbXBvcnQlMjBleHBvcnRfdG9fdmlkZW8lMEElMEElMjMlMjBxdWFudGl6ZSUyMHdlaWdodHMlMjB0byUyMGludDQlMjB3aXRoJTIwYml0c2FuZGJ5dGVzJTBBcGlwZWxpbmVfcXVhbnRfY29uZmlnJTIwJTNEJTIwUGlwZWxpbmVRdWFudGl6YXRpb25Db25maWcoJTBBJTIwJTIwcXVhbnRfYmFja2VuZCUzRCUyMmJpdHNhbmRieXRlc180Yml0JTIyJTJDJTBBJTIwJTIwcXVhbnRfa3dhcmdzJTNEJTdCJTBBJTIwJTIwJTIwJTIwJTIybG9hZF9pbl80Yml0JTIyJTNBJTIwVHJ1ZSUyQyUwQSUyMCUyMCUyMCUyMCUyMmJuYl80Yml0X3F1YW50X3R5cGUlMjIlM0ElMjAlMjJuZjQlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjJibmJfNGJpdF9jb21wdXRlX2R0eXBlJTIyJTNBJTIwdG9yY2guYmZsb2F0MTYlMEElMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjBjb21wb25lbnRzX3RvX3F1YW50aXplJTNEJTVCJTIydHJhbnNmb3JtZXIlMjIlNUQlMEEpJTBBJTBBcGlwZWxpbmUlMjAlM0QlMjBIdW55dWFuVmlkZW9QaXBlbGluZS5mcm9tX3ByZXRyYWluZWQoJTBBJTIwJTIwJTIwJTIwJTIyaHVueXVhbnZpZGVvLWNvbW11bml0eSUyRkh1bnl1YW5WaWRlbyUyMiUyQyUwQSUyMCUyMCUyMCUyMHF1YW50aXphdGlvbl9jb25maWclM0RwaXBlbGluZV9xdWFudF9jb25maWclMkMlMEElMjAlMjAlMjAlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmJmbG9hdDE2JTJDJTBBKSUwQSUwQSUyMyUyMG1vZGVsLW9mZmxvYWRpbmclMjBhbmQlMjB0aWxpbmclMEFwaXBlbGluZS5lbmFibGVfbW9kZWxfY3B1X29mZmxvYWQoKSUwQXBpcGVsaW5lLnZhZS5lbmFibGVfdGlsaW5nKCklMEElMEFwcm9tcHQlMjAlM0QlMjAlMjJBJTIwZmx1ZmZ5JTIwdGVkZHklMjBiZWFyJTIwc2l0cyUyMG9uJTIwYSUyMGJlZCUyMG9mJTIwc29mdCUyMHBpbGxvd3MlMjBzdXJyb3VuZGVkJTIwYnklMjBjaGlsZHJlbidzJTIwdG95cy4lMjIlMEF2aWRlbyUyMCUzRCUyMHBpcGVsaW5lKHByb21wdCUzRHByb21wdCUyQyUyMG51bV9mcmFtZXMlM0Q2MSUyQyUyMG51bV9pbmZlcmVuY2Vfc3RlcHMlM0QzMCkuZnJhbWVzJTVCMCU1RCUwQWV4cG9ydF90b192aWRlbyh2aWRlbyUyQyUyMCUyMm91dHB1dC5tcDQlMjIlMkMlMjBmcHMlM0QxNSk=",highlighted:`<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">from</span> diffusers importAutoModel, HunyuanVideoPipeline
<span class="hljs-keyword">from</span> diffusers.quantizers <span class="hljs-keyword">import</span> PipelineQuantizationConfig
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video

<span class="hljs-comment"># quantize weights to int4 with bitsandbytes</span>
pipeline_quant_config = PipelineQuantizationConfig(
  quant_backend=<span class="hljs-string">&quot;bitsandbytes_4bit&quot;</span>,
  quant_kwargs={
    <span class="hljs-string">&quot;load_in_4bit&quot;</span>: <span class="hljs-literal">True</span>,
    <span class="hljs-string">&quot;bnb_4bit_quant_type&quot;</span>: <span class="hljs-string">&quot;nf4&quot;</span>,
    <span class="hljs-string">&quot;bnb_4bit_compute_dtype&quot;</span>: torch.bfloat16
    },
  components_to_quantize=[<span class="hljs-string">&quot;transformer&quot;</span>]
)

pipeline = HunyuanVideoPipeline.from_pretrained(
    <span class="hljs-string">&quot;hunyuanvideo-community/HunyuanVideo&quot;</span>,
    quantization_config=pipeline_quant_config,
    torch_dtype=torch.bfloat16,
)

<span class="hljs-comment"># model-offloading and tiling</span>
pipeline.enable_model_cpu_offload()
pipeline.vae.enable_tiling()

prompt = <span class="hljs-string">&quot;A fluffy teddy bear sits on a bed of soft pillows surrounded by children&#x27;s toys.&quot;</span>
video = pipeline(prompt=prompt, num_frames=<span class="hljs-number">61</span>, num_inference_steps=<span class="hljs-number">30</span>).frames[<span class="hljs-number">0</span>]
export_to_video(video, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">15</span>)`,wrap:!1}}),{c(){y(a.$$.fragment)},l(t){m(a.$$.fragment,t)},m(t,b){r(a,t,b),p=!0},p:nl,i(t){p||(d(a.$$.fragment,t),p=!0)},o(t){c(a.$$.fragment,t),p=!1},d(t){J(a,t)}}}function de(Z){let a,p;return a=new B({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwZGlmZnVzZXJzJTIwaW1wb3J0JTIwTFRYUGlwZWxpbmUlMkMlMjBBdXRvTW9kZWwlMEFmcm9tJTIwZGlmZnVzZXJzLmhvb2tzJTIwaW1wb3J0JTIwYXBwbHlfZ3JvdXBfb2ZmbG9hZGluZyUwQWZyb20lMjBkaWZmdXNlcnMudXRpbHMlMjBpbXBvcnQlMjBleHBvcnRfdG9fdmlkZW8lMEElMEElMjMlMjBmcDglMjBsYXllcndpc2UlMjB3ZWlnaHQtY2FzdGluZyUwQXRyYW5zZm9ybWVyJTIwJTNEJTIwQXV0b01vZGVsLmZyb21fcHJldHJhaW5lZCglMEElMjAlMjAlMjAlMjAlMjJMaWdodHJpY2tzJTJGTFRYLVZpZGVvJTIyJTJDJTBBJTIwJTIwJTIwJTIwc3ViZm9sZGVyJTNEJTIydHJhbnNmb3JtZXIlMjIlMkMlMEElMjAlMjAlMjAlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmJmbG9hdDE2JTBBKSUwQXRyYW5zZm9ybWVyLmVuYWJsZV9sYXllcndpc2VfY2FzdGluZyglMEElMjAlMjAlMjAlMjBzdG9yYWdlX2R0eXBlJTNEdG9yY2guZmxvYXQ4X2U0bTNmbiUyQyUyMGNvbXB1dGVfZHR5cGUlM0R0b3JjaC5iZmxvYXQxNiUwQSklMEElMEFwaXBlbGluZSUyMCUzRCUyMExUWFBpcGVsaW5lLmZyb21fcHJldHJhaW5lZCglMjJMaWdodHJpY2tzJTJGTFRYLVZpZGVvJTIyJTJDJTIwdHJhbnNmb3JtZXIlM0R0cmFuc2Zvcm1lciUyQyUyMHRvcmNoX2R0eXBlJTNEdG9yY2guYmZsb2F0MTYpJTBBJTBBJTIzJTIwZ3JvdXAtb2ZmbG9hZGluZyUwQW9ubG9hZF9kZXZpY2UlMjAlM0QlMjB0b3JjaC5kZXZpY2UoJTIyY3VkYSUyMiklMEFvZmZsb2FkX2RldmljZSUyMCUzRCUyMHRvcmNoLmRldmljZSglMjJjcHUlMjIpJTBBcGlwZWxpbmUudHJhbnNmb3JtZXIuZW5hYmxlX2dyb3VwX29mZmxvYWQob25sb2FkX2RldmljZSUzRG9ubG9hZF9kZXZpY2UlMkMlMjBvZmZsb2FkX2RldmljZSUzRG9mZmxvYWRfZGV2aWNlJTJDJTIwb2ZmbG9hZF90eXBlJTNEJTIybGVhZl9sZXZlbCUyMiUyQyUyMHVzZV9zdHJlYW0lM0RUcnVlKSUwQWFwcGx5X2dyb3VwX29mZmxvYWRpbmcocGlwZWxpbmUudGV4dF9lbmNvZGVyJTJDJTIwb25sb2FkX2RldmljZSUzRG9ubG9hZF9kZXZpY2UlMkMlMjBvZmZsb2FkX3R5cGUlM0QlMjJibG9ja19sZXZlbCUyMiUyQyUyMG51bV9ibG9ja3NfcGVyX2dyb3VwJTNEMiklMEFhcHBseV9ncm91cF9vZmZsb2FkaW5nKHBpcGVsaW5lLnZhZSUyQyUyMG9ubG9hZF9kZXZpY2UlM0RvbmxvYWRfZGV2aWNlJTJDJTIwb2ZmbG9hZF90eXBlJTNEJTIybGVhZl9sZXZlbCUyMiklMEElMEFwcm9tcHQlMjAlM0QlMjAlMjIlMjIlMjIlMEFBJTIwd29tYW4lMjB3aXRoJTIwbG9uZyUyMGJyb3duJTIwaGFpciUyMGFuZCUyMGxpZ2h0JTIwc2tpbiUyMHNtaWxlcyUyMGF0JTIwYW5vdGhlciUyMHdvbWFuJTIwd2l0aCUyMGxvbmclMjBibG9uZGUlMjBoYWlyLiUyMFRoZSUyMHdvbWFuJTIwd2l0aCUyMGJyb3duJTIwaGFpciUyMHdlYXJzJTIwYSUyMGJsYWNrJTIwamFja2V0JTIwYW5kJTIwaGFzJTIwYSUyMHNtYWxsJTJDJTIwYmFyZWx5JTIwbm90aWNlYWJsZSUyMG1vbGUlMjBvbiUyMGhlciUyMHJpZ2h0JTIwY2hlZWsuJTIwVGhlJTIwY2FtZXJhJTIwYW5nbGUlMjBpcyUyMGElMjBjbG9zZS11cCUyQyUyMGZvY3VzZWQlMjBvbiUyMHRoZSUyMHdvbWFuJTIwd2l0aCUyMGJyb3duJTIwaGFpcidzJTIwZmFjZS4lMjBUaGUlMjBsaWdodGluZyUyMGlzJTIwd2FybSUyMGFuZCUyMG5hdHVyYWwlMkMlMjBsaWtlbHklMjBmcm9tJTIwdGhlJTIwc2V0dGluZyUyMHN1biUyQyUyMGNhc3RpbmclMjBhJTIwc29mdCUyMGdsb3clMjBvbiUyMHRoZSUyMHNjZW5lLiUyMFRoZSUyMHNjZW5lJTIwYXBwZWFycyUyMHRvJTIwYmUlMjByZWFsLWxpZmUlMjBmb290YWdlJTBBJTIyJTIyJTIyJTBBbmVnYXRpdmVfcHJvbXB0JTIwJTNEJTIwJTIyd29yc3QlMjBxdWFsaXR5JTJDJTIwaW5jb25zaXN0ZW50JTIwbW90aW9uJTJDJTIwYmx1cnJ5JTJDJTIwaml0dGVyeSUyQyUyMGRpc3RvcnRlZCUyMiUwQSUwQXZpZGVvJTIwJTNEJTIwcGlwZWxpbmUoJTBBJTIwJTIwJTIwJTIwcHJvbXB0JTNEcHJvbXB0JTJDJTBBJTIwJTIwJTIwJTIwbmVnYXRpdmVfcHJvbXB0JTNEbmVnYXRpdmVfcHJvbXB0JTJDJTBBJTIwJTIwJTIwJTIwd2lkdGglM0Q3NjglMkMlMEElMjAlMjAlMjAlMjBoZWlnaHQlM0Q1MTIlMkMlMEElMjAlMjAlMjAlMjBudW1fZnJhbWVzJTNEMTYxJTJDJTBBJTIwJTIwJTIwJTIwZGVjb2RlX3RpbWVzdGVwJTNEMC4wMyUyQyUwQSUyMCUyMCUyMCUyMGRlY29kZV9ub2lzZV9zY2FsZSUzRDAuMDI1JTJDJTBBJTIwJTIwJTIwJTIwbnVtX2luZmVyZW5jZV9zdGVwcyUzRDUwJTJDJTBBKS5mcmFtZXMlNUIwJTVEJTBBZXhwb3J0X3RvX3ZpZGVvKHZpZGVvJTJDJTIwJTIyb3V0cHV0Lm1wNCUyMiUyQyUyMGZwcyUzRDI0KQ==",highlighted:`<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> LTXPipeline, AutoModel
<span class="hljs-keyword">from</span> diffusers.hooks <span class="hljs-keyword">import</span> apply_group_offloading
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video

<span class="hljs-comment"># fp8 layerwise weight-casting</span>
transformer = AutoModel.from_pretrained(
    <span class="hljs-string">&quot;Lightricks/LTX-Video&quot;</span>,
    subfolder=<span class="hljs-string">&quot;transformer&quot;</span>,
    torch_dtype=torch.bfloat16
)
transformer.enable_layerwise_casting(
    storage_dtype=torch.float8_e4m3fn, compute_dtype=torch.bfloat16
)

pipeline = LTXPipeline.from_pretrained(<span class="hljs-string">&quot;Lightricks/LTX-Video&quot;</span>, transformer=transformer, torch_dtype=torch.bfloat16)

<span class="hljs-comment"># group-offloading</span>
onload_device = torch.device(<span class="hljs-string">&quot;cuda&quot;</span>)
offload_device = torch.device(<span class="hljs-string">&quot;cpu&quot;</span>)
pipeline.transformer.enable_group_offload(onload_device=onload_device, offload_device=offload_device, offload_type=<span class="hljs-string">&quot;leaf_level&quot;</span>, use_stream=<span class="hljs-literal">True</span>)
apply_group_offloading(pipeline.text_encoder, onload_device=onload_device, offload_type=<span class="hljs-string">&quot;block_level&quot;</span>, num_blocks_per_group=<span class="hljs-number">2</span>)
apply_group_offloading(pipeline.vae, onload_device=onload_device, offload_type=<span class="hljs-string">&quot;leaf_level&quot;</span>)

prompt = <span class="hljs-string">&quot;&quot;&quot;
A woman with long brown hair and light skin smiles at another woman with long blonde hair. The woman with brown hair wears a black jacket and has a small, barely noticeable mole on her right cheek. The camera angle is a close-up, focused on the woman with brown hair&#x27;s face. The lighting is warm and natural, likely from the setting sun, casting a soft glow on the scene. The scene appears to be real-life footage
&quot;&quot;&quot;</span>
negative_prompt = <span class="hljs-string">&quot;worst quality, inconsistent motion, blurry, jittery, distorted&quot;</span>

video = pipeline(
    prompt=prompt,
    negative_prompt=negative_prompt,
    width=<span class="hljs-number">768</span>,
    height=<span class="hljs-number">512</span>,
    num_frames=<span class="hljs-number">161</span>,
    decode_timestep=<span class="hljs-number">0.03</span>,
    decode_noise_scale=<span class="hljs-number">0.025</span>,
    num_inference_steps=<span class="hljs-number">50</span>,
).frames[<span class="hljs-number">0</span>]
export_to_video(video, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">24</span>)`,wrap:!1}}),{c(){y(a.$$.fragment)},l(t){m(a.$$.fragment,t)},m(t,b){r(a,t,b),p=!0},p:nl,i(t){p||(d(a.$$.fragment,t),p=!0)},o(t){c(a.$$.fragment,t),p=!1},d(t){J(a,t)}}}function ce(Z){let a,p,t,b,T,f;return a=new Hl({props:{id:"popular models",option:"Wan2.1",$$slots:{default:[me]},$$scope:{ctx:Z}}}),t=new Hl({props:{id:"popular models",option:"HunyuanVideo",$$slots:{default:[re]},$$scope:{ctx:Z}}}),T=new Hl({props:{id:"popular models",option:"LTX-Video",$$slots:{default:[de]},$$scope:{ctx:Z}}}),{c(){y(a.$$.fragment),p=M(),y(t.$$.fragment),b=M(),y(T.$$.fragment)},l(o){m(a.$$.fragment,o),p=i(o),m(t.$$.fragment,o),b=i(o),m(T.$$.fragment,o)},m(o,U){r(a,o,U),n(o,p,U),r(t,o,U),n(o,b,U),r(T,o,U),f=!0},p(o,U){const X={};U&2&&(X.$$scope={dirty:U,ctx:o}),a.$set(X);const j={};U&2&&(j.$$scope={dirty:U,ctx:o}),t.$set(j);const al={};U&2&&(al.$$scope={dirty:U,ctx:o}),T.$set(al)},i(o){f||(d(a.$$.fragment,o),d(t.$$.fragment,o),d(T.$$.fragment,o),f=!0)},o(o){c(a.$$.fragment,o),c(t.$$.fragment,o),c(T.$$.fragment,o),f=!1},d(o){o&&(s(p),s(b)),J(a,o),J(t,o),J(T,o)}}}function Je(Z){let a,p="If you’re interested in learning more about how to use a specific model, please refer to their pipeline API model card.";return{c(){a=u("p"),a.textContent=p},l(t){a=w(t,"P",{"data-svelte-h":!0}),h(a)!=="svelte-qd6kc4"&&(a.textContent=p)},m(t,b){n(t,a,b)},p:nl,d(t){t&&s(a)}}}function ue(Z){let a,p='Refer to the <a href="../optimization/memory">Reduce memory usage</a> guide for more details about other memory saving techniques.';return{c(){a=u("p"),a.innerHTML=p},l(t){a=w(t,"P",{"data-svelte-h":!0}),h(a)!=="svelte-1ih8c3a"&&(a.innerHTML=p)},m(t,b){n(t,a,b)},p:nl,d(t){t&&s(a)}}}function we(Z){let a,p,t,b,T,f,o,U="Video generation models extend image generation (can be considered a 1-frame video) to also process data related to space and time. Making sure all this data - text, space, time - remain consistent and aligned from frame-to-frame is a big challenge in generating long and high-resolution videos.",X,j,al="Modern video models tackle this challenge with the diffusion transformer (DiT) architecture. This reduces computational costs and allows more efficient scaling to larger and higher-quality image and video data.",ol,V,El="Check out what some of these video models are capable of below.",Ml,G,il,v,Cl="This guide will cover video generation basics such as which parameters to configure and how to reduce their memory usage.",pl,I,yl,g,ml,k,_l="There are several parameters to configure in the pipeline that’ll affect video generation quality or speed. Experimenting with different parameter values is important for discovering the appropriate quality and speed tradeoff.",rl,R,dl,Y,Fl="A frame is a still image that is played in a sequence of other frames to create motion or a video. Control the number of frames generated per second with <code>num_frames</code>. Increasing <code>num_frames</code> increases perceived motion smoothness and visual coherence, making it especially important for videos with dynamic content. A higher <code>num_frames</code> value also increases video duration.",cl,Q,zl='Some video models require more specific <code>num_frames</code> values for inference. For example, <a href="/docs/diffusers/main/en/api/pipelines/hunyuan_video#diffusers.HunyuanVideoPipeline">HunyuanVideoPipeline</a> recommends calculating the <code>num_frames</code> with <code>(4 * num_frames) +1</code>. Always check a pipelines API model card to see if there is a recommended value.',Jl,H,ul,E,wl,C,Nl="Guidance scale or “cfg” controls how closely the generated frames adhere to the input conditioning (text, image or both). Increasing <code>guidance_scale</code> generates frames that resemble the input conditions more closely and includes finer details, but risk introducing artifacts and reducing output diversity. Lower <code>guidance_scale</code> values encourages looser prompt adherence and increased output variety, but details may not be as great. If it’s too low, it may ignore your prompt entirely and generate random noise.",bl,_,hl,F,Tl,z,Sl="A negative prompt is useful for excluding things you don’t want to see in the generated video. It is commonly used to refine the quality and alignment of the generated video by pushing the model away from undesirable elements like “blurry, distorted, ugly”. This can create cleaner and more focused videos.",Ul,N,Zl,S,jl,x,xl='Recent video models like <a href="/docs/diffusers/main/en/api/pipelines/hunyuan_video#diffusers.HunyuanVideoPipeline">HunyuanVideoPipeline</a> and <a href="/docs/diffusers/main/en/api/pipelines/wan#diffusers.WanPipeline">WanPipeline</a>, which have 10B+ parameters, require a lot of memory and it often exceeds the memory availabe on consumer hardware. Diffusers offers several techniques for reducing the memory requirements of these large models.',fl,W,Bl,q,ql='One of these techniques is <a href="../optimization/memory#group-offloading">group-offloading</a>, which offloads groups of internal model layers (such as <code>torch.nn.Sequential</code>) to the CPU when it isn’t being used. These layers are only loaded when they’re needed for computation to avoid storing <strong>all</strong> the model components on the GPU. For a 14B parameter model like <a href="/docs/diffusers/main/en/api/pipelines/wan#diffusers.WanPipeline">WanPipeline</a>, group-offloading can lower the required memory to ~13GB of VRAM.',Gl,$,Il,A,$l='Another option for reducing memory is to consider quantizing a model, which stores the model weights in a lower precision data type. However, quantization may impact video quality depending on the specific video model. Refer to the quantization <a href="../quantization/overview">Overivew</a> to learn more about the different supported quantization backends.',Wl,D,Al='The example below uses <a href="../quantization/bitsandbytes">bitsandbytes</a> to quantize a model.',Xl,L,Vl,P,vl,K,Dl='<a href="https://pytorch.org/tutorials/intermediate/torch_compile_tutorial_.html" rel="nofollow">torch.compile</a> can speedup inference by using optimized kernels. Compilation takes longer the first time, but once compiled, it is much faster. It is best to compile the pipeline once, and then use the pipeline multiple times without changing anything. A change, such as in the image size, triggers recompilation.',gl,O,Ll="The example below compiles the transformer in the pipeline and uses the <code>&quot;max-autotune&quot;</code> mode to maximize performance.",kl,ll,Rl,el,Yl,tl,Ql;return T=new sl({props:{title:"Video generation",local:"video-generation",headingTag:"h1"}}),G=new ye({props:{id:"popular models",options:["Wan2.1","HunyuanVideo","LTX-Video"],$$slots:{default:[ce]},$$scope:{ctx:Z}}}),I=new se({props:{warning:!1,$$slots:{default:[Je]},$$scope:{ctx:Z}}}),g=new sl({props:{title:"Pipeline parameters",local:"pipeline-parameters",headingTag:"h2"}}),R=new sl({props:{title:"num_frames",local:"numframes",headingTag:"h3"}}),H=new B({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwZGlmZnVzZXJzJTIwaW1wb3J0JTIwTFRYUGlwZWxpbmUlMEFmcm9tJTIwZGlmZnVzZXJzLnV0aWxzJTIwaW1wb3J0JTIwZXhwb3J0X3RvX3ZpZGVvJTBBJTBBcGlwZWxpbmUlMjAlM0QlMjBMVFhQaXBlbGluZS5mcm9tX3ByZXRyYWluZWQoJTBBJTIwJTIwJTIwJTIwJTIyTGlnaHRyaWNrcyUyRkxUWC1WaWRlbyUyMiUyQyUyMHRvcmNoX2R0eXBlJTNEdG9yY2guYmZsb2F0MTYlMEEpLnRvKCUyMmN1ZGElMjIpJTBBJTBBcHJvbXB0JTIwJTNEJTIwJTIyJTIyJTIyJTBBQSUyMHdvbWFuJTIwd2l0aCUyMGxvbmclMjBicm93biUyMGhhaXIlMjBhbmQlMjBsaWdodCUyMHNraW4lMjBzbWlsZXMlMjBhdCUyMGFub3RoZXIlMjB3b21hbiUyMHdpdGglMjBsb25nJTIwYmxvbmRlJTIwaGFpci4lMjBUaGUlMjB3b21hbiUyMCUwQXdpdGglMjBicm93biUyMGhhaXIlMjB3ZWFycyUyMGElMjBibGFjayUyMGphY2tldCUyMGFuZCUyMGhhcyUyMGElMjBzbWFsbCUyQyUyMGJhcmVseSUyMG5vdGljZWFibGUlMjBtb2xlJTIwb24lMjBoZXIlMjByaWdodCUyMGNoZWVrLiUyMFRoZSUyMCUwQWNhbWVyYSUyMGFuZ2xlJTIwaXMlMjBhJTIwY2xvc2UtdXAlMkMlMjBmb2N1c2VkJTIwb24lMjB0aGUlMjB3b21hbiUyMHdpdGglMjBicm93biUyMGhhaXIncyUyMGZhY2UuJTIwVGhlJTIwbGlnaHRpbmclMjBpcyUyMHdhcm0lMjBhbmQlMjAlMEFuYXR1cmFsJTJDJTIwbGlrZWx5JTIwZnJvbSUyMHRoZSUyMHNldHRpbmclMjBzdW4lMkMlMjBjYXN0aW5nJTIwYSUyMHNvZnQlMjBnbG93JTIwb24lMjB0aGUlMjBzY2VuZS4lMjBUaGUlMjBzY2VuZSUyMGFwcGVhcnMlMjB0byUyMGJlJTIwJTBBcmVhbC1saWZlJTIwZm9vdGFnZSUwQSUyMiUyMiUyMiUwQSUwQXZpZGVvJTIwJTNEJTIwcGlwZWxpbmUoJTBBJTIwJTIwJTIwJTIwcHJvbXB0JTNEcHJvbXB0JTJDJTBBJTIwJTIwJTIwJTIwbmVnYXRpdmVfcHJvbXB0JTNEbmVnYXRpdmVfcHJvbXB0JTJDJTBBJTIwJTIwJTIwJTIwd2lkdGglM0Q3NjglMkMlMEElMjAlMjAlMjAlMjBoZWlnaHQlM0Q1MTIlMkMlMEElMjAlMjAlMjAlMjBudW1fZnJhbWVzJTNEMTYxJTJDJTBBJTIwJTIwJTIwJTIwZGVjb2RlX3RpbWVzdGVwJTNEMC4wMyUyQyUwQSUyMCUyMCUyMCUyMGRlY29kZV9ub2lzZV9zY2FsZSUzRDAuMDI1JTJDJTBBJTIwJTIwJTIwJTIwbnVtX2luZmVyZW5jZV9zdGVwcyUzRDUwJTJDJTBBKS5mcmFtZXMlNUIwJTVEJTBBZXhwb3J0X3RvX3ZpZGVvKHZpZGVvJTJDJTIwJTIyb3V0cHV0Lm1wNCUyMiUyQyUyMGZwcyUzRDI0KQ==",highlighted:`<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> LTXPipeline
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video

pipeline = LTXPipeline.from_pretrained(
    <span class="hljs-string">&quot;Lightricks/LTX-Video&quot;</span>, torch_dtype=torch.bfloat16
).to(<span class="hljs-string">&quot;cuda&quot;</span>)

prompt = <span class="hljs-string">&quot;&quot;&quot;
A woman with long brown hair and light skin smiles at another woman with long blonde hair. The woman 
with brown hair wears a black jacket and has a small, barely noticeable mole on her right cheek. The 
camera angle is a close-up, focused on the woman with brown hair&#x27;s face. The lighting is warm and 
natural, likely from the setting sun, casting a soft glow on the scene. The scene appears to be 
real-life footage
&quot;&quot;&quot;</span>

video = pipeline(
    prompt=prompt,
    negative_prompt=negative_prompt,
    width=<span class="hljs-number">768</span>,
    height=<span class="hljs-number">512</span>,
    num_frames=<span class="hljs-number">161</span>,
    decode_timestep=<span class="hljs-number">0.03</span>,
    decode_noise_scale=<span class="hljs-number">0.025</span>,
    num_inference_steps=<span class="hljs-number">50</span>,
).frames[<span class="hljs-number">0</span>]
export_to_video(video, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">24</span>)`,wrap:!1}}),E=new sl({props:{title:"guidance_scale",local:"guidancescale",headingTag:"h3"}}),_=new B({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwZGlmZnVzZXJzJTIwaW1wb3J0JTIwQ29nVmlkZW9YUGlwZWxpbmUlMkMlMjBDb2dWaWRlb1hUcmFuc2Zvcm1lcjNETW9kZWwlMEFmcm9tJTIwZGlmZnVzZXJzLnV0aWxzJTIwaW1wb3J0JTIwZXhwb3J0X3RvX3ZpZGVvJTBBJTBBcGlwZWxpbmUlMjAlM0QlMjBDb2dWaWRlb1hQaXBlbGluZS5mcm9tX3ByZXRyYWluZWQoJTBBJTIwJTIwJTIyVEhVRE0lMkZDb2dWaWRlb1gtMmIlMjIlMkMlMEElMjAlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmZsb2F0MTYlMEEpLnRvKCUyMmN1ZGElMjIpJTBBJTBBcHJvbXB0JTIwJTNEJTIwJTIyJTIyJTIyJTBBQSUyMGRldGFpbGVkJTIwd29vZGVuJTIwdG95JTIwc2hpcCUyMHdpdGglMjBpbnRyaWNhdGVseSUyMGNhcnZlZCUyMG1hc3RzJTIwYW5kJTIwc2FpbHMlMjBpcyUyMHNlZW4lMjBnbGlkaW5nJTIwc21vb3RobHklMjBvdmVyJTBBYSUyMHBsdXNoJTJDJTIwYmx1ZSUyMGNhcnBldCUyMHRoYXQlMjBtaW1pY3MlMjB0aGUlMjB3YXZlcyUyMG9mJTIwdGhlJTIwc2VhLiUyMFRoZSUyMHNoaXAncyUyMGh1bGwlMjBpcyUyMHBhaW50ZWQlMjBhJTIwcmljaCUyMGJyb3duJTJDJTIwJTBBd2l0aCUyMHRpbnklMjB3aW5kb3dzLiUyMFRoZSUyMGNhcnBldCUyQyUyMHNvZnQlMjBhbmQlMjB0ZXh0dXJlZCUyQyUyMHByb3ZpZGVzJTIwYSUyMHBlcmZlY3QlMjBiYWNrZHJvcCUyQyUyMHJlc2VtYmxpbmclMjBhbiUyMCUwQW9jZWFuaWMlMjBleHBhbnNlLiUyMFN1cnJvdW5kaW5nJTIwdGhlJTIwc2hpcCUyMGFyZSUyMHZhcmlvdXMlMjBvdGhlciUyMHRveXMlMjBhbmQlMjBjaGlsZHJlbidzJTIwaXRlbXMlMkMlMjBoaW50aW5nJTIwYXQlMjAlMEFhJTIwcGxheWZ1bCUyMGVudmlyb25tZW50LiUyMFRoZSUyMHNjZW5lJTIwY2FwdHVyZXMlMjB0aGUlMjBpbm5vY2VuY2UlMjBhbmQlMjBpbWFnaW5hdGlvbiUyMG9mJTIwY2hpbGRob29kJTJDJTIwJTBBd2l0aCUyMHRoZSUyMHRveSUyMHNoaXAncyUyMGpvdXJuZXklMjBzeW1ib2xpemluZyUyMGVuZGxlc3MlMjBhZHZlbnR1cmVzJTIwaW4lMjBhJTIwd2hpbXNpY2FsJTJDJTIwaW5kb29yJTIwc2V0dGluZy4lMEElMjIlMjIlMjIlMEElMEF2aWRlbyUyMCUzRCUyMHBpcGVsaW5lKCUwQSUyMCUyMHByb21wdCUzRHByb21wdCUyQyUwQSUyMCUyMGd1aWRhbmNlX3NjYWxlJTNENiUyQyUwQSUyMCUyMG51bV9pbmZlcmVuY2Vfc3RlcHMlM0Q1MCUwQSkuZnJhbWVzJTVCMCU1RCUwQWV4cG9ydF90b192aWRlbyh2aWRlbyUyQyUyMCUyMm91dHB1dC5tcDQlMjIlMkMlMjBmcHMlM0Q4KQ==",highlighted:`<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> CogVideoXPipeline, CogVideoXTransformer3DModel
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video

pipeline = CogVideoXPipeline.from_pretrained(
  <span class="hljs-string">&quot;THUDM/CogVideoX-2b&quot;</span>,
  torch_dtype=torch.float16
).to(<span class="hljs-string">&quot;cuda&quot;</span>)

prompt = <span class="hljs-string">&quot;&quot;&quot;
A detailed wooden toy ship with intricately carved masts and sails is seen gliding smoothly over
a plush, blue carpet that mimics the waves of the sea. The ship&#x27;s hull is painted a rich brown, 
with tiny windows. The carpet, soft and textured, provides a perfect backdrop, resembling an 
oceanic expanse. Surrounding the ship are various other toys and children&#x27;s items, hinting at 
a playful environment. The scene captures the innocence and imagination of childhood, 
with the toy ship&#x27;s journey symbolizing endless adventures in a whimsical, indoor setting.
&quot;&quot;&quot;</span>

video = pipeline(
  prompt=prompt,
  guidance_scale=<span class="hljs-number">6</span>,
  num_inference_steps=<span class="hljs-number">50</span>
).frames[<span class="hljs-number">0</span>]
export_to_video(video, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">8</span>)`,wrap:!1}}),F=new sl({props:{title:"negative_prompt",local:"negativeprompt",headingTag:"h3"}}),N=new B({props:{code:"JTIzJTIwcGlwJTIwaW5zdGFsbCUyMGZ0ZnklMEFpbXBvcnQlMjB0b3JjaCUwQWZyb20lMjBkaWZmdXNlcnMlMjBpbXBvcnQlMjBXYW5QaXBlbGluZSUwQWZyb20lMjBkaWZmdXNlcnMuc2NoZWR1bGVycy5zY2hlZHVsaW5nX3VuaXBjX211bHRpc3RlcCUyMGltcG9ydCUyMFVuaVBDTXVsdGlzdGVwU2NoZWR1bGVyJTBBZnJvbSUyMGRpZmZ1c2Vycy51dGlscyUyMGltcG9ydCUyMGV4cG9ydF90b192aWRlbyUwQSUwQXZhZSUyMCUzRCUyMEF1dG9lbmNvZGVyS0xXYW4uZnJvbV9wcmV0cmFpbmVkKCUwQSUyMCUyMCUyMldhbi1BSSUyRldhbjIuMS1UMlYtMTRCLURpZmZ1c2VycyUyMiUyQyUyMHN1YmZvbGRlciUzRCUyMnZhZSUyMiUyQyUyMHRvcmNoX2R0eXBlJTNEdG9yY2guZmxvYXQzMiUwQSklMEFwaXBlbGluZSUyMCUzRCUyMFdhblBpcGVsaW5lLmZyb21fcHJldHJhaW5lZCglMEElMjAlMjAlMjJXYW4tQUklMkZXYW4yLjEtVDJWLTE0Qi1EaWZmdXNlcnMlMjIlMkMlMjB2YWUlM0R2YWUlMkMlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmJmbG9hdDE2JTBBKSUwQXBpcGVsaW5lLnNjaGVkdWxlciUyMCUzRCUyMFVuaVBDTXVsdGlzdGVwU2NoZWR1bGVyLmZyb21fY29uZmlnKCUwQSUyMCUyMHBpcGVsaW5lLnNjaGVkdWxlci5jb25maWclMkMlMjBmbG93X3NoaWZ0JTNENS4wJTBBKSUwQXBpcGVsaW5lLnRvKCUyMmN1ZGElMjIpJTBBJTBBcGlwZWxpbmUubG9hZF9sb3JhX3dlaWdodHMoJTIyYmVuamFtaW4tcGFpbmUlMkZzdGVhbWJvYXQtd2lsbGllLTE0YiUyMiUyQyUyMGFkYXB0ZXJfbmFtZSUzRCUyMnN0ZWFtYm9hdC13aWxsaWUlMjIpJTBBcGlwZWxpbmUuc2V0X2FkYXB0ZXJzKCUyMnN0ZWFtYm9hdC13aWxsaWUlMjIpJTBBJTBBcGlwZWxpbmUuZW5hYmxlX21vZGVsX2NwdV9vZmZsb2FkKCklMEElMEElMjMlMjB1c2UlMjAlMjJzdGVhbWJvYXQlMjB3aWxsaWUlMjBzdHlsZSUyMiUyMHRvJTIwdHJpZ2dlciUyMHRoZSUyMExvUkElMEFwcm9tcHQlMjAlM0QlMjAlMjIlMjIlMjIlMEFzdGVhbWJvYXQlMjB3aWxsaWUlMjBzdHlsZSUyQyUyMGdvbGRlbiUyMGVyYSUyMGFuaW1hdGlvbiUyQyUyMFRoZSUyMGNhbWVyYSUyMHJ1c2hlcyUyMGZyb20lMjBmYXIlMjB0byUyMG5lYXIlMjBpbiUyMGElMjBsb3ctYW5nbGUlMjBzaG90JTJDJTIwJTBBcmV2ZWFsaW5nJTIwYSUyMHdoaXRlJTIwZmVycmV0JTIwb24lMjBhJTIwbG9nLiUyMEl0JTIwcGxheXMlMkMlMjBsZWFwcyUyMGludG8lMjB0aGUlMjB3YXRlciUyQyUyMGFuZCUyMGVtZXJnZXMlMkMlMjBhcyUyMHRoZSUyMGNhbWVyYSUyMHpvb21zJTIwaW4lMjAlMEFmb3IlMjBhJTIwY2xvc2UtdXAuJTIwV2F0ZXIlMjBzcGxhc2hlcyUyMGJlcnJ5JTIwYnVzaGVzJTIwbmVhcmJ5JTJDJTIwd2hpbGUlMjBtb3NzJTJDJTIwc25vdyUyQyUyMGFuZCUyMGxlYXZlcyUyMGJsYW5rZXQlMjB0aGUlMjBncm91bmQuJTIwJTBBQmlyY2glMjB0cmVlcyUyMGFuZCUyMGElMjBsaWdodCUyMGJsdWUlMjBza3klMjBmcmFtZSUyMHRoZSUyMHNjZW5lJTJDJTIwd2l0aCUyMGZlcm5zJTIwaW4lMjB0aGUlMjBmb3JlZ3JvdW5kLiUyMFNpZGUlMjBsaWdodGluZyUyMGNhc3RzJTIwJTBBZHluYW1pYyUyMHNoYWRvd3MlMjBhbmQlMjB3YXJtJTIwaGlnaGxpZ2h0cy4lMjBNZWRpdW0lMjBjb21wb3NpdGlvbiUyQyUyMGZyb250JTIwdmlldyUyQyUyMGxvdyUyMGFuZ2xlJTJDJTIwd2l0aCUyMGRlcHRoJTIwb2YlMjBmaWVsZC4lMEElMjIlMjIlMjIlMEElMEFvdXRwdXQlMjAlM0QlMjBwaXBlbGluZSglMEElMjAlMjBwcm9tcHQlM0Rwcm9tcHQlMkMlMEElMjAlMjBudW1fZnJhbWVzJTNEODElMkMlMEElMjAlMjBndWlkYW5jZV9zY2FsZSUzRDUuMCUyQyUwQSkuZnJhbWVzJTVCMCU1RCUwQWV4cG9ydF90b192aWRlbyhvdXRwdXQlMkMlMjAlMjJvdXRwdXQubXA0JTIyJTJDJTIwZnBzJTNEMTYp",highlighted:`<span class="hljs-comment"># pip install ftfy</span>
<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> WanPipeline
<span class="hljs-keyword">from</span> diffusers.schedulers.scheduling_unipc_multistep <span class="hljs-keyword">import</span> UniPCMultistepScheduler
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video

vae = AutoencoderKLWan.from_pretrained(
  <span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, subfolder=<span class="hljs-string">&quot;vae&quot;</span>, torch_dtype=torch.float32
)
pipeline = WanPipeline.from_pretrained(
  <span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, vae=vae, torch_dtype=torch.bfloat16
)
pipeline.scheduler = UniPCMultistepScheduler.from_config(
  pipeline.scheduler.config, flow_shift=<span class="hljs-number">5.0</span>
)
pipeline.to(<span class="hljs-string">&quot;cuda&quot;</span>)

pipeline.load_lora_weights(<span class="hljs-string">&quot;benjamin-paine/steamboat-willie-14b&quot;</span>, adapter_name=<span class="hljs-string">&quot;steamboat-willie&quot;</span>)
pipeline.set_adapters(<span class="hljs-string">&quot;steamboat-willie&quot;</span>)

pipeline.enable_model_cpu_offload()

<span class="hljs-comment"># use &quot;steamboat willie style&quot; to trigger the LoRA</span>
prompt = <span class="hljs-string">&quot;&quot;&quot;
steamboat willie style, golden era animation, The camera rushes from far to near in a low-angle shot, 
revealing a white ferret on a log. It plays, leaps into the water, and emerges, as the camera zooms in 
for a close-up. Water splashes berry bushes nearby, while moss, snow, and leaves blanket the ground. 
Birch trees and a light blue sky frame the scene, with ferns in the foreground. Side lighting casts 
dynamic shadows and warm highlights. Medium composition, front view, low angle, with depth of field.
&quot;&quot;&quot;</span>

output = pipeline(
  prompt=prompt,
  num_frames=<span class="hljs-number">81</span>,
  guidance_scale=<span class="hljs-number">5.0</span>,
).frames[<span class="hljs-number">0</span>]
export_to_video(output, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">16</span>)`,wrap:!1}}),S=new sl({props:{title:"Reduce memory usage",local:"reduce-memory-usage",headingTag:"h2"}}),W=new se({props:{warning:!1,$$slots:{default:[ue]},$$scope:{ctx:Z}}}),$=new B({props:{code:"JTIzJTIwcGlwJTIwaW5zdGFsbCUyMGZ0ZnklMEFpbXBvcnQlMjB0b3JjaCUwQWltcG9ydCUyMG51bXB5JTIwYXMlMjBucCUwQWZyb20lMjBkaWZmdXNlcnMlMjBpbXBvcnQlMjBBdXRvTW9kZWwlMkMlMjBXYW5QaXBlbGluZSUwQWZyb20lMjBkaWZmdXNlcnMuaG9va3MuZ3JvdXBfb2ZmbG9hZGluZyUyMGltcG9ydCUyMGFwcGx5X2dyb3VwX29mZmxvYWRpbmclMEFmcm9tJTIwZGlmZnVzZXJzLnV0aWxzJTIwaW1wb3J0JTIwZXhwb3J0X3RvX3ZpZGVvJTJDJTIwbG9hZF9pbWFnZSUwQWZyb20lMjB0cmFuc2Zvcm1lcnMlMjBpbXBvcnQlMjBVTVQ1RW5jb2Rlck1vZGVsJTBBJTBBdGV4dF9lbmNvZGVyJTIwJTNEJTIwVU1UNUVuY29kZXJNb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIyV2FuLUFJJTJGV2FuMi4xLVQyVi0xNEItRGlmZnVzZXJzJTIyJTJDJTIwc3ViZm9sZGVyJTNEJTIydGV4dF9lbmNvZGVyJTIyJTJDJTIwdG9yY2hfZHR5cGUlM0R0b3JjaC5iZmxvYXQxNiklMEF2YWUlMjAlM0QlMjBBdXRvTW9kZWwuZnJvbV9wcmV0cmFpbmVkKCUyMldhbi1BSSUyRldhbjIuMS1UMlYtMTRCLURpZmZ1c2VycyUyMiUyQyUyMHN1YmZvbGRlciUzRCUyMnZhZSUyMiUyQyUyMHRvcmNoX2R0eXBlJTNEdG9yY2guZmxvYXQzMiklMEF0cmFuc2Zvcm1lciUyMCUzRCUyMEF1dG9Nb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIyV2FuLUFJJTJGV2FuMi4xLVQyVi0xNEItRGlmZnVzZXJzJTIyJTJDJTIwc3ViZm9sZGVyJTNEJTIydHJhbnNmb3JtZXIlMjIlMkMlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmJmbG9hdDE2KSUwQSUwQSUyMyUyMGdyb3VwLW9mZmxvYWRpbmclMEFvbmxvYWRfZGV2aWNlJTIwJTNEJTIwdG9yY2guZGV2aWNlKCUyMmN1ZGElMjIpJTBBb2ZmbG9hZF9kZXZpY2UlMjAlM0QlMjB0b3JjaC5kZXZpY2UoJTIyY3B1JTIyKSUwQWFwcGx5X2dyb3VwX29mZmxvYWRpbmcodGV4dF9lbmNvZGVyJTJDJTBBJTIwJTIwJTIwJTIwb25sb2FkX2RldmljZSUzRG9ubG9hZF9kZXZpY2UlMkMlMEElMjAlMjAlMjAlMjBvZmZsb2FkX2RldmljZSUzRG9mZmxvYWRfZGV2aWNlJTJDJTBBJTIwJTIwJTIwJTIwb2ZmbG9hZF90eXBlJTNEJTIyYmxvY2tfbGV2ZWwlMjIlMkMlMEElMjAlMjAlMjAlMjBudW1fYmxvY2tzX3Blcl9ncm91cCUzRDQlMEEpJTBBdHJhbnNmb3JtZXIuZW5hYmxlX2dyb3VwX29mZmxvYWQoJTBBJTIwJTIwJTIwJTIwb25sb2FkX2RldmljZSUzRG9ubG9hZF9kZXZpY2UlMkMlMEElMjAlMjAlMjAlMjBvZmZsb2FkX2RldmljZSUzRG9mZmxvYWRfZGV2aWNlJTJDJTBBJTIwJTIwJTIwJTIwb2ZmbG9hZF90eXBlJTNEJTIybGVhZl9sZXZlbCUyMiUyQyUwQSUyMCUyMCUyMCUyMHVzZV9zdHJlYW0lM0RUcnVlJTBBKSUwQSUwQXBpcGVsaW5lJTIwJTNEJTIwV2FuUGlwZWxpbmUuZnJvbV9wcmV0cmFpbmVkKCUwQSUyMCUyMCUyMCUyMCUyMldhbi1BSSUyRldhbjIuMS1UMlYtMTRCLURpZmZ1c2VycyUyMiUyQyUwQSUyMCUyMCUyMCUyMHZhZSUzRHZhZSUyQyUwQSUyMCUyMCUyMCUyMHRyYW5zZm9ybWVyJTNEdHJhbnNmb3JtZXIlMkMlMEElMjAlMjAlMjAlMjB0ZXh0X2VuY29kZXIlM0R0ZXh0X2VuY29kZXIlMkMlMEElMjAlMjAlMjAlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmJmbG9hdDE2JTBBKSUwQXBpcGVsaW5lLnRvKCUyMmN1ZGElMjIpJTBBJTBBcHJvbXB0JTIwJTNEJTIwJTIyJTIyJTIyJTBBVGhlJTIwY2FtZXJhJTIwcnVzaGVzJTIwZnJvbSUyMGZhciUyMHRvJTIwbmVhciUyMGluJTIwYSUyMGxvdy1hbmdsZSUyMHNob3QlMkMlMjAlMEFyZXZlYWxpbmclMjBhJTIwd2hpdGUlMjBmZXJyZXQlMjBvbiUyMGElMjBsb2cuJTIwSXQlMjBwbGF5cyUyQyUyMGxlYXBzJTIwaW50byUyMHRoZSUyMHdhdGVyJTJDJTIwYW5kJTIwZW1lcmdlcyUyQyUyMGFzJTIwdGhlJTIwY2FtZXJhJTIwem9vbXMlMjBpbiUyMCUwQWZvciUyMGElMjBjbG9zZS11cC4lMjBXYXRlciUyMHNwbGFzaGVzJTIwYmVycnklMjBidXNoZXMlMjBuZWFyYnklMkMlMjB3aGlsZSUyMG1vc3MlMkMlMjBzbm93JTJDJTIwYW5kJTIwbGVhdmVzJTIwYmxhbmtldCUyMHRoZSUyMGdyb3VuZC4lMjAlMEFCaXJjaCUyMHRyZWVzJTIwYW5kJTIwYSUyMGxpZ2h0JTIwYmx1ZSUyMHNreSUyMGZyYW1lJTIwdGhlJTIwc2NlbmUlMkMlMjB3aXRoJTIwZmVybnMlMjBpbiUyMHRoZSUyMGZvcmVncm91bmQuJTIwU2lkZSUyMGxpZ2h0aW5nJTIwY2FzdHMlMjBkeW5hbWljJTIwJTBBc2hhZG93cyUyMGFuZCUyMHdhcm0lMjBoaWdobGlnaHRzLiUyME1lZGl1bSUyMGNvbXBvc2l0aW9uJTJDJTIwZnJvbnQlMjB2aWV3JTJDJTIwbG93JTIwYW5nbGUlMkMlMjB3aXRoJTIwZGVwdGglMjBvZiUyMGZpZWxkLiUwQSUyMiUyMiUyMiUwQW5lZ2F0aXZlX3Byb21wdCUyMCUzRCUyMCUyMiUyMiUyMiUwQUJyaWdodCUyMHRvbmVzJTJDJTIwb3ZlcmV4cG9zZWQlMkMlMjBzdGF0aWMlMkMlMjBibHVycmVkJTIwZGV0YWlscyUyQyUyMHN1YnRpdGxlcyUyQyUyMHN0eWxlJTJDJTIwd29ya3MlMkMlMjBwYWludGluZ3MlMkMlMjBpbWFnZXMlMkMlMjBzdGF0aWMlMkMlMjBvdmVyYWxsJTIwZ3JheSUyQyUyMHdvcnN0JTIwcXVhbGl0eSUyQyUyMCUwQWxvdyUyMHF1YWxpdHklMkMlMjBKUEVHJTIwY29tcHJlc3Npb24lMjByZXNpZHVlJTJDJTIwdWdseSUyQyUyMGluY29tcGxldGUlMkMlMjBleHRyYSUyMGZpbmdlcnMlMkMlMjBwb29ybHklMjBkcmF3biUyMGhhbmRzJTJDJTIwcG9vcmx5JTIwZHJhd24lMjBmYWNlcyUyQyUyMGRlZm9ybWVkJTJDJTIwZGlzZmlndXJlZCUyQyUyMCUwQW1pc3NoYXBlbiUyMGxpbWJzJTJDJTIwZnVzZWQlMjBmaW5nZXJzJTJDJTIwc3RpbGwlMjBwaWN0dXJlJTJDJTIwbWVzc3klMjBiYWNrZ3JvdW5kJTJDJTIwdGhyZWUlMjBsZWdzJTJDJTIwbWFueSUyMHBlb3BsZSUyMGluJTIwdGhlJTIwYmFja2dyb3VuZCUyQyUyMHdhbGtpbmclMjBiYWNrd2FyZHMlMEElMjIlMjIlMjIlMEElMEFvdXRwdXQlMjAlM0QlMjBwaXBlbGluZSglMEElMjAlMjAlMjAlMjBwcm9tcHQlM0Rwcm9tcHQlMkMlMEElMjAlMjAlMjAlMjBuZWdhdGl2ZV9wcm9tcHQlM0RuZWdhdGl2ZV9wcm9tcHQlMkMlMEElMjAlMjAlMjAlMjBudW1fZnJhbWVzJTNEODElMkMlMEElMjAlMjAlMjAlMjBndWlkYW5jZV9zY2FsZSUzRDUuMCUyQyUwQSkuZnJhbWVzJTVCMCU1RCUwQWV4cG9ydF90b192aWRlbyhvdXRwdXQlMkMlMjAlMjJvdXRwdXQubXA0JTIyJTJDJTIwZnBzJTNEMTYp",highlighted:`<span class="hljs-comment"># pip install ftfy</span>
<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">import</span> numpy <span class="hljs-keyword">as</span> np
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> AutoModel, WanPipeline
<span class="hljs-keyword">from</span> diffusers.hooks.group_offloading <span class="hljs-keyword">import</span> apply_group_offloading
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video, load_image
<span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> UMT5EncoderModel

text_encoder = UMT5EncoderModel.from_pretrained(<span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, subfolder=<span class="hljs-string">&quot;text_encoder&quot;</span>, torch_dtype=torch.bfloat16)
vae = AutoModel.from_pretrained(<span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, subfolder=<span class="hljs-string">&quot;vae&quot;</span>, torch_dtype=torch.float32)
transformer = AutoModel.from_pretrained(<span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, subfolder=<span class="hljs-string">&quot;transformer&quot;</span>, torch_dtype=torch.bfloat16)

<span class="hljs-comment"># group-offloading</span>
onload_device = torch.device(<span class="hljs-string">&quot;cuda&quot;</span>)
offload_device = torch.device(<span class="hljs-string">&quot;cpu&quot;</span>)
apply_group_offloading(text_encoder,
    onload_device=onload_device,
    offload_device=offload_device,
    offload_type=<span class="hljs-string">&quot;block_level&quot;</span>,
    num_blocks_per_group=<span class="hljs-number">4</span>
)
transformer.enable_group_offload(
    onload_device=onload_device,
    offload_device=offload_device,
    offload_type=<span class="hljs-string">&quot;leaf_level&quot;</span>,
    use_stream=<span class="hljs-literal">True</span>
)

pipeline = WanPipeline.from_pretrained(
    <span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>,
    vae=vae,
    transformer=transformer,
    text_encoder=text_encoder,
    torch_dtype=torch.bfloat16
)
pipeline.to(<span class="hljs-string">&quot;cuda&quot;</span>)

prompt = <span class="hljs-string">&quot;&quot;&quot;
The camera rushes from far to near in a low-angle shot, 
revealing a white ferret on a log. It plays, leaps into the water, and emerges, as the camera zooms in 
for a close-up. Water splashes berry bushes nearby, while moss, snow, and leaves blanket the ground. 
Birch trees and a light blue sky frame the scene, with ferns in the foreground. Side lighting casts dynamic 
shadows and warm highlights. Medium composition, front view, low angle, with depth of field.
&quot;&quot;&quot;</span>
negative_prompt = <span class="hljs-string">&quot;&quot;&quot;
Bright tones, overexposed, static, blurred details, subtitles, style, works, paintings, images, static, overall gray, worst quality, 
low quality, JPEG compression residue, ugly, incomplete, extra fingers, poorly drawn hands, poorly drawn faces, deformed, disfigured, 
misshapen limbs, fused fingers, still picture, messy background, three legs, many people in the background, walking backwards
&quot;&quot;&quot;</span>

output = pipeline(
    prompt=prompt,
    negative_prompt=negative_prompt,
    num_frames=<span class="hljs-number">81</span>,
    guidance_scale=<span class="hljs-number">5.0</span>,
).frames[<span class="hljs-number">0</span>]
export_to_video(output, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">16</span>)`,wrap:!1}}),L=new B({props:{code:"JTIzJTIwcGlwJTIwaW5zdGFsbCUyMGZ0ZnklMEElMEFpbXBvcnQlMjB0b3JjaCUwQWZyb20lMjBkaWZmdXNlcnMlMjBpbXBvcnQlMjBXYW5QaXBlbGluZSUwQWZyb20lMjBkaWZmdXNlcnMlMjBpbXBvcnQlMjBBdXRvTW9kZWwlMkMlMjBXYW5QaXBlbGluZSUwQWZyb20lMjBkaWZmdXNlcnMucXVhbnRpemVycyUyMGltcG9ydCUyMFBpcGVsaW5lUXVhbnRpemF0aW9uQ29uZmlnJTBBZnJvbSUyMGRpZmZ1c2Vycy5zY2hlZHVsZXJzLnNjaGVkdWxpbmdfdW5pcGNfbXVsdGlzdGVwJTIwaW1wb3J0JTIwVW5pUENNdWx0aXN0ZXBTY2hlZHVsZXIlMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwVU1UNUVuY29kZXJNb2RlbCUwQWZyb20lMjBkaWZmdXNlcnMudXRpbHMlMjBpbXBvcnQlMjBleHBvcnRfdG9fdmlkZW8lMEElMEElMjMlMjBxdWFudGl6ZSUyMHRyYW5zZm9ybWVyJTIwYW5kJTIwdGV4dCUyMGVuY29kZXIlMjB3ZWlnaHRzJTIwd2l0aCUyMGJpdHNhbmRieXRlcyUwQXBpcGVsaW5lX3F1YW50X2NvbmZpZyUyMCUzRCUyMFBpcGVsaW5lUXVhbnRpemF0aW9uQ29uZmlnKCUwQSUyMCUyMHF1YW50X2JhY2tlbmQlM0QlMjJiaXRzYW5kYnl0ZXNfNGJpdCUyMiUyQyUwQSUyMCUyMHF1YW50X2t3YXJncyUzRCU3QiUyMmxvYWRfaW5fNGJpdCUyMiUzQSUyMFRydWUlN0QlMkMlMEElMjAlMjBjb21wb25lbnRzX3RvX3F1YW50aXplJTNEJTVCJTIydHJhbnNmb3JtZXIlMjIlMkMlMjAlMjJ0ZXh0X2VuY29kZXIlMjIlNUQlMEEpJTBBJTBBdmFlJTIwJTNEJTIwQXV0b01vZGVsLmZyb21fcHJldHJhaW5lZCglMEElMjAlMjAlMjJXYW4tQUklMkZXYW4yLjEtVDJWLTE0Qi1EaWZmdXNlcnMlMjIlMkMlMjBzdWJmb2xkZXIlM0QlMjJ2YWUlMjIlMkMlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmZsb2F0MzIlMEEpJTBBcGlwZWxpbmUlMjAlM0QlMjBXYW5QaXBlbGluZS5mcm9tX3ByZXRyYWluZWQoJTBBJTIwJTIwJTIyV2FuLUFJJTJGV2FuMi4xLVQyVi0xNEItRGlmZnVzZXJzJTIyJTJDJTIwdmFlJTNEdmFlJTJDJTIwcXVhbnRpemF0aW9uX2NvbmZpZyUzRHBpcGVsaW5lX3F1YW50X2NvbmZpZyUyQyUyMHRvcmNoX2R0eXBlJTNEdG9yY2guYmZsb2F0MTYlMEEpJTBBcGlwZWxpbmUuc2NoZWR1bGVyJTIwJTNEJTIwVW5pUENNdWx0aXN0ZXBTY2hlZHVsZXIuZnJvbV9jb25maWcoJTBBJTIwJTIwcGlwZWxpbmUuc2NoZWR1bGVyLmNvbmZpZyUyQyUyMGZsb3dfc2hpZnQlM0Q1LjAlMEEpJTBBcGlwZWxpbmUudG8oJTIyY3VkYSUyMiklMEElMEFwaXBlbGluZS5sb2FkX2xvcmFfd2VpZ2h0cyglMjJiZW5qYW1pbi1wYWluZSUyRnN0ZWFtYm9hdC13aWxsaWUtMTRiJTIyJTJDJTIwYWRhcHRlcl9uYW1lJTNEJTIyc3RlYW1ib2F0LXdpbGxpZSUyMiklMEFwaXBlbGluZS5zZXRfYWRhcHRlcnMoJTIyc3RlYW1ib2F0LXdpbGxpZSUyMiklMEElMEFwaXBlbGluZS5lbmFibGVfbW9kZWxfY3B1X29mZmxvYWQoKSUwQSUwQSUyMyUyMHVzZSUyMCUyMnN0ZWFtYm9hdCUyMHdpbGxpZSUyMHN0eWxlJTIyJTIwdG8lMjB0cmlnZ2VyJTIwdGhlJTIwTG9SQSUwQXByb21wdCUyMCUzRCUyMCUyMiUyMiUyMiUwQXN0ZWFtYm9hdCUyMHdpbGxpZSUyMHN0eWxlJTJDJTIwZ29sZGVuJTIwZXJhJTIwYW5pbWF0aW9uJTJDJTIwVGhlJTIwY2FtZXJhJTIwcnVzaGVzJTIwZnJvbSUyMGZhciUyMHRvJTIwbmVhciUyMGluJTIwYSUyMGxvdy1hbmdsZSUyMHNob3QlMkMlMjAlMEFyZXZlYWxpbmclMjBhJTIwd2hpdGUlMjBmZXJyZXQlMjBvbiUyMGElMjBsb2cuJTIwSXQlMjBwbGF5cyUyQyUyMGxlYXBzJTIwaW50byUyMHRoZSUyMHdhdGVyJTJDJTIwYW5kJTIwZW1lcmdlcyUyQyUyMGFzJTIwdGhlJTIwY2FtZXJhJTIwem9vbXMlMjBpbiUyMCUwQWZvciUyMGElMjBjbG9zZS11cC4lMjBXYXRlciUyMHNwbGFzaGVzJTIwYmVycnklMjBidXNoZXMlMjBuZWFyYnklMkMlMjB3aGlsZSUyMG1vc3MlMkMlMjBzbm93JTJDJTIwYW5kJTIwbGVhdmVzJTIwYmxhbmtldCUyMHRoZSUyMGdyb3VuZC4lMjAlMEFCaXJjaCUyMHRyZWVzJTIwYW5kJTIwYSUyMGxpZ2h0JTIwYmx1ZSUyMHNreSUyMGZyYW1lJTIwdGhlJTIwc2NlbmUlMkMlMjB3aXRoJTIwZmVybnMlMjBpbiUyMHRoZSUyMGZvcmVncm91bmQuJTIwU2lkZSUyMGxpZ2h0aW5nJTIwY2FzdHMlMjAlMEFkeW5hbWljJTIwc2hhZG93cyUyMGFuZCUyMHdhcm0lMjBoaWdobGlnaHRzLiUyME1lZGl1bSUyMGNvbXBvc2l0aW9uJTJDJTIwZnJvbnQlMjB2aWV3JTJDJTIwbG93JTIwYW5nbGUlMkMlMjB3aXRoJTIwZGVwdGglMjBvZiUyMGZpZWxkLiUwQSUyMiUyMiUyMiUwQSUwQW91dHB1dCUyMCUzRCUyMHBpcGVsaW5lKCUwQSUyMCUyMHByb21wdCUzRHByb21wdCUyQyUwQSUyMCUyMG51bV9mcmFtZXMlM0Q4MSUyQyUwQSUyMCUyMGd1aWRhbmNlX3NjYWxlJTNENS4wJTJDJTBBKS5mcmFtZXMlNUIwJTVEJTBBZXhwb3J0X3RvX3ZpZGVvKG91dHB1dCUyQyUyMCUyMm91dHB1dC5tcDQlMjIlMkMlMjBmcHMlM0QxNik=",highlighted:`<span class="hljs-comment"># pip install ftfy</span>

<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> WanPipeline
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> AutoModel, WanPipeline
<span class="hljs-keyword">from</span> diffusers.quantizers <span class="hljs-keyword">import</span> PipelineQuantizationConfig
<span class="hljs-keyword">from</span> diffusers.schedulers.scheduling_unipc_multistep <span class="hljs-keyword">import</span> UniPCMultistepScheduler
<span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> UMT5EncoderModel
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video

<span class="hljs-comment"># quantize transformer and text encoder weights with bitsandbytes</span>
pipeline_quant_config = PipelineQuantizationConfig(
  quant_backend=<span class="hljs-string">&quot;bitsandbytes_4bit&quot;</span>,
  quant_kwargs={<span class="hljs-string">&quot;load_in_4bit&quot;</span>: <span class="hljs-literal">True</span>},
  components_to_quantize=[<span class="hljs-string">&quot;transformer&quot;</span>, <span class="hljs-string">&quot;text_encoder&quot;</span>]
)

vae = AutoModel.from_pretrained(
  <span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, subfolder=<span class="hljs-string">&quot;vae&quot;</span>, torch_dtype=torch.float32
)
pipeline = WanPipeline.from_pretrained(
  <span class="hljs-string">&quot;Wan-AI/Wan2.1-T2V-14B-Diffusers&quot;</span>, vae=vae, quantization_config=pipeline_quant_config, torch_dtype=torch.bfloat16
)
pipeline.scheduler = UniPCMultistepScheduler.from_config(
  pipeline.scheduler.config, flow_shift=<span class="hljs-number">5.0</span>
)
pipeline.to(<span class="hljs-string">&quot;cuda&quot;</span>)

pipeline.load_lora_weights(<span class="hljs-string">&quot;benjamin-paine/steamboat-willie-14b&quot;</span>, adapter_name=<span class="hljs-string">&quot;steamboat-willie&quot;</span>)
pipeline.set_adapters(<span class="hljs-string">&quot;steamboat-willie&quot;</span>)

pipeline.enable_model_cpu_offload()

<span class="hljs-comment"># use &quot;steamboat willie style&quot; to trigger the LoRA</span>
prompt = <span class="hljs-string">&quot;&quot;&quot;
steamboat willie style, golden era animation, The camera rushes from far to near in a low-angle shot, 
revealing a white ferret on a log. It plays, leaps into the water, and emerges, as the camera zooms in 
for a close-up. Water splashes berry bushes nearby, while moss, snow, and leaves blanket the ground. 
Birch trees and a light blue sky frame the scene, with ferns in the foreground. Side lighting casts 
dynamic shadows and warm highlights. Medium composition, front view, low angle, with depth of field.
&quot;&quot;&quot;</span>

output = pipeline(
  prompt=prompt,
  num_frames=<span class="hljs-number">81</span>,
  guidance_scale=<span class="hljs-number">5.0</span>,
).frames[<span class="hljs-number">0</span>]
export_to_video(output, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">16</span>)`,wrap:!1}}),P=new sl({props:{title:"Inference speed",local:"inference-speed",headingTag:"h2"}}),ll=new B({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwZGlmZnVzZXJzJTIwaW1wb3J0JTIwQ29nVmlkZW9YUGlwZWxpbmUlMkMlMjBDb2dWaWRlb1hUcmFuc2Zvcm1lcjNETW9kZWwlMEFmcm9tJTIwZGlmZnVzZXJzLnV0aWxzJTIwaW1wb3J0JTIwZXhwb3J0X3RvX3ZpZGVvJTBBJTBBcGlwZWxpbmUlMjAlM0QlMjBDb2dWaWRlb1hQaXBlbGluZS5mcm9tX3ByZXRyYWluZWQoJTBBJTIwJTIwJTIyVEhVRE0lMkZDb2dWaWRlb1gtMmIlMjIlMkMlMEElMjAlMjB0b3JjaF9kdHlwZSUzRHRvcmNoLmZsb2F0MTYlMEEpLnRvKCUyMmN1ZGElMjIpJTBBJTBBJTIzJTIwdG9yY2guY29tcGlsZSUwQXBpcGVsaW5lLnRyYW5zZm9ybWVyLnRvKG1lbW9yeV9mb3JtYXQlM0R0b3JjaC5jaGFubmVsc19sYXN0KSUwQXBpcGVsaW5lLnRyYW5zZm9ybWVyJTIwJTNEJTIwdG9yY2guY29tcGlsZSglMEElMjAlMjAlMjAlMjBwaXBlbGluZS50cmFuc2Zvcm1lciUyQyUyMG1vZGUlM0QlMjJtYXgtYXV0b3R1bmUlMjIlMkMlMjBmdWxsZ3JhcGglM0RUcnVlJTBBKSUwQSUwQXByb21wdCUyMCUzRCUyMCUyMiUyMiUyMiUwQUElMjBkZXRhaWxlZCUyMHdvb2RlbiUyMHRveSUyMHNoaXAlMjB3aXRoJTIwaW50cmljYXRlbHklMjBjYXJ2ZWQlMjBtYXN0cyUyMGFuZCUyMHNhaWxzJTIwaXMlMjBzZWVuJTIwZ2xpZGluZyUyMHNtb290aGx5JTIwb3ZlciUyMGElMjBwbHVzaCUyQyUyMGJsdWUlMjBjYXJwZXQlMjB0aGF0JTIwbWltaWNzJTIwdGhlJTIwd2F2ZXMlMjBvZiUyMHRoZSUyMHNlYS4lMjAlMEFUaGUlMjBzaGlwJ3MlMjBodWxsJTIwaXMlMjBwYWludGVkJTIwYSUyMHJpY2glMjBicm93biUyQyUyMHdpdGglMjB0aW55JTIwd2luZG93cy4lMjBUaGUlMjBjYXJwZXQlMkMlMjBzb2Z0JTIwYW5kJTIwdGV4dHVyZWQlMkMlMjBwcm92aWRlcyUyMGElMjBwZXJmZWN0JTIwYmFja2Ryb3AlMkMlMjByZXNlbWJsaW5nJTIwYW4lMjBvY2VhbmljJTIwZXhwYW5zZS4lMjAlMEFTdXJyb3VuZGluZyUyMHRoZSUyMHNoaXAlMjBhcmUlMjB2YXJpb3VzJTIwb3RoZXIlMjB0b3lzJTIwYW5kJTIwY2hpbGRyZW4ncyUyMGl0ZW1zJTJDJTIwaGludGluZyUyMGF0JTIwYSUyMHBsYXlmdWwlMjBlbnZpcm9ubWVudC4lMjBUaGUlMjBzY2VuZSUyMGNhcHR1cmVzJTIwdGhlJTIwaW5ub2NlbmNlJTIwYW5kJTIwaW1hZ2luYXRpb24lMjBvZiUyMGNoaWxkaG9vZCUyQyUyMCUwQXdpdGglMjB0aGUlMjB0b3klMjBzaGlwJ3MlMjBqb3VybmV5JTIwc3ltYm9saXppbmclMjBlbmRsZXNzJTIwYWR2ZW50dXJlcyUyMGluJTIwYSUyMHdoaW1zaWNhbCUyQyUyMGluZG9vciUyMHNldHRpbmcuJTBBJTIyJTIyJTIyJTBBJTBBdmlkZW8lMjAlM0QlMjBwaXBlbGluZSglMEElMjAlMjBwcm9tcHQlM0Rwcm9tcHQlMkMlMEElMjAlMjBndWlkYW5jZV9zY2FsZSUzRDYlMkMlMEElMjAlMjBudW1faW5mZXJlbmNlX3N0ZXBzJTNENTAlMEEpLmZyYW1lcyU1QjAlNUQlMEFleHBvcnRfdG9fdmlkZW8odmlkZW8lMkMlMjAlMjJvdXRwdXQubXA0JTIyJTJDJTIwZnBzJTNEOCk=",highlighted:`<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">from</span> diffusers <span class="hljs-keyword">import</span> CogVideoXPipeline, CogVideoXTransformer3DModel
<span class="hljs-keyword">from</span> diffusers.utils <span class="hljs-keyword">import</span> export_to_video

pipeline = CogVideoXPipeline.from_pretrained(
  <span class="hljs-string">&quot;THUDM/CogVideoX-2b&quot;</span>,
  torch_dtype=torch.float16
).to(<span class="hljs-string">&quot;cuda&quot;</span>)

<span class="hljs-comment"># torch.compile</span>
pipeline.transformer.to(memory_format=torch.channels_last)
pipeline.transformer = torch.<span class="hljs-built_in">compile</span>(
    pipeline.transformer, mode=<span class="hljs-string">&quot;max-autotune&quot;</span>, fullgraph=<span class="hljs-literal">True</span>
)

prompt = <span class="hljs-string">&quot;&quot;&quot;
A detailed wooden toy ship with intricately carved masts and sails is seen gliding smoothly over a plush, blue carpet that mimics the waves of the sea. 
The ship&#x27;s hull is painted a rich brown, with tiny windows. The carpet, soft and textured, provides a perfect backdrop, resembling an oceanic expanse. 
Surrounding the ship are various other toys and children&#x27;s items, hinting at a playful environment. The scene captures the innocence and imagination of childhood, 
with the toy ship&#x27;s journey symbolizing endless adventures in a whimsical, indoor setting.
&quot;&quot;&quot;</span>

video = pipeline(
  prompt=prompt,
  guidance_scale=<span class="hljs-number">6</span>,
  num_inference_steps=<span class="hljs-number">50</span>
).frames[<span class="hljs-number">0</span>]
export_to_video(video, <span class="hljs-string">&quot;output.mp4&quot;</span>, fps=<span class="hljs-number">8</span>)`,wrap:!1}}),el=new pe({props:{source:"https://github.com/huggingface/diffusers/blob/main/docs/source/en/using-diffusers/text-img2vid.md"}}),{c(){a=u("meta"),p=M(),t=u("p"),b=M(),y(T.$$.fragment),f=M(),o=u("p"),o.textContent=U,X=M(),j=u("p"),j.textContent=al,ol=M(),V=u("p"),V.textContent=El,Ml=M(),y(G.$$.fragment),il=M(),v=u("p"),v.textContent=Cl,pl=M(),y(I.$$.fragment),yl=M(),y(g.$$.fragment),ml=M(),k=u("p"),k.textContent=_l,rl=M(),y(R.$$.fragment),dl=M(),Y=u("p"),Y.innerHTML=Fl,cl=M(),Q=u("p"),Q.innerHTML=zl,Jl=M(),y(H.$$.fragment),ul=M(),y(E.$$.fragment),wl=M(),C=u("p"),C.innerHTML=Nl,bl=M(),y(_.$$.fragment),hl=M(),y(F.$$.fragment),Tl=M(),z=u("p"),z.textContent=Sl,Ul=M(),y(N.$$.fragment),Zl=M(),y(S.$$.fragment),jl=M(),x=u("p"),x.innerHTML=xl,fl=M(),y(W.$$.fragment),Bl=M(),q=u("p"),q.innerHTML=ql,Gl=M(),y($.$$.fragment),Il=M(),A=u("p"),A.innerHTML=$l,Wl=M(),D=u("p"),D.innerHTML=Al,Xl=M(),y(L.$$.fragment),Vl=M(),y(P.$$.fragment),vl=M(),K=u("p"),K.innerHTML=Dl,gl=M(),O=u("p"),O.innerHTML=Ll,kl=M(),y(ll.$$.fragment),Rl=M(),y(el.$$.fragment),Yl=M(),tl=u("p"),this.h()},l(l){const e=Me("svelte-u9bgzb",document.head);a=w(e,"META",{name:!0,content:!0}),e.forEach(s),p=i(l),t=w(l,"P",{}),le(t).forEach(s),b=i(l),m(T.$$.fragment,l),f=i(l),o=w(l,"P",{"data-svelte-h":!0}),h(o)!=="svelte-1bo3eh2"&&(o.textContent=U),X=i(l),j=w(l,"P",{"data-svelte-h":!0}),h(j)!=="svelte-i9eaqp"&&(j.textContent=al),ol=i(l),V=w(l,"P",{"data-svelte-h":!0}),h(V)!=="svelte-1aaeavb"&&(V.textContent=El),Ml=i(l),m(G.$$.fragment,l),il=i(l),v=w(l,"P",{"data-svelte-h":!0}),h(v)!=="svelte-1q9es90"&&(v.textContent=Cl),pl=i(l),m(I.$$.fragment,l),yl=i(l),m(g.$$.fragment,l),ml=i(l),k=w(l,"P",{"data-svelte-h":!0}),h(k)!=="svelte-7qv10n"&&(k.textContent=_l),rl=i(l),m(R.$$.fragment,l),dl=i(l),Y=w(l,"P",{"data-svelte-h":!0}),h(Y)!=="svelte-nhumen"&&(Y.innerHTML=Fl),cl=i(l),Q=w(l,"P",{"data-svelte-h":!0}),h(Q)!=="svelte-1sbc2mp"&&(Q.innerHTML=zl),Jl=i(l),m(H.$$.fragment,l),ul=i(l),m(E.$$.fragment,l),wl=i(l),C=w(l,"P",{"data-svelte-h":!0}),h(C)!=="svelte-7ligo6"&&(C.innerHTML=Nl),bl=i(l),m(_.$$.fragment,l),hl=i(l),m(F.$$.fragment,l),Tl=i(l),z=w(l,"P",{"data-svelte-h":!0}),h(z)!=="svelte-11664c2"&&(z.textContent=Sl),Ul=i(l),m(N.$$.fragment,l),Zl=i(l),m(S.$$.fragment,l),jl=i(l),x=w(l,"P",{"data-svelte-h":!0}),h(x)!=="svelte-1k3di49"&&(x.innerHTML=xl),fl=i(l),m(W.$$.fragment,l),Bl=i(l),q=w(l,"P",{"data-svelte-h":!0}),h(q)!=="svelte-16lygi9"&&(q.innerHTML=ql),Gl=i(l),m($.$$.fragment,l),Il=i(l),A=w(l,"P",{"data-svelte-h":!0}),h(A)!=="svelte-8hypvu"&&(A.innerHTML=$l),Wl=i(l),D=w(l,"P",{"data-svelte-h":!0}),h(D)!=="svelte-1b52ou4"&&(D.innerHTML=Al),Xl=i(l),m(L.$$.fragment,l),Vl=i(l),m(P.$$.fragment,l),vl=i(l),K=w(l,"P",{"data-svelte-h":!0}),h(K)!=="svelte-1s92ub6"&&(K.innerHTML=Dl),gl=i(l),O=w(l,"P",{"data-svelte-h":!0}),h(O)!=="svelte-113cz6n"&&(O.innerHTML=Ll),kl=i(l),m(ll.$$.fragment,l),Rl=i(l),m(el.$$.fragment,l),Yl=i(l),tl=w(l,"P",{}),le(tl).forEach(s),this.h()},h(){ee(a,"name","hf:doc:metadata"),ee(a,"content",be)},m(l,e){ie(document.head,a),n(l,p,e),n(l,t,e),n(l,b,e),r(T,l,e),n(l,f,e),n(l,o,e),n(l,X,e),n(l,j,e),n(l,ol,e),n(l,V,e),n(l,Ml,e),r(G,l,e),n(l,il,e),n(l,v,e),n(l,pl,e),r(I,l,e),n(l,yl,e),r(g,l,e),n(l,ml,e),n(l,k,e),n(l,rl,e),r(R,l,e),n(l,dl,e),n(l,Y,e),n(l,cl,e),n(l,Q,e),n(l,Jl,e),r(H,l,e),n(l,ul,e),r(E,l,e),n(l,wl,e),n(l,C,e),n(l,bl,e),r(_,l,e),n(l,hl,e),r(F,l,e),n(l,Tl,e),n(l,z,e),n(l,Ul,e),r(N,l,e),n(l,Zl,e),r(S,l,e),n(l,jl,e),n(l,x,e),n(l,fl,e),r(W,l,e),n(l,Bl,e),n(l,q,e),n(l,Gl,e),r($,l,e),n(l,Il,e),n(l,A,e),n(l,Wl,e),n(l,D,e),n(l,Xl,e),r(L,l,e),n(l,Vl,e),r(P,l,e),n(l,vl,e),n(l,K,e),n(l,gl,e),n(l,O,e),n(l,kl,e),r(ll,l,e),n(l,Rl,e),r(el,l,e),n(l,Yl,e),n(l,tl,e),Ql=!0},p(l,[e]){const Pl={};e&2&&(Pl.$$scope={dirty:e,ctx:l}),G.$set(Pl);const Kl={};e&2&&(Kl.$$scope={dirty:e,ctx:l}),I.$set(Kl);const Ol={};e&2&&(Ol.$$scope={dirty:e,ctx:l}),W.$set(Ol)},i(l){Ql||(d(T.$$.fragment,l),d(G.$$.fragment,l),d(I.$$.fragment,l),d(g.$$.fragment,l),d(R.$$.fragment,l),d(H.$$.fragment,l),d(E.$$.fragment,l),d(_.$$.fragment,l),d(F.$$.fragment,l),d(N.$$.fragment,l),d(S.$$.fragment,l),d(W.$$.fragment,l),d($.$$.fragment,l),d(L.$$.fragment,l),d(P.$$.fragment,l),d(ll.$$.fragment,l),d(el.$$.fragment,l),Ql=!0)},o(l){c(T.$$.fragment,l),c(G.$$.fragment,l),c(I.$$.fragment,l),c(g.$$.fragment,l),c(R.$$.fragment,l),c(H.$$.fragment,l),c(E.$$.fragment,l),c(_.$$.fragment,l),c(F.$$.fragment,l),c(N.$$.fragment,l),c(S.$$.fragment,l),c(W.$$.fragment,l),c($.$$.fragment,l),c(L.$$.fragment,l),c(P.$$.fragment,l),c(ll.$$.fragment,l),c(el.$$.fragment,l),Ql=!1},d(l){l&&(s(p),s(t),s(b),s(f),s(o),s(X),s(j),s(ol),s(V),s(Ml),s(il),s(v),s(pl),s(yl),s(ml),s(k),s(rl),s(dl),s(Y),s(cl),s(Q),s(Jl),s(ul),s(wl),s(C),s(bl),s(hl),s(Tl),s(z),s(Ul),s(Zl),s(jl),s(x),s(fl),s(Bl),s(q),s(Gl),s(Il),s(A),s(Wl),s(D),s(Xl),s(Vl),s(vl),s(K),s(gl),s(O),s(kl),s(Rl),s(Yl),s(tl)),s(a),J(T,l),J(G,l),J(I,l),J(g,l),J(R,l),J(H,l),J(E,l),J(_,l),J(F,l),J(N,l),J(S,l),J(W,l),J($,l),J(L,l),J(P,l),J(ll,l),J(el,l)}}}const be='{"title":"Video generation","local":"video-generation","sections":[{"title":"Pipeline parameters","local":"pipeline-parameters","sections":[{"title":"num_frames","local":"numframes","sections":[],"depth":3},{"title":"guidance_scale","local":"guidancescale","sections":[],"depth":3},{"title":"negative_prompt","local":"negativeprompt","sections":[],"depth":3}],"depth":2},{"title":"Reduce memory usage","local":"reduce-memory-usage","sections":[],"depth":2},{"title":"Inference speed","local":"inference-speed","sections":[],"depth":2}],"depth":1}';function he(Z){return te(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Ge extends ne{constructor(a){super(),oe(this,a,he,we,ae,{})}}export{Ge as component};
