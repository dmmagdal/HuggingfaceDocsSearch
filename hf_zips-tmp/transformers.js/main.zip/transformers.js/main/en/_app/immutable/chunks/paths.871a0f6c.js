var s;const t=((s=globalThis.__sveltekit_ed4t7h)==null?void 0:s.base)??"/docs/transformers.js/main/en";var e;const a=((e=globalThis.__sveltekit_ed4t7h)==null?void 0:e.assets)??t;export{a,t as b};
