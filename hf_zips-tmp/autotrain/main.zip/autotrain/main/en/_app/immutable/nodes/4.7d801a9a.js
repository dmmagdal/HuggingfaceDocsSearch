import{s as O,n as q,o as K}from"../chunks/scheduler.7b8d42e8.js";import{S as ss,i as as,g as i,s as n,r as N,A as ts,h as r,f as t,c as e,j as L,u as S,x as b,k as P,y as ls,a as l,v as C,d as A,t as F,w as H}from"../chunks/index.0671836c.js";import{C as D}from"../chunks/CodeBlock.c4671c67.js";import{H as ns,E as es}from"../chunks/EditOnGithub.15b2d305.js";function ps(Q){let p,J,y,w,c,B,o,Y="AutoTrain Configs are the way to use and train models using AutoTrain locally.",U,h,V="Once you have installed AutoTrain Advanced, you can use the following command to train models using AutoTrain config files:",E,m,_,d,X=`Example configurations for all tasks can be found in the <code>configs</code> directory of
the <a href="https://github.com/huggingface/autotrain-advanced" rel="nofollow">AutoTrain Advanced GitHub repository</a>.`,W,j,z="Here is an example of an AutoTrain config file:",G,u,I,M,k=`In this config, we are finetuning the <code>meta-llama/Meta-Llama-3-8B-Instruct</code> model
on the <code>argilla/distilabel-capybara-dpo-7k-binarized</code> dataset using the <code>orpo</code>
trainer for 3 epochs with a batch size of 2 and a learning rate of <code>3e-5</code>.
More information on the available parameters can be found in the <em>Data Formats and Parameters</em> section.`,Z,f,R=`In case you dont want to push the model to hub, you can set <code>push_to_hub</code> to <code>false</code> in the config file.
If not pushing the model to hub username and token are not required. Note: they may still be needed
if you are trying to access gated models or datasets.`,$,T,v,g,x;return c=new ns({props:{title:"AutoTrain Configs",local:"autotrain-configs",headingTag:"h1"}}),m=new D({props:{code:"JTI0JTIwZXhwb3J0JTIwSEZfVVNFUk5BTUUlM0R5b3VyX2h1Z2dpbmdfZmFjZV91c2VybmFtZSUwQSUyNCUyMGV4cG9ydCUyMEhGX1RPS0VOJTNEeW91cl9odWdnaW5nX2ZhY2Vfd3JpdGVfdG9rZW4lMEElMEElMjQlMjBhdXRvdHJhaW4lMjAtLWNvbmZpZyUyMHBhdGglMkZ0byUyRmNvbmZpZy55YW1s",highlighted:`$ <span class="hljs-built_in">export</span> HF_USERNAME=your_hugging_face_username
$ <span class="hljs-built_in">export</span> HF_TOKEN=your_hugging_face_write_token

$ autotrain --config path/to/config.yaml`,wrap:!1}}),u=new D({props:{code:"dGFzayUzQSUyMGxsbSUwQWJhc2VfbW9kZWwlM0ElMjBtZXRhLWxsYW1hJTJGTWV0YS1MbGFtYS0zLThCLUluc3RydWN0JTBBcHJvamVjdF9uYW1lJTNBJTIwYXV0b3RyYWluLWxsYW1hMy04Yi1vcnBvJTBBbG9nJTNBJTIwdGVuc29yYm9hcmQlMEFiYWNrZW5kJTNBJTIwbG9jYWwlMEElMEFkYXRhJTNBJTBBJTIwJTIwcGF0aCUzQSUyMGFyZ2lsbGElMkZkaXN0aWxhYmVsLWNhcHliYXJhLWRwby03ay1iaW5hcml6ZWQlMEElMjAlMjB0cmFpbl9zcGxpdCUzQSUyMHRyYWluJTBBJTIwJTIwdmFsaWRfc3BsaXQlM0ElMjBudWxsJTBBJTIwJTIwY2hhdF90ZW1wbGF0ZSUzQSUyMGNoYXRtbCUwQSUyMCUyMGNvbHVtbl9tYXBwaW5nJTNBJTBBJTIwJTIwJTIwJTIwdGV4dF9jb2x1bW4lM0ElMjBjaG9zZW4lMEElMjAlMjAlMjAlMjByZWplY3RlZF90ZXh0X2NvbHVtbiUzQSUyMHJlamVjdGVkJTBBJTBBcGFyYW1zJTNBJTBBJTIwJTIwdHJhaW5lciUzQSUyMG9ycG8lMEElMjAlMjBibG9ja19zaXplJTNBJTIwMTAyNCUwQSUyMCUyMG1vZGVsX21heF9sZW5ndGglM0ElMjAyMDQ4JTBBJTIwJTIwbWF4X3Byb21wdF9sZW5ndGglM0ElMjA1MTIlMEElMjAlMjBlcG9jaHMlM0ElMjAzJTBBJTIwJTIwYmF0Y2hfc2l6ZSUzQSUyMDIlMEElMjAlMjBsciUzQSUyMDNlLTUlMEElMjAlMjBwZWZ0JTNBJTIwdHJ1ZSUwQSUyMCUyMHF1YW50aXphdGlvbiUzQSUyMGludDQlMEElMjAlMjB0YXJnZXRfbW9kdWxlcyUzQSUyMGFsbC1saW5lYXIlMEElMjAlMjBwYWRkaW5nJTNBJTIwcmlnaHQlMEElMjAlMjBvcHRpbWl6ZXIlM0ElMjBhZGFtd190b3JjaCUwQSUyMCUyMHNjaGVkdWxlciUzQSUyMGxpbmVhciUwQSUyMCUyMGdyYWRpZW50X2FjY3VtdWxhdGlvbiUzQSUyMDQlMEElMjAlMjBtaXhlZF9wcmVjaXNpb24lM0ElMjBiZjE2JTBBJTBBaHViJTNBJTBBJTIwJTIwdXNlcm5hbWUlM0ElMjAlMjQlN0JIRl9VU0VSTkFNRSU3RCUwQSUyMCUyMHRva2VuJTNBJTIwJTI0JTdCSEZfVE9LRU4lN0QlMEElMjAlMjBwdXNoX3RvX2h1YiUzQSUyMHRydWU=",highlighted:`<span class="hljs-attr">task:</span> <span class="hljs-string">llm</span>
<span class="hljs-attr">base_model:</span> <span class="hljs-string">meta-llama/Meta-Llama-3-8B-Instruct</span>
<span class="hljs-attr">project_name:</span> <span class="hljs-string">autotrain-llama3-8b-orpo</span>
<span class="hljs-attr">log:</span> <span class="hljs-string">tensorboard</span>
<span class="hljs-attr">backend:</span> <span class="hljs-string">local</span>

<span class="hljs-attr">data:</span>
  <span class="hljs-attr">path:</span> <span class="hljs-string">argilla/distilabel-capybara-dpo-7k-binarized</span>
  <span class="hljs-attr">train_split:</span> <span class="hljs-string">train</span>
  <span class="hljs-attr">valid_split:</span> <span class="hljs-literal">null</span>
  <span class="hljs-attr">chat_template:</span> <span class="hljs-string">chatml</span>
  <span class="hljs-attr">column_mapping:</span>
    <span class="hljs-attr">text_column:</span> <span class="hljs-string">chosen</span>
    <span class="hljs-attr">rejected_text_column:</span> <span class="hljs-string">rejected</span>

<span class="hljs-attr">params:</span>
  <span class="hljs-attr">trainer:</span> <span class="hljs-string">orpo</span>
  <span class="hljs-attr">block_size:</span> <span class="hljs-number">1024</span>
  <span class="hljs-attr">model_max_length:</span> <span class="hljs-number">2048</span>
  <span class="hljs-attr">max_prompt_length:</span> <span class="hljs-number">512</span>
  <span class="hljs-attr">epochs:</span> <span class="hljs-number">3</span>
  <span class="hljs-attr">batch_size:</span> <span class="hljs-number">2</span>
  <span class="hljs-attr">lr:</span> <span class="hljs-number">3e-5</span>
  <span class="hljs-attr">peft:</span> <span class="hljs-literal">true</span>
  <span class="hljs-attr">quantization:</span> <span class="hljs-string">int4</span>
  <span class="hljs-attr">target_modules:</span> <span class="hljs-string">all-linear</span>
  <span class="hljs-attr">padding:</span> <span class="hljs-string">right</span>
  <span class="hljs-attr">optimizer:</span> <span class="hljs-string">adamw_torch</span>
  <span class="hljs-attr">scheduler:</span> <span class="hljs-string">linear</span>
  <span class="hljs-attr">gradient_accumulation:</span> <span class="hljs-number">4</span>
  <span class="hljs-attr">mixed_precision:</span> <span class="hljs-string">bf16</span>

<span class="hljs-attr">hub:</span>
  <span class="hljs-attr">username:</span> <span class="hljs-string">\${HF_USERNAME}</span>
  <span class="hljs-attr">token:</span> <span class="hljs-string">\${HF_TOKEN}</span>
  <span class="hljs-attr">push_to_hub:</span> <span class="hljs-literal">true</span>`,wrap:!1}}),T=new es({props:{source:"https://github.com/huggingface/autotrain-advanced/blob/main/docs/source/config.mdx"}}),{c(){p=i("meta"),J=n(),y=i("p"),w=n(),N(c.$$.fragment),B=n(),o=i("p"),o.textContent=Y,U=n(),h=i("p"),h.textContent=V,E=n(),N(m.$$.fragment),_=n(),d=i("p"),d.innerHTML=X,W=n(),j=i("p"),j.textContent=z,G=n(),N(u.$$.fragment),I=n(),M=i("p"),M.innerHTML=k,Z=n(),f=i("p"),f.innerHTML=R,$=n(),N(T.$$.fragment),v=n(),g=i("p"),this.h()},l(s){const a=ts("svelte-u9bgzb",document.head);p=r(a,"META",{name:!0,content:!0}),a.forEach(t),J=e(s),y=r(s,"P",{}),L(y).forEach(t),w=e(s),S(c.$$.fragment,s),B=e(s),o=r(s,"P",{"data-svelte-h":!0}),b(o)!=="svelte-1eim3ay"&&(o.textContent=Y),U=e(s),h=r(s,"P",{"data-svelte-h":!0}),b(h)!=="svelte-vg07k5"&&(h.textContent=V),E=e(s),S(m.$$.fragment,s),_=e(s),d=r(s,"P",{"data-svelte-h":!0}),b(d)!=="svelte-g36qrt"&&(d.innerHTML=X),W=e(s),j=r(s,"P",{"data-svelte-h":!0}),b(j)!=="svelte-w9dhtm"&&(j.textContent=z),G=e(s),S(u.$$.fragment,s),I=e(s),M=r(s,"P",{"data-svelte-h":!0}),b(M)!=="svelte-krc8fr"&&(M.innerHTML=k),Z=e(s),f=r(s,"P",{"data-svelte-h":!0}),b(f)!=="svelte-i1s9p9"&&(f.innerHTML=R),$=e(s),S(T.$$.fragment,s),v=e(s),g=r(s,"P",{}),L(g).forEach(t),this.h()},h(){P(p,"name","hf:doc:metadata"),P(p,"content",is)},m(s,a){ls(document.head,p),l(s,J,a),l(s,y,a),l(s,w,a),C(c,s,a),l(s,B,a),l(s,o,a),l(s,U,a),l(s,h,a),l(s,E,a),C(m,s,a),l(s,_,a),l(s,d,a),l(s,W,a),l(s,j,a),l(s,G,a),C(u,s,a),l(s,I,a),l(s,M,a),l(s,Z,a),l(s,f,a),l(s,$,a),C(T,s,a),l(s,v,a),l(s,g,a),x=!0},p:q,i(s){x||(A(c.$$.fragment,s),A(m.$$.fragment,s),A(u.$$.fragment,s),A(T.$$.fragment,s),x=!0)},o(s){F(c.$$.fragment,s),F(m.$$.fragment,s),F(u.$$.fragment,s),F(T.$$.fragment,s),x=!1},d(s){s&&(t(J),t(y),t(w),t(B),t(o),t(U),t(h),t(E),t(_),t(d),t(W),t(j),t(G),t(I),t(M),t(Z),t(f),t($),t(v),t(g)),t(p),H(c,s),H(m,s),H(u,s),H(T,s)}}}const is='{"title":"AutoTrain Configs","local":"autotrain-configs","sections":[],"depth":1}';function rs(Q){return K(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class ds extends ss{constructor(p){super(),as(this,p,rs,ps,O,{})}}export{ds as component};
