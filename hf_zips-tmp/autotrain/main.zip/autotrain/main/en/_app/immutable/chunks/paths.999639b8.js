var s;const t=((s=globalThis.__sveltekit_nq77m8)==null?void 0:s.base)??"/docs/autotrain/main/en";var a;const e=((a=globalThis.__sveltekit_nq77m8)==null?void 0:a.assets)??t;export{e as a,t as b};
