var s;const a=((s=globalThis.__sveltekit_1wy9yhi)==null?void 0:s.base)??"/docs/google-cloud/main/en";var e;const o=((e=globalThis.__sveltekit_1wy9yhi)==null?void 0:e.assets)??a;export{o as a,a as b};
