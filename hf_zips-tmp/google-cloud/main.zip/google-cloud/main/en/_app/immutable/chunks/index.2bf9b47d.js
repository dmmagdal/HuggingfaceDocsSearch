var Zt=Object.defineProperty;var Gt=(e,t,a)=>t in e?Zt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a;var _=(e,t,a)=>(Gt(e,typeof t!="symbol"?t+"":t,a),a);import{s as Ke,n as Me}from"./scheduler.b108d059.js";import{S as Je,i as Qe,B as ft,C as ht,j as L,f as A,k as b,a as J,y as T,e as gt,p as ea,t as ee,b as ta,d as te,g as $,r as de,s as ae,m as pe,h as D,u as ue,c as ie,n as me,v as fe,o as he,w as ge,x as Ne}from"./index.008de539.js";function aa(e){let t,a;return{c(){t=ft("svg"),a=ft("path"),this.h()},l(i){t=ht(i,"svg",{class:!0,xmlns:!0,"xmlns:xlink":!0,"aria-hidden":!0,role:!0,width:!0,height:!0,preserveAspectRatio:!0,viewBox:!0});var n=L(t);a=ht(n,"path",{d:!0,fill:!0}),L(a).forEach(A),n.forEach(A),this.h()},h(){b(a,"d","M167.594 88.393a8.001 8.001 0 0 1 0 11.314l-67.882 67.882a8 8 0 1 1-11.314-11.315l67.882-67.881a8.003 8.003 0 0 1 11.314 0zm-28.287 84.86l-28.284 28.284a40 40 0 0 1-56.567-56.567l28.284-28.284a8 8 0 0 0-11.315-11.315l-28.284 28.284a56 56 0 0 0 79.196 79.197l28.285-28.285a8 8 0 1 0-11.315-11.314zM212.852 43.14a56.002 56.002 0 0 0-79.196 0l-28.284 28.284a8 8 0 1 0 11.314 11.314l28.284-28.284a40 40 0 0 1 56.568 56.567l-28.285 28.285a8 8 0 0 0 11.315 11.314l28.284-28.284a56.065 56.065 0 0 0 0-79.196z"),b(a,"fill","currentColor"),b(t,"class",e[0]),b(t,"xmlns","http://www.w3.org/2000/svg"),b(t,"xmlns:xlink","http://www.w3.org/1999/xlink"),b(t,"aria-hidden","true"),b(t,"role","img"),b(t,"width","1em"),b(t,"height","1em"),b(t,"preserveAspectRatio","xMidYMid meet"),b(t,"viewBox","0 0 256 256")},m(i,n){J(i,t,n),T(t,a)},p(i,[n]){n&1&&b(t,"class",i[0])},i:Me,o:Me,d(i){i&&A(t)}}}function ia(e,t,a){let{classNames:i=""}=t;return e.$$set=n=>{"classNames"in n&&a(0,i=n.classNames)},[i]}class be extends Je{constructor(t){super(),Qe(this,t,ia,aa,Ke,{classNames:0})}}function na(e){let t,a,i,n,o,r,p,u,d;return n=new be({}),{c(){t=$("h6"),a=$("a"),i=$("span"),de(n.$$.fragment),r=ae(),p=$("span"),u=pe(e[0]),this.h()},l(c){t=D(c,"H6",{class:!0});var l=L(t);a=D(l,"A",{id:!0,class:!0,href:!0});var f=L(a);i=D(f,"SPAN",{});var y=L(i);ue(n.$$.fragment,y),y.forEach(A),f.forEach(A),r=ie(l),p=D(l,"SPAN",{});var k=L(p);u=me(k,e[0]),k.forEach(A),l.forEach(A),this.h()},h(){b(a,"id",e[1]),b(a,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),b(a,"href",o="#"+e[1]),b(t,"class","relative group")},m(c,l){J(c,t,l),T(t,a),T(a,i),fe(n,i,null),T(t,r),T(t,p),T(p,u),d=!0},p(c,l){(!d||l&2)&&b(a,"id",c[1]),(!d||l&2&&o!==(o="#"+c[1]))&&b(a,"href",o),(!d||l&1)&&he(u,c[0])},i(c){d||(te(n.$$.fragment,c),d=!0)},o(c){ee(n.$$.fragment,c),d=!1},d(c){c&&A(t),ge(n)}}}function oa(e){let t,a,i,n,o,r,p,u,d;return n=new be({}),{c(){t=$("h5"),a=$("a"),i=$("span"),de(n.$$.fragment),r=ae(),p=$("span"),u=pe(e[0]),this.h()},l(c){t=D(c,"H5",{class:!0});var l=L(t);a=D(l,"A",{id:!0,class:!0,href:!0});var f=L(a);i=D(f,"SPAN",{});var y=L(i);ue(n.$$.fragment,y),y.forEach(A),f.forEach(A),r=ie(l),p=D(l,"SPAN",{});var k=L(p);u=me(k,e[0]),k.forEach(A),l.forEach(A),this.h()},h(){b(a,"id",e[1]),b(a,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),b(a,"href",o="#"+e[1]),b(t,"class","relative group")},m(c,l){J(c,t,l),T(t,a),T(a,i),fe(n,i,null),T(t,r),T(t,p),T(p,u),d=!0},p(c,l){(!d||l&2)&&b(a,"id",c[1]),(!d||l&2&&o!==(o="#"+c[1]))&&b(a,"href",o),(!d||l&1)&&he(u,c[0])},i(c){d||(te(n.$$.fragment,c),d=!0)},o(c){ee(n.$$.fragment,c),d=!1},d(c){c&&A(t),ge(n)}}}function ra(e){let t,a,i,n,o,r,p,u,d;return n=new be({}),{c(){t=$("h4"),a=$("a"),i=$("span"),de(n.$$.fragment),r=ae(),p=$("span"),u=pe(e[0]),this.h()},l(c){t=D(c,"H4",{class:!0});var l=L(t);a=D(l,"A",{id:!0,class:!0,href:!0});var f=L(a);i=D(f,"SPAN",{});var y=L(i);ue(n.$$.fragment,y),y.forEach(A),f.forEach(A),r=ie(l),p=D(l,"SPAN",{});var k=L(p);u=me(k,e[0]),k.forEach(A),l.forEach(A),this.h()},h(){b(a,"id",e[1]),b(a,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),b(a,"href",o="#"+e[1]),b(t,"class","relative group")},m(c,l){J(c,t,l),T(t,a),T(a,i),fe(n,i,null),T(t,r),T(t,p),T(p,u),d=!0},p(c,l){(!d||l&2)&&b(a,"id",c[1]),(!d||l&2&&o!==(o="#"+c[1]))&&b(a,"href",o),(!d||l&1)&&he(u,c[0])},i(c){d||(te(n.$$.fragment,c),d=!0)},o(c){ee(n.$$.fragment,c),d=!1},d(c){c&&A(t),ge(n)}}}function sa(e){let t,a,i,n,o,r,p,u,d;return n=new be({}),{c(){t=$("h3"),a=$("a"),i=$("span"),de(n.$$.fragment),r=ae(),p=$("span"),u=pe(e[0]),this.h()},l(c){t=D(c,"H3",{class:!0});var l=L(t);a=D(l,"A",{id:!0,class:!0,href:!0});var f=L(a);i=D(f,"SPAN",{});var y=L(i);ue(n.$$.fragment,y),y.forEach(A),f.forEach(A),r=ie(l),p=D(l,"SPAN",{});var k=L(p);u=me(k,e[0]),k.forEach(A),l.forEach(A),this.h()},h(){b(a,"id",e[1]),b(a,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),b(a,"href",o="#"+e[1]),b(t,"class","relative group")},m(c,l){J(c,t,l),T(t,a),T(a,i),fe(n,i,null),T(t,r),T(t,p),T(p,u),d=!0},p(c,l){(!d||l&2)&&b(a,"id",c[1]),(!d||l&2&&o!==(o="#"+c[1]))&&b(a,"href",o),(!d||l&1)&&he(u,c[0])},i(c){d||(te(n.$$.fragment,c),d=!0)},o(c){ee(n.$$.fragment,c),d=!1},d(c){c&&A(t),ge(n)}}}function la(e){let t,a,i,n,o,r,p,u,d;return n=new be({}),{c(){t=$("h2"),a=$("a"),i=$("span"),de(n.$$.fragment),r=ae(),p=$("span"),u=pe(e[0]),this.h()},l(c){t=D(c,"H2",{class:!0});var l=L(t);a=D(l,"A",{id:!0,class:!0,href:!0});var f=L(a);i=D(f,"SPAN",{});var y=L(i);ue(n.$$.fragment,y),y.forEach(A),f.forEach(A),r=ie(l),p=D(l,"SPAN",{});var k=L(p);u=me(k,e[0]),k.forEach(A),l.forEach(A),this.h()},h(){b(a,"id",e[1]),b(a,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),b(a,"href",o="#"+e[1]),b(t,"class","relative group")},m(c,l){J(c,t,l),T(t,a),T(a,i),fe(n,i,null),T(t,r),T(t,p),T(p,u),d=!0},p(c,l){(!d||l&2)&&b(a,"id",c[1]),(!d||l&2&&o!==(o="#"+c[1]))&&b(a,"href",o),(!d||l&1)&&he(u,c[0])},i(c){d||(te(n.$$.fragment,c),d=!0)},o(c){ee(n.$$.fragment,c),d=!1},d(c){c&&A(t),ge(n)}}}function ca(e){let t,a,i,n,o,r,p,u,d;return n=new be({}),{c(){t=$("h1"),a=$("a"),i=$("span"),de(n.$$.fragment),r=ae(),p=$("span"),u=pe(e[0]),this.h()},l(c){t=D(c,"H1",{class:!0});var l=L(t);a=D(l,"A",{id:!0,class:!0,href:!0});var f=L(a);i=D(f,"SPAN",{});var y=L(i);ue(n.$$.fragment,y),y.forEach(A),f.forEach(A),r=ie(l),p=D(l,"SPAN",{});var k=L(p);u=me(k,e[0]),k.forEach(A),l.forEach(A),this.h()},h(){b(a,"id",e[1]),b(a,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),b(a,"href",o="#"+e[1]),b(t,"class","relative group")},m(c,l){J(c,t,l),T(t,a),T(a,i),fe(n,i,null),T(t,r),T(t,p),T(p,u),d=!0},p(c,l){(!d||l&2)&&b(a,"id",c[1]),(!d||l&2&&o!==(o="#"+c[1]))&&b(a,"href",o),(!d||l&1)&&he(u,c[0])},i(c){d||(te(n.$$.fragment,c),d=!0)},o(c){ee(n.$$.fragment,c),d=!1},d(c){c&&A(t),ge(n)}}}function da(e){let t,a,i,n;const o=[ca,la,sa,ra,oa,na],r=[];function p(u,d){return u[2]==="h1"?0:u[2]==="h2"?1:u[2]==="h3"?2:u[2]==="h4"?3:u[2]==="h5"?4:5}return t=p(e),a=r[t]=o[t](e),{c(){a.c(),i=gt()},l(u){a.l(u),i=gt()},m(u,d){r[t].m(u,d),J(u,i,d),n=!0},p(u,[d]){let c=t;t=p(u),t===c?r[t].p(u,d):(ea(),ee(r[c],1,1,()=>{r[c]=null}),ta(),a=r[t],a?a.p(u,d):(a=r[t]=o[t](u),a.c()),te(a,1),a.m(i.parentNode,i))},i(u){n||(te(a),n=!0)},o(u){ee(a),n=!1},d(u){u&&A(i),r[t].d(u)}}}function pa(e,t,a){let{title:i}=t,{local:n}=t,{headingTag:o}=t;return e.$$set=r=>{"title"in r&&a(0,i=r.title),"local"in r&&a(1,n=r.local),"headingTag"in r&&a(2,o=r.headingTag)},[i,n,o]}class pl extends Je{constructor(t){super(),Qe(this,t,pa,da,Ke,{title:0,local:1,headingTag:2})}}function ua(e){let t,a,i="<",n,o,r=">",p,u,d='<span class="underline ml-1.5">Update</span> on GitHub';return{c(){t=$("a"),a=$("span"),a.textContent=i,n=ae(),o=$("span"),o.textContent=r,p=ae(),u=$("span"),u.innerHTML=d,this.h()},l(c){t=D(c,"A",{class:!0,href:!0,target:!0});var l=L(t);a=D(l,"SPAN",{"data-svelte-h":!0}),Ne(a)!=="svelte-1kd6by1"&&(a.textContent=i),n=ie(l),o=D(l,"SPAN",{"data-svelte-h":!0}),Ne(o)!=="svelte-x0xyl0"&&(o.textContent=r),p=ie(l),u=D(l,"SPAN",{"data-svelte-h":!0}),Ne(u)!=="svelte-1dajgef"&&(u.innerHTML=d),l.forEach(A),this.h()},h(){b(t,"class","!text-gray-400 !no-underline text-sm flex items-center not-prose mt-4"),b(t,"href",e[0]),b(t,"target","_blank")},m(c,l){J(c,t,l),T(t,a),T(t,n),T(t,o),T(t,p),T(t,u)},p(c,[l]){l&1&&b(t,"href",c[0])},i:Me,o:Me,d(c){c&&A(t)}}}function ma(e,t,a){let{source:i=""}=t;return e.$$set=n=>{"source"in n&&a(0,i=n.source)},[i]}class ul extends Je{constructor(t){super(),Qe(this,t,ma,ua,Ke,{source:0})}}var s=Object.freeze({Text:"Text",NumericLiteral:"NumericLiteral",BooleanLiteral:"BooleanLiteral",NullLiteral:"NullLiteral",StringLiteral:"StringLiteral",Identifier:"Identifier",Equals:"Equals",OpenParen:"OpenParen",CloseParen:"CloseParen",OpenStatement:"OpenStatement",CloseStatement:"CloseStatement",OpenExpression:"OpenExpression",CloseExpression:"CloseExpression",OpenSquareBracket:"OpenSquareBracket",CloseSquareBracket:"CloseSquareBracket",OpenCurlyBracket:"OpenCurlyBracket",CloseCurlyBracket:"CloseCurlyBracket",Comma:"Comma",Dot:"Dot",Colon:"Colon",Pipe:"Pipe",CallOperator:"CallOperator",AdditiveBinaryOperator:"AdditiveBinaryOperator",MultiplicativeBinaryOperator:"MultiplicativeBinaryOperator",ComparisonBinaryOperator:"ComparisonBinaryOperator",UnaryOperator:"UnaryOperator",Set:"Set",If:"If",For:"For",In:"In",Is:"Is",NotIn:"NotIn",Else:"Else",EndSet:"EndSet",EndIf:"EndIf",ElseIf:"ElseIf",EndFor:"EndFor",And:"And",Or:"Or",Not:"UnaryOperator",Macro:"Macro",EndMacro:"EndMacro"}),bt=Object.freeze({set:s.Set,for:s.For,in:s.In,is:s.Is,if:s.If,else:s.Else,endset:s.EndSet,endif:s.EndIf,elif:s.ElseIf,endfor:s.EndFor,and:s.And,or:s.Or,not:s.Not,"not in":s.NotIn,macro:s.Macro,endmacro:s.EndMacro,true:s.BooleanLiteral,false:s.BooleanLiteral,none:s.NullLiteral,True:s.BooleanLiteral,False:s.BooleanLiteral,None:s.NullLiteral}),ne=class{constructor(e,t){this.value=e,this.type=t}};function yt(e){return/\w/.test(e)}function je(e){return/[0-9]/.test(e)}var fa=[["{%",s.OpenStatement],["%}",s.CloseStatement],["{{",s.OpenExpression],["}}",s.CloseExpression],["(",s.OpenParen],[")",s.CloseParen],["{",s.OpenCurlyBracket],["}",s.CloseCurlyBracket],["[",s.OpenSquareBracket],["]",s.CloseSquareBracket],[",",s.Comma],[".",s.Dot],[":",s.Colon],["|",s.Pipe],["<=",s.ComparisonBinaryOperator],[">=",s.ComparisonBinaryOperator],["==",s.ComparisonBinaryOperator],["!=",s.ComparisonBinaryOperator],["<",s.ComparisonBinaryOperator],[">",s.ComparisonBinaryOperator],["+",s.AdditiveBinaryOperator],["-",s.AdditiveBinaryOperator],["*",s.MultiplicativeBinaryOperator],["/",s.MultiplicativeBinaryOperator],["%",s.MultiplicativeBinaryOperator],["=",s.Equals]],ha=new Map([["n",`
`],["t","	"],["r","\r"],["b","\b"],["f","\f"],["v","\v"],["'","'"],['"','"'],["\\","\\"]]);function ga(e,t={}){return e.endsWith(`
`)&&(e=e.slice(0,-1)),e=e.replace(/{#.*?#}/gs,"{##}"),t.lstrip_blocks&&(e=e.replace(/^[ \t]*({[#%])/gm,"$1")),t.trim_blocks&&(e=e.replace(/([#%]})\n/g,"$1")),e.replace(/{##}/g,"").replace(/-%}\s*/g,"%}").replace(/\s*{%-/g,"{%").replace(/-}}\s*/g,"}}").replace(/\s*{{-/g,"{{")}function ba(e,t={}){var r,p,u;const a=[],i=ga(e,t);let n=0;const o=d=>{let c="";for(;d(i[n]);){if(i[n]==="\\"){if(++n,n>=i.length)throw new SyntaxError("Unexpected end of input");const l=i[n++],f=ha.get(l);if(f===void 0)throw new SyntaxError(`Unexpected escaped character: ${l}`);c+=f;continue}if(c+=i[n++],n>=i.length)throw new SyntaxError("Unexpected end of input")}return c};e:for(;n<i.length;){const d=(r=a.at(-1))==null?void 0:r.type;if(d===void 0||d===s.CloseStatement||d===s.CloseExpression){let l="";for(;n<i.length&&!(i[n]==="{"&&(i[n+1]==="%"||i[n+1]==="{"));)l+=i[n++];if(l.length>0){a.push(new ne(l,s.Text));continue}}o(l=>/\s/.test(l));const c=i[n];if(c==="-"||c==="+"){const l=(p=a.at(-1))==null?void 0:p.type;if(l===s.Text||l===void 0)throw new SyntaxError(`Unexpected character: ${c}`);switch(l){case s.Identifier:case s.NumericLiteral:case s.BooleanLiteral:case s.NullLiteral:case s.StringLiteral:case s.CloseParen:case s.CloseSquareBracket:break;default:{++n;const f=o(je);a.push(new ne(`${c}${f}`,f.length>0?s.NumericLiteral:s.UnaryOperator));continue}}}for(const[l,f]of fa)if(i.slice(n,n+l.length)===l){a.push(new ne(l,f)),n+=l.length;continue e}if(c==="'"||c==='"'){++n;const l=o(f=>f!==c);a.push(new ne(l,s.StringLiteral)),++n;continue}if(je(c)){const l=o(je);a.push(new ne(l,s.NumericLiteral));continue}if(yt(c)){const l=o(yt),f=Object.hasOwn(bt,l)?bt[l]:s.Identifier;f===s.In&&((u=a.at(-1))==null?void 0:u.type)===s.Not?(a.pop(),a.push(new ne("not in",s.NotIn))):a.push(new ne(l,f));continue}throw new SyntaxError(`Unexpected character: ${c}`)}return a}var ye=class{constructor(){_(this,"type","Statement")}},ya=class extends ye{constructor(t){super();_(this,"type","Program");this.body=t}},wt=class extends ye{constructor(t,a,i){super();_(this,"type","If");this.test=t,this.body=a,this.alternate=i}},wa=class extends ye{constructor(t,a,i,n){super();_(this,"type","For");this.loopvar=t,this.iterable=a,this.body=i,this.defaultBlock=n}},vt=class extends ye{constructor(t,a,i){super();_(this,"type","Set");this.assignee=t,this.value=a,this.body=i}},va=class extends ye{constructor(t,a,i){super();_(this,"type","Macro");this.name=t,this.args=a,this.body=i}},W=class extends ye{constructor(){super(...arguments);_(this,"type","Expression")}},_a=class extends W{constructor(t,a,i){super();_(this,"type","MemberExpression");this.object=t,this.property=a,this.computed=i}},xa=class extends W{constructor(t,a){super();_(this,"type","CallExpression");this.callee=t,this.args=a}},oe=class extends W{constructor(t){super();_(this,"type","Identifier");this.value=t}},re=class extends W{constructor(t){super();_(this,"type","Literal");this.value=t}},ka=class extends re{constructor(){super(...arguments);_(this,"type","NumericLiteral")}},_t=class extends re{constructor(){super(...arguments);_(this,"type","StringLiteral")}},xt=class extends re{constructor(){super(...arguments);_(this,"type","BooleanLiteral")}},kt=class extends re{constructor(){super(...arguments);_(this,"type","NullLiteral")}},Aa=class extends re{constructor(){super(...arguments);_(this,"type","ArrayLiteral")}},At=class extends re{constructor(){super(...arguments);_(this,"type","TupleLiteral")}},Ta=class extends re{constructor(){super(...arguments);_(this,"type","ObjectLiteral")}},_e=class extends W{constructor(t,a,i){super();_(this,"type","BinaryExpression");this.operator=t,this.left=a,this.right=i}},Sa=class extends W{constructor(t,a){super();_(this,"type","FilterExpression");this.operand=t,this.filter=a}},Ia=class extends W{constructor(t,a){super();_(this,"type","SelectExpression");this.iterable=t,this.test=a}},Ea=class extends W{constructor(t,a,i){super();_(this,"type","TestExpression");this.operand=t,this.negate=a,this.test=i}},Ca=class extends W{constructor(t,a){super();_(this,"type","UnaryExpression");this.operator=t,this.argument=a}},Ma=class extends W{constructor(t=void 0,a=void 0,i=void 0){super();_(this,"type","SliceExpression");this.start=t,this.stop=a,this.step=i}},Ra=class extends W{constructor(t,a){super();_(this,"type","KeywordArgumentExpression");this.key=t,this.value=a}};function $a(e){const t=new ya([]);let a=0;function i(m,h){const g=e[a++];if(!g||g.type!==m)throw new Error(`Parser Error: ${h}. ${g.type} !== ${m}.`);return g}function n(){switch(e[a].type){case s.Text:return p();case s.OpenStatement:return u();case s.OpenExpression:return d();default:throw new SyntaxError(`Unexpected token type: ${e[a].type}`)}}function o(...m){return a+m.length<=e.length&&m.some((h,g)=>h!==e[a+g].type)}function r(...m){return a+m.length<=e.length&&m.every((h,g)=>h===e[a+g].type)}function p(){return new _t(i(s.Text,"Expected text token").value)}function u(){i(s.OpenStatement,"Expected opening statement token");let m;switch(e[a].type){case s.Set:++a,m=c(),i(s.CloseStatement,"Expected closing statement token");break;case s.If:++a,m=l(),i(s.OpenStatement,"Expected {% token"),i(s.EndIf,"Expected endif token"),i(s.CloseStatement,"Expected %} token");break;case s.Macro:++a,m=f(),i(s.OpenStatement,"Expected {% token"),i(s.EndMacro,"Expected endmacro token"),i(s.CloseStatement,"Expected %} token");break;case s.For:++a,m=k(),i(s.OpenStatement,"Expected {% token"),i(s.EndFor,"Expected endfor token"),i(s.CloseStatement,"Expected %} token");break;default:throw new SyntaxError(`Unknown statement type: ${e[a].type}`)}return m}function d(){i(s.OpenExpression,"Expected opening expression token");const m=S();return i(s.CloseExpression,"Expected closing expression token"),m}function c(){var h,g;const m=S();if(r(s.Equals)){++a;const j=S();return new vt(m,j,[])}else{const j=[];for(i(s.CloseStatement,"Expected %} token");!(((h=e[a])==null?void 0:h.type)===s.OpenStatement&&((g=e[a+1])==null?void 0:g.type)===s.EndSet);){const Ie=n();j.push(Ie)}return i(s.OpenStatement,"Expected {% token"),i(s.EndSet,"Expected endset token"),new vt(m,null,j)}}function l(){var j,Ie,lt,ct,dt,pt,ut,mt;const m=S();i(s.CloseStatement,"Expected closing statement token");const h=[],g=[];for(;!(((j=e[a])==null?void 0:j.type)===s.OpenStatement&&(((Ie=e[a+1])==null?void 0:Ie.type)===s.ElseIf||((lt=e[a+1])==null?void 0:lt.type)===s.Else||((ct=e[a+1])==null?void 0:ct.type)===s.EndIf));)h.push(n());if(((dt=e[a])==null?void 0:dt.type)===s.OpenStatement&&((pt=e[a+1])==null?void 0:pt.type)!==s.EndIf)if(++a,r(s.ElseIf))i(s.ElseIf,"Expected elseif token"),g.push(l());else for(i(s.Else,"Expected else token"),i(s.CloseStatement,"Expected closing statement token");!(((ut=e[a])==null?void 0:ut.type)===s.OpenStatement&&((mt=e[a+1])==null?void 0:mt.type)===s.EndIf);)g.push(n());return new wt(m,h,g)}function f(){const m=le();if(m.type!=="Identifier")throw new SyntaxError("Expected identifier following macro statement");const h=Se();i(s.CloseStatement,"Expected closing statement token");const g=[];for(;o(s.OpenStatement,s.EndMacro);)g.push(n());return new va(m,h,g)}function y(m=!1){const h=m?le:S,g=[h()],j=r(s.Comma);for(;j&&(++a,g.push(h()),!!r(s.Comma)););return j?new At(g):g[0]}function k(){const m=y(!0);if(!(m instanceof oe||m instanceof At))throw new SyntaxError(`Expected identifier/tuple for the loop variable, got ${m.type} instead`);i(s.In,"Expected `in` keyword following loop variable");const h=S();i(s.CloseStatement,"Expected closing statement token");const g=[];for(;o(s.OpenStatement,s.EndFor)&&o(s.OpenStatement,s.Else);)g.push(n());const j=[];if(r(s.OpenStatement,s.Else))for(++a,++a,i(s.CloseStatement,"Expected closing statement token");o(s.OpenStatement,s.EndFor);)j.push(n());return new wa(m,h,g,j)}function S(){return N()}function N(){const m=O();if(r(s.If)){++a;const h=O();if(r(s.Else)){++a;const g=O();return new wt(h,[m],[g])}else return new Ia(m,h)}return m}function O(){let m=Z();for(;r(s.Or);){const h=e[a];++a;const g=Z();m=new _e(h,m,g)}return m}function Z(){let m=B();for(;r(s.And);){const h=e[a];++a;const g=B();m=new _e(h,m,g)}return m}function B(){let m;for(;r(s.Not);){const h=e[a];++a;const g=B();m=new Ca(h,g)}return m??we()}function we(){let m=Te();for(;r(s.ComparisonBinaryOperator)||r(s.In)||r(s.NotIn);){const h=e[a];++a;const g=Te();m=new _e(h,m,g)}return m}function Te(){let m=rt();for(;r(s.AdditiveBinaryOperator);){const h=e[a];++a;const g=rt();m=new _e(h,m,g)}return m}function se(){const m=ot(le());return r(s.OpenParen)?ve(m):m}function ve(m){let h=new xa(m,Se());return h=ot(h),r(s.OpenParen)&&(h=ve(h)),h}function Se(){i(s.OpenParen,"Expected opening parenthesis for arguments list");const m=Qt();return i(s.CloseParen,"Expected closing parenthesis for arguments list"),m}function Qt(){const m=[];for(;!r(s.CloseParen);){let h=S();if(r(s.Equals)){if(++a,!(h instanceof oe))throw new SyntaxError("Expected identifier for keyword argument");const g=S();h=new Ra(h,g)}m.push(h),r(s.Comma)&&++a}return m}function Xt(){const m=[];let h=!1;for(;!r(s.CloseSquareBracket);)r(s.Colon)?(m.push(void 0),++a,h=!0):(m.push(S()),r(s.Colon)&&(++a,h=!0));if(m.length===0)throw new SyntaxError("Expected at least one argument for member/slice expression");if(h){if(m.length>3)throw new SyntaxError("Expected 0-3 arguments for slice expression");return new Ma(...m)}return m[0]}function ot(m){for(;r(s.Dot)||r(s.OpenSquareBracket);){const h=e[a];++a;let g;const j=h.type!==s.Dot;if(j)g=Xt(),i(s.CloseSquareBracket,"Expected closing square bracket");else if(g=le(),g.type!=="Identifier")throw new SyntaxError("Expected identifier following dot operator");m=new _a(m,g,j)}return m}function rt(){let m=st();for(;r(s.MultiplicativeBinaryOperator);){const h=e[a];++a;const g=st();m=new _e(h,m,g)}return m}function st(){let m=Yt();for(;r(s.Is);){++a;const h=r(s.Not);h&&++a;let g=le();if(g instanceof xt?g=new oe(g.value.toString()):g instanceof kt&&(g=new oe("none")),!(g instanceof oe))throw new SyntaxError("Expected identifier for the test");m=new Ea(m,h,g)}return m}function Yt(){let m=se();for(;r(s.Pipe);){++a;let h=le();if(!(h instanceof oe))throw new SyntaxError("Expected identifier for the filter");r(s.OpenParen)&&(h=ve(h)),m=new Sa(m,h)}return m}function le(){const m=e[a];switch(m.type){case s.NumericLiteral:return++a,new ka(Number(m.value));case s.StringLiteral:return++a,new _t(m.value);case s.BooleanLiteral:return++a,new xt(m.value.toLowerCase()==="true");case s.NullLiteral:return++a,new kt(null);case s.Identifier:return++a,new oe(m.value);case s.OpenParen:{++a;const h=y();if(e[a].type!==s.CloseParen)throw new SyntaxError(`Expected closing parenthesis, got ${e[a].type} instead`);return++a,h}case s.OpenSquareBracket:{++a;const h=[];for(;!r(s.CloseSquareBracket);)h.push(S()),r(s.Comma)&&++a;return++a,new Aa(h)}case s.OpenCurlyBracket:{++a;const h=new Map;for(;!r(s.CloseCurlyBracket);){const g=S();i(s.Colon,"Expected colon between key and value in object literal");const j=S();h.set(g,j),r(s.Comma)&&++a}return++a,new Ta(h)}default:throw new SyntaxError(`Unexpected token: ${m.type}`)}}for(;a<e.length;)t.body.push(n());return t}function Da(e,t,a=1){t===void 0&&(t=e,e=0);const i=[];for(let n=e;n<t;n+=a)i.push(n);return i}function Tt(e,t,a,i=1){const n=Math.sign(i);n>=0?(t=(t??(t=0))<0?Math.max(e.length+t,0):Math.min(t,e.length),a=(a??(a=e.length))<0?Math.max(e.length+a,0):Math.min(a,e.length)):(t=(t??(t=e.length-1))<0?Math.max(e.length+t,-1):Math.min(t,e.length-1),a=(a??(a=-1))<-1?Math.max(e.length+a,-1):Math.min(a,e.length-1));const o=[];for(let r=t;n*r<n*a;r+=i)o.push(e[r]);return o}function Ot(e){return e.replace(/\b\w/g,t=>t.toUpperCase())}var Q=class{constructor(e=void 0){_(this,"type","RuntimeValue");_(this,"value");_(this,"builtins",new Map);this.value=e}__bool__(){return new P(!!this.value)}},E=class extends Q{constructor(){super(...arguments);_(this,"type","NumericValue")}},w=class extends Q{constructor(){super(...arguments);_(this,"type","StringValue");_(this,"builtins",new Map([["upper",new H(()=>new w(this.value.toUpperCase()))],["lower",new H(()=>new w(this.value.toLowerCase()))],["strip",new H(()=>new w(this.value.trim()))],["title",new H(()=>new w(Ot(this.value)))],["length",new E(this.value.length)],["rstrip",new H(()=>new w(this.value.trimEnd()))],["lstrip",new H(()=>new w(this.value.trimStart()))],["split",new H(t=>{const a=t[0]??new z;if(!(a instanceof w||a instanceof z))throw new Error("sep argument must be a string or null");const i=t[1]??new E(-1);if(!(i instanceof E))throw new Error("maxsplit argument must be a number");let n=[];if(a instanceof z){const o=this.value.trimStart();for(const{0:r,index:p}of o.matchAll(/\S+/g)){if(i.value!==-1&&n.length>=i.value&&p!==void 0){n.push(r+o.slice(p+r.length));break}n.push(r)}}else{if(a.value==="")throw new Error("empty separator");n=this.value.split(a.value),i.value!==-1&&n.length>i.value&&n.push(n.splice(i.value).join(a.value))}return new U(n.map(o=>new w(o)))})]]))}},P=class extends Q{constructor(){super(...arguments);_(this,"type","BooleanValue")}},V=class extends Q{constructor(){super(...arguments);_(this,"type","ObjectValue");_(this,"builtins",new Map([["get",new H(([t,a])=>{if(!(t instanceof w))throw new Error(`Object key must be a string: got ${t.type}`);return this.value.get(t.value)??a??new z})],["items",new H(()=>new U(Array.from(this.value.entries()).map(([t,a])=>new U([new w(t),a]))))]]))}__bool__(){return new P(this.value.size>0)}},La=class extends V{constructor(){super(...arguments);_(this,"type","KeywordArgumentsValue")}},U=class extends Q{constructor(){super(...arguments);_(this,"type","ArrayValue");_(this,"builtins",new Map([["length",new E(this.value.length)]]))}__bool__(){return new P(this.value.length>0)}},Ua=class extends U{constructor(){super(...arguments);_(this,"type","TupleValue")}},H=class extends Q{constructor(){super(...arguments);_(this,"type","FunctionValue")}},z=class extends Q{constructor(){super(...arguments);_(this,"type","NullValue")}},F=class extends Q{constructor(){super(...arguments);_(this,"type","UndefinedValue")}},xe=class{constructor(e){_(this,"variables",new Map([["namespace",new H(e=>{if(e.length===0)return new V(new Map);if(e.length!==1||!(e[0]instanceof V))throw new Error("`namespace` expects either zero arguments or a single object argument");return e[0]})]]));_(this,"tests",new Map([["boolean",e=>e.type==="BooleanValue"],["callable",e=>e instanceof H],["odd",e=>{if(e.type!=="NumericValue")throw new Error(`Cannot apply test "odd" to type: ${e.type}`);return e.value%2!==0}],["even",e=>{if(e.type!=="NumericValue")throw new Error(`Cannot apply test "even" to type: ${e.type}`);return e.value%2===0}],["false",e=>e.type==="BooleanValue"&&!e.value],["true",e=>e.type==="BooleanValue"&&e.value],["none",e=>e.type==="NullValue"],["string",e=>e.type==="StringValue"],["number",e=>e.type==="NumericValue"],["integer",e=>e.type==="NumericValue"&&Number.isInteger(e.value)],["iterable",e=>e.type==="ArrayValue"||e.type==="StringValue"],["mapping",e=>e.type==="ObjectValue"],["lower",e=>{const t=e.value;return e.type==="StringValue"&&t===t.toLowerCase()}],["upper",e=>{const t=e.value;return e.type==="StringValue"&&t===t.toUpperCase()}],["none",e=>e.type==="NullValue"],["defined",e=>e.type!=="UndefinedValue"],["undefined",e=>e.type==="UndefinedValue"],["equalto",(e,t)=>e.value===t.value],["eq",(e,t)=>e.value===t.value]]));this.parent=e}set(e,t){return this.declareVariable(e,Ce(t))}declareVariable(e,t){if(this.variables.has(e))throw new SyntaxError(`Variable already declared: ${e}`);return this.variables.set(e,t),t}setVariable(e,t){return this.variables.set(e,t),t}resolve(e){if(this.variables.has(e))return this;if(this.parent)return this.parent.resolve(e);throw new Error(`Unknown variable: ${e}`)}lookupVariable(e){try{return this.resolve(e).variables.get(e)??new F}catch{return new F}}},Pa=class{constructor(e){_(this,"global");this.global=e??new xe}run(e){return this.evaluate(e,this.global)}evaluateBinaryExpression(e,t){const a=this.evaluate(e.left,t);switch(e.operator.value){case"and":return a.__bool__().value?this.evaluate(e.right,t):a;case"or":return a.__bool__().value?a:this.evaluate(e.right,t)}const i=this.evaluate(e.right,t);switch(e.operator.value){case"==":return new P(a.value==i.value);case"!=":return new P(a.value!=i.value)}if(a instanceof F||i instanceof F)throw new Error("Cannot perform operation on undefined values");if(a instanceof z||i instanceof z)throw new Error("Cannot perform operation on null values");if(a instanceof E&&i instanceof E)switch(e.operator.value){case"+":return new E(a.value+i.value);case"-":return new E(a.value-i.value);case"*":return new E(a.value*i.value);case"/":return new E(a.value/i.value);case"%":return new E(a.value%i.value);case"<":return new P(a.value<i.value);case">":return new P(a.value>i.value);case">=":return new P(a.value>=i.value);case"<=":return new P(a.value<=i.value)}else if(a instanceof U&&i instanceof U)switch(e.operator.value){case"+":return new U(a.value.concat(i.value))}else if(i instanceof U){const n=i.value.find(o=>o.value===a.value)!==void 0;switch(e.operator.value){case"in":return new P(n);case"not in":return new P(!n)}}if(a instanceof w||i instanceof w)switch(e.operator.value){case"+":return new w(a.value.toString()+i.value.toString())}if(a instanceof w&&i instanceof w)switch(e.operator.value){case"in":return new P(i.value.includes(a.value));case"not in":return new P(!i.value.includes(a.value))}if(a instanceof w&&i instanceof V)switch(e.operator.value){case"in":return new P(i.value.has(a.value));case"not in":return new P(!i.value.has(a.value))}throw new SyntaxError(`Unknown operator "${e.operator.value}" between ${a.type} and ${i.type}`)}evaluateArguments(e,t){const a=[],i=new Map;for(const n of e)if(n.type==="KeywordArgumentExpression"){const o=n;i.set(o.key.value,this.evaluate(o.value,t))}else{if(i.size>0)throw new Error("Positional arguments must come before keyword arguments");a.push(this.evaluate(n,t))}return[a,i]}evaluateFilterExpression(e,t){const a=this.evaluate(e.operand,t);if(e.filter.type==="Identifier"){const i=e.filter;if(i.value==="tojson")return new w(ke(a));if(a instanceof U)switch(i.value){case"list":return a;case"first":return a.value[0];case"last":return a.value[a.value.length-1];case"length":return new E(a.value.length);case"reverse":return new U(a.value.reverse());case"sort":return new U(a.value.sort((n,o)=>{if(n.type!==o.type)throw new Error(`Cannot compare different types: ${n.type} and ${o.type}`);switch(n.type){case"NumericValue":return n.value-o.value;case"StringValue":return n.value.localeCompare(o.value);default:throw new Error(`Cannot compare type: ${n.type}`)}}));case"join":return new w(a.value.map(n=>n.value).join(""));case"string":return new w(ke(a));default:throw new Error(`Unknown ArrayValue filter: ${i.value}`)}else if(a instanceof w)switch(i.value){case"length":return new E(a.value.length);case"upper":return new w(a.value.toUpperCase());case"lower":return new w(a.value.toLowerCase());case"title":return new w(Ot(a.value));case"capitalize":return new w(a.value.charAt(0).toUpperCase()+a.value.slice(1));case"trim":return new w(a.value.trim());case"indent":return new w(a.value.split(`
`).map((n,o)=>o===0||n.length===0?n:"    "+n).join(`
`));case"join":case"string":return a;default:throw new Error(`Unknown StringValue filter: ${i.value}`)}else if(a instanceof E)switch(i.value){case"abs":return new E(Math.abs(a.value));default:throw new Error(`Unknown NumericValue filter: ${i.value}`)}else if(a instanceof V)switch(i.value){case"items":return new U(Array.from(a.value.entries()).map(([n,o])=>new U([new w(n),o])));case"length":return new E(a.value.size);default:throw new Error(`Unknown ObjectValue filter: ${i.value}`)}throw new Error(`Cannot apply filter "${i.value}" to type: ${a.type}`)}else if(e.filter.type==="CallExpression"){const i=e.filter;if(i.callee.type!=="Identifier")throw new Error(`Unknown filter: ${i.callee.type}`);const n=i.callee.value;if(n==="tojson"){const[,o]=this.evaluateArguments(i.args,t),r=o.get("indent")??new z;if(!(r instanceof E||r instanceof z))throw new Error("If set, indent must be a number");return new w(ke(a,r.value))}else if(n==="join"){let o;if(a instanceof w)o=Array.from(a.value);else if(a instanceof U)o=a.value.map(d=>d.value);else throw new Error(`Cannot apply filter "${n}" to type: ${a.type}`);const[r,p]=this.evaluateArguments(i.args,t),u=r.at(0)??p.get("separator")??new w("");if(!(u instanceof w))throw new Error("separator must be a string");return new w(o.join(u.value))}if(a instanceof U){switch(n){case"selectattr":case"rejectattr":{const o=n==="selectattr";if(a.value.some(l=>!(l instanceof V)))throw new Error(`\`${n}\` can only be applied to array of objects`);if(i.args.some(l=>l.type!=="StringLiteral"))throw new Error(`arguments of \`${n}\` must be strings`);const[r,p,u]=i.args.map(l=>this.evaluate(l,t));let d;if(p){const l=t.tests.get(p.value);if(!l)throw new Error(`Unknown test: ${p.value}`);d=l}else d=(...l)=>l[0].__bool__().value;const c=a.value.filter(l=>{const f=l.value.get(r.value),y=f?d(f,u):!1;return o?y:!y});return new U(c)}case"map":{const[,o]=this.evaluateArguments(i.args,t);if(o.has("attribute")){const r=o.get("attribute");if(!(r instanceof w))throw new Error("attribute must be a string");const p=o.get("default"),u=a.value.map(d=>{if(!(d instanceof V))throw new Error("items in map must be an object");return d.value.get(r.value)??p??new F});return new U(u)}else throw new Error("`map` expressions without `attribute` set are not currently supported.")}}throw new Error(`Unknown ArrayValue filter: ${n}`)}else if(a instanceof w){switch(n){case"indent":{const[o,r]=this.evaluateArguments(i.args,t),p=o.at(0)??r.get("width")??new E(4);if(!(p instanceof E))throw new Error("width must be a number");const u=o.at(1)??r.get("first")??new P(!1),d=o.at(2)??r.get("blank")??new P(!1),c=a.value.split(`
`),l=" ".repeat(p.value),f=c.map((y,k)=>!u.value&&k===0||!d.value&&y.length===0?y:l+y);return new w(f.join(`
`))}}throw new Error(`Unknown StringValue filter: ${n}`)}else throw new Error(`Cannot apply filter "${n}" to type: ${a.type}`)}throw new Error(`Unknown filter: ${e.filter.type}`)}evaluateTestExpression(e,t){const a=this.evaluate(e.operand,t),i=t.tests.get(e.test.value);if(!i)throw new Error(`Unknown test: ${e.test.value}`);const n=i(a);return new P(e.negate?!n:n)}evaluateUnaryExpression(e,t){const a=this.evaluate(e.argument,t);switch(e.operator.value){case"not":return new P(!a.value);default:throw new SyntaxError(`Unknown operator: ${e.operator.value}`)}}evalProgram(e,t){return this.evaluateBlock(e.body,t)}evaluateBlock(e,t){let a="";for(const i of e){const n=this.evaluate(i,t);n.type!=="NullValue"&&n.type!=="UndefinedValue"&&(a+=n.value)}return new w(a)}evaluateIdentifier(e,t){return t.lookupVariable(e.value)}evaluateCallExpression(e,t){const[a,i]=this.evaluateArguments(e.args,t);i.size>0&&a.push(new La(i));const n=this.evaluate(e.callee,t);if(n.type!=="FunctionValue")throw new Error(`Cannot call something that is not a function: got ${n.type}`);return n.value(a,t)}evaluateSliceExpression(e,t,a){if(!(e instanceof U||e instanceof w))throw new Error("Slice object must be an array or string");const i=this.evaluate(t.start,a),n=this.evaluate(t.stop,a),o=this.evaluate(t.step,a);if(!(i instanceof E||i instanceof F))throw new Error("Slice start must be numeric or undefined");if(!(n instanceof E||n instanceof F))throw new Error("Slice stop must be numeric or undefined");if(!(o instanceof E||o instanceof F))throw new Error("Slice step must be numeric or undefined");return e instanceof U?new U(Tt(e.value,i.value,n.value,o.value)):new w(Tt(Array.from(e.value),i.value,n.value,o.value).join(""))}evaluateMemberExpression(e,t){const a=this.evaluate(e.object,t);let i;if(e.computed){if(e.property.type==="SliceExpression")return this.evaluateSliceExpression(a,e.property,t);i=this.evaluate(e.property,t)}else i=new w(e.property.value);let n;if(a instanceof V){if(!(i instanceof w))throw new Error(`Cannot access property with non-string: got ${i.type}`);n=a.value.get(i.value)??a.builtins.get(i.value)}else if(a instanceof U||a instanceof w)if(i instanceof E)n=a.value.at(i.value),a instanceof w&&(n=new w(a.value.at(i.value)));else if(i instanceof w)n=a.builtins.get(i.value);else throw new Error(`Cannot access property with non-string/non-number: got ${i.type}`);else{if(!(i instanceof w))throw new Error(`Cannot access property with non-string: got ${i.type}`);n=a.builtins.get(i.value)}return n instanceof Q?n:new F}evaluateSet(e,t){const a=e.value?this.evaluate(e.value,t):this.evaluateBlock(e.body,t);if(e.assignee.type==="Identifier"){const i=e.assignee.value;t.setVariable(i,a)}else if(e.assignee.type==="MemberExpression"){const i=e.assignee,n=this.evaluate(i.object,t);if(!(n instanceof V))throw new Error("Cannot assign to member of non-object");if(i.property.type!=="Identifier")throw new Error("Cannot assign to member with non-identifier property");n.value.set(i.property.value,a)}else throw new Error(`Invalid LHS inside assignment expression: ${JSON.stringify(e.assignee)}`);return new z}evaluateIf(e,t){const a=this.evaluate(e.test,t);return this.evaluateBlock(a.__bool__().value?e.body:e.alternate,t)}evaluateFor(e,t){const a=new xe(t);let i,n;if(e.iterable.type==="SelectExpression"){const d=e.iterable;n=this.evaluate(d.iterable,a),i=d.test}else n=this.evaluate(e.iterable,a);if(!(n instanceof U))throw new Error(`Expected iterable type in for loop: got ${n.type}`);const o=[],r=[];for(let d=0;d<n.value.length;++d){const c=new xe(a),l=n.value[d];let f;if(e.loopvar.type==="Identifier")f=y=>y.setVariable(e.loopvar.value,l);else if(e.loopvar.type==="TupleLiteral"){const y=e.loopvar;if(l.type!=="ArrayValue")throw new Error(`Cannot unpack non-iterable type: ${l.type}`);const k=l;if(y.value.length!==k.value.length)throw new Error(`Too ${y.value.length>k.value.length?"few":"many"} items to unpack`);f=S=>{for(let N=0;N<y.value.length;++N){if(y.value[N].type!=="Identifier")throw new Error(`Cannot unpack non-identifier type: ${y.value[N].type}`);S.setVariable(y.value[N].value,k.value[N])}}}else throw new Error(`Invalid loop variable(s): ${e.loopvar.type}`);i&&(f(c),!this.evaluate(i,c).__bool__().value)||(o.push(l),r.push(f))}let p="",u=!0;for(let d=0;d<o.length;++d){const c=new Map([["index",new E(d+1)],["index0",new E(d)],["revindex",new E(o.length-d)],["revindex0",new E(o.length-d-1)],["first",new P(d===0)],["last",new P(d===o.length-1)],["length",new E(o.length)],["previtem",d>0?o[d-1]:new F],["nextitem",d<o.length-1?o[d+1]:new F]]);a.setVariable("loop",new V(c)),r[d](a);const l=this.evaluateBlock(e.body,a);p+=l.value,u=!1}if(u){const d=this.evaluateBlock(e.defaultBlock,a);p+=d.value}return new w(p)}evaluateMacro(e,t){return t.setVariable(e.name.value,new H((a,i)=>{var r;const n=new xe(i);a=a.slice();let o;((r=a.at(-1))==null?void 0:r.type)==="KeywordArgumentsValue"&&(o=a.pop());for(let p=0;p<e.args.length;++p){const u=e.args[p],d=a[p];if(u.type==="Identifier"){const c=u;if(!d)throw new Error(`Missing positional argument: ${c.value}`);n.setVariable(c.value,d)}else if(u.type==="KeywordArgumentExpression"){const c=u,l=d??(o==null?void 0:o.value.get(c.key.value))??this.evaluate(c.value,n);n.setVariable(c.key.value,l)}else throw new Error(`Unknown argument type: ${u.type}`)}return this.evaluateBlock(e.body,n)})),new z}evaluate(e,t){if(e===void 0)return new F;switch(e.type){case"Program":return this.evalProgram(e,t);case"Set":return this.evaluateSet(e,t);case"If":return this.evaluateIf(e,t);case"For":return this.evaluateFor(e,t);case"Macro":return this.evaluateMacro(e,t);case"NumericLiteral":return new E(Number(e.value));case"StringLiteral":return new w(e.value);case"BooleanLiteral":return new P(e.value);case"NullLiteral":return new z(e.value);case"ArrayLiteral":return new U(e.value.map(a=>this.evaluate(a,t)));case"TupleLiteral":return new Ua(e.value.map(a=>this.evaluate(a,t)));case"ObjectLiteral":{const a=new Map;for(const[i,n]of e.value){const o=this.evaluate(i,t);if(!(o instanceof w))throw new Error(`Object keys must be strings: got ${o.type}`);a.set(o.value,this.evaluate(n,t))}return new V(a)}case"Identifier":return this.evaluateIdentifier(e,t);case"CallExpression":return this.evaluateCallExpression(e,t);case"MemberExpression":return this.evaluateMemberExpression(e,t);case"UnaryExpression":return this.evaluateUnaryExpression(e,t);case"BinaryExpression":return this.evaluateBinaryExpression(e,t);case"FilterExpression":return this.evaluateFilterExpression(e,t);case"TestExpression":return this.evaluateTestExpression(e,t);default:throw new SyntaxError(`Unknown node type: ${e.type}`)}}};function Ce(e){switch(typeof e){case"number":return new E(e);case"string":return new w(e);case"boolean":return new P(e);case"undefined":return new F;case"object":return e===null?new z:Array.isArray(e)?new U(e.map(Ce)):new V(new Map(Object.entries(e).map(([t,a])=>[t,Ce(a)])));case"function":return new H((t,a)=>{const i=e(...t.map(n=>n.value))??null;return Ce(i)});default:throw new Error(`Cannot convert to runtime value: ${e}`)}}function ke(e,t,a){const i=a??0;switch(e.type){case"NullValue":case"UndefinedValue":return"null";case"NumericValue":case"StringValue":case"BooleanValue":return JSON.stringify(e.value);case"ArrayValue":case"ObjectValue":{const n=t?" ".repeat(t):"",o=`
`+n.repeat(i),r=o+n;if(e.type==="ArrayValue"){const p=e.value.map(u=>ke(u,t,i+1));return t?`[${r}${p.join(`,${r}`)}${o}]`:`[${p.join(", ")}]`}else{const p=Array.from(e.value.entries()).map(([u,d])=>{const c=`"${u}": ${ke(d,t,i+1)}`;return t?`${r}${c}`:c});return t?`{${p.join(",")}${o}}`:`{${p.join(", ")}}`}}default:throw new Error(`Cannot convert to JSON: ${e.type}`)}}var Na=class{constructor(e){_(this,"parsed");const t=ba(e,{lstrip_blocks:!0,trim_blocks:!0});this.parsed=$a(t)}render(e){const t=new xe;if(t.set("false",!1),t.set("true",!0),t.set("raise_exception",n=>{throw new Error(n)}),t.set("range",Da),e)for(const[n,o]of Object.entries(e))t.set(n,o);return new Pa(t).run(this.parsed).value}};const ja={"adapter-transformers":["question-answering","text-classification","token-classification"],allennlp:["question-answering"],asteroid:["audio-to-audio"],bertopic:["text-classification"],diffusers:["image-to-image","text-to-image"],doctr:["object-detection"],espnet:["text-to-speech","automatic-speech-recognition"],fairseq:["text-to-speech","audio-to-audio"],fastai:["image-classification"],fasttext:["feature-extraction","text-classification"],flair:["token-classification"],k2:["automatic-speech-recognition"],keras:["image-classification"],nemo:["automatic-speech-recognition"],open_clip:["zero-shot-classification","zero-shot-image-classification"],paddlenlp:["fill-mask","summarization","zero-shot-classification"],peft:["text-generation"],"pyannote-audio":["automatic-speech-recognition"],"sentence-transformers":["feature-extraction","sentence-similarity"],setfit:["text-classification"],sklearn:["tabular-classification","tabular-regression","text-classification"],spacy:["token-classification","text-classification","sentence-similarity"],"span-marker":["token-classification"],speechbrain:["audio-classification","audio-to-audio","automatic-speech-recognition","text-to-speech","text2text-generation"],stanza:["token-classification"],timm:["image-classification","image-feature-extraction"],transformers:["audio-classification","automatic-speech-recognition","depth-estimation","document-question-answering","feature-extraction","fill-mask","image-classification","image-feature-extraction","image-segmentation","image-to-image","image-to-text","image-text-to-text","mask-generation","object-detection","question-answering","summarization","table-question-answering","text2text-generation","text-classification","text-generation","text-to-audio","text-to-speech","token-classification","translation","video-classification","visual-question-answering","zero-shot-classification","zero-shot-image-classification","zero-shot-object-detection"],mindspore:["image-classification"]},Xe={"text-classification":{name:"Text Classification",subtasks:[{type:"acceptability-classification",name:"Acceptability Classification"},{type:"entity-linking-classification",name:"Entity Linking Classification"},{type:"fact-checking",name:"Fact Checking"},{type:"intent-classification",name:"Intent Classification"},{type:"language-identification",name:"Language Identification"},{type:"multi-class-classification",name:"Multi Class Classification"},{type:"multi-label-classification",name:"Multi Label Classification"},{type:"multi-input-text-classification",name:"Multi-input Text Classification"},{type:"natural-language-inference",name:"Natural Language Inference"},{type:"semantic-similarity-classification",name:"Semantic Similarity Classification"},{type:"sentiment-classification",name:"Sentiment Classification"},{type:"topic-classification",name:"Topic Classification"},{type:"semantic-similarity-scoring",name:"Semantic Similarity Scoring"},{type:"sentiment-scoring",name:"Sentiment Scoring"},{type:"sentiment-analysis",name:"Sentiment Analysis"},{type:"hate-speech-detection",name:"Hate Speech Detection"},{type:"text-scoring",name:"Text Scoring"}],modality:"nlp",color:"orange"},"token-classification":{name:"Token Classification",subtasks:[{type:"named-entity-recognition",name:"Named Entity Recognition"},{type:"part-of-speech",name:"Part of Speech"},{type:"parsing",name:"Parsing"},{type:"lemmatization",name:"Lemmatization"},{type:"word-sense-disambiguation",name:"Word Sense Disambiguation"},{type:"coreference-resolution",name:"Coreference-resolution"}],modality:"nlp",color:"blue"},"table-question-answering":{name:"Table Question Answering",modality:"nlp",color:"green"},"question-answering":{name:"Question Answering",subtasks:[{type:"extractive-qa",name:"Extractive QA"},{type:"open-domain-qa",name:"Open Domain QA"},{type:"closed-domain-qa",name:"Closed Domain QA"}],modality:"nlp",color:"blue"},"zero-shot-classification":{name:"Zero-Shot Classification",modality:"nlp",color:"yellow"},translation:{name:"Translation",modality:"nlp",color:"green"},summarization:{name:"Summarization",subtasks:[{type:"news-articles-summarization",name:"News Articles Summarization"},{type:"news-articles-headline-generation",name:"News Articles Headline Generation"}],modality:"nlp",color:"indigo"},"feature-extraction":{name:"Feature Extraction",modality:"nlp",color:"red"},"text-generation":{name:"Text Generation",subtasks:[{type:"dialogue-modeling",name:"Dialogue Modeling"},{type:"dialogue-generation",name:"Dialogue Generation"},{type:"conversational",name:"Conversational"},{type:"language-modeling",name:"Language Modeling"}],modality:"nlp",color:"indigo"},"text2text-generation":{name:"Text2Text Generation",subtasks:[{type:"text-simplification",name:"Text simplification"},{type:"explanation-generation",name:"Explanation Generation"},{type:"abstractive-qa",name:"Abstractive QA"},{type:"open-domain-abstractive-qa",name:"Open Domain Abstractive QA"},{type:"closed-domain-qa",name:"Closed Domain QA"},{type:"open-book-qa",name:"Open Book QA"},{type:"closed-book-qa",name:"Closed Book QA"}],modality:"nlp",color:"indigo"},"fill-mask":{name:"Fill-Mask",subtasks:[{type:"slot-filling",name:"Slot Filling"},{type:"masked-language-modeling",name:"Masked Language Modeling"}],modality:"nlp",color:"red"},"sentence-similarity":{name:"Sentence Similarity",modality:"nlp",color:"yellow"},"text-to-speech":{name:"Text-to-Speech",modality:"audio",color:"yellow"},"text-to-audio":{name:"Text-to-Audio",modality:"audio",color:"yellow"},"automatic-speech-recognition":{name:"Automatic Speech Recognition",modality:"audio",color:"yellow"},"audio-to-audio":{name:"Audio-to-Audio",modality:"audio",color:"blue"},"audio-classification":{name:"Audio Classification",subtasks:[{type:"keyword-spotting",name:"Keyword Spotting"},{type:"speaker-identification",name:"Speaker Identification"},{type:"audio-intent-classification",name:"Audio Intent Classification"},{type:"audio-emotion-recognition",name:"Audio Emotion Recognition"},{type:"audio-language-identification",name:"Audio Language Identification"}],modality:"audio",color:"green"},"audio-text-to-text":{name:"Audio-Text-to-Text",modality:"multimodal",color:"red",hideInDatasets:!0},"voice-activity-detection":{name:"Voice Activity Detection",modality:"audio",color:"red"},"depth-estimation":{name:"Depth Estimation",modality:"cv",color:"yellow"},"image-classification":{name:"Image Classification",subtasks:[{type:"multi-label-image-classification",name:"Multi Label Image Classification"},{type:"multi-class-image-classification",name:"Multi Class Image Classification"}],modality:"cv",color:"blue"},"object-detection":{name:"Object Detection",subtasks:[{type:"face-detection",name:"Face Detection"},{type:"vehicle-detection",name:"Vehicle Detection"}],modality:"cv",color:"yellow"},"image-segmentation":{name:"Image Segmentation",subtasks:[{type:"instance-segmentation",name:"Instance Segmentation"},{type:"semantic-segmentation",name:"Semantic Segmentation"},{type:"panoptic-segmentation",name:"Panoptic Segmentation"}],modality:"cv",color:"green"},"text-to-image":{name:"Text-to-Image",modality:"cv",color:"yellow"},"image-to-text":{name:"Image-to-Text",subtasks:[{type:"image-captioning",name:"Image Captioning"}],modality:"cv",color:"red"},"image-to-image":{name:"Image-to-Image",subtasks:[{type:"image-inpainting",name:"Image Inpainting"},{type:"image-colorization",name:"Image Colorization"},{type:"super-resolution",name:"Super Resolution"}],modality:"cv",color:"indigo"},"image-to-video":{name:"Image-to-Video",modality:"cv",color:"indigo"},"unconditional-image-generation":{name:"Unconditional Image Generation",modality:"cv",color:"green"},"video-classification":{name:"Video Classification",modality:"cv",color:"blue"},"reinforcement-learning":{name:"Reinforcement Learning",modality:"rl",color:"red"},robotics:{name:"Robotics",modality:"rl",subtasks:[{type:"grasping",name:"Grasping"},{type:"task-planning",name:"Task Planning"}],color:"blue"},"tabular-classification":{name:"Tabular Classification",modality:"tabular",subtasks:[{type:"tabular-multi-class-classification",name:"Tabular Multi Class Classification"},{type:"tabular-multi-label-classification",name:"Tabular Multi Label Classification"}],color:"blue"},"tabular-regression":{name:"Tabular Regression",modality:"tabular",subtasks:[{type:"tabular-single-column-regression",name:"Tabular Single Column Regression"}],color:"blue"},"tabular-to-text":{name:"Tabular to Text",modality:"tabular",subtasks:[{type:"rdf-to-text",name:"RDF to text"}],color:"blue",hideInModels:!0},"table-to-text":{name:"Table to Text",modality:"nlp",color:"blue",hideInModels:!0},"multiple-choice":{name:"Multiple Choice",subtasks:[{type:"multiple-choice-qa",name:"Multiple Choice QA"},{type:"multiple-choice-coreference-resolution",name:"Multiple Choice Coreference Resolution"}],modality:"nlp",color:"blue",hideInModels:!0},"text-ranking":{name:"Text Ranking",modality:"nlp",color:"red"},"text-retrieval":{name:"Text Retrieval",subtasks:[{type:"document-retrieval",name:"Document Retrieval"},{type:"utterance-retrieval",name:"Utterance Retrieval"},{type:"entity-linking-retrieval",name:"Entity Linking Retrieval"},{type:"fact-checking-retrieval",name:"Fact Checking Retrieval"}],modality:"nlp",color:"indigo",hideInModels:!0},"time-series-forecasting":{name:"Time Series Forecasting",modality:"tabular",subtasks:[{type:"univariate-time-series-forecasting",name:"Univariate Time Series Forecasting"},{type:"multivariate-time-series-forecasting",name:"Multivariate Time Series Forecasting"}],color:"blue"},"text-to-video":{name:"Text-to-Video",modality:"cv",color:"green"},"image-text-to-text":{name:"Image-Text-to-Text",modality:"multimodal",color:"red",hideInDatasets:!0},"visual-question-answering":{name:"Visual Question Answering",subtasks:[{type:"visual-question-answering",name:"Visual Question Answering"}],modality:"multimodal",color:"red"},"document-question-answering":{name:"Document Question Answering",subtasks:[{type:"document-question-answering",name:"Document Question Answering"}],modality:"multimodal",color:"blue",hideInDatasets:!0},"zero-shot-image-classification":{name:"Zero-Shot Image Classification",modality:"cv",color:"yellow"},"graph-ml":{name:"Graph Machine Learning",modality:"other",color:"green"},"mask-generation":{name:"Mask Generation",modality:"cv",color:"indigo"},"zero-shot-object-detection":{name:"Zero-Shot Object Detection",modality:"cv",color:"yellow"},"text-to-3d":{name:"Text-to-3D",modality:"cv",color:"yellow"},"image-to-3d":{name:"Image-to-3D",modality:"cv",color:"green"},"image-feature-extraction":{name:"Image Feature Extraction",modality:"cv",color:"indigo"},"video-text-to-text":{name:"Video-Text-to-Text",modality:"multimodal",color:"blue",hideInDatasets:!1},"keypoint-detection":{name:"Keypoint Detection",subtasks:[{type:"pose-estimation",name:"Pose Estimation"}],modality:"cv",color:"red",hideInDatasets:!0},"visual-document-retrieval":{name:"Visual Document Retrieval",modality:"multimodal",color:"yellow",hideInDatasets:!0},"any-to-any":{name:"Any-to-Any",modality:"multimodal",color:"yellow",hideInDatasets:!0},other:{name:"Other",modality:"other",color:"blue",hideInModels:!0,hideInDatasets:!0}},Oa=Object.keys(Xe);Object.values(Xe).flatMap(e=>"subtasks"in e?e.subtasks:[]).map(e=>e.type);new Set(Oa);const qa={datasets:[{description:"A dataset with multiple modality input and output pairs.",id:"PKU-Alignment/align-anything"}],demo:{inputs:[{filename:"any-to-any-input.jpg",type:"img"},{label:"Text Prompt",content:"Describe the position of the bee in detail.",type:"text"}],outputs:[{label:"Generated Text",content:"The place in the picture is Osaka Castle, located in Osaka, Japan. Osaka Castle is a historic castle that was originally built in the 16th century by Toyotomi Hideyoshi, a powerful warlord of the time. It is one of the most famous landmarks in Osaka and is known for its distinctive white walls and black roof tiles. The castle has been rebuilt several times over the centuries and is now a popular tourist attraction, offering visitors a glimpse into Japan's rich history and culture.",type:"text"},{filename:"any-to-any-output.wav",type:"audio"}]},metrics:[],models:[{description:"Strong model that can take in video, audio, image, text and output text and natural speech.",id:"Qwen/Qwen2.5-Omni-7B"},{description:"Robust model that can take in image and text and generate image and text.",id:"deepseek-ai/Janus-Pro-7B"},{description:"Any-to-any model with speech, video, audio, image and text understanding capabilities.",id:"openbmb/MiniCPM-o-2_6"},{description:"A model that can understand image and text and generate image and text.",id:"EPFL-VILAB/4M-21_XL"}],spaces:[{description:"An application to chat with an any-to-any (image & text) model.",id:"deepseek-ai/Janus-Pro-7B"}],summary:"Any-to-any models can understand two or more modalities and output two or more modalities.",widgetModels:[],youtubeId:""},Ba={datasets:[{description:"A benchmark of 10 different audio tasks.",id:"s3prl/superb"},{description:"A dataset of YouTube clips and their sound categories.",id:"agkphysics/AudioSet"}],demo:{inputs:[{filename:"audio.wav",type:"audio"}],outputs:[{data:[{label:"Up",score:.2},{label:"Down",score:.8}],type:"chart"}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"An easy-to-use model for command recognition.",id:"speechbrain/google_speech_command_xvector"},{description:"An emotion recognition model.",id:"ehcalabres/wav2vec2-lg-xlsr-en-speech-emotion-recognition"},{description:"A language identification model.",id:"facebook/mms-lid-126"}],spaces:[{description:"An application that can classify music into different genre.",id:"kurianbenoy/audioclassification"}],summary:"Audio classification is the task of assigning a label or class to a given audio. It can be used for recognizing which command a user is giving or the emotion of a statement, as well as identifying a speaker.",widgetModels:["MIT/ast-finetuned-audioset-10-10-0.4593"],youtubeId:"KWwzcmG98Ds"},Fa={datasets:[{description:"512-element X-vector embeddings of speakers from CMU ARCTIC dataset.",id:"Matthijs/cmu-arctic-xvectors"}],demo:{inputs:[{filename:"input.wav",type:"audio"}],outputs:[{filename:"label-0.wav",type:"audio"},{filename:"label-1.wav",type:"audio"}]},metrics:[{description:"The Signal-to-Noise ratio is the relationship between the target signal level and the background noise level. It is calculated as the logarithm of the target signal divided by the background noise, in decibels.",id:"snri"},{description:"The Signal-to-Distortion ratio is the relationship between the target signal and the sum of noise, interference, and artifact errors",id:"sdri"}],models:[{description:"A speech enhancement model.",id:"ResembleAI/resemble-enhance"},{description:"A model that can change the voice in a speech recording.",id:"microsoft/speecht5_vc"}],spaces:[{description:"An application for speech separation.",id:"younver/speechbrain-speech-separation"},{description:"An application for audio style transfer.",id:"nakas/audio-diffusion_style_transfer"}],summary:"Audio-to-Audio is a family of tasks in which the input is an audio and the output is one or multiple generated audios. Some example tasks are speech enhancement and source separation.",widgetModels:["speechbrain/sepformer-wham"],youtubeId:"iohj7nCCYoM"},Ha={datasets:[{description:"31,175 hours of multilingual audio-text dataset in 108 languages.",id:"mozilla-foundation/common_voice_17_0"},{description:"Multilingual and diverse audio dataset with 101k hours of audio.",id:"amphion/Emilia-Dataset"},{description:"A dataset with 44.6k hours of English speaker data and 6k hours of other language speakers.",id:"parler-tts/mls_eng"},{description:"A multilingual audio dataset with 370K hours of audio.",id:"espnet/yodas"}],demo:{inputs:[{filename:"input.flac",type:"audio"}],outputs:[{label:"Transcript",content:"Going along slushy country roads and speaking to damp audiences in...",type:"text"}]},metrics:[{description:"",id:"wer"},{description:"",id:"cer"}],models:[{description:"A powerful ASR model by OpenAI.",id:"openai/whisper-large-v3"},{description:"A good generic speech model by MetaAI for fine-tuning.",id:"facebook/w2v-bert-2.0"},{description:"An end-to-end model that performs ASR and Speech Translation by MetaAI.",id:"facebook/seamless-m4t-v2-large"},{description:"A powerful multilingual ASR and Speech Translation model by Nvidia.",id:"nvidia/canary-1b"},{description:"Powerful speaker diarization model.",id:"pyannote/speaker-diarization-3.1"}],spaces:[{description:"A powerful general-purpose speech recognition application.",id:"hf-audio/whisper-large-v3"},{description:"Latest ASR model from Useful Sensors.",id:"mrfakename/Moonshinex"},{description:"A high quality speech and text translation model by Meta.",id:"facebook/seamless_m4t"},{description:"A powerful multilingual ASR and Speech Translation model by Nvidia",id:"nvidia/canary-1b"}],summary:"Automatic Speech Recognition (ASR), also known as Speech to Text (STT), is the task of transcribing a given audio to text. It has many applications, such as voice user interfaces.",widgetModels:["openai/whisper-large-v3"],youtubeId:"TksaY_FDgnk"},Va={datasets:[{description:"Largest document understanding dataset.",id:"HuggingFaceM4/Docmatix"},{description:"Dataset from the 2020 DocVQA challenge. The documents are taken from the UCSF Industry Documents Library.",id:"eliolio/docvqa"}],demo:{inputs:[{label:"Question",content:"What is the idea behind the consumer relations efficiency team?",type:"text"},{filename:"document-question-answering-input.png",type:"img"}],outputs:[{label:"Answer",content:"Balance cost efficiency with quality customer service",type:"text"}]},metrics:[{description:"The evaluation metric for the DocVQA challenge is the Average Normalized Levenshtein Similarity (ANLS). This metric is flexible to character regognition errors and compares the predicted answer with the ground truth answer.",id:"anls"},{description:"Exact Match is a metric based on the strict character match of the predicted answer and the right answer. For answers predicted correctly, the Exact Match will be 1. Even if only one character is different, Exact Match will be 0",id:"exact-match"}],models:[{description:"A robust document question answering model.",id:"impira/layoutlm-document-qa"},{description:"A document question answering model specialized in invoices.",id:"impira/layoutlm-invoices"},{description:"A special model for OCR-free document question answering.",id:"microsoft/udop-large"},{description:"A powerful model for document question answering.",id:"google/pix2struct-docvqa-large"}],spaces:[{description:"A robust document question answering application.",id:"impira/docquery"},{description:"An application that can answer questions from invoices.",id:"impira/invoices"},{description:"An application to compare different document question answering models.",id:"merve/compare_docvqa_models"}],summary:"Document Question Answering (also known as Document Visual Question Answering) is the task of answering questions on document images. Document question answering models take a (document, question) pair as input and return an answer in natural language. Models usually rely on multi-modal features, combining text, position of words (bounding-boxes) and image.",widgetModels:["impira/layoutlm-invoices"],youtubeId:""},za={datasets:[{description:"Wikipedia dataset containing cleaned articles of all languages. Can be used to train `feature-extraction` models.",id:"wikipedia"}],demo:{inputs:[{label:"Input",content:"India, officially the Republic of India, is a country in South Asia.",type:"text"}],outputs:[{table:[["Dimension 1","Dimension 2","Dimension 3"],["2.583383083343506","2.757075071334839","0.9023529887199402"],["8.29393482208252","1.1071064472198486","2.03399395942688"],["-0.7754912972450256","-1.647324562072754","-0.6113331913948059"],["0.07087723910808563","1.5942802429199219","1.4610432386398315"]],type:"tabular"}]},metrics:[],models:[{description:"A powerful feature extraction model for natural language processing tasks.",id:"thenlper/gte-large"},{description:"A strong feature extraction model for retrieval.",id:"Alibaba-NLP/gte-Qwen1.5-7B-instruct"}],spaces:[{description:"A leaderboard to rank text feature extraction models based on a benchmark.",id:"mteb/leaderboard"},{description:"A leaderboard to rank best feature extraction models based on human feedback.",id:"mteb/arena"}],summary:"Feature extraction is the task of extracting features learnt in a model.",widgetModels:["facebook/bart-base"]},Wa={datasets:[{description:"A common dataset that is used to train models for many languages.",id:"wikipedia"},{description:"A large English dataset with text crawled from the web.",id:"c4"}],demo:{inputs:[{label:"Input",content:"The <mask> barked at me",type:"text"}],outputs:[{type:"chart",data:[{label:"wolf",score:.487},{label:"dog",score:.061},{label:"cat",score:.058},{label:"fox",score:.047},{label:"squirrel",score:.025}]}]},metrics:[{description:"Cross Entropy is a metric that calculates the difference between two probability distributions. Each probability distribution is the distribution of predicted words",id:"cross_entropy"},{description:"Perplexity is the exponential of the cross-entropy loss. It evaluates the probabilities assigned to the next word by the model. Lower perplexity indicates better performance",id:"perplexity"}],models:[{description:"State-of-the-art masked language model.",id:"answerdotai/ModernBERT-large"},{description:"A multilingual model trained on 100 languages.",id:"FacebookAI/xlm-roberta-base"}],spaces:[],summary:"Masked language modeling is the task of masking some of the words in a sentence and predicting which words should replace those masks. These models are useful when we want to get a statistical understanding of the language in which the model is trained in.",widgetModels:["distilroberta-base"],youtubeId:"mqElG5QJWUg"},Ka={datasets:[{description:"Benchmark dataset used for image classification with images that belong to 100 classes.",id:"cifar100"},{description:"Dataset consisting of images of garments.",id:"fashion_mnist"}],demo:{inputs:[{filename:"image-classification-input.jpeg",type:"img"}],outputs:[{type:"chart",data:[{label:"Egyptian cat",score:.514},{label:"Tabby cat",score:.193},{label:"Tiger cat",score:.068}]}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"A strong image classification model.",id:"google/vit-base-patch16-224"},{description:"A robust image classification model.",id:"facebook/deit-base-distilled-patch16-224"},{description:"A strong image classification model.",id:"facebook/convnext-large-224"}],spaces:[{description:"A leaderboard to evaluate different image classification models.",id:"timm/leaderboard"}],summary:"Image classification is the task of assigning a label or class to an entire image. Images are expected to have only one class for each image. Image classification models take an image as input and return a prediction about which class the image belongs to.",widgetModels:["google/vit-base-patch16-224"],youtubeId:"tjAIM7BOYhw"},Ja={datasets:[{description:"ImageNet-1K is a image classification dataset in which images are used to train image-feature-extraction models.",id:"imagenet-1k"}],demo:{inputs:[{filename:"mask-generation-input.png",type:"img"}],outputs:[{table:[["Dimension 1","Dimension 2","Dimension 3"],["0.21236686408519745","1.0919708013534546","0.8512550592422485"],["0.809657871723175","-0.18544459342956543","-0.7851548194885254"],["1.3103108406066895","-0.2479034662246704","-0.9107287526130676"],["1.8536205291748047","-0.36419737339019775","0.09717650711536407"]],type:"tabular"}]},metrics:[],models:[{description:"A powerful image feature extraction model.",id:"timm/vit_large_patch14_dinov2.lvd142m"},{description:"A strong image feature extraction model.",id:"nvidia/MambaVision-T-1K"},{description:"A robust image feature extraction model.",id:"facebook/dino-vitb16"},{description:"Cutting-edge image feature extraction model.",id:"apple/aimv2-large-patch14-336-distilled"},{description:"Strong image feature extraction model that can be used on images and documents.",id:"OpenGVLab/InternViT-6B-448px-V1-2"}],spaces:[{description:"A leaderboard to evaluate different image-feature-extraction models on classification performances",id:"timm/leaderboard"}],summary:"Image feature extraction is the task of extracting features learnt in a computer vision model.",widgetModels:[]},Qa={datasets:[{description:"Synthetic dataset, for image relighting",id:"VIDIT"},{description:"Multiple images of celebrities, used for facial expression translation",id:"huggan/CelebA-faces"},{description:"12M image-caption pairs.",id:"Spawning/PD12M"}],demo:{inputs:[{filename:"image-to-image-input.jpeg",type:"img"}],outputs:[{filename:"image-to-image-output.png",type:"img"}]},isPlaceholder:!1,metrics:[{description:"Peak Signal to Noise Ratio (PSNR) is an approximation of the human perception, considering the ratio of the absolute intensity with respect to the variations. Measured in dB, a high value indicates a high fidelity.",id:"PSNR"},{description:"Structural Similarity Index (SSIM) is a perceptual metric which compares the luminance, contrast and structure of two images. The values of SSIM range between -1 and 1, and higher values indicate closer resemblance to the original image.",id:"SSIM"},{description:"Inception Score (IS) is an analysis of the labels predicted by an image classification model when presented with a sample of the generated images.",id:"IS"}],models:[{description:"An image-to-image model to improve image resolution.",id:"fal/AuraSR-v2"},{description:"A model that increases the resolution of an image.",id:"keras-io/super-resolution"},{description:"A model for applying edits to images through image controls.",id:"Yuanshi/OminiControl"},{description:"A model that generates images based on segments in the input image and the text prompt.",id:"mfidabel/controlnet-segment-anything"},{description:"Strong model for inpainting and outpainting.",id:"black-forest-labs/FLUX.1-Fill-dev"},{description:"Strong model for image editing using depth maps.",id:"black-forest-labs/FLUX.1-Depth-dev-lora"}],spaces:[{description:"Image enhancer application for low light.",id:"keras-io/low-light-image-enhancement"},{description:"Style transfer application.",id:"keras-io/neural-style-transfer"},{description:"An application that generates images based on segment control.",id:"mfidabel/controlnet-segment-anything"},{description:"Image generation application that takes image control and text prompt.",id:"hysts/ControlNet"},{description:"Colorize any image using this app.",id:"ioclab/brightness-controlnet"},{description:"Edit images with instructions.",id:"timbrooks/instruct-pix2pix"}],summary:"Image-to-image is the task of transforming an input image through a variety of possible manipulations and enhancements, such as super-resolution, image inpainting, colorization, and more.",widgetModels:["stabilityai/stable-diffusion-2-inpainting"],youtubeId:""},Xa={datasets:[{description:"Dataset from 12M image-text of Reddit",id:"red_caps"},{description:"Dataset from 3.3M images of Google",id:"datasets/conceptual_captions"}],demo:{inputs:[{filename:"savanna.jpg",type:"img"}],outputs:[{label:"Detailed description",content:"a herd of giraffes and zebras grazing in a field",type:"text"}]},metrics:[],models:[{description:"A robust image captioning model.",id:"Salesforce/blip2-opt-2.7b"},{description:"A powerful and accurate image-to-text model that can also localize concepts in images.",id:"microsoft/kosmos-2-patch14-224"},{description:"A strong optical character recognition model.",id:"facebook/nougat-base"},{description:"A powerful model that lets you have a conversation with the image.",id:"llava-hf/llava-1.5-7b-hf"}],spaces:[{description:"An application that compares various image captioning models.",id:"nielsr/comparing-captioning-models"},{description:"A robust image captioning application.",id:"flax-community/image-captioning"},{description:"An application that transcribes handwritings into text.",id:"nielsr/TrOCR-handwritten"},{description:"An application that can caption images and answer questions about a given image.",id:"Salesforce/BLIP"},{description:"An application that can caption images and answer questions with a conversational agent.",id:"Salesforce/BLIP2"},{description:"An image captioning application that demonstrates the effect of noise on captions.",id:"johko/capdec-image-captioning"}],summary:"Image to text models output a text from a given image. Image captioning or optical character recognition can be considered as the most common applications of image to text.",widgetModels:["Salesforce/blip-image-captioning-large"],youtubeId:""},Ya={datasets:[{description:"Instructions composed of image and text.",id:"liuhaotian/LLaVA-Instruct-150K"},{description:"Collection of image-text pairs on scientific topics.",id:"DAMO-NLP-SG/multimodal_textbook"},{description:"A collection of datasets made for model fine-tuning.",id:"HuggingFaceM4/the_cauldron"},{description:"Screenshots of websites with their HTML/CSS codes.",id:"HuggingFaceM4/WebSight"}],demo:{inputs:[{filename:"image-text-to-text-input.png",type:"img"},{label:"Text Prompt",content:"Describe the position of the bee in detail.",type:"text"}],outputs:[{label:"Answer",content:"The bee is sitting on a pink flower, surrounded by other flowers. The bee is positioned in the center of the flower, with its head and front legs sticking out.",type:"text"}]},metrics:[],models:[{description:"Small and efficient yet powerful vision language model.",id:"HuggingFaceTB/SmolVLM-Instruct"},{description:"A screenshot understanding model used to control computers.",id:"microsoft/OmniParser-v2.0"},{description:"Cutting-edge vision language model.",id:"allenai/Molmo-7B-D-0924"},{description:"Small yet powerful model.",id:"vikhyatk/moondream2"},{description:"Strong image-text-to-text model.",id:"Qwen/Qwen2.5-VL-7B-Instruct"},{description:"Image-text-to-text model with agentic capabilities.",id:"microsoft/Magma-8B"},{description:"Strong image-text-to-text model focused on documents.",id:"allenai/olmOCR-7B-0225-preview"},{description:"Small yet strong image-text-to-text model.",id:"ibm-granite/granite-vision-3.2-2b"}],spaces:[{description:"Leaderboard to evaluate vision language models.",id:"opencompass/open_vlm_leaderboard"},{description:"Vision language models arena, where models are ranked by votes of users.",id:"WildVision/vision-arena"},{description:"Powerful vision-language model assistant.",id:"akhaliq/Molmo-7B-D-0924"},{description:"Powerful vision language assistant that can understand multiple images.",id:"HuggingFaceTB/SmolVLM2"},{description:"An application for chatting with an image-text-to-text model.",id:"GanymedeNil/Qwen2-VL-7B"},{description:"An application that parses screenshots into actions.",id:"showlab/ShowUI"},{description:"An application that detects gaze.",id:"moondream/gaze-demo"}],summary:"Image-text-to-text models take in an image and text prompt and output text. These models are also called vision-language models, or VLMs. The difference from image-to-text models is that these models take an additional text input, not restricting the model to certain use cases like image captioning, and may also be trained to accept a conversation as input.",widgetModels:["Qwen/Qwen2-VL-7B-Instruct"],youtubeId:"IoGaGfU1CIg"},Za={datasets:[{description:"Scene segmentation dataset.",id:"scene_parse_150"}],demo:{inputs:[{filename:"image-segmentation-input.jpeg",type:"img"}],outputs:[{filename:"image-segmentation-output.png",type:"img"}]},metrics:[{description:"Average Precision (AP) is the Area Under the PR Curve (AUC-PR). It is calculated for each semantic class separately",id:"Average Precision"},{description:"Mean Average Precision (mAP) is the overall average of the AP values",id:"Mean Average Precision"},{description:"Intersection over Union (IoU) is the overlap of segmentation masks. Mean IoU is the average of the IoU of all semantic classes",id:"Mean Intersection over Union"},{description:"APα is the Average Precision at the IoU threshold of a α value, for example, AP50 and AP75",id:"APα"}],models:[{description:"Solid semantic segmentation model trained on ADE20k.",id:"openmmlab/upernet-convnext-small"},{description:"Background removal model.",id:"briaai/RMBG-1.4"},{description:"A multipurpose image segmentation model for high resolution images.",id:"ZhengPeng7/BiRefNet"},{description:"Powerful human-centric image segmentation model.",id:"facebook/sapiens-seg-1b"},{description:"Panoptic segmentation model trained on the COCO (common objects) dataset.",id:"facebook/mask2former-swin-large-coco-panoptic"}],spaces:[{description:"A semantic segmentation application that can predict unseen instances out of the box.",id:"facebook/ov-seg"},{description:"One of the strongest segmentation applications.",id:"jbrinkma/segment-anything"},{description:"A human-centric segmentation model.",id:"facebook/sapiens-pose"},{description:"An instance segmentation application to predict neuronal cell types from microscopy images.",id:"rashmi/sartorius-cell-instance-segmentation"},{description:"An application that segments videos.",id:"ArtGAN/Segment-Anything-Video"},{description:"An panoptic segmentation application built for outdoor environments.",id:"segments/panoptic-segment-anything"}],summary:"Image Segmentation divides an image into segments where each pixel in the image is mapped to an object. This task has multiple variants such as instance segmentation, panoptic segmentation and semantic segmentation.",widgetModels:["nvidia/segformer-b0-finetuned-ade-512-512"],youtubeId:"dKE8SIt9C-w"},Ga={datasets:[{description:"Widely used benchmark dataset for multiple Vision tasks.",id:"merve/coco2017"},{description:"Medical Imaging dataset of the Human Brain for segmentation and mask generating tasks",id:"rocky93/BraTS_segmentation"}],demo:{inputs:[{filename:"mask-generation-input.png",type:"img"}],outputs:[{filename:"mask-generation-output.png",type:"img"}]},metrics:[{description:"IoU is used to measure the overlap between predicted mask and the ground truth mask.",id:"Intersection over Union (IoU)"}],models:[{description:"Small yet powerful mask generation model.",id:"Zigeng/SlimSAM-uniform-50"},{description:"Very strong mask generation model.",id:"facebook/sam2-hiera-large"}],spaces:[{description:"An application that combines a mask generation model with a zero-shot object detection model for text-guided image segmentation.",id:"merve/OWLSAM2"},{description:"An application that compares the performance of a large and a small mask generation model.",id:"merve/slimsam"},{description:"An application based on an improved mask generation model.",id:"SkalskiP/segment-anything-model-2"},{description:"An application to remove objects from videos using mask generation models.",id:"SkalskiP/SAM_and_ProPainter"}],summary:"Mask generation is the task of generating masks that identify a specific object or region of interest in a given image. Masks are often used in segmentation tasks, where they provide a precise way to isolate the object of interest for further processing or analysis.",widgetModels:[],youtubeId:""},ei={datasets:[{description:"Widely used benchmark dataset for multiple vision tasks.",id:"merve/coco2017"},{description:"Multi-task computer vision benchmark.",id:"merve/pascal-voc"}],demo:{inputs:[{filename:"object-detection-input.jpg",type:"img"}],outputs:[{filename:"object-detection-output.jpg",type:"img"}]},metrics:[{description:"The Average Precision (AP) metric is the Area Under the PR Curve (AUC-PR). It is calculated for each class separately",id:"Average Precision"},{description:"The Mean Average Precision (mAP) metric is the overall average of the AP values",id:"Mean Average Precision"},{description:"The APα metric is the Average Precision at the IoU threshold of a α value, for example, AP50 and AP75",id:"APα"}],models:[{description:"Solid object detection model pre-trained on the COCO 2017 dataset.",id:"facebook/detr-resnet-50"},{description:"Accurate object detection model.",id:"IDEA-Research/dab-detr-resnet-50"},{description:"Fast and accurate object detection model.",id:"PekingU/rtdetr_v2_r50vd"},{description:"Object detection model for low-lying objects.",id:"StephanST/WALDO30"}],spaces:[{description:"Leaderboard to compare various object detection models across several metrics.",id:"hf-vision/object_detection_leaderboard"},{description:"An application that contains various object detection models to try from.",id:"Gradio-Blocks/Object-Detection-With-DETR-and-YOLOS"},{description:"A cutting-edge object detection application.",id:"sunsmarterjieleaf/yolov12"},{description:"An object tracking, segmentation and inpainting application.",id:"VIPLab/Track-Anything"},{description:"Very fast object tracking application based on object detection.",id:"merve/RT-DETR-tracking-coco"}],summary:"Object Detection models allow users to identify objects of certain defined classes. Object detection models receive an image as input and output the images with bounding boxes and labels on detected objects.",widgetModels:["facebook/detr-resnet-50"],youtubeId:"WdAeKSOpxhw"},ti={datasets:[{description:"NYU Depth V2 Dataset: Video dataset containing both RGB and depth sensor data.",id:"sayakpaul/nyu_depth_v2"},{description:"Monocular depth estimation benchmark based without noise and errors.",id:"depth-anything/DA-2K"}],demo:{inputs:[{filename:"depth-estimation-input.jpg",type:"img"}],outputs:[{filename:"depth-estimation-output.png",type:"img"}]},metrics:[],models:[{description:"Cutting-edge depth estimation model.",id:"depth-anything/Depth-Anything-V2-Large"},{description:"A strong monocular depth estimation model.",id:"jingheya/lotus-depth-g-v1-0"},{description:"A depth estimation model that predicts depth in videos.",id:"tencent/DepthCrafter"},{description:"A robust depth estimation model.",id:"apple/DepthPro-hf"}],spaces:[{description:"An application that predicts the depth of an image and then reconstruct the 3D model as voxels.",id:"radames/dpt-depth-estimation-3d-voxels"},{description:"An application for bleeding-edge depth estimation.",id:"akhaliq/depth-pro"},{description:"An application on cutting-edge depth estimation in videos.",id:"tencent/DepthCrafter"},{description:"A human-centric depth estimation application.",id:"facebook/sapiens-depth"}],summary:"Depth estimation is the task of predicting depth of the objects present in an image.",widgetModels:[""],youtubeId:""},Be={datasets:[],demo:{inputs:[],outputs:[]},isPlaceholder:!0,metrics:[],models:[],spaces:[],summary:"",widgetModels:[],youtubeId:void 0,canonicalId:void 0},ai={datasets:[{description:"A curation of widely used datasets for Data Driven Deep Reinforcement Learning (D4RL)",id:"edbeeching/decision_transformer_gym_replay"}],demo:{inputs:[{label:"State",content:"Red traffic light, pedestrians are about to pass.",type:"text"}],outputs:[{label:"Action",content:"Stop the car.",type:"text"},{label:"Next State",content:"Yellow light, pedestrians have crossed.",type:"text"}]},metrics:[{description:"Accumulated reward across all time steps discounted by a factor that ranges between 0 and 1 and determines how much the agent optimizes for future relative to immediate rewards. Measures how good is the policy ultimately found by a given algorithm considering uncertainty over the future.",id:"Discounted Total Reward"},{description:"Average return obtained after running the policy for a certain number of evaluation episodes. As opposed to total reward, mean reward considers how much reward a given algorithm receives while learning.",id:"Mean Reward"},{description:"Measures how good a given algorithm is after a predefined time. Some algorithms may be guaranteed to converge to optimal behavior across many time steps. However, an agent that reaches an acceptable level of optimality after a given time horizon may be preferable to one that ultimately reaches optimality but takes a long time.",id:"Level of Performance After Some Time"}],models:[{description:"A Reinforcement Learning model trained on expert data from the Gym Hopper environment",id:"edbeeching/decision-transformer-gym-hopper-expert"},{description:"A PPO agent playing seals/CartPole-v0 using the stable-baselines3 library and the RL Zoo.",id:"HumanCompatibleAI/ppo-seals-CartPole-v0"}],spaces:[{description:"An application for a cute puppy agent learning to catch a stick.",id:"ThomasSimonini/Huggy"},{description:"An application to play Snowball Fight with a reinforcement learning agent.",id:"ThomasSimonini/SnowballFight"}],summary:"Reinforcement learning is the computational approach of learning from action by interacting with an environment through trial and error and receiving rewards (negative or positive) as feedback",widgetModels:[],youtubeId:"q0BiUn5LiBc"},ii={datasets:[{description:"A famous question answering dataset based on English articles from Wikipedia.",id:"squad_v2"},{description:"A dataset of aggregated anonymized actual queries issued to the Google search engine.",id:"natural_questions"}],demo:{inputs:[{label:"Question",content:"Which name is also used to describe the Amazon rainforest in English?",type:"text"},{label:"Context",content:"The Amazon rainforest, also known in English as Amazonia or the Amazon Jungle",type:"text"}],outputs:[{label:"Answer",content:"Amazonia",type:"text"}]},metrics:[{description:"Exact Match is a metric based on the strict character match of the predicted answer and the right answer. For answers predicted correctly, the Exact Match will be 1. Even if only one character is different, Exact Match will be 0",id:"exact-match"},{description:" The F1-Score metric is useful if we value both false positives and false negatives equally. The F1-Score is calculated on each word in the predicted sequence against the correct answer",id:"f1"}],models:[{description:"A robust baseline model for most question answering domains.",id:"deepset/roberta-base-squad2"},{description:"Small yet robust model that can answer questions.",id:"distilbert/distilbert-base-cased-distilled-squad"},{description:"A special model that can answer questions from tables.",id:"google/tapas-base-finetuned-wtq"}],spaces:[{description:"An application that can answer a long question from Wikipedia.",id:"deepset/wikipedia-assistant"}],summary:"Question Answering models can retrieve the answer to a question from a given text, which is useful for searching for an answer in a document. Some question answering models can generate answers without context!",widgetModels:["deepset/roberta-base-squad2"],youtubeId:"ajPx5LwJD-I"},ni={datasets:[{description:"Bing queries with relevant passages from various web sources.",id:"microsoft/ms_marco"}],demo:{inputs:[{label:"Source sentence",content:"Machine learning is so easy.",type:"text"},{label:"Sentences to compare to",content:"Deep learning is so straightforward.",type:"text"},{label:"",content:"This is so difficult, like rocket science.",type:"text"},{label:"",content:"I can't believe how much I struggled with this.",type:"text"}],outputs:[{type:"chart",data:[{label:"Deep learning is so straightforward.",score:.623},{label:"This is so difficult, like rocket science.",score:.413},{label:"I can't believe how much I struggled with this.",score:.256}]}]},metrics:[{description:"Reciprocal Rank is a measure used to rank the relevancy of documents given a set of documents. Reciprocal Rank is the reciprocal of the rank of the document retrieved, meaning, if the rank is 3, the Reciprocal Rank is 0.33. If the rank is 1, the Reciprocal Rank is 1",id:"Mean Reciprocal Rank"},{description:"The similarity of the embeddings is evaluated mainly on cosine similarity. It is calculated as the cosine of the angle between two vectors. It is particularly useful when your texts are not the same length",id:"Cosine Similarity"}],models:[{description:"This model works well for sentences and paragraphs and can be used for clustering/grouping and semantic searches.",id:"sentence-transformers/all-mpnet-base-v2"},{description:"A multilingual robust sentence similarity model.",id:"BAAI/bge-m3"},{description:"A robust sentence similarity model.",id:"HIT-TMG/KaLM-embedding-multilingual-mini-instruct-v1.5"}],spaces:[{description:"An application that leverages sentence similarity to answer questions from YouTube videos.",id:"Gradio-Blocks/Ask_Questions_To_YouTube_Videos"},{description:"An application that retrieves relevant PubMed abstracts for a given online article which can be used as further references.",id:"Gradio-Blocks/pubmed-abstract-retriever"},{description:"An application that leverages sentence similarity to summarize text.",id:"nickmuchi/article-text-summarizer"},{description:"A guide that explains how Sentence Transformers can be used for semantic search.",id:"sentence-transformers/Sentence_Transformers_for_semantic_search"}],summary:"Sentence Similarity is the task of determining how similar two texts are. Sentence similarity models convert input texts into vectors (embeddings) that capture semantic information and calculate how close (similar) they are between them. This task is particularly useful for information retrieval and clustering/grouping.",widgetModels:["BAAI/bge-small-en-v1.5"],youtubeId:"VCZq5AkbNEU"},oi={canonicalId:"text2text-generation",datasets:[{description:"News articles in five different languages along with their summaries. Widely used for benchmarking multilingual summarization models.",id:"mlsum"},{description:"English conversations and their summaries. Useful for benchmarking conversational agents.",id:"samsum"}],demo:{inputs:[{label:"Input",content:"The tower is 324 metres (1,063 ft) tall, about the same height as an 81-storey building, and the tallest structure in Paris. Its base is square, measuring 125 metres (410 ft) on each side. It was the first structure to reach a height of 300 metres. Excluding transmitters, the Eiffel Tower is the second tallest free-standing structure in France after the Millau Viaduct.",type:"text"}],outputs:[{label:"Output",content:"The tower is 324 metres (1,063 ft) tall, about the same height as an 81-storey building. It was the first structure to reach a height of 300 metres.",type:"text"}]},metrics:[{description:"The generated sequence is compared against its summary, and the overlap of tokens are counted. ROUGE-N refers to overlap of N subsequent tokens, ROUGE-1 refers to overlap of single tokens and ROUGE-2 is the overlap of two subsequent tokens.",id:"rouge"}],models:[{description:"A strong summarization model trained on English news articles. Excels at generating factual summaries.",id:"facebook/bart-large-cnn"},{description:"A summarization model trained on medical articles.",id:"Falconsai/medical_summarization"}],spaces:[{description:"An application that can summarize long paragraphs.",id:"pszemraj/summarize-long-text"},{description:"A much needed summarization application for terms and conditions.",id:"ml6team/distilbart-tos-summarizer-tosdr"},{description:"An application that summarizes long documents.",id:"pszemraj/document-summarization"},{description:"An application that can detect errors in abstractive summarization.",id:"ml6team/post-processing-summarization"}],summary:"Summarization is the task of producing a shorter version of a document while preserving its important information. Some models can extract text from the original input, while other models can generate entirely new text.",widgetModels:["facebook/bart-large-cnn"],youtubeId:"yHnr5Dk2zCI"},ri={datasets:[{description:"The WikiTableQuestions dataset is a large-scale dataset for the task of question answering on semi-structured tables.",id:"wikitablequestions"},{description:"WikiSQL is a dataset of 80654 hand-annotated examples of questions and SQL queries distributed across 24241 tables from Wikipedia.",id:"wikisql"}],demo:{inputs:[{table:[["Rank","Name","No.of reigns","Combined days"],["1","lou Thesz","3","3749"],["2","Ric Flair","8","3103"],["3","Harley Race","7","1799"]],type:"tabular"},{label:"Question",content:"What is the number of reigns for Harley Race?",type:"text"}],outputs:[{label:"Result",content:"7",type:"text"}]},metrics:[{description:"Checks whether the predicted answer(s) is the same as the ground-truth answer(s).",id:"Denotation Accuracy"}],models:[{description:"A table question answering model that is capable of neural SQL execution, i.e., employ TAPEX to execute a SQL query on a given table.",id:"microsoft/tapex-base"},{description:"A robust table question answering model.",id:"google/tapas-base-finetuned-wtq"}],spaces:[{description:"An application that answers questions based on table CSV files.",id:"katanaml/table-query"}],summary:"Table Question Answering (Table QA) is the answering a question about an information on a given table.",widgetModels:["google/tapas-base-finetuned-wtq"]},si={datasets:[{description:"A comprehensive curation of datasets covering all benchmarks.",id:"inria-soda/tabular-benchmark"}],demo:{inputs:[{table:[["Glucose","Blood Pressure ","Skin Thickness","Insulin","BMI"],["148","72","35","0","33.6"],["150","50","30","0","35.1"],["141","60","29","1","39.2"]],type:"tabular"}],outputs:[{table:[["Diabetes"],["1"],["1"],["0"]],type:"tabular"}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"Breast cancer prediction model based on decision trees.",id:"scikit-learn/cancer-prediction-trees"}],spaces:[{description:"An application that can predict defective products on a production line.",id:"scikit-learn/tabular-playground"},{description:"An application that compares various tabular classification techniques on different datasets.",id:"scikit-learn/classification"}],summary:"Tabular classification is the task of classifying a target category (a group) based on set of attributes.",widgetModels:["scikit-learn/tabular-playground"],youtubeId:""},li={datasets:[{description:"A comprehensive curation of datasets covering all benchmarks.",id:"inria-soda/tabular-benchmark"}],demo:{inputs:[{table:[["Car Name","Horsepower","Weight"],["ford torino","140","3,449"],["amc hornet","97","2,774"],["toyota corolla","65","1,773"]],type:"tabular"}],outputs:[{table:[["MPG (miles per gallon)"],["17"],["18"],["31"]],type:"tabular"}]},metrics:[{description:"",id:"mse"},{description:"Coefficient of determination (or R-squared) is a measure of how well the model fits the data. Higher R-squared is considered a better fit.",id:"r-squared"}],models:[{description:"Fish weight prediction based on length measurements and species.",id:"scikit-learn/Fish-Weight"}],spaces:[{description:"An application that can predict weight of a fish based on set of attributes.",id:"scikit-learn/fish-weight-prediction"}],summary:"Tabular regression is the task of predicting a numerical value given a set of attributes.",widgetModels:["scikit-learn/Fish-Weight"],youtubeId:""},ci={datasets:[{description:"RedCaps is a large-scale dataset of 12M image-text pairs collected from Reddit.",id:"red_caps"},{description:"Conceptual Captions is a dataset consisting of ~3.3M images annotated with captions.",id:"conceptual_captions"},{description:"12M image-caption pairs.",id:"Spawning/PD12M"}],demo:{inputs:[{label:"Input",content:"A city above clouds, pastel colors, Victorian style",type:"text"}],outputs:[{filename:"image.jpeg",type:"img"}]},metrics:[{description:"The Inception Score (IS) measure assesses diversity and meaningfulness. It uses a generated image sample to predict its label. A higher score signifies more diverse and meaningful images.",id:"IS"},{description:"The Fréchet Inception Distance (FID) calculates the distance between distributions between synthetic and real samples. A lower FID score indicates better similarity between the distributions of real and generated images.",id:"FID"},{description:"R-precision assesses how the generated image aligns with the provided text description. It uses the generated images as queries to retrieve relevant text descriptions. The top 'r' relevant descriptions are selected and used to calculate R-precision as r/R, where 'R' is the number of ground truth descriptions associated with the generated images. A higher R-precision value indicates a better model.",id:"R-Precision"}],models:[{description:"One of the most powerful image generation models that can generate realistic outputs.",id:"black-forest-labs/FLUX.1-dev"},{description:"A powerful yet fast image generation model.",id:"latent-consistency/lcm-lora-sdxl"},{description:"Text-to-image model for photorealistic generation.",id:"Kwai-Kolors/Kolors"},{description:"A powerful text-to-image model.",id:"stabilityai/stable-diffusion-3-medium-diffusers"}],spaces:[{description:"A powerful text-to-image application.",id:"stabilityai/stable-diffusion-3-medium"},{description:"A text-to-image application to generate comics.",id:"jbilcke-hf/ai-comic-factory"},{description:"An application to match multiple custom image generation models.",id:"multimodalart/flux-lora-lab"},{description:"A powerful yet very fast image generation application.",id:"latent-consistency/lcm-lora-for-sdxl"},{description:"A gallery to explore various text-to-image models.",id:"multimodalart/LoraTheExplorer"},{description:"An application for `text-to-image`, `image-to-image` and image inpainting.",id:"ArtGAN/Stable-Diffusion-ControlNet-WebUI"},{description:"An application to generate realistic images given photos of a person and a prompt.",id:"InstantX/InstantID"}],summary:"Text-to-image is the task of generating images from input text. These pipelines can also be used to modify and edit images based on text prompts.",widgetModels:["black-forest-labs/FLUX.1-dev"],youtubeId:""},di={canonicalId:"text-to-audio",datasets:[{description:"10K hours of multi-speaker English dataset.",id:"parler-tts/mls_eng_10k"},{description:"Multi-speaker English dataset.",id:"mythicinfinity/libritts_r"},{description:"Multi-lingual dataset.",id:"facebook/multilingual_librispeech"}],demo:{inputs:[{label:"Input",content:"I love audio models on the Hub!",type:"text"}],outputs:[{filename:"audio.wav",type:"audio"}]},metrics:[{description:"The Mel Cepstral Distortion (MCD) metric is used to calculate the quality of generated speech.",id:"mel cepstral distortion"}],models:[{description:"A prompt based, powerful TTS model.",id:"parler-tts/parler-tts-large-v1"},{description:"A powerful TTS model that supports English and Chinese.",id:"SWivid/F5-TTS"},{description:"A massively multi-lingual TTS model.",id:"fishaudio/fish-speech-1.5"},{description:"A powerful TTS model.",id:"OuteAI/OuteTTS-0.1-350M"},{description:"Small yet powerful TTS model.",id:"hexgrad/Kokoro-82M"}],spaces:[{description:"An application for generate high quality speech in different languages.",id:"hexgrad/Kokoro-TTS"},{description:"A multilingual text-to-speech application.",id:"fishaudio/fish-speech-1"},{description:"An application that generates speech in different styles in English and Chinese.",id:"mrfakename/E2-F5-TTS"},{description:"An application that synthesizes emotional speech for diverse speaker prompts.",id:"parler-tts/parler-tts-expresso"},{description:"An application that generates podcast episodes.",id:"ngxson/kokoro-podcast-generator"}],summary:"Text-to-Speech (TTS) is the task of generating natural sounding speech given text input. TTS models can be extended to have a single model that generates speech for multiple speakers and multiple languages.",widgetModels:["suno/bark"],youtubeId:"NW62DpzJ274"},pi={datasets:[{description:"A widely used dataset useful to benchmark named entity recognition models.",id:"eriktks/conll2003"},{description:"A multilingual dataset of Wikipedia articles annotated for named entity recognition in over 150 different languages.",id:"unimelb-nlp/wikiann"}],demo:{inputs:[{label:"Input",content:"My name is Omar and I live in Zürich.",type:"text"}],outputs:[{text:"My name is Omar and I live in Zürich.",tokens:[{type:"PERSON",start:11,end:15},{type:"GPE",start:30,end:36}],type:"text-with-tokens"}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"A robust performance model to identify people, locations, organizations and names of miscellaneous entities.",id:"dslim/bert-base-NER"},{description:"A strong model to identify people, locations, organizations and names in multiple languages.",id:"FacebookAI/xlm-roberta-large-finetuned-conll03-english"},{description:"A token classification model specialized on medical entity recognition.",id:"blaze999/Medical-NER"},{description:"Flair models are typically the state of the art in named entity recognition tasks.",id:"flair/ner-english"}],spaces:[{description:"An application that can recognizes entities, extracts noun chunks and recognizes various linguistic features of each token.",id:"spacy/gradio_pipeline_visualizer"}],summary:"Token classification is a natural language understanding task in which a label is assigned to some tokens in a text. Some popular token classification subtasks are Named Entity Recognition (NER) and Part-of-Speech (PoS) tagging. NER models could be trained to identify specific entities in a text, such as dates, individuals and places; and PoS tagging would identify, for example, which words in a text are verbs, nouns, and punctuation marks.",widgetModels:["FacebookAI/xlm-roberta-large-finetuned-conll03-english"],youtubeId:"wVHdVlPScxA"},ui={canonicalId:"text2text-generation",datasets:[{description:"A dataset of copyright-free books translated into 16 different languages.",id:"Helsinki-NLP/opus_books"},{description:"An example of translation between programming languages. This dataset consists of functions in Java and C#.",id:"google/code_x_glue_cc_code_to_code_trans"}],demo:{inputs:[{label:"Input",content:"My name is Omar and I live in Zürich.",type:"text"}],outputs:[{label:"Output",content:"Mein Name ist Omar und ich wohne in Zürich.",type:"text"}]},metrics:[{description:"BLEU score is calculated by counting the number of shared single or subsequent tokens between the generated sequence and the reference. Subsequent n tokens are called “n-grams”. Unigram refers to a single token while bi-gram refers to token pairs and n-grams refer to n subsequent tokens. The score ranges from 0 to 1, where 1 means the translation perfectly matched and 0 did not match at all",id:"bleu"},{description:"",id:"sacrebleu"}],models:[{description:"Very powerful model that can translate many languages between each other, especially low-resource languages.",id:"facebook/nllb-200-1.3B"},{description:"A general-purpose Transformer that can be used to translate from English to German, French, or Romanian.",id:"google-t5/t5-base"}],spaces:[{description:"An application that can translate between 100 languages.",id:"Iker/Translate-100-languages"},{description:"An application that can translate between many languages.",id:"Geonmo/nllb-translation-demo"}],summary:"Translation is the task of converting text from one language to another.",widgetModels:["facebook/mbart-large-50-many-to-many-mmt"],youtubeId:"1JvfrvZgi6c"},mi={datasets:[{description:"A widely used dataset used to benchmark multiple variants of text classification.",id:"nyu-mll/glue"},{description:"A text classification dataset used to benchmark natural language inference models",id:"stanfordnlp/snli"}],demo:{inputs:[{label:"Input",content:"I love Hugging Face!",type:"text"}],outputs:[{type:"chart",data:[{label:"POSITIVE",score:.9},{label:"NEUTRAL",score:.1},{label:"NEGATIVE",score:0}]}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"The F1 metric is the harmonic mean of the precision and recall. It can be calculated as: F1 = 2 * (precision * recall) / (precision + recall)",id:"f1"}],models:[{description:"A robust model trained for sentiment analysis.",id:"distilbert/distilbert-base-uncased-finetuned-sst-2-english"},{description:"A sentiment analysis model specialized in financial sentiment.",id:"ProsusAI/finbert"},{description:"A sentiment analysis model specialized in analyzing tweets.",id:"cardiffnlp/twitter-roberta-base-sentiment-latest"},{description:"A model that can classify languages.",id:"papluca/xlm-roberta-base-language-detection"},{description:"A model that can classify text generation attacks.",id:"meta-llama/Prompt-Guard-86M"}],spaces:[{description:"An application that can classify financial sentiment.",id:"IoannisTr/Tech_Stocks_Trading_Assistant"},{description:"A dashboard that contains various text classification tasks.",id:"miesnerjacob/Multi-task-NLP"},{description:"An application that analyzes user reviews in healthcare.",id:"spacy/healthsea-demo"}],summary:"Text Classification is the task of assigning a label or class to a given text. Some use cases are sentiment analysis, natural language inference, and assessing grammatical correctness.",widgetModels:["distilbert/distilbert-base-uncased-finetuned-sst-2-english"],youtubeId:"leNG9fN9FQU"},fi={datasets:[{description:"Multilingual dataset used to evaluate text generation models.",id:"CohereForAI/Global-MMLU"},{description:"High quality multilingual data used to train text-generation models.",id:"HuggingFaceFW/fineweb-2"},{description:"Truly open-source, curated and cleaned dialogue dataset.",id:"HuggingFaceH4/ultrachat_200k"},{description:"A reasoning dataset.",id:"open-r1/OpenThoughts-114k-math"},{description:"A multilingual instruction dataset with preference ratings on responses.",id:"allenai/tulu-3-sft-mixture"},{description:"A large synthetic dataset for alignment of text generation models.",id:"HuggingFaceTB/smoltalk"},{description:"A dataset made for training text generation models solving math questions.",id:"HuggingFaceTB/finemath"}],demo:{inputs:[{label:"Input",content:"Once upon a time,",type:"text"}],outputs:[{label:"Output",content:"Once upon a time, we knew that our ancestors were on the verge of extinction. The great explorers and poets of the Old World, from Alexander the Great to Chaucer, are dead and gone. A good many of our ancient explorers and poets have",type:"text"}]},metrics:[{description:"Cross Entropy is a metric that calculates the difference between two probability distributions. Each probability distribution is the distribution of predicted words",id:"Cross Entropy"},{description:"The Perplexity metric is the exponential of the cross-entropy loss. It evaluates the probabilities assigned to the next word by the model. Lower perplexity indicates better performance",id:"Perplexity"}],models:[{description:"A text-generation model trained to follow instructions.",id:"google/gemma-2-2b-it"},{description:"Smaller variant of one of the most powerful models.",id:"deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B"},{description:"Very powerful text generation model trained to follow instructions.",id:"meta-llama/Meta-Llama-3.1-8B-Instruct"},{description:"Powerful text generation model by Microsoft.",id:"microsoft/phi-4"},{description:"A very powerful model with reasoning capabilities.",id:"simplescaling/s1.1-32B"},{description:"Strong conversational model that supports very long instructions.",id:"Qwen/Qwen2.5-7B-Instruct-1M"},{description:"Text generation model used to write code.",id:"Qwen/Qwen2.5-Coder-32B-Instruct"},{description:"Powerful reasoning based open large language model.",id:"deepseek-ai/DeepSeek-R1"}],spaces:[{description:"A leaderboard to compare different open-source text generation models based on various benchmarks.",id:"open-llm-leaderboard/open_llm_leaderboard"},{description:"A leaderboard for comparing chain-of-thought performance of models.",id:"logikon/open_cot_leaderboard"},{description:"An text generation based application based on a very powerful LLaMA2 model.",id:"ysharma/Explore_llamav2_with_TGI"},{description:"An text generation based application to converse with Zephyr model.",id:"HuggingFaceH4/zephyr-chat"},{description:"A leaderboard that ranks text generation models based on blind votes from people.",id:"lmsys/chatbot-arena-leaderboard"},{description:"An chatbot to converse with a very powerful text generation model.",id:"mlabonne/phixtral-chat"}],summary:"Generating text is the task of generating new text given another text. These models can, for example, fill in incomplete text or paraphrase.",widgetModels:["mistralai/Mistral-Nemo-Instruct-2407"],youtubeId:"e9gNEAlsOvU"},hi={datasets:[{description:"Bing queries with relevant passages from various web sources.",id:"microsoft/ms_marco"}],demo:{inputs:[{label:"Source sentence",content:"Machine learning is so easy.",type:"text"},{label:"Sentences to compare to",content:"Deep learning is so straightforward.",type:"text"},{label:"",content:"This is so difficult, like rocket science.",type:"text"},{label:"",content:"I can't believe how much I struggled with this.",type:"text"}],outputs:[{type:"chart",data:[{label:"Deep learning is so straightforward.",score:2.2006407},{label:"This is so difficult, like rocket science.",score:-6.2634873},{label:"I can't believe how much I struggled with this.",score:-10.251488}]}]},metrics:[{description:"Discounted Cumulative Gain (DCG) measures the gain, or usefulness, of search results discounted by their position. The normalization is done by dividing the DCG by the ideal DCG, which is the DCG of the perfect ranking.",id:"Normalized Discounted Cumulative Gain"},{description:"Reciprocal Rank is a measure used to rank the relevancy of documents given a set of documents. Reciprocal Rank is the reciprocal of the rank of the document retrieved, meaning, if the rank is 3, the Reciprocal Rank is 0.33. If the rank is 1, the Reciprocal Rank is 1",id:"Mean Reciprocal Rank"},{description:"Mean Average Precision (mAP) is the overall average of the Average Precision (AP) values, where AP is the Area Under the PR Curve (AUC-PR)",id:"Mean Average Precision"}],models:[{description:"An extremely efficient text ranking model trained on a web search dataset.",id:"cross-encoder/ms-marco-MiniLM-L6-v2"},{description:"A strong multilingual text reranker model.",id:"Alibaba-NLP/gte-multilingual-reranker-base"},{description:"An efficient text ranking model that punches above its weight.",id:"Alibaba-NLP/gte-reranker-modernbert-base"}],spaces:[],summary:"Text Ranking is the task of ranking a set of texts based on their relevance to a query. Text ranking models are trained on large datasets of queries and relevant documents to learn how to rank documents based on their relevance to the query. This task is particularly useful for search engines and information retrieval systems.",widgetModels:["cross-encoder/ms-marco-MiniLM-L6-v2"],youtubeId:""},gi={datasets:[{description:"Microsoft Research Video to Text is a large-scale dataset for open domain video captioning",id:"iejMac/CLIP-MSR-VTT"},{description:"UCF101 Human Actions dataset consists of 13,320 video clips from YouTube, with 101 classes.",id:"quchenyuan/UCF101-ZIP"},{description:"A high-quality dataset for human action recognition in YouTube videos.",id:"nateraw/kinetics"},{description:"A dataset of video clips of humans performing pre-defined basic actions with everyday objects.",id:"HuggingFaceM4/something_something_v2"},{description:"This dataset consists of text-video pairs and contains noisy samples with irrelevant video descriptions",id:"HuggingFaceM4/webvid"},{description:"A dataset of short Flickr videos for the temporal localization of events with descriptions.",id:"iejMac/CLIP-DiDeMo"}],demo:{inputs:[{label:"Input",content:"Darth Vader is surfing on the waves.",type:"text"}],outputs:[{filename:"text-to-video-output.gif",type:"img"}]},metrics:[{description:"Inception Score uses an image classification model that predicts class labels and evaluates how distinct and diverse the images are. A higher score indicates better video generation.",id:"is"},{description:"Frechet Inception Distance uses an image classification model to obtain image embeddings. The metric compares mean and standard deviation of the embeddings of real and generated images. A smaller score indicates better video generation.",id:"fid"},{description:"Frechet Video Distance uses a model that captures coherence for changes in frames and the quality of each frame. A smaller score indicates better video generation.",id:"fvd"},{description:"CLIPSIM measures similarity between video frames and text using an image-text similarity model. A higher score indicates better video generation.",id:"clipsim"}],models:[{description:"A strong model for consistent video generation.",id:"tencent/HunyuanVideo"},{description:"A text-to-video model with high fidelity motion and strong prompt adherence.",id:"Lightricks/LTX-Video"},{description:"A text-to-video model focusing on physics-aware applications like robotics.",id:"nvidia/Cosmos-1.0-Diffusion-7B-Text2World"},{description:"A robust model for video generation.",id:"Wan-AI/Wan2.1-T2V-1.3B"}],spaces:[{description:"An application that generates video from text.",id:"VideoCrafter/VideoCrafter"},{description:"Consistent video generation application.",id:"Wan-AI/Wan2.1"},{description:"A cutting edge video generation application.",id:"Pyramid-Flow/pyramid-flow"}],summary:"Text-to-video models can be used in any application that requires generating consistent sequence of images from text. ",widgetModels:["Wan-AI/Wan2.1-T2V-14B"],youtubeId:void 0},bi={datasets:[{description:"The CIFAR-100 dataset consists of 60000 32x32 colour images in 100 classes, with 600 images per class.",id:"cifar100"},{description:"Multiple images of celebrities, used for facial expression translation.",id:"CelebA"}],demo:{inputs:[{label:"Seed",content:"42",type:"text"},{label:"Number of images to generate:",content:"4",type:"text"}],outputs:[{filename:"unconditional-image-generation-output.jpeg",type:"img"}]},metrics:[{description:"The inception score (IS) evaluates the quality of generated images. It measures the diversity of the generated images (the model predictions are evenly distributed across all possible labels) and their 'distinction' or 'sharpness' (the model confidently predicts a single label for each image).",id:"Inception score (IS)"},{description:"The Fréchet Inception Distance (FID) evaluates the quality of images created by a generative model by calculating the distance between feature vectors for real and generated images.",id:"Frećhet Inception Distance (FID)"}],models:[{description:"High-quality image generation model trained on the CIFAR-10 dataset. It synthesizes images of the ten classes presented in the dataset using diffusion probabilistic models, a class of latent variable models inspired by considerations from nonequilibrium thermodynamics.",id:"google/ddpm-cifar10-32"},{description:"High-quality image generation model trained on the 256x256 CelebA-HQ dataset. It synthesizes images of faces using diffusion probabilistic models, a class of latent variable models inspired by considerations from nonequilibrium thermodynamics.",id:"google/ddpm-celebahq-256"}],spaces:[{description:"An application that can generate realistic faces.",id:"CompVis/celeba-latent-diffusion"}],summary:"Unconditional image generation is the task of generating images with no condition in any context (like a prompt text or another image). Once trained, the model will create images that resemble its training data distribution.",widgetModels:[""],youtubeId:""},yi={datasets:[{description:"Benchmark dataset used for video classification with videos that belong to 400 classes.",id:"kinetics400"}],demo:{inputs:[{filename:"video-classification-input.gif",type:"img"}],outputs:[{type:"chart",data:[{label:"Playing Guitar",score:.514},{label:"Playing Tennis",score:.193},{label:"Cooking",score:.068}]}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"Strong Video Classification model trained on the Kinetics 400 dataset.",id:"google/vivit-b-16x2-kinetics400"},{description:"Strong Video Classification model trained on the Kinetics 400 dataset.",id:"microsoft/xclip-base-patch32"}],spaces:[{description:"An application that classifies video at different timestamps.",id:"nateraw/lavila"},{description:"An application that classifies video.",id:"fcakyon/video-classification"}],summary:"Video classification is the task of assigning a label or class to an entire video. Videos are expected to have only one class for each video. Video classification models take a video as input and return a prediction about which class the video belongs to.",widgetModels:[],youtubeId:""},wi={datasets:[{description:"A widely used dataset containing questions (with answers) about images.",id:"Graphcore/vqa"},{description:"A dataset to benchmark visual reasoning based on text in images.",id:"facebook/textvqa"}],demo:{inputs:[{filename:"elephant.jpeg",type:"img"},{label:"Question",content:"What is in this image?",type:"text"}],outputs:[{type:"chart",data:[{label:"elephant",score:.97},{label:"elephants",score:.06},{label:"animal",score:.003}]}]},isPlaceholder:!1,metrics:[{description:"",id:"accuracy"},{description:"Measures how much a predicted answer differs from the ground truth based on the difference in their semantic meaning.",id:"wu-palmer similarity"}],models:[{description:"A visual question answering model trained to convert charts and plots to text.",id:"google/deplot"},{description:"A visual question answering model trained for mathematical reasoning and chart derendering from images.",id:"google/matcha-base"},{description:"A strong visual question answering that answers questions from book covers.",id:"google/pix2struct-ocrvqa-large"}],spaces:[{description:"An application that compares visual question answering models across different tasks.",id:"merve/pix2struct"},{description:"An application that can answer questions based on images.",id:"nielsr/vilt-vqa"},{description:"An application that can caption images and answer questions about a given image. ",id:"Salesforce/BLIP"},{description:"An application that can caption images and answer questions about a given image. ",id:"vumichien/Img2Prompt"}],summary:"Visual Question Answering is the task of answering open-ended questions based on an image. They output natural language responses to natural language questions.",widgetModels:["dandelin/vilt-b32-finetuned-vqa"],youtubeId:""},vi={datasets:[{description:"A widely used dataset used to benchmark multiple variants of text classification.",id:"nyu-mll/glue"},{description:"The Multi-Genre Natural Language Inference (MultiNLI) corpus is a crowd-sourced collection of 433k sentence pairs annotated with textual entailment information.",id:"nyu-mll/multi_nli"},{description:"FEVER is a publicly available dataset for fact extraction and verification against textual sources.",id:"fever/fever"}],demo:{inputs:[{label:"Text Input",content:"Dune is the best movie ever.",type:"text"},{label:"Candidate Labels",content:"CINEMA, ART, MUSIC",type:"text"}],outputs:[{type:"chart",data:[{label:"CINEMA",score:.9},{label:"ART",score:.1},{label:"MUSIC",score:0}]}]},metrics:[],models:[{description:"Powerful zero-shot text classification model.",id:"facebook/bart-large-mnli"},{description:"Cutting-edge zero-shot multilingual text classification model.",id:"MoritzLaurer/ModernBERT-large-zeroshot-v2.0"},{description:"Zero-shot text classification model that can be used for topic and sentiment classification.",id:"knowledgator/gliclass-modern-base-v2.0-init"}],spaces:[],summary:"Zero-shot text classification is a task in natural language processing where a model is trained on a set of labeled examples but is then able to classify new examples from previously unseen classes.",widgetModels:["facebook/bart-large-mnli"]},_i={datasets:[{description:"",id:""}],demo:{inputs:[{filename:"image-classification-input.jpeg",type:"img"},{label:"Classes",content:"cat, dog, bird",type:"text"}],outputs:[{type:"chart",data:[{label:"Cat",score:.664},{label:"Dog",score:.329},{label:"Bird",score:.008}]}]},metrics:[{description:"Computes the number of times the correct label appears in top K labels predicted",id:"top-K accuracy"}],models:[{description:"Multilingual image classification model for 80 languages.",id:"visheratin/mexma-siglip"},{description:"Strong zero-shot image classification model.",id:"google/siglip2-base-patch16-224"},{description:"Robust zero-shot image classification model.",id:"intfloat/mmE5-mllama-11b-instruct"},{description:"Powerful zero-shot image classification model supporting 94 languages.",id:"jinaai/jina-clip-v2"},{description:"Strong image classification model for biomedical domain.",id:"microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224"}],spaces:[{description:"An application that leverages zero-shot image classification to find best captions to generate an image. ",id:"pharma/CLIP-Interrogator"},{description:"An application to compare different zero-shot image classification models. ",id:"merve/compare_clip_siglip"}],summary:"Zero-shot image classification is the task of classifying previously unseen classes during training of a model.",widgetModels:["google/siglip-so400m-patch14-224"],youtubeId:""},xi={datasets:[],demo:{inputs:[{filename:"zero-shot-object-detection-input.jpg",type:"img"},{label:"Classes",content:"cat, dog, bird",type:"text"}],outputs:[{filename:"zero-shot-object-detection-output.jpg",type:"img"}]},metrics:[{description:"The Average Precision (AP) metric is the Area Under the PR Curve (AUC-PR). It is calculated for each class separately",id:"Average Precision"},{description:"The Mean Average Precision (mAP) metric is the overall average of the AP values",id:"Mean Average Precision"},{description:"The APα metric is the Average Precision at the IoU threshold of a α value, for example, AP50 and AP75",id:"APα"}],models:[{description:"Solid zero-shot object detection model.",id:"IDEA-Research/grounding-dino-base"},{description:"Cutting-edge zero-shot object detection model.",id:"google/owlv2-base-patch16-ensemble"}],spaces:[{description:"A demo to try the state-of-the-art zero-shot object detection model, OWLv2.",id:"merve/owlv2"},{description:"A demo that combines a zero-shot object detection and mask generation model for zero-shot segmentation.",id:"merve/OWLSAM"}],summary:"Zero-shot object detection is a computer vision task to detect objects and their classes in images, without any prior training or knowledge of the classes. Zero-shot object detection models receive an image as input, as well as a list of candidate classes, and output the bounding boxes and labels where the objects have been detected.",widgetModels:[],youtubeId:""},ki={datasets:[{description:"A large dataset of over 10 million 3D objects.",id:"allenai/objaverse-xl"},{description:"A dataset of isolated object images for evaluating image-to-3D models.",id:"dylanebert/iso3d"}],demo:{inputs:[{filename:"image-to-3d-image-input.png",type:"img"}],outputs:[{label:"Result",content:"image-to-3d-3d-output-filename.glb",type:"text"}]},metrics:[],models:[{description:"Fast image-to-3D mesh model by Tencent.",id:"TencentARC/InstantMesh"},{description:"Fast image-to-3D mesh model by StabilityAI",id:"stabilityai/TripoSR"},{description:"A scaled up image-to-3D mesh model derived from TripoSR.",id:"hwjiang/Real3D"},{description:"Consistent image-to-3d generation model.",id:"stabilityai/stable-point-aware-3d"}],spaces:[{description:"Leaderboard to evaluate image-to-3D models.",id:"dylanebert/3d-arena"},{description:"Image-to-3D demo with mesh outputs.",id:"TencentARC/InstantMesh"},{description:"Image-to-3D demo.",id:"stabilityai/stable-point-aware-3d"},{description:"Image-to-3D demo with mesh outputs.",id:"hwjiang/Real3D"},{description:"Image-to-3D demo with splat outputs.",id:"dylanebert/LGM-mini"}],summary:"Image-to-3D models take in image input and produce 3D output.",widgetModels:[],youtubeId:""},Ai={datasets:[{description:"A large dataset of over 10 million 3D objects.",id:"allenai/objaverse-xl"},{description:"Descriptive captions for 3D objects in Objaverse.",id:"tiange/Cap3D"}],demo:{inputs:[{label:"Prompt",content:"a cat statue",type:"text"}],outputs:[{label:"Result",content:"text-to-3d-3d-output-filename.glb",type:"text"}]},metrics:[],models:[{description:"Text-to-3D mesh model by OpenAI",id:"openai/shap-e"},{description:"Generative 3D gaussian splatting model.",id:"ashawkey/LGM"}],spaces:[{description:"Text-to-3D demo with mesh outputs.",id:"hysts/Shap-E"},{description:"Text/image-to-3D demo with splat outputs.",id:"ashawkey/LGM"}],summary:"Text-to-3D models take in text input and produce 3D output.",widgetModels:[],youtubeId:""},Ti={datasets:[{description:"A dataset of hand keypoints of over 500k examples.",id:"Vincent-luo/hagrid-mediapipe-hands"}],demo:{inputs:[{filename:"keypoint-detection-input.png",type:"img"}],outputs:[{filename:"keypoint-detection-output.png",type:"img"}]},metrics:[],models:[{description:"A robust keypoint detection model.",id:"magic-leap-community/superpoint"},{description:"A robust keypoint matching model.",id:"magic-leap-community/superglue_outdoor"},{description:"Strong keypoint detection model used to detect human pose.",id:"facebook/sapiens-pose-1b"},{description:"Powerful keypoint detection model used to detect human pose.",id:"usyd-community/vitpose-plus-base"}],spaces:[{description:"An application that detects hand keypoints in real-time.",id:"datasciencedojo/Hand-Keypoint-Detection-Realtime"},{description:"An application to try a universal keypoint detection model.",id:"merve/SuperPoint"}],summary:"Keypoint detection is the task of identifying meaningful distinctive points or features in an image.",widgetModels:[],youtubeId:""},Si={datasets:[{description:"Multiple-choice questions and answers about videos.",id:"lmms-lab/Video-MME"},{description:"A dataset of instructions and question-answer pairs about videos.",id:"lmms-lab/VideoChatGPT"},{description:"Large video understanding dataset.",id:"HuggingFaceFV/finevideo"}],demo:{inputs:[{filename:"video-text-to-text-input.gif",type:"img"},{label:"Text Prompt",content:"What is happening in this video?",type:"text"}],outputs:[{label:"Answer",content:"The video shows a series of images showing a fountain with water jets and a variety of colorful flowers and butterflies in the background.",type:"text"}]},metrics:[],models:[{description:"A robust video-text-to-text model.",id:"Vision-CAIR/LongVU_Qwen2_7B"},{description:"Strong video-text-to-text model with reasoning capabilities.",id:"GoodiesHere/Apollo-LMMs-Apollo-7B-t32"},{description:"Strong video-text-to-text model.",id:"HuggingFaceTB/SmolVLM2-2.2B-Instruct"}],spaces:[{description:"An application to chat with a video-text-to-text model.",id:"llava-hf/video-llava"},{description:"A leaderboard for various video-text-to-text models.",id:"opencompass/openvlm_video_leaderboard"},{description:"An application to generate highlights from a video.",id:"HuggingFaceTB/SmolVLM2-HighlightGenerator"}],summary:"Video-text-to-text models take in a video and a text prompt and output text. These models are also called video-language models.",widgetModels:[""],youtubeId:""},Ii={"audio-classification":["speechbrain","transformers","transformers.js"],"audio-to-audio":["asteroid","fairseq","speechbrain"],"automatic-speech-recognition":["espnet","nemo","speechbrain","transformers","transformers.js"],"audio-text-to-text":[],"depth-estimation":["transformers","transformers.js"],"document-question-answering":["transformers","transformers.js"],"feature-extraction":["sentence-transformers","transformers","transformers.js"],"fill-mask":["transformers","transformers.js"],"graph-ml":["transformers"],"image-classification":["keras","timm","transformers","transformers.js"],"image-feature-extraction":["timm","transformers"],"image-segmentation":["transformers","transformers.js"],"image-text-to-text":["transformers"],"image-to-image":["diffusers","transformers","transformers.js"],"image-to-text":["transformers","transformers.js"],"image-to-video":["diffusers"],"keypoint-detection":["transformers"],"video-classification":["transformers"],"mask-generation":["transformers"],"multiple-choice":["transformers"],"object-detection":["transformers","transformers.js","ultralytics"],other:[],"question-answering":["adapter-transformers","allennlp","transformers","transformers.js"],robotics:[],"reinforcement-learning":["transformers","stable-baselines3","ml-agents","sample-factory"],"sentence-similarity":["sentence-transformers","spacy","transformers.js"],summarization:["transformers","transformers.js"],"table-question-answering":["transformers"],"table-to-text":["transformers"],"tabular-classification":["sklearn"],"tabular-regression":["sklearn"],"tabular-to-text":["transformers"],"text-classification":["adapter-transformers","setfit","spacy","transformers","transformers.js"],"text-generation":["transformers","transformers.js"],"text-ranking":["sentence-transformers","transformers"],"text-retrieval":[],"text-to-image":["diffusers"],"text-to-speech":["espnet","tensorflowtts","transformers","transformers.js"],"text-to-audio":["transformers","transformers.js"],"text-to-video":["diffusers"],"text2text-generation":["transformers","transformers.js"],"time-series-forecasting":[],"token-classification":["adapter-transformers","flair","spacy","span-marker","stanza","transformers","transformers.js"],translation:["transformers","transformers.js"],"unconditional-image-generation":["diffusers"],"video-text-to-text":["transformers"],"visual-question-answering":["transformers","transformers.js"],"voice-activity-detection":[],"zero-shot-classification":["transformers","transformers.js"],"zero-shot-image-classification":["transformers","transformers.js"],"zero-shot-object-detection":["transformers","transformers.js"],"text-to-3d":["diffusers"],"image-to-3d":["diffusers"],"any-to-any":["transformers"],"visual-document-retrieval":["transformers"]};function x(e,t=Be){return{...t,id:e,label:Xe[e].name,libraries:Ii[e]}}x("any-to-any",qa),x("audio-classification",Ba),x("audio-to-audio",Fa),x("audio-text-to-text",Be),x("automatic-speech-recognition",Ha),x("depth-estimation",ti),x("document-question-answering",Va),x("visual-document-retrieval",Be),x("feature-extraction",za),x("fill-mask",Wa),x("image-classification",Ka),x("image-feature-extraction",Ja),x("image-segmentation",Za),x("image-to-image",Qa),x("image-text-to-text",Ya),x("image-to-text",Xa),x("keypoint-detection",Ti),x("mask-generation",Ga),x("object-detection",ei),x("video-classification",yi),x("question-answering",ii),x("reinforcement-learning",ai),x("sentence-similarity",ni),x("summarization",oi),x("table-question-answering",ri),x("tabular-classification",si),x("tabular-regression",li),x("text-classification",mi),x("text-generation",fi),x("text-ranking",hi),x("text-to-image",ci),x("text-to-speech",di),x("text-to-video",gi),x("token-classification",pi),x("translation",ui),x("unconditional-image-generation",bi),x("video-text-to-text",Si),x("visual-question-answering",wi),x("zero-shot-classification",vi),x("zero-shot-image-classification",_i),x("zero-shot-object-detection",xi),x("text-to-3d",Ai),x("image-to-3d",ki);const Ei=()=>'"Hi, I recently bought a device from your company but it is not working as advertised and I would like to get reimbursed!"',Ci=()=>'"Меня зовут Вольфганг и я живу в Берлине"',Mi=()=>'"The tower is 324 metres (1,063 ft) tall, about the same height as an 81-storey building, and the tallest structure in Paris. Its base is square, measuring 125 metres (410 ft) on each side. During its construction, the Eiffel Tower surpassed the Washington Monument to become the tallest man-made structure in the world, a title it held for 41 years until the Chrysler Building in New York City was finished in 1930. It was the first structure to reach a height of 300 metres. Due to the addition of a broadcasting aerial at the top of the tower in 1957, it is now taller than the Chrysler Building by 5.2 metres (17 ft). Excluding transmitters, the Eiffel Tower is the second tallest free-standing structure in France after the Millau Viaduct."',Ri=()=>`{
    "query": "How many stars does the transformers repository have?",
    "table": {
        "Repository": ["Transformers", "Datasets", "Tokenizers"],
        "Stars": ["36542", "4512", "3934"],
        "Contributors": ["651", "77", "34"],
        "Programming language": [
            "Python",
            "Python",
            "Rust, Python and NodeJS"
        ]
    }
}`,$i=()=>`{
        "image": "cat.png",
        "question": "What is in this image?"
    }`,Di=()=>`{
    "question": "What is my name?",
    "context": "My name is Clara and I live in Berkeley."
}`,Li=()=>'"I like you. I love you"',Ui=()=>'"My name is Sarah Jessica Parker but you can call me Jessica"',St=e=>e.tags.includes("conversational")?e.pipeline_tag==="text-generation"?[{role:"user",content:"What is the capital of France?"}]:[{role:"user",content:[{type:"text",text:"Describe this image in one sentence."},{type:"image_url",image_url:{url:"https://cdn.britannica.com/61/93061-050-99147DCE/Statue-of-Liberty-Island-New-York-Bay.jpg"}}]}]:'"Can you please let us know more details about your "',Pi=()=>'"The answer to the universe is"',Ni=e=>`"The answer to the universe is ${e.mask_token}."`,ji=()=>`{
    "source_sentence": "That is a happy person",
    "sentences": [
        "That is a happy dog",
        "That is a very happy person",
        "Today is a sunny day"
    ]
}`,Oi=()=>'"Today is a sunny day and I will get some ice cream."',qi=()=>'"cats.jpg"',Bi=()=>'"cats.jpg"',Fi=()=>`{
    "image": "cat.png",
    "prompt": "Turn the cat into a tiger."
}`,Hi=()=>'"cats.jpg"',Vi=()=>'"cats.jpg"',zi=()=>'"sample1.flac"',Wi=()=>'"sample1.flac"',Ki=()=>'"Astronaut riding a horse"',Ji=()=>'"A young man walking on the street"',Qi=()=>'"The answer to the universe is 42"',Xi=()=>'"liquid drum and bass, atmospheric synths, airy sounds"',Yi=()=>'"sample1.flac"',It=()=>`'{"Height":[11.52,12.48],"Length1":[23.2,24.0],"Length2":[25.4,26.3],"Species": ["Bream","Bream"]}'`,Zi=()=>'"cats.jpg"',Gi={"audio-to-audio":zi,"audio-classification":Wi,"automatic-speech-recognition":Yi,"document-question-answering":$i,"feature-extraction":Oi,"fill-mask":Ni,"image-classification":qi,"image-to-text":Bi,"image-to-image":Fi,"image-segmentation":Hi,"object-detection":Vi,"question-answering":Di,"sentence-similarity":ji,summarization:Mi,"table-question-answering":Ri,"tabular-regression":It,"tabular-classification":It,"text-classification":Li,"text-generation":St,"image-text-to-text":St,"text-to-image":Ki,"text-to-video":Ji,"text-to-speech":Qi,"text-to-audio":Xi,"text2text-generation":Pi,"token-classification":Ui,translation:Ci,"zero-shot-classification":Ei,"zero-shot-image-classification":Zi};function Ae(e,t=!1,a=!1){if(e.pipeline_tag){const i=Gi[e.pipeline_tag];if(i){let n=i(e);if(typeof n=="string"&&(t&&(n=n.replace(/(?:(?:\r?\n|\r)\t*)|\t+/g," ")),a)){const o=/^"(.+)"$/s,r=n.match(o);n=r?r[1]:n}return n}}return"No input example has been defined for this model task."}function en(e,t){let a=JSON.stringify(e,null,"	");return t!=null&&t.indent&&(a=a.replaceAll(`
`,`
${t.indent}`)),t!=null&&t.attributeKeyQuotes||(a=a.replace(/"([^"]+)":/g,"$1:")),t!=null&&t.customContentEscaper&&(a=t.customContentEscaper(a)),a}const qt="custom_code";function G(e){const t=e.split("/");return t.length===1?t[0]:t[1]}const tn=e=>JSON.stringify(e).slice(1,-1),an=e=>{var t,a;return[`from adapters import AutoAdapterModel

model = AutoAdapterModel.from_pretrained("${(a=(t=e.config)==null?void 0:t.adapter_transformers)==null?void 0:a.model_name}")
model.load_adapter("${e.id}", set_active=True)`]},nn=e=>[`import allennlp_models
from allennlp.predictors.predictor import Predictor

predictor = Predictor.from_path("hf://${e.id}")`],on=e=>[`import allennlp_models
from allennlp.predictors.predictor import Predictor

predictor = Predictor.from_path("hf://${e.id}")
predictor_input = {"passage": "My name is Wolfgang and I live in Berlin", "question": "Where do I live?"}
predictions = predictor.predict_json(predictor_input)`],rn=e=>e.tags.includes("question-answering")?on(e):nn(e),sn=e=>[`from araclip import AraClip

model = AraClip.from_pretrained("${e.id}")`],ln=e=>[`from asteroid.models import BaseModel

model = BaseModel.from_pretrained("${e.id}")`],cn=e=>{const t=`# Watermark Generator
from audioseal import AudioSeal

model = AudioSeal.load_generator("${e.id}")
# pass a tensor (tensor_wav) of shape (batch, channels, samples) and a sample rate
wav, sr = tensor_wav, 16000
	
watermark = model.get_watermark(wav, sr)
watermarked_audio = wav + watermark`,a=`# Watermark Detector
from audioseal import AudioSeal

detector = AudioSeal.load_detector("${e.id}")
	
result, message = detector.detect_watermark(watermarked_audio, sr)`;return[t,a]};function Ye(e){var t,a;return((a=(t=e.cardData)==null?void 0:t.base_model)==null?void 0:a.toString())??"fill-in-base-model"}function Bt(e){var a,i,n;const t=((i=(a=e.widgetData)==null?void 0:a[0])==null?void 0:i.text)??((n=e.cardData)==null?void 0:n.instance_prompt);if(t)return tn(t)}const dn=e=>[`import requests
from PIL import Image
from ben2 import AutoModel

url = "https://huggingface.co/datasets/mishig/sample_images/resolve/main/teapot.jpg"
image = Image.open(requests.get(url, stream=True).raw)

model = AutoModel.from_pretrained("${e.id}")
model.to("cuda").eval()
foreground = model.inference(image)
`],pn=e=>[`from bertopic import BERTopic

model = BERTopic.load("${e.id}")`],un=e=>[`from bm25s.hf import BM25HF

retriever = BM25HF.load_from_hub("${e.id}")`],mn=()=>[`# pip install git+https://github.com/Google-Health/cxr-foundation.git#subdirectory=python

# Load image as grayscale (Stillwaterising, CC0, via Wikimedia Commons)
import requests
from PIL import Image
from io import BytesIO
image_url = "https://upload.wikimedia.org/wikipedia/commons/c/c8/Chest_Xray_PA_3-8-2010.png"
img = Image.open(requests.get(image_url, headers={'User-Agent': 'Demo'}, stream=True).raw).convert('L')

# Run inference
from clientside.clients import make_hugging_face_client
cxr_client = make_hugging_face_client('cxr_model')
print(cxr_client.get_image_embeddings_from_images([img]))`],fn=e=>{let t,a,i;return t="<ENCODER>",a="<NUMBER_OF_FEATURES>",i="<OUT_CHANNELS>",e.id==="depth-anything/Depth-Anything-V2-Small"?(t="vits",a="64",i="[48, 96, 192, 384]"):e.id==="depth-anything/Depth-Anything-V2-Base"?(t="vitb",a="128",i="[96, 192, 384, 768]"):e.id==="depth-anything/Depth-Anything-V2-Large"&&(t="vitl",a="256",i="[256, 512, 1024, 1024"),[`
# Install from https://github.com/DepthAnything/Depth-Anything-V2

# Load the model and infer depth from an image
import cv2
import torch

from depth_anything_v2.dpt import DepthAnythingV2

# instantiate the model
model = DepthAnythingV2(encoder="${t}", features=${a}, out_channels=${i})

# load the weights
filepath = hf_hub_download(repo_id="${e.id}", filename="depth_anything_v2_${t}.pth", repo_type="model")
state_dict = torch.load(filepath, map_location="cpu")
model.load_state_dict(state_dict).eval()

raw_img = cv2.imread("your/image/path")
depth = model.infer_image(raw_img) # HxW raw depth map in numpy
    `]},hn=e=>[`# Download checkpoint
pip install huggingface-hub
huggingface-cli download --local-dir checkpoints ${e.id}`,`import depth_pro

# Load model and preprocessing transform
model, transform = depth_pro.create_model_and_transforms()
model.eval()

# Load and preprocess an image.
image, _, f_px = depth_pro.load_rgb("example.png")
image = transform(image)

# Run inference.
prediction = model.infer(image, f_px=f_px)

# Results: 1. Depth in meters
depth = prediction["depth"]
# Results: 2. Focal length in pixels
focallength_px = prediction["focallength_px"]`],gn=()=>[`from huggingface_hub import from_pretrained_keras
import tensorflow as tf, requests

# Load and format input
IMAGE_URL = "https://storage.googleapis.com/dx-scin-public-data/dataset/images/3445096909671059178.png"
input_tensor = tf.train.Example(
    features=tf.train.Features(
        feature={
            "image/encoded": tf.train.Feature(
                bytes_list=tf.train.BytesList(value=[requests.get(IMAGE_URL, stream=True).content])
            )
        }
    )
).SerializeToString()

# Load model and run inference
loaded_model = from_pretrained_keras("google/derm-foundation")
infer = loaded_model.signatures["serving_default"]
print(infer(inputs=tf.constant([input_tensor])))`],Ft="Astronaut in a jungle, cold color palette, muted colors, detailed, 8k",bn=e=>[`from diffusers import DiffusionPipeline

pipe = DiffusionPipeline.from_pretrained("${e.id}")

prompt = "${Bt(e)??Ft}"
image = pipe(prompt).images[0]`],yn=e=>[`from diffusers import ControlNetModel, StableDiffusionControlNetPipeline

controlnet = ControlNetModel.from_pretrained("${e.id}")
pipe = StableDiffusionControlNetPipeline.from_pretrained(
	"${Ye(e)}", controlnet=controlnet
)`],wn=e=>[`from diffusers import DiffusionPipeline

pipe = DiffusionPipeline.from_pretrained("${Ye(e)}")
pipe.load_lora_weights("${e.id}")

prompt = "${Bt(e)??Ft}"
image = pipe(prompt).images[0]`],vn=e=>[`from diffusers import DiffusionPipeline

pipe = DiffusionPipeline.from_pretrained("${Ye(e)}")
pipe.load_textual_inversion("${e.id}")`],_n=e=>e.tags.includes("controlnet")?yn(e):e.tags.includes("lora")?wn(e):e.tags.includes("textual_inversion")?vn(e):bn(e),xn=e=>{const t=`# Pipeline for Stable Diffusion 3
from diffusionkit.mlx import DiffusionPipeline

pipeline = DiffusionPipeline(
	shift=3.0,
	use_t5=False,
	model_version=${e.id},
	low_memory_mode=True,
	a16=True,
	w16=True,
)`,a=`# Pipeline for Flux
from diffusionkit.mlx import FluxPipeline

pipeline = FluxPipeline(
  shift=1.0,
  model_version=${e.id},
  low_memory_mode=True,
  a16=True,
  w16=True,
)`,i=`# Image Generation
HEIGHT = 512
WIDTH = 512
NUM_STEPS = ${e.tags.includes("flux")?4:50}
CFG_WEIGHT = ${e.tags.includes("flux")?0:5}

image, _ = pipeline.generate_image(
  "a photo of a cat",
  cfg_weight=CFG_WEIGHT,
  num_steps=NUM_STEPS,
  latent_size=(HEIGHT // 8, WIDTH // 8),
)`;return[e.tags.includes("flux")?a:t,i]},kn=e=>[`# pip install --no-binary :all: cartesia-pytorch
from cartesia_pytorch import ReneLMHeadModel
from transformers import AutoTokenizer

model = ReneLMHeadModel.from_pretrained("${e.id}")
tokenizer = AutoTokenizer.from_pretrained("allenai/OLMo-1B-hf")

in_message = ["Rene Descartes was"]
inputs = tokenizer(in_message, return_tensors="pt")

outputs = model.generate(inputs.input_ids, max_length=50, top_k=100, top_p=0.99)
out_message = tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]

print(out_message)
)`],An=e=>[`import mlx.core as mx
import cartesia_mlx as cmx

model = cmx.from_pretrained("${e.id}")
model.set_dtype(mx.float32)   

prompt = "Rene Descartes was"

for text in model.generate(
    prompt,
    max_tokens=500,
    eval_every_n=5,
    verbose=True,
    top_p=0.99,
    temperature=0.85,
):
    print(text, end="", flush=True)
`],Tn=e=>{const t=G(e.id).replaceAll("-","_");return[`# Load it from the Hub directly
import edsnlp
nlp = edsnlp.load("${e.id}")
`,`# Or install it as a package
!pip install git+https://huggingface.co/${e.id}

# and import it as a module
import ${t}

nlp = ${t}.load()  # or edsnlp.load("${t}")
`]},Sn=e=>[`from espnet2.bin.tts_inference import Text2Speech

model = Text2Speech.from_pretrained("${e.id}")

speech, *_ = model("text to generate speech from")`],In=e=>[`from espnet2.bin.asr_inference import Speech2Text

model = Speech2Text.from_pretrained(
  "${e.id}"
)

speech, rate = soundfile.read("speech.wav")
text, *_ = model(speech)[0]`],En=()=>["unknown model type (must be text-to-speech or automatic-speech-recognition)"],Cn=e=>e.tags.includes("text-to-speech")?Sn(e):e.tags.includes("automatic-speech-recognition")?In(e):En(),Mn=e=>[`from fairseq.checkpoint_utils import load_model_ensemble_and_task_from_hf_hub

models, cfg, task = load_model_ensemble_and_task_from_hf_hub(
    "${e.id}"
)`],Rn=e=>[`from flair.models import SequenceTagger

tagger = SequenceTagger.load("${e.id}")`],$n=e=>[`from gliner import GLiNER

model = GLiNER.from_pretrained("${e.id}")`],Dn=e=>[`# CLI usage
# see docs: https://ai-riksarkivet.github.io/htrflow/latest/getting_started/quick_start.html
htrflow pipeline <path/to/pipeline.yaml> <path/to/image>`,`# Python usage
from htrflow.pipeline.pipeline import Pipeline
from htrflow.pipeline.steps import Task
from htrflow.models.framework.model import ModelClass

pipeline = Pipeline(
    [
        Task(
            ModelClass, {"model": "${e.id}"}, {}
        ),
    ])`],Ln=e=>[`# Available backend options are: "jax", "torch", "tensorflow".
import os
os.environ["KERAS_BACKEND"] = "jax"
	
import keras

model = keras.saving.load_model("hf://${e.id}")
`],Un=e=>`
import keras_hub

# Load CausalLM model (optional: use half precision for inference)
causal_lm = keras_hub.models.CausalLM.from_preset("hf://${e}", dtype="bfloat16")
causal_lm.compile(sampler="greedy")  # (optional) specify a sampler

# Generate text
causal_lm.generate("Keras: deep learning for", max_length=64)
`,Pn=e=>`
import keras_hub

# Load TextToImage model (optional: use half precision for inference)
text_to_image = keras_hub.models.TextToImage.from_preset("hf://${e}", dtype="bfloat16")

# Generate images with a TextToImage model.
text_to_image.generate("Astronaut in a jungle")
`,Nn=e=>`
import keras_hub

# Load TextClassifier model
text_classifier = keras_hub.models.TextClassifier.from_preset(
    "hf://${e}",
    num_classes=2,
)
# Fine-tune
text_classifier.fit(x=["Thilling adventure!", "Total snoozefest."], y=[1, 0])
# Classify text
text_classifier.predict(["Not my cup of tea."])
`,jn=e=>`
import keras_hub
import keras

# Load ImageClassifier model
image_classifier = keras_hub.models.ImageClassifier.from_preset(
    "hf://${e}",
    num_classes=2,
)
# Fine-tune
image_classifier.fit(
    x=keras.random.randint((32, 64, 64, 3), 0, 256),
    y=keras.random.randint((32, 1), 0, 2),
)
# Classify image
image_classifier.predict(keras.random.randint((1, 64, 64, 3), 0, 256))
`,Et={CausalLM:Un,TextToImage:Pn,TextClassifier:Nn,ImageClassifier:jn},On=(e,t)=>`
import keras_hub

# Create a ${e} model
task = keras_hub.models.${e}.from_preset("hf://${t}")
`,qn=e=>`
import keras_hub

# Create a Backbone model unspecialized for any task
backbone = keras_hub.models.Backbone.from_preset("hf://${e}")
`,Bn=e=>{var n,o;const t=e.id,a=((o=(n=e.config)==null?void 0:n.keras_hub)==null?void 0:o.tasks)??[],i=[];for(const[r,p]of Object.entries(Et))a.includes(r)&&i.push(p(t));for(const r of a)Object.keys(Et).includes(r)||i.push(On(r,t));return i.push(qn(t)),i},Fn=e=>e.tags.includes("bi-encoder")?[`#install from https://github.com/webis-de/lightning-ir

from lightning_ir import BiEncoderModule
model = BiEncoderModule("${e.id}")

model.score("query", ["doc1", "doc2", "doc3"])`]:e.tags.includes("cross-encoder")?[`#install from https://github.com/webis-de/lightning-ir

from lightning_ir import CrossEncoderModule
model = CrossEncoderModule("${e.id}")

model.score("query", ["doc1", "doc2", "doc3"])`]:[`#install from https://github.com/webis-de/lightning-ir

from lightning_ir import BiEncoderModule, CrossEncoderModule

# depending on the model type, use either BiEncoderModule or CrossEncoderModule
model = BiEncoderModule("${e.id}") 
# model = CrossEncoderModule("${e.id}")

model.score("query", ["doc1", "doc2", "doc3"])`],Hn=e=>{const t=[`from llama_cpp import Llama

llm = Llama.from_pretrained(
	repo_id="${e.id}",
	filename="{{GGUF_FILE}}",
)
`];if(e.tags.includes("conversational")){const a=Ae(e);t.push(`llm.create_chat_completion(
	messages = ${en(a,{attributeKeyQuotes:!0,indent:"	"})}
)`)}else t.push(`output = llm(
	"Once upon a time,",
	max_tokens=512,
	echo=True
)
print(output)`);return t},Vn=e=>[`# Note: 'keras<3.x' or 'tf_keras' must be installed (legacy)
# See https://github.com/keras-team/tf-keras for more details.
from huggingface_hub import from_pretrained_keras

model = from_pretrained_keras("${e.id}")
`],zn=e=>[`from mamba_ssm import MambaLMHeadModel

model = MambaLMHeadModel.from_pretrained("${e.id}")`],Wn=e=>[`# Install from https://github.com/Camb-ai/MARS5-TTS

from inference import Mars5TTS
mars5 = Mars5TTS.from_pretrained("${e.id}")`],Kn=e=>[`# Install from https://github.com/pq-yang/MatAnyone.git

from matanyone.model.matanyone import MatAnyone
model = MatAnyone.from_pretrained("${e.id}")`],Jn=()=>[`# Install from https://github.com/buaacyw/MeshAnything.git

from MeshAnything.models.meshanything import MeshAnything

# refer to https://github.com/buaacyw/MeshAnything/blob/main/main.py#L91 on how to define args
# and https://github.com/buaacyw/MeshAnything/blob/main/app.py regarding usage
model = MeshAnything(args)`],Qn=e=>[`import open_clip

model, preprocess_train, preprocess_val = open_clip.create_model_and_transforms('hf-hub:${e.id}')
tokenizer = open_clip.get_tokenizer('hf-hub:${e.id}')`],Xn=e=>{var t,a;if((a=(t=e.config)==null?void 0:t.architectures)!=null&&a[0]){const i=e.config.architectures[0];return[[`from paddlenlp.transformers import AutoTokenizer, ${i}`,"",`tokenizer = AutoTokenizer.from_pretrained("${e.id}", from_hf_hub=True)`,`model = ${i}.from_pretrained("${e.id}", from_hf_hub=True)`].join(`
`)]}else return[["# ⚠️ Type of model unknown","from paddlenlp.transformers import AutoTokenizer, AutoModel","",`tokenizer = AutoTokenizer.from_pretrained("${e.id}", from_hf_hub=True)`,`model = AutoModel.from_pretrained("${e.id}", from_hf_hub=True)`].join(`
`)]},Yn=e=>[`from pyannote.audio import Pipeline
  
pipeline = Pipeline.from_pretrained("${e.id}")

# inference on the whole file
pipeline("file.wav")

# inference on an excerpt
from pyannote.core import Segment
excerpt = Segment(start=2.0, end=5.0)

from pyannote.audio import Audio
waveform, sample_rate = Audio().crop("file.wav", excerpt)
pipeline({"waveform": waveform, "sample_rate": sample_rate})`],Zn=e=>[`from pyannote.audio import Model, Inference

model = Model.from_pretrained("${e.id}")
inference = Inference(model)

# inference on the whole file
inference("file.wav")

# inference on an excerpt
from pyannote.core import Segment
excerpt = Segment(start=2.0, end=5.0)
inference.crop("file.wav", excerpt)`],Gn=e=>e.tags.includes("pyannote-audio-pipeline")?Yn(e):Zn(e),eo=e=>[`from relik import Relik
 
relik = Relik.from_pretrained("${e.id}")`],to=e=>[`from tensorflow_tts.inference import AutoProcessor, TFAutoModel

processor = AutoProcessor.from_pretrained("${e.id}")
model = TFAutoModel.from_pretrained("${e.id}")
`],ao=e=>[`from tensorflow_tts.inference import TFAutoModel

model = TFAutoModel.from_pretrained("${e.id}")
audios = model.inference(mels)
`],io=e=>[`from tensorflow_tts.inference import TFAutoModel

model = TFAutoModel.from_pretrained("${e.id}")
`],no=e=>e.tags.includes("text-to-mel")?to(e):e.tags.includes("mel-to-wav")?ao(e):io(e),oo=e=>[`import timm

model = timm.create_model("hf_hub:${e.id}", pretrained=True)`],ro=()=>[`# pip install sae-lens
from sae_lens import SAE

sae, cfg_dict, sparsity = SAE.from_pretrained(
    release = "RELEASE_ID", # e.g., "gpt2-small-res-jb". See other options in https://github.com/jbloomAus/SAELens/blob/main/sae_lens/pretrained_saes.yaml
    sae_id = "SAE_ID", # e.g., "blocks.8.hook_resid_pre". Won't always be a hook point
)`],so=()=>[`# seed_story_cfg_path refers to 'https://github.com/TencentARC/SEED-Story/blob/master/configs/clm_models/agent_7b_sft.yaml'
# llm_cfg_path refers to 'https://github.com/TencentARC/SEED-Story/blob/master/configs/clm_models/llama2chat7b_lora.yaml'
from omegaconf import OmegaConf
import hydra

# load Llama2
llm_cfg = OmegaConf.load(llm_cfg_path)
llm = hydra.utils.instantiate(llm_cfg, torch_dtype="fp16")

# initialize seed_story
seed_story_cfg = OmegaConf.load(seed_story_cfg_path)
seed_story = hydra.utils.instantiate(seed_story_cfg, llm=llm) `],lo=(e,t)=>[`import joblib
from skops.hub_utils import download
download("${e.id}", "path_to_folder")
model = joblib.load(
	"${t}"
)
# only load pickle files from sources you trust
# read more about it here https://skops.readthedocs.io/en/stable/persistence.html`],co=(e,t)=>[`from skops.hub_utils import download
from skops.io import load
download("${e.id}", "path_to_folder")
# make sure model file is in skops format
# if model is a pickle file, make sure it's from a source you trust
model = load("path_to_folder/${t}")`],po=e=>[`from huggingface_hub import hf_hub_download
import joblib
model = joblib.load(
	hf_hub_download("${e.id}", "sklearn_model.joblib")
)
# only load pickle files from sources you trust
# read more about it here https://skops.readthedocs.io/en/stable/persistence.html`],uo=e=>{var t,a,i,n,o;if(e.tags.includes("skops")){const r=(i=(a=(t=e.config)==null?void 0:t.sklearn)==null?void 0:a.model)==null?void 0:i.file,p=(o=(n=e.config)==null?void 0:n.sklearn)==null?void 0:o.model_format;return r?p==="pickle"?lo(e,r):co(e,r):["# ⚠️ Model filename not specified in config.json"]}else return po(e)},mo=e=>[`import torch
import torchaudio
from einops import rearrange
from stable_audio_tools import get_pretrained_model
from stable_audio_tools.inference.generation import generate_diffusion_cond

device = "cuda" if torch.cuda.is_available() else "cpu"

# Download model
model, model_config = get_pretrained_model("${e.id}")
sample_rate = model_config["sample_rate"]
sample_size = model_config["sample_size"]

model = model.to(device)

# Set up text and timing conditioning
conditioning = [{
	"prompt": "128 BPM tech house drum loop",
}]

# Generate stereo audio
output = generate_diffusion_cond(
	model,
	conditioning=conditioning,
	sample_size=sample_size,
	device=device
)

# Rearrange audio batch to a single sequence
output = rearrange(output, "b d n -> d (b n)")

# Peak normalize, clip, convert to int16, and save to file
output = output.to(torch.float32).div(torch.max(torch.abs(output))).clamp(-1, 1).mul(32767).to(torch.int16).cpu()
torchaudio.save("output.wav", output, sample_rate)`],fo=e=>[`from huggingface_hub import from_pretrained_fastai

learn = from_pretrained_fastai("${e.id}")`],ho=e=>{const t=`# Use SAM2 with images
import torch
from sam2.sam2_image_predictor import SAM2ImagePredictor

predictor = SAM2ImagePredictor.from_pretrained(${e.id})

with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
    predictor.set_image(<your_image>)
    masks, _, _ = predictor.predict(<input_prompts>)`,a=`# Use SAM2 with videos
import torch
from sam2.sam2_video_predictor import SAM2VideoPredictor
	
predictor = SAM2VideoPredictor.from_pretrained(${e.id})

with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
    state = predictor.init_state(<your_video>)

    # add new prompts and instantly get the output on the same frame
    frame_idx, object_ids, masks = predictor.add_new_points(state, <your_prompts>):

    # propagate the prompts to get masklets throughout the video
    for frame_idx, object_ids, masks in predictor.propagate_in_video(state):
        ...`;return[t,a]},go=e=>[`python -m sample_factory.huggingface.load_from_hub -r ${e.id} -d ./train_dir`];function bo(e){var a,i;const t=(a=e.widgetData)==null?void 0:a[0];if(t!=null&&t.source_sentence&&((i=t==null?void 0:t.sentences)!=null&&i.length))return[t.source_sentence,...t.sentences]}const yo=e=>{const t=e.tags.includes(qt)?", trust_remote_code=True":"";if(e.tags.includes("cross-encoder")||e.pipeline_tag=="text-ranking")return[`from sentence_transformers import CrossEncoder

model = CrossEncoder("${e.id}"${t})

query = "Which planet is known as the Red Planet?"
passages = [
	"Venus is often called Earth's twin because of its similar size and proximity.",
	"Mars, known for its reddish appearance, is often referred to as the Red Planet.",
	"Jupiter, the largest planet in our solar system, has a prominent red spot.",
	"Saturn, famous for its rings, is sometimes mistaken for the Red Planet."
]

scores = model.predict([(query, passage) for passage in passages])
print(scores)`];const a=bo(e)??["The weather is lovely today.","It's so sunny outside!","He drove to the stadium."];return[`from sentence_transformers import SentenceTransformer

model = SentenceTransformer("${e.id}"${t})

sentences = ${JSON.stringify(a,null,4)}
embeddings = model.encode(sentences)

similarities = model.similarity(embeddings, embeddings)
print(similarities.shape)
# [${a.length}, ${a.length}]`]},wo=e=>[`from setfit import SetFitModel

model = SetFitModel.from_pretrained("${e.id}")`],vo=e=>[`!pip install https://huggingface.co/${e.id}/resolve/main/${G(e.id)}-any-py3-none-any.whl

# Using spacy.load().
import spacy
nlp = spacy.load("${G(e.id)}")

# Importing as module.
import ${G(e.id)}
nlp = ${G(e.id)}.load()`],_o=e=>[`from span_marker import SpanMarkerModel

model = SpanMarkerModel.from_pretrained("${e.id}")`],xo=e=>[`import stanza

stanza.download("${G(e.id).replace("stanza-","")}")
nlp = stanza.Pipeline("${G(e.id).replace("stanza-","")}")`],ko=e=>{switch(e){case"EncoderClassifier":return"classify_file";case"EncoderDecoderASR":case"EncoderASR":return"transcribe_file";case"SpectralMaskEnhancement":return"enhance_file";case"SepformerSeparation":return"separate_file";default:return}},Ao=e=>{var i,n;const t=(n=(i=e.config)==null?void 0:i.speechbrain)==null?void 0:n.speechbrain_interface;if(t===void 0)return["# interface not specified in config.json"];const a=ko(t);return a===void 0?["# interface in config.json invalid"]:[`from speechbrain.pretrained import ${t}
model = ${t}.from_hparams(
  "${e.id}"
)
model.${a}("file.wav")`]},To=e=>[`from terratorch.registry import BACKBONE_REGISTRY

model = BACKBONE_REGISTRY.build("${e.id}")`],So=e=>{var n,o,r,p,u;const t=e.transformersInfo;if(!t)return["# ⚠️ Type of model unknown"];const a=e.tags.includes(qt)?", trust_remote_code=True":"";let i;if(t.processor){const d=t.processor==="AutoTokenizer"?"tokenizer":t.processor==="AutoFeatureExtractor"?"extractor":"processor";i=["# Load model directly",`from transformers import ${t.processor}, ${t.auto_model}`,"",`${d} = ${t.processor}.from_pretrained("${e.id}"`+a+")",`model = ${t.auto_model}.from_pretrained("${e.id}"`+a+")"].join(`
`)}else i=["# Load model directly",`from transformers import ${t.auto_model}`,`model = ${t.auto_model}.from_pretrained("${e.id}"`+a+")"].join(`
`);if(e.pipeline_tag&&((n=ja.transformers)!=null&&n.includes(e.pipeline_tag))){const d=["# Use a pipeline as a high-level helper","from transformers import pipeline",""];return e.tags.includes("conversational")&&((r=(o=e.config)==null?void 0:o.tokenizer_config)!=null&&r.chat_template)&&d.push("messages = [",'    {"role": "user", "content": "Who are you?"},',"]"),d.push(`pipe = pipeline("${e.pipeline_tag}", model="${e.id}"`+a+")"),e.tags.includes("conversational")&&((u=(p=e.config)==null?void 0:p.tokenizer_config)!=null&&u.chat_template)&&d.push("pipe(messages)"),[d.join(`
`),i]}return[i]},Io=e=>{if(!e.pipeline_tag)return["// ⚠️ Unknown pipeline tag"];const t="@huggingface/transformers";return[`// npm i ${t}
import { pipeline } from '${t}';

// Allocate pipeline
const pipe = await pipeline('${e.pipeline_tag}', '${e.id}');`]},Eo=e=>{switch(e){case"CAUSAL_LM":return"CausalLM";case"SEQ_2_SEQ_LM":return"Seq2SeqLM";case"TOKEN_CLS":return"TokenClassification";case"SEQ_CLS":return"SequenceClassification";default:return}},Co=e=>{var n;const{base_model_name_or_path:t,task_type:a}=((n=e.config)==null?void 0:n.peft)??{},i=Eo(a);return i?t?[`from peft import PeftModel
from transformers import AutoModelFor${i}

base_model = AutoModelFor${i}.from_pretrained("${t}")
model = PeftModel.from_pretrained(base_model, "${e.id}")`]:["Base model is not found."]:["Task type is invalid."]},Mo=e=>[`from huggingface_hub import hf_hub_download
import fasttext

model = fasttext.load_model(hf_hub_download("${e.id}", "model.bin"))`],Ro=e=>[`from huggingface_sb3 import load_from_hub
checkpoint = load_from_hub(
	repo_id="${e.id}",
	filename="{MODEL FILENAME}.zip",
)`],$o=(e,t)=>{switch(e){case"ASR":return[`import nemo.collections.asr as nemo_asr
asr_model = nemo_asr.models.ASRModel.from_pretrained("${t.id}")

transcriptions = asr_model.transcribe(["file.wav"])`];default:return}},Do=e=>[`mlagents-load-from-hf --repo-id="${e.id}" --local-dir="./download: string[]s"`],Lo=()=>[`string modelName = "[Your model name here].sentis";
Model model = ModelLoader.Load(Application.streamingAssetsPath + "/" + modelName);
IWorker engine = WorkerFactory.CreateWorker(BackendType.GPUCompute, model);
// Please see provided C# file for more details
`],Uo=e=>[`
# Load the model and infer image from text
import torch
from app.sana_pipeline import SanaPipeline
from torchvision.utils import save_image

sana = SanaPipeline("configs/sana_config/1024ms/Sana_1600M_img1024.yaml")
sana.from_pretrained("hf://${e.id}")

image = sana(
    prompt='a cyberpunk cat with a neon sign that says "Sana"',
    height=1024,
    width=1024,
    guidance_scale=5.0,
    pag_guidance_scale=2.0,
    num_inference_steps=18,
) `],Po=e=>[`from Trainer_finetune import Model

model = Model.from_pretrained("${e.id}")`],No=e=>[`from voicecraft import VoiceCraft

model = VoiceCraft.from_pretrained("${e.id}")`],jo=()=>[`import ChatTTS
import torchaudio

chat = ChatTTS.Chat()
chat.load_models(compile=False) # Set to True for better performance

texts = ["PUT YOUR TEXT HERE",]

wavs = chat.infer(texts, )

torchaudio.save("output1.wav", torch.from_numpy(wavs[0]), 24000)`],Ct=e=>{const t=e.tags.find(n=>n.match(/^yolov\d+$/)),a=t?`YOLOv${t.slice(4)}`:"YOLOvXX";return[(t?"":`# Couldn't find a valid YOLO version tag.
# Replace XX with the correct version.
`)+`from ultralytics import ${a}

model = ${a}.from_pretrained("${e.id}")
source = 'http://images.cocodataset.org/val2017/000000039769.jpg'
model.predict(source=source, save=True)`]},Oo=e=>[`# Option 1: use with transformers

from transformers import AutoModelForImageSegmentation
birefnet = AutoModelForImageSegmentation.from_pretrained("${e.id}", trust_remote_code=True)
`,`# Option 2: use with BiRefNet

# Install from https://github.com/ZhengPeng7/BiRefNet

from models.birefnet import BiRefNet
model = BiRefNet.from_pretrained("${e.id}")`],qo=e=>[`from swarmformer import SwarmFormerModel

model = SwarmFormerModel.from_pretrained("${e.id}")
`],Bo=e=>[`pip install huggingface_hub hf_transfer

export HF_HUB_ENABLE_HF_TRANSFER=1
huggingface-cli download --local-dir ${G(e.id)} ${e.id}`],Fo=e=>[`from mlxim.model import create_model

model = create_model(${e.id})`],Ho=e=>[`from model2vec import StaticModel

model = StaticModel.from_pretrained("${e.id}")`],Vo=e=>{let t;return e.tags.includes("automatic-speech-recognition")&&(t=$o("ASR",e)),t??["# tag did not correspond to a valid NeMo domain."]},zo=e=>[`from pxia import AutoModel

model = AutoModel.from_pretrained("${e.id}")`],Wo=e=>[`from pythae.models import AutoModel

model = AutoModel.load_from_hf_hub("${e.id}")`],Ko=e=>[`from audiocraft.models import MusicGen

model = MusicGen.get_pretrained("${e.id}")

descriptions = ['happy rock', 'energetic EDM', 'sad jazz']
wav = model.generate(descriptions)  # generates 3 samples.`],Jo=e=>[`from audiocraft.models import MAGNeT
	
model = MAGNeT.get_pretrained("${e.id}")

descriptions = ['disco beat', 'energetic EDM', 'funky groove']
wav = model.generate(descriptions)  # generates 3 samples.`],Qo=e=>[`from audiocraft.models import AudioGen
	
model = AudioGen.get_pretrained("${e.id}")
model.set_generation_params(duration=5)  # generate 5 seconds.
descriptions = ['dog barking', 'sirene of an emergency vehicle', 'footsteps in a corridor']
wav = model.generate(descriptions)  # generates 3 samples.`],Xo=e=>[`from anemoi.inference.runners.default import DefaultRunner
from anemoi.inference.config import Configuration
# Create Configuration
config = Configuration(checkpoint = {"huggingface":{"repo_id":"${e.id}"}})
# Load Runner
runner = DefaultRunner(config)`],Yo=e=>e.tags.includes("musicgen")?Ko(e):e.tags.includes("audiogen")?Qo(e):e.tags.includes("magnet")?Jo(e):["# Type of model unknown."],Zo=()=>[`# Install CLI with Homebrew on macOS device
brew install whisperkit-cli

# View all available inference options
whisperkit-cli transcribe --help
	
# Download and run inference using whisper base model
whisperkit-cli transcribe --audio-path /path/to/audio.mp3

# Or use your preferred model variant
whisperkit-cli transcribe --model "large-v3" --model-prefix "distil" --audio-path /path/to/audio.mp3 --verbose`],Go=e=>[`from threedtopia_xl.models import threedtopia_xl

model = threedtopia_xl.from_pretrained("${e.id}")
model.generate(cond="path/to/image.png")`],er={"adapter-transformers":{prettyLabel:"Adapters",repoName:"adapters",repoUrl:"https://github.com/Adapter-Hub/adapters",docsUrl:"https://huggingface.co/docs/hub/adapters",snippets:an,filter:!0,countDownloads:'path:"adapter_config.json"'},allennlp:{prettyLabel:"AllenNLP",repoName:"AllenNLP",repoUrl:"https://github.com/allenai/allennlp",docsUrl:"https://huggingface.co/docs/hub/allennlp",snippets:rn,filter:!0},anemoi:{prettyLabel:"AnemoI",repoName:"AnemoI",repoUrl:"https://github.com/ecmwf/anemoi-inference",docsUrl:"https://anemoi-docs.readthedocs.io/en/latest/",filter:!1,countDownloads:'path_extension:"ckpt"',snippets:Xo},araclip:{prettyLabel:"AraClip",repoName:"AraClip",repoUrl:"https://huggingface.co/Arabic-Clip/araclip",filter:!1,snippets:sn},asteroid:{prettyLabel:"Asteroid",repoName:"Asteroid",repoUrl:"https://github.com/asteroid-team/asteroid",docsUrl:"https://huggingface.co/docs/hub/asteroid",snippets:ln,filter:!0,countDownloads:'path:"pytorch_model.bin"'},audiocraft:{prettyLabel:"Audiocraft",repoName:"audiocraft",repoUrl:"https://github.com/facebookresearch/audiocraft",snippets:Yo,filter:!1,countDownloads:'path:"state_dict.bin"'},audioseal:{prettyLabel:"AudioSeal",repoName:"audioseal",repoUrl:"https://github.com/facebookresearch/audioseal",filter:!1,countDownloads:'path_extension:"pth"',snippets:cn},ben2:{prettyLabel:"BEN2",repoName:"BEN2",repoUrl:"https://github.com/PramaLLC/BEN2",snippets:dn,filter:!1},bertopic:{prettyLabel:"BERTopic",repoName:"BERTopic",repoUrl:"https://github.com/MaartenGr/BERTopic",snippets:pn,filter:!0},big_vision:{prettyLabel:"Big Vision",repoName:"big_vision",repoUrl:"https://github.com/google-research/big_vision",filter:!1,countDownloads:'path_extension:"npz"'},birder:{prettyLabel:"Birder",repoName:"Birder",repoUrl:"https://gitlab.com/birder/birder",filter:!1,countDownloads:'path_extension:"pt"'},birefnet:{prettyLabel:"BiRefNet",repoName:"BiRefNet",repoUrl:"https://github.com/ZhengPeng7/BiRefNet",snippets:Oo,filter:!1},bm25s:{prettyLabel:"BM25S",repoName:"bm25s",repoUrl:"https://github.com/xhluca/bm25s",snippets:un,filter:!1,countDownloads:'path:"params.index.json"'},champ:{prettyLabel:"Champ",repoName:"Champ",repoUrl:"https://github.com/fudan-generative-vision/champ",countDownloads:'path:"champ/motion_module.pth"'},chat_tts:{prettyLabel:"ChatTTS",repoName:"ChatTTS",repoUrl:"https://github.com/2noise/ChatTTS.git",snippets:jo,filter:!1,countDownloads:'path:"asset/GPT.pt"'},colpali:{prettyLabel:"ColPali",repoName:"ColPali",repoUrl:"https://github.com/ManuelFay/colpali",filter:!1,countDownloads:'path:"adapter_config.json"'},comet:{prettyLabel:"COMET",repoName:"COMET",repoUrl:"https://github.com/Unbabel/COMET/",countDownloads:'path:"hparams.yaml"'},cosmos:{prettyLabel:"Cosmos",repoName:"Cosmos",repoUrl:"https://github.com/NVIDIA/Cosmos",countDownloads:'path:"config.json" OR path_extension:"pt"'},"cxr-foundation":{prettyLabel:"CXR Foundation",repoName:"cxr-foundation",repoUrl:"https://github.com/google-health/cxr-foundation",snippets:mn,filter:!1,countDownloads:'path:"precomputed_embeddings/embeddings.npz" OR path:"pax-elixr-b-text/saved_model.pb"'},deepforest:{prettyLabel:"DeepForest",repoName:"deepforest",docsUrl:"https://deepforest.readthedocs.io/en/latest/",repoUrl:"https://github.com/weecology/DeepForest"},"depth-anything-v2":{prettyLabel:"DepthAnythingV2",repoName:"Depth Anything V2",repoUrl:"https://github.com/DepthAnything/Depth-Anything-V2",snippets:fn,filter:!1,countDownloads:'path_extension:"pth"'},"depth-pro":{prettyLabel:"Depth Pro",repoName:"Depth Pro",repoUrl:"https://github.com/apple/ml-depth-pro",countDownloads:'path_extension:"pt"',snippets:hn,filter:!1},"derm-foundation":{prettyLabel:"Derm Foundation",repoName:"derm-foundation",repoUrl:"https://github.com/google-health/derm-foundation",snippets:gn,filter:!1,countDownloads:'path:"scin_dataset_precomputed_embeddings.npz" OR path:"saved_model.pb"'},diffree:{prettyLabel:"Diffree",repoName:"Diffree",repoUrl:"https://github.com/OpenGVLab/Diffree",filter:!1,countDownloads:'path:"diffree-step=000010999.ckpt"'},diffusers:{prettyLabel:"Diffusers",repoName:"🤗/diffusers",repoUrl:"https://github.com/huggingface/diffusers",docsUrl:"https://huggingface.co/docs/hub/diffusers",snippets:_n,filter:!0},diffusionkit:{prettyLabel:"DiffusionKit",repoName:"DiffusionKit",repoUrl:"https://github.com/argmaxinc/DiffusionKit",snippets:xn},doctr:{prettyLabel:"docTR",repoName:"doctr",repoUrl:"https://github.com/mindee/doctr"},cartesia_pytorch:{prettyLabel:"Cartesia Pytorch",repoName:"Cartesia Pytorch",repoUrl:"https://github.com/cartesia-ai/cartesia_pytorch",snippets:kn},cartesia_mlx:{prettyLabel:"Cartesia MLX",repoName:"Cartesia MLX",repoUrl:"https://github.com/cartesia-ai/cartesia_mlx",snippets:An},clipscope:{prettyLabel:"clipscope",repoName:"clipscope",repoUrl:"https://github.com/Lewington-pitsos/clipscope",filter:!1,countDownloads:'path_extension:"pt"'},cosyvoice:{prettyLabel:"CosyVoice",repoName:"CosyVoice",repoUrl:"https://github.com/FunAudioLLM/CosyVoice",filter:!1,countDownloads:'path_extension:"onnx" OR path_extension:"pt"'},cotracker:{prettyLabel:"CoTracker",repoName:"CoTracker",repoUrl:"https://github.com/facebookresearch/co-tracker",filter:!1,countDownloads:'path_extension:"pth"'},edsnlp:{prettyLabel:"EDS-NLP",repoName:"edsnlp",repoUrl:"https://github.com/aphp/edsnlp",docsUrl:"https://aphp.github.io/edsnlp/latest/",filter:!1,snippets:Tn,countDownloads:'path_filename:"config" AND path_extension:"cfg"'},elm:{prettyLabel:"ELM",repoName:"elm",repoUrl:"https://github.com/slicex-ai/elm",filter:!1,countDownloads:'path_filename:"slicex_elm_config" AND path_extension:"json"'},espnet:{prettyLabel:"ESPnet",repoName:"ESPnet",repoUrl:"https://github.com/espnet/espnet",docsUrl:"https://huggingface.co/docs/hub/espnet",snippets:Cn,filter:!0},fairseq:{prettyLabel:"Fairseq",repoName:"fairseq",repoUrl:"https://github.com/pytorch/fairseq",snippets:Mn,filter:!0},fastai:{prettyLabel:"fastai",repoName:"fastai",repoUrl:"https://github.com/fastai/fastai",docsUrl:"https://huggingface.co/docs/hub/fastai",snippets:fo,filter:!0},fasttext:{prettyLabel:"fastText",repoName:"fastText",repoUrl:"https://fasttext.cc/",snippets:Mo,filter:!0,countDownloads:'path_extension:"bin"'},flair:{prettyLabel:"Flair",repoName:"Flair",repoUrl:"https://github.com/flairNLP/flair",docsUrl:"https://huggingface.co/docs/hub/flair",snippets:Rn,filter:!0,countDownloads:'path:"pytorch_model.bin"'},"gemma.cpp":{prettyLabel:"gemma.cpp",repoName:"gemma.cpp",repoUrl:"https://github.com/google/gemma.cpp",filter:!1,countDownloads:'path_extension:"sbs"'},"geometry-crafter":{prettyLabel:"GeometryCrafter",repoName:"GeometryCrafter",repoUrl:"https://github.com/TencentARC/GeometryCrafter",countDownloads:'path:"point_map_vae/diffusion_pytorch_model.safetensors"'},gliner:{prettyLabel:"GLiNER",repoName:"GLiNER",repoUrl:"https://github.com/urchade/GLiNER",snippets:$n,filter:!1,countDownloads:'path:"gliner_config.json"'},"glyph-byt5":{prettyLabel:"Glyph-ByT5",repoName:"Glyph-ByT5",repoUrl:"https://github.com/AIGText/Glyph-ByT5",filter:!1,countDownloads:'path:"checkpoints/byt5_model.pt"'},grok:{prettyLabel:"Grok",repoName:"Grok",repoUrl:"https://github.com/xai-org/grok-1",filter:!1,countDownloads:'path:"ckpt/tensor00000_000" OR path:"ckpt-0/tensor00000_000"'},hallo:{prettyLabel:"Hallo",repoName:"Hallo",repoUrl:"https://github.com/fudan-generative-vision/hallo",countDownloads:'path:"hallo/net.pth"'},hezar:{prettyLabel:"Hezar",repoName:"Hezar",repoUrl:"https://github.com/hezarai/hezar",docsUrl:"https://hezarai.github.io/hezar",countDownloads:'path:"model_config.yaml" OR path:"embedding/embedding_config.yaml"'},htrflow:{prettyLabel:"HTRflow",repoName:"HTRflow",repoUrl:"https://github.com/AI-Riksarkivet/htrflow",docsUrl:"https://ai-riksarkivet.github.io/htrflow",snippets:Dn},"hunyuan-dit":{prettyLabel:"HunyuanDiT",repoName:"HunyuanDiT",repoUrl:"https://github.com/Tencent/HunyuanDiT",countDownloads:'path:"pytorch_model_ema.pt" OR path:"pytorch_model_distill.pt"'},"hunyuan3d-2":{prettyLabel:"Hunyuan3D-2",repoName:"Hunyuan3D-2",repoUrl:"https://github.com/Tencent/Hunyuan3D-2",countDownloads:'path_filename:"model_index" OR path_filename:"config"'},imstoucan:{prettyLabel:"IMS Toucan",repoName:"IMS-Toucan",repoUrl:"https://github.com/DigitalPhonetics/IMS-Toucan",countDownloads:'path:"embedding_gan.pt" OR path:"Vocoder.pt" OR path:"ToucanTTS.pt"'},"infinite-you":{prettyLabel:"InfiniteYou",repoName:"InfiniteYou",repoUrl:"https://github.com/bytedance/InfiniteYou",filter:!1,countDownloads:'path:"infu_flux_v1.0/sim_stage1/image_proj_model.bin" OR path:"infu_flux_v1.0/aes_stage2/image_proj_model.bin"'},keras:{prettyLabel:"Keras",repoName:"Keras",repoUrl:"https://github.com/keras-team/keras",docsUrl:"https://huggingface.co/docs/hub/keras",snippets:Ln,filter:!0,countDownloads:'path:"config.json" OR path_extension:"keras"'},"tf-keras":{prettyLabel:"TF-Keras",repoName:"TF-Keras",repoUrl:"https://github.com/keras-team/tf-keras",docsUrl:"https://huggingface.co/docs/hub/tf-keras",snippets:Vn,countDownloads:'path:"saved_model.pb"'},"keras-hub":{prettyLabel:"KerasHub",repoName:"KerasHub",repoUrl:"https://github.com/keras-team/keras-hub",docsUrl:"https://keras.io/keras_hub/",snippets:Bn,filter:!0},k2:{prettyLabel:"K2",repoName:"k2",repoUrl:"https://github.com/k2-fsa/k2"},"lightning-ir":{prettyLabel:"Lightning IR",repoName:"Lightning IR",repoUrl:"https://github.com/webis-de/lightning-ir",snippets:Fn},liveportrait:{prettyLabel:"LivePortrait",repoName:"LivePortrait",repoUrl:"https://github.com/KwaiVGI/LivePortrait",filter:!1,countDownloads:'path:"liveportrait/landmark.onnx"'},"llama-cpp-python":{prettyLabel:"llama-cpp-python",repoName:"llama-cpp-python",repoUrl:"https://github.com/abetlen/llama-cpp-python",snippets:Hn},"mini-omni2":{prettyLabel:"Mini-Omni2",repoName:"Mini-Omni2",repoUrl:"https://github.com/gpt-omni/mini-omni2",countDownloads:'path:"model_config.yaml"'},mindspore:{prettyLabel:"MindSpore",repoName:"mindspore",repoUrl:"https://github.com/mindspore-ai/mindspore"},"mamba-ssm":{prettyLabel:"MambaSSM",repoName:"MambaSSM",repoUrl:"https://github.com/state-spaces/mamba",filter:!1,snippets:zn},"mars5-tts":{prettyLabel:"MARS5-TTS",repoName:"MARS5-TTS",repoUrl:"https://github.com/Camb-ai/MARS5-TTS",filter:!1,countDownloads:'path:"mars5_ar.safetensors"',snippets:Wn},matanyone:{prettyLabel:"MatAnyone",repoName:"MatAnyone",repoUrl:"https://github.com/pq-yang/MatAnyone",snippets:Kn,filter:!1},"mesh-anything":{prettyLabel:"MeshAnything",repoName:"MeshAnything",repoUrl:"https://github.com/buaacyw/MeshAnything",filter:!1,countDownloads:'path:"MeshAnything_350m.pth"',snippets:Jn},merlin:{prettyLabel:"Merlin",repoName:"Merlin",repoUrl:"https://github.com/StanfordMIMI/Merlin",filter:!1,countDownloads:'path_extension:"pt"'},medvae:{prettyLabel:"MedVAE",repoName:"MedVAE",repoUrl:"https://github.com/StanfordMIMI/MedVAE",filter:!1,countDownloads:'path_extension:"ckpt"'},mitie:{prettyLabel:"MITIE",repoName:"MITIE",repoUrl:"https://github.com/mit-nlp/MITIE",countDownloads:'path_filename:"total_word_feature_extractor"'},"ml-agents":{prettyLabel:"ml-agents",repoName:"ml-agents",repoUrl:"https://github.com/Unity-Technologies/ml-agents",docsUrl:"https://huggingface.co/docs/hub/ml-agents",snippets:Do,filter:!0,countDownloads:'path_extension:"onnx"'},mlx:{prettyLabel:"MLX",repoName:"MLX",repoUrl:"https://github.com/ml-explore/mlx-examples/tree/main",snippets:Bo,filter:!0},"mlx-image":{prettyLabel:"mlx-image",repoName:"mlx-image",repoUrl:"https://github.com/riccardomusmeci/mlx-image",docsUrl:"https://huggingface.co/docs/hub/mlx-image",snippets:Fo,filter:!1,countDownloads:'path:"model.safetensors"'},"mlc-llm":{prettyLabel:"MLC-LLM",repoName:"MLC-LLM",repoUrl:"https://github.com/mlc-ai/mlc-llm",docsUrl:"https://llm.mlc.ai/docs/",filter:!1,countDownloads:'path:"mlc-chat-config.json"'},model2vec:{prettyLabel:"Model2Vec",repoName:"model2vec",repoUrl:"https://github.com/MinishLab/model2vec",snippets:Ho,filter:!1},moshi:{prettyLabel:"Moshi",repoName:"Moshi",repoUrl:"https://github.com/kyutai-labs/moshi",filter:!1,countDownloads:'path:"tokenizer-e351c8d8-checkpoint125.safetensors"'},nemo:{prettyLabel:"NeMo",repoName:"NeMo",repoUrl:"https://github.com/NVIDIA/NeMo",snippets:Vo,filter:!0,countDownloads:'path_extension:"nemo" OR path:"model_config.yaml"'},"open-oasis":{prettyLabel:"open-oasis",repoName:"open-oasis",repoUrl:"https://github.com/etched-ai/open-oasis",countDownloads:'path:"oasis500m.safetensors"'},open_clip:{prettyLabel:"OpenCLIP",repoName:"OpenCLIP",repoUrl:"https://github.com/mlfoundations/open_clip",snippets:Qn,filter:!0,countDownloads:`path:"open_clip_model.safetensors"
			OR path:"model.safetensors"
			OR path:"open_clip_pytorch_model.bin"
			OR path:"pytorch_model.bin"`},"open-sora":{prettyLabel:"Open-Sora",repoName:"Open-Sora",repoUrl:"https://github.com/hpcaitech/Open-Sora",filter:!1,countDownloads:'path:"Open_Sora_v2.safetensors"'},paddlenlp:{prettyLabel:"paddlenlp",repoName:"PaddleNLP",repoUrl:"https://github.com/PaddlePaddle/PaddleNLP",docsUrl:"https://huggingface.co/docs/hub/paddlenlp",snippets:Xn,filter:!0,countDownloads:'path:"model_config.json"'},peft:{prettyLabel:"PEFT",repoName:"PEFT",repoUrl:"https://github.com/huggingface/peft",snippets:Co,filter:!0,countDownloads:'path:"adapter_config.json"'},pxia:{prettyLabel:"pxia",repoName:"pxia",repoUrl:"https://github.com/not-lain/pxia",snippets:zo,filter:!1},"pyannote-audio":{prettyLabel:"pyannote.audio",repoName:"pyannote-audio",repoUrl:"https://github.com/pyannote/pyannote-audio",snippets:Gn,filter:!0},"py-feat":{prettyLabel:"Py-Feat",repoName:"Py-Feat",repoUrl:"https://github.com/cosanlab/py-feat",docsUrl:"https://py-feat.org/",filter:!1},pythae:{prettyLabel:"pythae",repoName:"pythae",repoUrl:"https://github.com/clementchadebec/benchmark_VAE",snippets:Wo,filter:!1},recurrentgemma:{prettyLabel:"RecurrentGemma",repoName:"recurrentgemma",repoUrl:"https://github.com/google-deepmind/recurrentgemma",filter:!1,countDownloads:'path:"tokenizer.model"'},relik:{prettyLabel:"Relik",repoName:"Relik",repoUrl:"https://github.com/SapienzaNLP/relik",snippets:eo,filter:!1},refiners:{prettyLabel:"Refiners",repoName:"Refiners",repoUrl:"https://github.com/finegrain-ai/refiners",docsUrl:"https://refine.rs/",filter:!1,countDownloads:'path:"model.safetensors"'},reverb:{prettyLabel:"Reverb",repoName:"Reverb",repoUrl:"https://github.com/revdotcom/reverb",filter:!1},saelens:{prettyLabel:"SAELens",repoName:"SAELens",repoUrl:"https://github.com/jbloomAus/SAELens",snippets:ro,filter:!1},sam2:{prettyLabel:"sam2",repoName:"sam2",repoUrl:"https://github.com/facebookresearch/segment-anything-2",filter:!1,snippets:ho,countDownloads:'path_extension:"pt"'},"sample-factory":{prettyLabel:"sample-factory",repoName:"sample-factory",repoUrl:"https://github.com/alex-petrenko/sample-factory",docsUrl:"https://huggingface.co/docs/hub/sample-factory",snippets:go,filter:!0,countDownloads:'path:"cfg.json"'},sapiens:{prettyLabel:"sapiens",repoName:"sapiens",repoUrl:"https://github.com/facebookresearch/sapiens",filter:!1,countDownloads:'path_extension:"pt2" OR path_extension:"pth" OR path_extension:"onnx"'},"sentence-transformers":{prettyLabel:"sentence-transformers",repoName:"sentence-transformers",repoUrl:"https://github.com/UKPLab/sentence-transformers",docsUrl:"https://huggingface.co/docs/hub/sentence-transformers",snippets:yo,filter:!0},setfit:{prettyLabel:"setfit",repoName:"setfit",repoUrl:"https://github.com/huggingface/setfit",docsUrl:"https://huggingface.co/docs/hub/setfit",snippets:wo,filter:!0},sklearn:{prettyLabel:"Scikit-learn",repoName:"Scikit-learn",repoUrl:"https://github.com/scikit-learn/scikit-learn",snippets:uo,filter:!0,countDownloads:'path:"sklearn_model.joblib"'},spacy:{prettyLabel:"spaCy",repoName:"spaCy",repoUrl:"https://github.com/explosion/spaCy",docsUrl:"https://huggingface.co/docs/hub/spacy",snippets:vo,filter:!0,countDownloads:'path_extension:"whl"'},"span-marker":{prettyLabel:"SpanMarker",repoName:"SpanMarkerNER",repoUrl:"https://github.com/tomaarsen/SpanMarkerNER",docsUrl:"https://huggingface.co/docs/hub/span_marker",snippets:_o,filter:!0},speechbrain:{prettyLabel:"speechbrain",repoName:"speechbrain",repoUrl:"https://github.com/speechbrain/speechbrain",docsUrl:"https://huggingface.co/docs/hub/speechbrain",snippets:Ao,filter:!0,countDownloads:'path:"hyperparams.yaml"'},"ssr-speech":{prettyLabel:"SSR-Speech",repoName:"SSR-Speech",repoUrl:"https://github.com/WangHelin1997/SSR-Speech",filter:!1,countDownloads:'path_extension:".pth"'},"stable-audio-tools":{prettyLabel:"Stable Audio Tools",repoName:"stable-audio-tools",repoUrl:"https://github.com/Stability-AI/stable-audio-tools.git",filter:!1,countDownloads:'path:"model.safetensors"',snippets:mo},"diffusion-single-file":{prettyLabel:"Diffusion Single File",repoName:"diffusion-single-file",repoUrl:"https://github.com/comfyanonymous/ComfyUI",filter:!1,countDownloads:'path_extension:"safetensors"'},"seed-story":{prettyLabel:"SEED-Story",repoName:"SEED-Story",repoUrl:"https://github.com/TencentARC/SEED-Story",filter:!1,countDownloads:'path:"cvlm_llama2_tokenizer/tokenizer.model"',snippets:so},soloaudio:{prettyLabel:"SoloAudio",repoName:"SoloAudio",repoUrl:"https://github.com/WangHelin1997/SoloAudio",filter:!1,countDownloads:'path:"soloaudio_v2.pt"'},"stable-baselines3":{prettyLabel:"stable-baselines3",repoName:"stable-baselines3",repoUrl:"https://github.com/huggingface/huggingface_sb3",docsUrl:"https://huggingface.co/docs/hub/stable-baselines3",snippets:Ro,filter:!0,countDownloads:'path_extension:"zip"'},stanza:{prettyLabel:"Stanza",repoName:"stanza",repoUrl:"https://github.com/stanfordnlp/stanza",docsUrl:"https://huggingface.co/docs/hub/stanza",snippets:xo,filter:!0,countDownloads:'path:"models/default.zip"'},swarmformer:{prettyLabel:"SwarmFormer",repoName:"SwarmFormer",repoUrl:"https://github.com/takara-ai/SwarmFormer",snippets:qo,filter:!1},"f5-tts":{prettyLabel:"F5-TTS",repoName:"F5-TTS",repoUrl:"https://github.com/SWivid/F5-TTS",filter:!1,countDownloads:'path_extension:"safetensors" OR path_extension:"pt"'},genmo:{prettyLabel:"Genmo",repoName:"Genmo",repoUrl:"https://github.com/genmoai/models",filter:!1,countDownloads:'path:"vae_stats.json"'},tensorflowtts:{prettyLabel:"TensorFlowTTS",repoName:"TensorFlowTTS",repoUrl:"https://github.com/TensorSpeech/TensorFlowTTS",snippets:no},tabpfn:{prettyLabel:"TabPFN",repoName:"TabPFN",repoUrl:"https://github.com/PriorLabs/TabPFN"},terratorch:{prettyLabel:"TerraTorch",repoName:"TerraTorch",repoUrl:"https://github.com/IBM/terratorch",docsUrl:"https://ibm.github.io/terratorch/",filter:!1,countDownloads:'path_extension:"pt"',snippets:To},"tic-clip":{prettyLabel:"TiC-CLIP",repoName:"TiC-CLIP",repoUrl:"https://github.com/apple/ml-tic-clip",filter:!1,countDownloads:'path_extension:"pt" AND path_prefix:"checkpoints/"'},timesfm:{prettyLabel:"TimesFM",repoName:"timesfm",repoUrl:"https://github.com/google-research/timesfm",filter:!1,countDownloads:'path:"checkpoints/checkpoint_1100000/state/checkpoint"'},timm:{prettyLabel:"timm",repoName:"pytorch-image-models",repoUrl:"https://github.com/rwightman/pytorch-image-models",docsUrl:"https://huggingface.co/docs/hub/timm",snippets:oo,filter:!0,countDownloads:'path:"pytorch_model.bin" OR path:"model.safetensors"'},transformers:{prettyLabel:"Transformers",repoName:"🤗/transformers",repoUrl:"https://github.com/huggingface/transformers",docsUrl:"https://huggingface.co/docs/hub/transformers",snippets:So,filter:!0},"transformers.js":{prettyLabel:"Transformers.js",repoName:"transformers.js",repoUrl:"https://github.com/huggingface/transformers.js",docsUrl:"https://huggingface.co/docs/hub/transformers-js",snippets:Io,filter:!0},trellis:{prettyLabel:"Trellis",repoName:"Trellis",repoUrl:"https://github.com/microsoft/TRELLIS",countDownloads:'path_extension:"safetensors"'},ultralytics:{prettyLabel:"ultralytics",repoName:"ultralytics",repoUrl:"https://github.com/ultralytics/ultralytics",docsUrl:"https://github.com/ultralytics/ultralytics",filter:!1,countDownloads:'path_extension:"pt"',snippets:Ct},"uni-3dar":{prettyLabel:"Uni-3DAR",repoName:"Uni-3DAR",repoUrl:"https://github.com/dptech-corp/Uni-3DAR",docsUrl:"https://github.com/dptech-corp/Uni-3DAR",countDownloads:'path_extension:"pt"'},"unity-sentis":{prettyLabel:"unity-sentis",repoName:"unity-sentis",repoUrl:"https://github.com/Unity-Technologies/sentis-samples",snippets:Lo,filter:!0,countDownloads:'path_extension:"sentis"'},sana:{prettyLabel:"Sana",repoName:"Sana",repoUrl:"https://github.com/NVlabs/Sana",countDownloads:'path_extension:"pth"',snippets:Uo},"vfi-mamba":{prettyLabel:"VFIMamba",repoName:"VFIMamba",repoUrl:"https://github.com/MCG-NJU/VFIMamba",countDownloads:'path_extension:"pkl"',snippets:Po},voicecraft:{prettyLabel:"VoiceCraft",repoName:"VoiceCraft",repoUrl:"https://github.com/jasonppy/VoiceCraft",docsUrl:"https://github.com/jasonppy/VoiceCraft",snippets:No},wham:{prettyLabel:"WHAM",repoName:"wham",repoUrl:"https://huggingface.co/microsoft/wham",docsUrl:"https://huggingface.co/microsoft/wham/blob/main/README.md",countDownloads:'path_extension:"ckpt"'},whisperkit:{prettyLabel:"WhisperKit",repoName:"WhisperKit",repoUrl:"https://github.com/argmaxinc/WhisperKit",docsUrl:"https://github.com/argmaxinc/WhisperKit?tab=readme-ov-file#homebrew",snippets:Zo,countDownloads:'path_filename:"model" AND path_extension:"mil" AND _exists_:"path_prefix"'},yolov10:{prettyLabel:"YOLOv10",repoName:"YOLOv10",repoUrl:"https://github.com/THU-MIG/yolov10",docsUrl:"https://github.com/THU-MIG/yolov10",countDownloads:'path_extension:"pt" OR path_extension:"safetensors"',snippets:Ct},"3dtopia-xl":{prettyLabel:"3DTopia-XL",repoName:"3DTopia-XL",repoUrl:"https://github.com/3DTopia/3DTopia-XL",filter:!1,countDownloads:'path:"model_vae_fp16.pt"',snippets:Go}};Object.entries(er).filter(([e,t])=>t.filter).map(([e])=>e);var Fe;(function(e){e[e.F32=0]="F32",e[e.F16=1]="F16",e[e.Q4_0=2]="Q4_0",e[e.Q4_1=3]="Q4_1",e[e.Q5_0=6]="Q5_0",e[e.Q5_1=7]="Q5_1",e[e.Q8_0=8]="Q8_0",e[e.Q8_1=9]="Q8_1",e[e.Q2_K=10]="Q2_K",e[e.Q3_K=11]="Q3_K",e[e.Q4_K=12]="Q4_K",e[e.Q5_K=13]="Q5_K",e[e.Q6_K=14]="Q6_K",e[e.Q8_K=15]="Q8_K",e[e.IQ2_XXS=16]="IQ2_XXS",e[e.IQ2_XS=17]="IQ2_XS",e[e.IQ3_XXS=18]="IQ3_XXS",e[e.IQ1_S=19]="IQ1_S",e[e.IQ4_NL=20]="IQ4_NL",e[e.IQ3_S=21]="IQ3_S",e[e.IQ2_S=22]="IQ2_S",e[e.IQ4_XS=23]="IQ4_XS",e[e.I8=24]="I8",e[e.I16=25]="I16",e[e.I32=26]="I32",e[e.I64=27]="I64",e[e.F64=28]="F64",e[e.IQ1_M=29]="IQ1_M",e[e.BF16=30]="BF16"})(Fe||(Fe={}));const tr=Object.values(Fe).filter(e=>typeof e=="string");new RegExp(`(?<quant>${tr.join("|")})(_(?<sizeVariation>[A-Z]+))?`);const ar=["python","js","sh"];var ir=Object.defineProperty,Ht=(e,t)=>{for(var a in t)ir(e,a,{get:t[a],enumerable:!0})},nr={};Ht(nr,{audioClassification:()=>bs,audioToAudio:()=>ys,automaticSpeechRecognition:()=>ws,chatCompletion:()=>Rs,chatCompletionStream:()=>$s,documentQuestionAnswering:()=>zs,featureExtraction:()=>Ds,fillMask:()=>Ls,imageClassification:()=>xs,imageSegmentation:()=>ks,imageToImage:()=>As,imageToText:()=>Ts,objectDetection:()=>Ss,questionAnswering:()=>Us,request:()=>hs,sentenceSimilarity:()=>Ps,streamingRequest:()=>gs,summarization:()=>Ns,tableQuestionAnswering:()=>js,tabularClassification:()=>Ks,tabularRegression:()=>Js,textClassification:()=>Os,textGeneration:()=>qs,textGenerationStream:()=>Bs,textToImage:()=>Is,textToSpeech:()=>_s,textToVideo:()=>Es,tokenClassification:()=>Fs,translation:()=>Hs,visualQuestionAnswering:()=>Ws,zeroShotClassification:()=>Vs,zeroShotImageClassification:()=>Ms});var v=class extends TypeError{constructor(e){super(`Invalid inference output: ${e}. Use the 'request' method with the same parameters to do a custom call with no type checking.`),this.name="InferenceOutputError"}};function Vt(e){return new Promise(t=>{setTimeout(()=>t(),e)})}function or(e,t){return Object.assign({},...t.map(a=>{if(e[a]!==void 0)return{[a]:e[a]}}))}function He(e,t){return e.includes(t)}function q(e,t){const a=Array.isArray(t)?t:[t],i=Object.keys(e).filter(n=>!He(a,n));return or(e,i)}var Re="https://huggingface.co",zt="https://router.huggingface.co",rr="X-HF-Bill-To";function Wt(e){return Array.isArray(e)?e:[e]}var X=class{constructor(e,t,a=!1){this.provider=e,this.baseUrl=t,this.clientSideRoutingOnly=a}makeBaseUrl(e){return e.authMethod!=="provider-key"?`${zt}/${this.provider}`:this.baseUrl}makeBody(e){return"data"in e.args&&e.args.data?e.args.data:JSON.stringify(this.preparePayload(e))}makeUrl(e){const t=this.makeBaseUrl(e),a=this.makeRoute(e).replace(/^\/+/,"");return`${t}/${a}`}prepareHeaders(e,t){const a={Authorization:`Bearer ${e.accessToken}`};return t||(a["Content-Type"]="application/json"),a}},Y=class extends X{constructor(e,t,a=!1){super(e,t,a)}makeRoute(){return"v1/chat/completions"}preparePayload(e){return{...e.args,model:e.model}}async getResponse(e){if(typeof e=="object"&&Array.isArray(e==null?void 0:e.choices)&&typeof(e==null?void 0:e.created)=="number"&&typeof(e==null?void 0:e.id)=="string"&&typeof(e==null?void 0:e.model)=="string"&&(e.system_fingerprint===void 0||e.system_fingerprint===null||typeof e.system_fingerprint=="string")&&typeof(e==null?void 0:e.usage)=="object")return e;throw new v("Expected ChatCompletionOutput")}},$e=class extends X{constructor(e,t,a=!1){super(e,t,a)}preparePayload(e){return{...e.args,model:e.model}}makeRoute(){return"v1/completions"}async getResponse(e){const t=Wt(e);if(Array.isArray(t)&&t.length>0&&t.every(a=>typeof a=="object"&&!!a&&"generated_text"in a&&typeof a.generated_text=="string"))return t[0];throw new v("Expected Array<{generated_text: string}>")}},sr="https://api.us1.bfl.ai",lr=class extends X{constructor(){super("black-forest-labs",sr)}preparePayload(e){return{...q(e.args,["inputs","parameters"]),...e.args.parameters,prompt:e.args.inputs}}prepareHeaders(e,t){const a={Authorization:e.authMethod!=="provider-key"?`Bearer ${e.accessToken}`:`X-Key ${e.accessToken}`};return t||(a["Content-Type"]="application/json"),a}makeRoute(e){if(!e)throw new Error("Params are required");return`/v1/${e.model}`}async getResponse(e,t,a,i){const n=new URL(e.polling_url);for(let o=0;o<5;o++){await Vt(1e3),console.debug(`Polling Black Forest Labs API for the result... ${o+1}/5`),n.searchParams.set("attempt",o.toString(10));const r=await fetch(n,{headers:{"Content-Type":"application/json"}});if(!r.ok)throw new v("Failed to fetch result from black forest labs API");const p=await r.json();if(typeof p=="object"&&p&&"status"in p&&typeof p.status=="string"&&p.status==="Ready"&&"result"in p&&typeof p.result=="object"&&p.result&&"sample"in p.result&&typeof p.result.sample=="string")return i==="url"?p.result.sample:await(await fetch(p.result.sample)).blob()}throw new v("Failed to fetch result from black forest labs API")}},cr=class extends Y{constructor(){super("cerebras","https://api.cerebras.ai")}},dr=class extends Y{constructor(){super("cohere","https://api.cohere.com")}makeRoute(){return"/compatibility/v1/chat/completions"}};function Ze(e){return/^http(s?):/.test(e)||e.startsWith("/")}var Mt=["audio/mpeg","audio/mp4","audio/wav","audio/x-wav"],De=class extends X{constructor(e){super("fal-ai",e||"https://fal.run")}preparePayload(e){return e.args}makeRoute(e){return`/${e.model}`}prepareHeaders(e,t){const a={Authorization:e.authMethod!=="provider-key"?`Bearer ${e.accessToken}`:`Key ${e.accessToken}`};return t||(a["Content-Type"]="application/json"),a}};function Rt(e,t){return`${Re}/${e}/resolve/main/${t}`}var pr=class extends De{preparePayload(e){var a,i;const t={...q(e.args,["inputs","parameters"]),...e.args.parameters,sync_mode:!0,prompt:e.args.inputs,...((a=e.mapping)==null?void 0:a.adapter)==="lora"&&e.mapping.adapterWeightsPath?{loras:[{path:Rt(e.mapping.hfModelId,e.mapping.adapterWeightsPath),scale:1}]}:void 0};return((i=e.mapping)==null?void 0:i.adapter)==="lora"&&e.mapping.adapterWeightsPath&&(t.loras=[{path:Rt(e.mapping.hfModelId,e.mapping.adapterWeightsPath),scale:1}],e.mapping.providerId==="fal-ai/lora"&&(t.model_name="stabilityai/stable-diffusion-xl-base-1.0")),t}async getResponse(e,t){if(typeof e=="object"&&"images"in e&&Array.isArray(e.images)&&e.images.length>0&&"url"in e.images[0]&&typeof e.images[0].url=="string")return t==="url"?e.images[0].url:await(await fetch(e.images[0].url)).blob();throw new v("Expected Fal.ai text-to-image response format")}},ur=class extends De{constructor(){super("https://queue.fal.run")}makeRoute(e){return e.authMethod!=="provider-key"?`/${e.model}?_subdomain=queue`:`/${e.model}`}preparePayload(e){return{...q(e.args,["inputs","parameters"]),...e.args.parameters,prompt:e.args.inputs}}async getResponse(e,t,a){if(!t||!a)throw new v("URL and headers are required for text-to-video task");if(!e.request_id)throw new v("No request ID found in the response");let n=e.status;const o=new URL(t),r=`${o.protocol}//${o.host}${o.host==="router.huggingface.co"?"/fal-ai":""}`,p=new URL(e.response_url).pathname,u=o.search,d=`${r}${p}/status${u}`,c=`${r}${p}${u}`;for(;n!=="COMPLETED";){await Vt(500);const y=await fetch(d,{headers:a});if(!y.ok)throw new v("Failed to fetch response status from fal-ai API");try{n=(await y.json()).status}catch{throw new v("Failed to parse status response from fal-ai API")}}const l=await fetch(c,{headers:a});let f;try{f=await l.json()}catch{throw new v("Failed to parse result response from fal-ai API")}if(typeof f=="object"&&f&&"video"in f&&typeof f.video=="object"&&f.video&&"url"in f.video&&typeof f.video.url=="string"&&Ze(f.video.url))return await(await fetch(f.video.url)).blob();throw new v("Expected { video: { url: string } } result format, got instead: "+JSON.stringify(f))}},mr=class extends De{prepareHeaders(e,t){const a=super.prepareHeaders(e,t);return a["Content-Type"]="application/json",a}async getResponse(e){const t=e;if(typeof(t==null?void 0:t.text)!="string")throw new v(`Expected { text: string } format from Fal.ai Automatic Speech Recognition, got: ${JSON.stringify(e)}`);return{text:t.text}}},fr=class extends De{preparePayload(e){return{...q(e.args,["inputs","parameters"]),...e.args.parameters,lyrics:e.args.inputs}}async getResponse(e){var a;const t=e;if(typeof((a=t==null?void 0:t.audio)==null?void 0:a.url)!="string")throw new v(`Expected { audio: { url: string } } format from Fal.ai Text-to-Speech, got: ${JSON.stringify(e)}`);try{const i=await fetch(t.audio.url);if(!i.ok)throw new Error(`Failed to fetch audio from ${t.audio.url}: ${i.statusText}`);return await i.blob()}catch(i){throw new v(`Error fetching or processing audio from Fal.ai Text-to-Speech URL: ${t.audio.url}. ${i instanceof Error?i.message:String(i)}`)}}},hr=class extends Y{constructor(){super("fireworks-ai","https://api.fireworks.ai")}makeRoute(){return"/inference/v1/chat/completions"}},$t=["feature-extraction","sentence-similarity"],R=class extends X{constructor(){super("hf-inference",`${zt}/hf-inference`)}preparePayload(e){return e.args}makeUrl(e){return e.model.startsWith("http://")||e.model.startsWith("https://")?e.model:super.makeUrl(e)}makeRoute(e){return e.task&&["feature-extraction","sentence-similarity"].includes(e.task)?`pipeline/${e.task}/${e.model}`:`models/${e.model}`}async getResponse(e){return e}},gr=class extends R{async getResponse(e,t,a,i){if(!e)throw new v("response is undefined");if(typeof e=="object"){if("data"in e&&Array.isArray(e.data)&&e.data[0].b64_json){const n=e.data[0].b64_json;return i==="url"?`data:image/jpeg;base64,${n}`:await(await fetch(`data:image/jpeg;base64,${n}`)).blob()}if("output"in e&&Array.isArray(e.output))return i==="url"?e.output[0]:await(await fetch(e.output[0])).blob()}if(e instanceof Blob)return i==="url"?`data:image/jpeg;base64,${await e.arrayBuffer().then(o=>Buffer.from(o).toString("base64"))}`:e;throw new v("Expected a Blob ")}},br=class extends R{makeUrl(e){let t;return e.model.startsWith("http://")||e.model.startsWith("https://")?t=e.model.trim():t=`${this.makeBaseUrl(e)}/models/${e.model}`,t=t.replace(/\/+$/,""),t.endsWith("/v1")?t+="/chat/completions":t.endsWith("/chat/completions")||(t+="/v1/chat/completions"),t}preparePayload(e){return{...e.args,model:e.model}}async getResponse(e){return e}},yr=class extends R{async getResponse(e){const t=Wt(e);if(Array.isArray(t)&&t.every(a=>"generated_text"in a&&typeof(a==null?void 0:a.generated_text)=="string"))return t==null?void 0:t[0];throw new v("Expected Array<{generated_text: string}>")}},wr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t=="object"&&t!==null&&typeof t.label=="string"&&typeof t.score=="number"))return e;throw new v("Expected Array<{label: string, score: number}> but received different format")}},vr=class extends R{async getResponse(e){return e}},_r=class extends R{async getResponse(e){if(!Array.isArray(e))throw new v("Expected Array");if(!e.every(t=>typeof t=="object"&&t&&"label"in t&&typeof t.label=="string"&&"content-type"in t&&typeof t["content-type"]=="string"&&"blob"in t&&typeof t.blob=="string"))throw new v("Expected Array<{label: string, audio: Blob}>");return e}},xr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t=="object"&&!!t&&typeof(t==null?void 0:t.answer)=="string"&&(typeof t.end=="number"||typeof t.end>"u")&&(typeof t.score=="number"||typeof t.score>"u")&&(typeof t.start=="number"||typeof t.start>"u")))return e[0];throw new v("Expected Array<{answer: string, end: number, score: number, start: number}>")}},kr=class extends R{async getResponse(e){const t=(a,i,n=0)=>n>i?!1:a.every(o=>Array.isArray(o))?a.every(o=>t(o,i,n+1)):a.every(o=>typeof o=="number");if(Array.isArray(e)&&t(e,3,0))return e;throw new v("Expected Array<number[][][] | number[][] | number[] | number>")}},Ar=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t.label=="string"&&typeof t.score=="number"))return e;throw new v("Expected Array<{label: string, score: number}>")}},Tr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t.label=="string"&&typeof t.mask=="string"&&typeof t.score=="number"))return e;throw new v("Expected Array<{label: string, mask: string, score: number}>")}},Sr=class extends R{async getResponse(e){if(typeof(e==null?void 0:e.generated_text)!="string")throw new v("Expected {generated_text: string}");return e}},Ir=class extends R{async getResponse(e){if(e instanceof Blob)return e;throw new v("Expected Blob")}},Er=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t.label=="string"&&typeof t.score=="number"&&typeof t.box.xmin=="number"&&typeof t.box.ymin=="number"&&typeof t.box.xmax=="number"&&typeof t.box.ymax=="number"))return e;throw new v("Expected Array<{label: string, score: number, box: {xmin: number, ymin: number, xmax: number, ymax: number}}>")}},Cr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t.label=="string"&&typeof t.score=="number"))return e;throw new v("Expected Array<{label: string, score: number}>")}},Mr=class extends R{async getResponse(e){const t=e==null?void 0:e[0];if(Array.isArray(t)&&t.every(a=>typeof(a==null?void 0:a.label)=="string"&&typeof a.score=="number"))return t;throw new v("Expected Array<{label: string, score: number}>")}},Rr=class extends R{async getResponse(e){if(Array.isArray(e)?e.every(t=>typeof t=="object"&&!!t&&typeof t.answer=="string"&&typeof t.end=="number"&&typeof t.score=="number"&&typeof t.start=="number"):typeof e=="object"&&e&&typeof e.answer=="string"&&typeof e.end=="number"&&typeof e.score=="number"&&typeof e.start=="number")return Array.isArray(e)?e[0]:e;throw new v("Expected Array<{answer: string, end: number, score: number, start: number}>")}},$r=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t.score=="number"&&typeof t.sequence=="string"&&typeof t.token=="number"&&typeof t.token_str=="string"))return e;throw new v("Expected Array<{score: number, sequence: string, token: number, token_str: string}>")}},Dr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>Array.isArray(t.labels)&&t.labels.every(a=>typeof a=="string")&&Array.isArray(t.scores)&&t.scores.every(a=>typeof a=="number")&&typeof t.sequence=="string"))return e;throw new v("Expected Array<{labels: string[], scores: number[], sequence: string}>")}},Lr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t=="number"))return e;throw new v("Expected Array<number>")}},Ve=class extends R{static validate(e){return typeof e=="object"&&!!e&&"aggregator"in e&&typeof e.aggregator=="string"&&"answer"in e&&typeof e.answer=="string"&&"cells"in e&&Array.isArray(e.cells)&&e.cells.every(t=>typeof t=="string")&&"coordinates"in e&&Array.isArray(e.coordinates)&&e.coordinates.every(t=>Array.isArray(t)&&t.every(a=>typeof a=="number"))}async getResponse(e){if(Array.isArray(e)&&Array.isArray(e)?e.every(t=>Ve.validate(t)):Ve.validate(e))return Array.isArray(e)?e[0]:e;throw new v("Expected {aggregator: string, answer: string, cells: string[], coordinates: number[][]}")}},Ur=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t.end=="number"&&typeof t.entity_group=="string"&&typeof t.score=="number"&&typeof t.start=="number"&&typeof t.word=="string"))return e;throw new v("Expected Array<{end: number, entity_group: string, score: number, start: number, word: string}>")}},Pr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof(t==null?void 0:t.translation_text)=="string"))return(e==null?void 0:e.length)===1?e==null?void 0:e[0]:e;throw new v("Expected Array<{translation_text: string}>")}},Nr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof(t==null?void 0:t.summary_text)=="string"))return e==null?void 0:e[0];throw new v("Expected Array<{summary_text: string}>")}},jr=class extends R{async getResponse(e){return e}},Or=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t=="number"))return e;throw new v("Expected Array<number>")}},qr=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t=="object"&&!!t&&typeof(t==null?void 0:t.answer)=="string"&&typeof t.score=="number"))return e[0];throw new v("Expected Array<{answer: string, score: number}>")}},Br=class extends R{async getResponse(e){if(Array.isArray(e)&&e.every(t=>typeof t=="number"))return e;throw new v("Expected Array<number>")}},Fr=class extends R{async getResponse(e){return e}},Ge="https://api.hyperbolic.xyz",Hr=class extends Y{constructor(){super("hyperbolic",Ge)}},Vr=class extends $e{constructor(){super("hyperbolic",Ge)}makeRoute(){return"v1/chat/completions"}preparePayload(e){return{messages:[{content:e.args.inputs,role:"user"}],...e.args.parameters?{max_tokens:e.args.parameters.max_new_tokens,...q(e.args.parameters,"max_new_tokens")}:void 0,...q(e.args,["inputs","parameters"]),model:e.model}}async getResponse(e){if(typeof e=="object"&&"choices"in e&&Array.isArray(e==null?void 0:e.choices)&&typeof(e==null?void 0:e.model)=="string")return{generated_text:e.choices[0].message.content};throw new v("Expected Hyperbolic text generation response format")}},zr=class extends X{constructor(){super("hyperbolic",Ge)}makeRoute(e){return"/v1/images/generations"}preparePayload(e){return{...q(e.args,["inputs","parameters"]),...e.args.parameters,prompt:e.args.inputs,model_name:e.model}}async getResponse(e,t,a,i){if(typeof e=="object"&&"images"in e&&Array.isArray(e.images)&&e.images[0]&&typeof e.images[0].image=="string")return i==="url"?`data:image/jpeg;base64,${e.images[0].image}`:fetch(`data:image/jpeg;base64,${e.images[0].image}`).then(n=>n.blob());throw new v("Expected Hyperbolic text-to-image response format")}},et="https://api.studio.nebius.ai",Wr=class extends Y{constructor(){super("nebius",et)}},Kr=class extends $e{constructor(){super("nebius",et)}},Jr=class extends X{constructor(){super("nebius",et)}preparePayload(e){return{...q(e.args,["inputs","parameters"]),...e.args.parameters,response_format:"b64_json",prompt:e.args.inputs,model:e.model}}makeRoute(e){return"v1/images/generations"}async getResponse(e,t,a,i){if(typeof e=="object"&&"data"in e&&Array.isArray(e.data)&&e.data.length>0&&"b64_json"in e.data[0]&&typeof e.data[0].b64_json=="string"){const n=e.data[0].b64_json;return i==="url"?`data:image/jpeg;base64,${n}`:fetch(`data:image/jpeg;base64,${n}`).then(o=>o.blob())}throw new v("Expected Nebius text-to-image response format")}},Kt="https://api.novita.ai",Qr=class extends $e{constructor(){super("novita",Kt)}makeRoute(){return"/v3/openai/chat/completions"}},Xr=class extends Y{constructor(){super("novita",Kt)}makeRoute(){return"/v3/openai/chat/completions"}},Yr="https://api.openai.com",Zr=class extends Y{constructor(){super("openai",Yr,!0)}},tt=class extends X{constructor(e){super("replicate",e||"https://api.replicate.com")}makeRoute(e){return e.model.includes(":")?"v1/predictions":`v1/models/${e.model}/predictions`}preparePayload(e){return{input:{...q(e.args,["inputs","parameters"]),...e.args.parameters,prompt:e.args.inputs},version:e.model.includes(":")?e.model.split(":")[1]:void 0}}prepareHeaders(e,t){const a={Authorization:`Bearer ${e.accessToken}`,Prefer:"wait"};return t||(a["Content-Type"]="application/json"),a}makeUrl(e){const t=this.makeBaseUrl(e);return e.model.includes(":")?`${t}/v1/predictions`:`${t}/v1/models/${e.model}/predictions`}},Gr=class extends tt{async getResponse(e,t,a,i){if(typeof e=="object"&&"output"in e&&Array.isArray(e.output)&&e.output.length>0&&typeof e.output[0]=="string")return i==="url"?e.output[0]:await(await fetch(e.output[0])).blob();throw new v("Expected Replicate text-to-image response format")}},es=class extends tt{preparePayload(e){const t=super.preparePayload(e),a=t.input;if(typeof a=="object"&&a!==null&&"prompt"in a){const i=a;i.text=i.prompt,delete i.prompt}return t}async getResponse(e){if(e instanceof Blob)return e;if(e&&typeof e=="object"&&"output"in e){if(typeof e.output=="string")return await(await fetch(e.output)).blob();if(Array.isArray(e.output))return await(await fetch(e.output[0])).blob()}throw new v("Expected Blob or object with output")}},ts=class extends tt{async getResponse(e){if(typeof e=="object"&&e&&"output"in e&&typeof e.output=="string"&&Ze(e.output))return await(await fetch(e.output)).blob();throw new v("Expected { output: string }")}},as=class extends Y{constructor(){super("sambanova","https://api.sambanova.ai")}},at="https://api.together.xyz",is=class extends Y{constructor(){super("together",at)}},ns=class extends $e{constructor(){super("together",at)}preparePayload(e){return{model:e.model,...e.args,prompt:e.args.inputs}}async getResponse(e){if(typeof e=="object"&&"choices"in e&&Array.isArray(e==null?void 0:e.choices)&&typeof(e==null?void 0:e.model)=="string")return{generated_text:e.choices[0].text};throw new v("Expected Together text generation response format")}},os=class extends X{constructor(){super("together",at)}makeRoute(){return"v1/images/generations"}preparePayload(e){return{...q(e.args,["inputs","parameters"]),...e.args.parameters,prompt:e.args.inputs,response_format:"base64",model:e.model}}async getResponse(e,t){if(typeof e=="object"&&"data"in e&&Array.isArray(e.data)&&e.data.length>0&&"b64_json"in e.data[0]&&typeof e.data[0].b64_json=="string"){const a=e.data[0].b64_json;return t==="url"?`data:image/jpeg;base64,${a}`:fetch(`data:image/jpeg;base64,${a}`).then(i=>i.blob())}throw new v("Expected Together text-to-image response format")}},Oe={"black-forest-labs":{"text-to-image":new lr},cerebras:{conversational:new cr},cohere:{conversational:new dr},"fal-ai":{"text-to-image":new pr,"text-to-speech":new fr,"text-to-video":new ur,"automatic-speech-recognition":new mr},"hf-inference":{"text-to-image":new gr,conversational:new br,"text-generation":new yr,"text-classification":new Mr,"question-answering":new Rr,"audio-classification":new wr,"automatic-speech-recognition":new vr,"fill-mask":new $r,"feature-extraction":new kr,"image-classification":new Ar,"image-segmentation":new Tr,"document-question-answering":new xr,"image-to-text":new Sr,"object-detection":new Er,"audio-to-audio":new _r,"zero-shot-image-classification":new Cr,"zero-shot-classification":new Dr,"image-to-image":new Ir,"sentence-similarity":new Lr,"table-question-answering":new Ve,"tabular-classification":new Or,"text-to-speech":new jr,"token-classification":new Ur,translation:new Pr,summarization:new Nr,"visual-question-answering":new qr,"tabular-regression":new Br,"text-to-audio":new Fr},"fireworks-ai":{conversational:new hr},hyperbolic:{"text-to-image":new zr,conversational:new Hr,"text-generation":new Vr},nebius:{"text-to-image":new Jr,conversational:new Wr,"text-generation":new Kr},novita:{conversational:new Xr,"text-generation":new Qr},openai:{conversational:new Zr},replicate:{"text-to-image":new Gr,"text-to-speech":new es,"text-to-video":new ts},sambanova:{conversational:new as},together:{"text-to-image":new os,conversational:new is,"text-generation":new ns}};function I(e,t){if(e==="hf-inference"&&!t)return new R;if(!t)throw new Error("you need to provide a task name when using an external provider, e.g. 'text-to-image'");if(!(e in Oe))throw new Error(`Provider '${e}' not supported. Available providers: ${Object.keys(Oe)}`);const a=Oe[e];if(!a||!(t in a))throw new Error(`Task '${t}' not supported for provider '${e}'. Available tasks: ${Object.keys(a??{})}`);return a[t]}var rs="@huggingface/inference",ss="3.8.1",Dt={"black-forest-labs":{},cerebras:{},cohere:{},"fal-ai":{},"fireworks-ai":{},"hf-inference":{},hyperbolic:{},nebius:{},novita:{},openai:{},replicate:{},sambanova:{},together:{}},Lt=new Map;async function ls(e,t){var n,o;if(Dt[e.provider][e.modelId])return Dt[e.provider][e.modelId];let a;if(Lt.has(e.modelId))a=Lt.get(e.modelId);else{const r=await((t==null?void 0:t.fetch)??fetch)(`${Re}/api/models/${e.modelId}?expand[]=inferenceProviderMapping`,{headers:(n=e.accessToken)!=null&&n.startsWith("hf_")?{Authorization:`Bearer ${e.accessToken}`}:{}});if(r.status===404)throw new Error(`Model ${e.modelId} does not exist`);a=await r.json().then(p=>p.inferenceProviderMapping).catch(()=>null)}if(!a)throw new Error(`We have not been able to find inference provider information for model ${e.modelId}.`);const i=a[e.provider];if(i){const r=e.provider==="hf-inference"&&He($t,e.task)?$t:[e.task];if(!He(r,i.task))throw new Error(`Model ${e.modelId} is not supported for task ${e.task} and provider ${e.provider}. Supported task: ${i.task}.`);if(i.status==="staging"&&console.warn(`Model ${e.modelId} is in staging mode for provider ${e.provider}. Meant for test purposes only.`),i.adapter==="lora"){const p=await((t==null?void 0:t.fetch)??fetch)(`${Re}/api/models/${e.modelId}/tree/main`);if(!p.ok)throw new Error(`Unable to fetch the model tree for ${e.modelId}.`);const d=(o=(await p.json()).find(({type:c,path:l})=>c==="file"&&l.endsWith(".safetensors")))==null?void 0:o.path;if(!d)throw new Error(`No .safetensors file found in the model tree for ${e.modelId}.`);return{...i,hfModelId:e.modelId,adapterWeightsPath:d}}return{...i,hfModelId:e.modelId}}return null}var qe=null;async function Le(e,t,a){const{provider:i,model:n}=e,o=i??"hf-inference",{task:r}=a??{};if(e.endpointUrl&&o!=="hf-inference")throw new Error("Cannot use endpointUrl with a third-party provider.");if(n&&Ze(n))throw new Error("Model URLs are no longer supported. Use endpointUrl instead.");if(e.endpointUrl)return ze(n??e.endpointUrl,t,e,void 0,a);if(!n&&!r)throw new Error("No model provided, and no task has been specified.");const p=n??await cs(r);if(t.clientSideRoutingOnly&&!n)throw new Error(`Provider ${o} requires a model ID to be passed directly.`);const u=t.clientSideRoutingOnly?{providerId:ps(n,o),hfModelId:n,status:"live",task:r}:await ls({modelId:p,task:r,provider:o,accessToken:e.accessToken},{fetch:a==null?void 0:a.fetch});if(!u)throw new Error(`We have not been able to find inference provider information for model ${p}.`);return ze(u.providerId,t,e,u,a)}function ze(e,t,a,i,n){const{accessToken:o,endpointUrl:r,provider:p,model:u,...d}=a,c=p??"hf-inference",{includeCredentials:l,task:f,signal:y,billTo:k}=n??{},S=(()=>{if(t.clientSideRoutingOnly){if(o&&o.startsWith("hf_"))throw new Error(`Provider ${c} is closed-source and does not support HF tokens.`);return"provider-key"}return o?o.startsWith("hf_")?"hf-token":"provider-key":l==="include"?"credentials-include":"none"})(),N=r??e,O=t.makeUrl({authMethod:S,model:N,task:f}),Z=t.prepareHeaders({accessToken:o,authMethod:S},"data"in a&&!!a.data);k&&(Z[rr]=k);const we=[`${rs}/${ss}`,typeof navigator<"u"?navigator.userAgent:void 0].filter(Se=>Se!==void 0).join(" ");Z["User-Agent"]=we;const Te=t.makeBody({args:d,model:e,task:f,mapping:i});let se;typeof l=="string"?se=l:l===!0&&(se="include");const ve={headers:Z,method:"POST",body:Te,...se?{credentials:se}:void 0,signal:y};return{url:O,info:ve}}async function cs(e){qe||(qe=await ds());const t=qe[e];if(((t==null?void 0:t.models.length)??0)<=0)throw new Error(`No default model defined for task ${e}, please define the model explicitly.`);return t.models[0].id}async function ds(){const e=await fetch(`${Re}/api/tasks`);if(!e.ok)throw new Error("Failed to load tasks definitions from Hugging Face Hub.");return await e.json()}function ps(e,t){if(!e.startsWith(`${t}/`))throw new Error(`Models from ${t} must be prefixed by "${t}/". Got "${e}".`);return e.slice(t.length+1)}function us(e){let t,a,i,n=!1;return function(r){t===void 0?(t=r,a=0,i=-1):t=fs(t,r);const p=t.length;let u=0;for(;a<p;){n&&(t[a]===10&&(u=++a),n=!1);let d=-1;for(;a<p&&d===-1;++a)switch(t[a]){case 58:i===-1&&(i=a-u);break;case 13:n=!0;case 10:d=a;break}if(d===-1)break;e(t.subarray(u,d),i),u=a,i=-1}u===p?t=void 0:u!==0&&(t=t.subarray(u),a-=u)}}function ms(e,t,a){let i=Ut();const n=new TextDecoder;return function(r,p){if(r.length===0)a==null||a(i),i=Ut();else if(p>0){const u=n.decode(r.subarray(0,p)),d=p+(r[p+1]===32?2:1),c=n.decode(r.subarray(d));switch(u){case"data":i.data=i.data?i.data+`
`+c:c;break;case"event":i.event=c;break;case"id":e(i.id=c);break;case"retry":const l=parseInt(c,10);isNaN(l)||t(i.retry=l);break}}}}function fs(e,t){const a=new Uint8Array(e.length+t.length);return a.set(e),a.set(t,e.length),a}function Ut(){return{data:"",event:"",id:"",retry:void 0}}async function C(e,t,a){var u;const{url:i,info:n}=await Le(e,t,a),o=await((a==null?void 0:a.fetch)??fetch)(i,n),r={url:i,info:n};if((a==null?void 0:a.retry_on_error)!==!1&&o.status===503)return C(e,t,a);if(!o.ok){const d=o.headers.get("Content-Type");if(["application/json","application/problem+json"].some(l=>d==null?void 0:d.startsWith(l))){const l=await o.json();throw[400,422,404,500].includes(o.status)&&(a!=null&&a.chatCompletion)?new Error(`Server ${e.model} does not seem to support chat completion. Error: ${JSON.stringify(l.error)}`):l.error||l.detail?new Error(JSON.stringify(l.error??l.detail)):new Error(l)}const c=d!=null&&d.startsWith("text/plain;")?await o.text():void 0;throw new Error(c??"An error occurred while fetching the blob")}return(u=o.headers.get("Content-Type"))!=null&&u.startsWith("application/json")?{data:await o.json(),requestContext:r}:{data:await o.blob(),requestContext:r}}async function*Ue(e,t,a){var c,l;const{url:i,info:n}=await Le({...e,stream:!0},t,a),o=await((a==null?void 0:a.fetch)??fetch)(i,n);if((a==null?void 0:a.retry_on_error)!==!1&&o.status===503)return yield*Ue(e,t,a);if(!o.ok){if((c=o.headers.get("Content-Type"))!=null&&c.startsWith("application/json")){const f=await o.json();if([400,422,404,500].includes(o.status)&&(a!=null&&a.chatCompletion))throw new Error(`Server ${e.model} does not seem to support chat completion. Error: ${f.error}`);if(typeof f.error=="string")throw new Error(f.error);if(f.error&&"message"in f.error&&typeof f.error.message=="string")throw new Error(f.error.message);if(typeof f.message=="string")throw new Error(f.message)}throw new Error(`Server response contains error: ${o.status}`)}if(!((l=o.headers.get("content-type"))!=null&&l.startsWith("text/event-stream")))throw new Error("Server does not support event stream content type, it returned "+o.headers.get("content-type"));if(!o.body)return;const r=o.body.getReader();let p=[];const d=us(ms(()=>{},()=>{},f=>{p.push(f)}));try{for(;;){const{done:f,value:y}=await r.read();if(f)return;d(y);for(const k of p)if(k.data.length>0){if(k.data==="[DONE]")return;const S=JSON.parse(k.data);if(typeof S=="object"&&S!==null&&"error"in S){const N=typeof S.error=="string"?S.error:typeof S.error=="object"&&S.error&&"message"in S.error&&typeof S.error.message=="string"?S.error.message:JSON.stringify(S.error);throw new Error("Error forwarded from backend: "+N)}yield S}p=[]}}finally{r.releaseLock()}}async function hs(e,t){console.warn("The request method is deprecated and will be removed in a future version of huggingface.js. Use specific task functions instead.");const a=I(e.provider??"hf-inference",t==null?void 0:t.task);return(await C(e,a,t)).data}async function*gs(e,t){console.warn("The streamingRequest method is deprecated and will be removed in a future version of huggingface.js. Use specific task functions instead.");const a=I(e.provider??"hf-inference",t==null?void 0:t.task);yield*Ue(e,a,t)}function it(e){return"data"in e?e:{...q(e,"inputs"),data:e.inputs}}async function bs(e,t){const a=I(e.provider??"hf-inference","audio-classification"),i=it(e),{data:n}=await C(i,a,{...t,task:"audio-classification"});return a.getResponse(n)}async function ys(e,t){const a=I(e.provider??"hf-inference","audio-to-audio"),i=it(e),{data:n}=await C(i,a,{...t,task:"audio-to-audio"});return a.getResponse(n)}function ce(e){if(globalThis.Buffer)return globalThis.Buffer.from(e).toString("base64");{const t=[];return e.forEach(a=>{t.push(String.fromCharCode(a))}),globalThis.btoa(t.join(""))}}async function ws(e,t){const a=I(e.provider??"hf-inference","automatic-speech-recognition"),i=await vs(e),{data:n}=await C(i,a,{...t,task:"automatic-speech-recognition"});if(!(typeof(n==null?void 0:n.text)=="string"))throw new v("Expected {text: string}");return a.getResponse(n)}async function vs(e){if(e.provider==="fal-ai"){const t="data"in e&&e.data instanceof Blob?e.data:"inputs"in e?e.inputs:void 0,a=t==null?void 0:t.type;if(!a)throw new Error("Unable to determine the input's content-type. Make sure your are passing a Blob when using provider fal-ai.");if(!Mt.includes(a))throw new Error(`Provider fal-ai does not support blob type ${a} - supported content types are: ${Mt.join(", ")}`);const i=ce(new Uint8Array(await t.arrayBuffer()));return{..."data"in e?q(e,"data"):q(e,"inputs"),audio_url:`data:${a};base64,${i}`}}else return it(e)}async function _s(e,t){const a=e.provider??"hf-inference",i=I(a,"text-to-speech"),{data:n}=await C(e,i,{...t,task:"text-to-speech"});return i.getResponse(n)}function Pe(e){return"data"in e?e:{...q(e,"inputs"),data:e.inputs}}async function xs(e,t){const a=I(e.provider??"hf-inference","image-classification"),i=Pe(e),{data:n}=await C(i,a,{...t,task:"image-classification"});return a.getResponse(n)}async function ks(e,t){const a=I(e.provider??"hf-inference","image-segmentation"),i=Pe(e),{data:n}=await C(i,a,{...t,task:"image-segmentation"});return a.getResponse(n)}async function As(e,t){const a=I(e.provider??"hf-inference","image-to-image");let i;e.parameters?i={...e,inputs:ce(new Uint8Array(e.inputs instanceof ArrayBuffer?e.inputs:await e.inputs.arrayBuffer()))}:i={accessToken:e.accessToken,model:e.model,data:e.inputs};const{data:n}=await C(i,a,{...t,task:"image-to-image"});return a.getResponse(n)}async function Ts(e,t){const a=I(e.provider??"hf-inference","image-to-text"),i=Pe(e),{data:n}=await C(i,a,{...t,task:"image-to-text"});return a.getResponse(n[0])}async function Ss(e,t){const a=I(e.provider??"hf-inference","object-detection"),i=Pe(e),{data:n}=await C(i,a,{...t,task:"object-detection"});return a.getResponse(n)}async function Is(e,t){const a=e.provider??"hf-inference",i=I(a,"text-to-image"),{data:n}=await C(e,i,{...t,task:"text-to-image"}),{url:o,info:r}=await Le(e,i,{...t,task:"text-to-image"});return i.getResponse(n,o,r.headers,t==null?void 0:t.outputType)}async function Es(e,t){const a=e.provider??"hf-inference",i=I(a,"text-to-video"),{data:n}=await C(e,i,{...t,task:"text-to-video"}),{url:o,info:r}=await Le(e,i,{...t,task:"text-to-video"});return i.getResponse(n,o,r.headers)}async function Cs(e){return e.inputs instanceof Blob?{...e,inputs:{image:ce(new Uint8Array(await e.inputs.arrayBuffer()))}}:{...e,inputs:{image:ce(new Uint8Array(e.inputs.image instanceof ArrayBuffer?e.inputs.image:await e.inputs.image.arrayBuffer()))}}}async function Ms(e,t){const a=I(e.provider??"hf-inference","zero-shot-image-classification"),i=await Cs(e),{data:n}=await C(i,a,{...t,task:"zero-shot-image-classification"});return a.getResponse(n)}async function Rs(e,t){const a=I(e.provider??"hf-inference","conversational"),{data:i}=await C(e,a,{...t,task:"conversational"});return a.getResponse(i)}async function*$s(e,t){const a=I(e.provider??"hf-inference","conversational");yield*Ue(e,a,{...t,task:"conversational"})}async function Ds(e,t){const a=I(e.provider??"hf-inference","feature-extraction"),{data:i}=await C(e,a,{...t,task:"feature-extraction"});return a.getResponse(i)}async function Ls(e,t){const a=I(e.provider??"hf-inference","fill-mask"),{data:i}=await C(e,a,{...t,task:"fill-mask"});return a.getResponse(i)}async function Us(e,t){const a=I(e.provider??"hf-inference","question-answering"),{data:i}=await C(e,a,{...t,task:"question-answering"});return a.getResponse(i)}async function Ps(e,t){const a=I(e.provider??"hf-inference","sentence-similarity"),{data:i}=await C(e,a,{...t,task:"sentence-similarity"});return a.getResponse(i)}async function Ns(e,t){const a=I(e.provider??"hf-inference","summarization"),{data:i}=await C(e,a,{...t,task:"summarization"});return a.getResponse(i)}async function js(e,t){const a=I(e.provider??"hf-inference","table-question-answering"),{data:i}=await C(e,a,{...t,task:"table-question-answering"});return a.getResponse(i)}async function Os(e,t){const a=I(e.provider??"hf-inference","text-classification"),{data:i}=await C(e,a,{...t,task:"text-classification"});return a.getResponse(i)}async function qs(e,t){const a=I(e.provider??"hf-inference","text-generation"),{data:i}=await C(e,a,{...t,task:"text-generation"});return a.getResponse(i)}async function*Bs(e,t){const a=I(e.provider??"hf-inference","text-generation");yield*Ue(e,a,{...t,task:"text-generation"})}async function Fs(e,t){const a=I(e.provider??"hf-inference","token-classification"),{data:i}=await C(e,a,{...t,task:"token-classification"});return a.getResponse(i)}async function Hs(e,t){const a=I(e.provider??"hf-inference","translation"),{data:i}=await C(e,a,{...t,task:"translation"});return a.getResponse(i)}async function Vs(e,t){const a=I(e.provider??"hf-inference","zero-shot-classification"),{data:i}=await C(e,a,{...t,task:"zero-shot-classification"});return a.getResponse(i)}async function zs(e,t){const a=I(e.provider??"hf-inference","document-question-answering"),i={...e,inputs:{question:e.inputs.question,image:ce(new Uint8Array(await e.inputs.image.arrayBuffer()))}},{data:n}=await C(i,a,{...t,task:"document-question-answering"});return a.getResponse(n)}async function Ws(e,t){const a=I(e.provider??"hf-inference","visual-question-answering"),i={...e,inputs:{question:e.inputs.question,image:ce(new Uint8Array(await e.inputs.image.arrayBuffer()))}},{data:n}=await C(i,a,{...t,task:"visual-question-answering"});return a.getResponse(n)}async function Ks(e,t){const a=I(e.provider??"hf-inference","tabular-classification"),{data:i}=await C(e,a,{...t,task:"tabular-classification"});return a.getResponse(i)}async function Js(e,t){const a=I(e.provider??"hf-inference","tabular-regression"),{data:i}=await C(e,a,{...t,task:"tabular-regression"});return a.getResponse(i)}var Qs={};Ht(Qs,{getInferenceSnippets:()=>rl});var Jt={js:{fetch:{basic:`async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "application/json",
{% if billTo %}
				"X-HF-Bill-To": "{{ billTo }}",
{% endif %}			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.json();
	return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    console.log(JSON.stringify(response));
});`,basicAudio:`async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "audio/flac",
{% if billTo %}
				"X-HF-Bill-To": "{{ billTo }}",
{% endif %}			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.json();
	return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    console.log(JSON.stringify(response));
});`,basicImage:`async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "image/jpeg",
{% if billTo %}
				"X-HF-Bill-To": "{{ billTo }}",
{% endif %}			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.json();
	return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    console.log(JSON.stringify(response));
});`,textToAudio:`{% if model.library_name == "transformers" %}
async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "application/json",
{% if billTo %}
				"X-HF-Bill-To": "{{ billTo }}",
{% endif %}			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.blob();
    return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    // Returns a byte object of the Audio wavform. Use it directly!
});
{% else %}
async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "application/json",
			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
    const result = await response.json();
    return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    console.log(JSON.stringify(response));
});
{% endif %} `,textToImage:`async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "application/json",
{% if billTo %}
				"X-HF-Bill-To": "{{ billTo }}",
{% endif %}			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.blob();
	return result;
}


query({ {{ providerInputs.asTsString }} }).then((response) => {
    // Use image
});`,zeroShotClassification:`async function query(data) {
    const response = await fetch(
		"{{ fullUrl }}",
        {
            headers: {
				Authorization: "{{ authorizationHeader }}",
                "Content-Type": "application/json",
{% if billTo %}
                "X-HF-Bill-To": "{{ billTo }}",
{% endif %}         },
            method: "POST",
            body: JSON.stringify(data),
        }
    );
    const result = await response.json();
    return result;
}

query({
    inputs: {{ providerInputs.asObj.inputs }},
    parameters: { candidate_labels: ["refund", "legal", "faq"] }
}).then((response) => {
    console.log(JSON.stringify(response));
});`},"huggingface.js":{basic:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const output = await client.{{ methodName }}({
	model: "{{ model.id }}",
	inputs: {{ inputs.asObj.inputs }},
	provider: "{{ provider }}",
}{% if billTo %}, {
	billTo: "{{ billTo }}",
}{% endif %});

console.log(output);`,basicAudio:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const data = fs.readFileSync({{inputs.asObj.inputs}});

const output = await client.{{ methodName }}({
	data,
	model: "{{ model.id }}",
	provider: "{{ provider }}",
}{% if billTo %}, {
	billTo: "{{ billTo }}",
}{% endif %});

console.log(output);`,basicImage:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const data = fs.readFileSync({{inputs.asObj.inputs}});

const output = await client.{{ methodName }}({
	data,
	model: "{{ model.id }}",
	provider: "{{ provider }}",
}{% if billTo %}, {
	billTo: "{{ billTo }}",
}{% endif %});

console.log(output);`,conversational:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const chatCompletion = await client.chatCompletion({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
{{ inputs.asTsString }}
}{% if billTo %}, {
    billTo: "{{ billTo }}",
}{% endif %});

console.log(chatCompletion.choices[0].message);`,conversationalStream:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

let out = "";

const stream = await client.chatCompletionStream({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
{{ inputs.asTsString }}
}{% if billTo %}, {
    billTo: "{{ billTo }}",
}{% endif %});

for await (const chunk of stream) {
	if (chunk.choices && chunk.choices.length > 0) {
		const newContent = chunk.choices[0].delta.content;
		out += newContent;
		console.log(newContent);
	}  
}`,textToImage:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const image = await client.textToImage({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
	inputs: {{ inputs.asObj.inputs }},
	parameters: { num_inference_steps: 5 },
}{% if billTo %}, {
    billTo: "{{ billTo }}",
}{% endif %});
/// Use the generated image (it's a Blob)`,textToVideo:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const image = await client.textToVideo({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
	inputs: {{ inputs.asObj.inputs }},
}{% if billTo %}, {
    billTo: "{{ billTo }}",
}{% endif %});
// Use the generated video (it's a Blob)`},openai:{conversational:`import { OpenAI } from "openai";

const client = new OpenAI({
	baseURL: "{{ baseUrl }}",
	apiKey: "{{ accessToken }}",
{% if billTo %}
	defaultHeaders: {
		"X-HF-Bill-To": "{{ billTo }}" 
	}
{% endif %}
});

const chatCompletion = await client.chat.completions.create({
	model: "{{ providerModelId }}",
{{ inputs.asTsString }}
});

console.log(chatCompletion.choices[0].message);`,conversationalStream:`import { OpenAI } from "openai";

const client = new OpenAI({
	baseURL: "{{ baseUrl }}",
	apiKey: "{{ accessToken }}",
{% if billTo %}
    defaultHeaders: {
		"X-HF-Bill-To": "{{ billTo }}" 
	}
{% endif %}
});

const stream = await client.chat.completions.create({
    model: "{{ providerModelId }}",
{{ inputs.asTsString }}
    stream: true,
});

for await (const chunk of stream) {
    process.stdout.write(chunk.choices[0]?.delta?.content || "");
}`}},python:{fal_client:{textToImage:`{% if provider == "fal-ai" %}
import fal_client

result = fal_client.subscribe(
    "{{ providerModelId }}",
    arguments={
        "prompt": {{ inputs.asObj.inputs }},
    },
)
print(result)
{% endif %} `},huggingface_hub:{basic:`result = client.{{ methodName }}(
    inputs={{ inputs.asObj.inputs }},
    model="{{ model.id }}",
)`,basicAudio:'output = client.{{ methodName }}({{ inputs.asObj.inputs }}, model="{{ model.id }}")',basicImage:'output = client.{{ methodName }}({{ inputs.asObj.inputs }}, model="{{ model.id }}")',conversational:`completion = client.chat.completions.create(
    model="{{ model.id }}",
{{ inputs.asPythonString }}
)

print(completion.choices[0].message) `,conversationalStream:`stream = client.chat.completions.create(
    model="{{ model.id }}",
{{ inputs.asPythonString }}
    stream=True,
)

for chunk in stream:
    print(chunk.choices[0].delta.content, end="") `,documentQuestionAnswering:`output = client.document_question_answering(
    "{{ inputs.asObj.image }}",
    question="{{ inputs.asObj.question }}",
    model="{{ model.id }}",
) `,imageToImage:`# output is a PIL.Image object
image = client.image_to_image(
    "{{ inputs.asObj.inputs }}",
    prompt="{{ inputs.asObj.parameters.prompt }}",
    model="{{ model.id }}",
) `,importInferenceClient:`from huggingface_hub import InferenceClient

client = InferenceClient(
    provider="{{ provider }}",
    api_key="{{ accessToken }}",
{% if billTo %}
    bill_to="{{ billTo }}",
{% endif %}
)`,textToImage:`# output is a PIL.Image object
image = client.text_to_image(
    {{ inputs.asObj.inputs }},
    model="{{ model.id }}",
) `,textToVideo:`video = client.text_to_video(
    {{ inputs.asObj.inputs }},
    model="{{ model.id }}",
) `},openai:{conversational:`from openai import OpenAI

client = OpenAI(
    base_url="{{ baseUrl }}",
    api_key="{{ accessToken }}",
{% if billTo %}
    default_headers={
        "X-HF-Bill-To": "{{ billTo }}"
    }
{% endif %}
)

completion = client.chat.completions.create(
    model="{{ providerModelId }}",
{{ inputs.asPythonString }}
)

print(completion.choices[0].message) `,conversationalStream:`from openai import OpenAI

client = OpenAI(
    base_url="{{ baseUrl }}",
    api_key="{{ accessToken }}",
{% if billTo %}
    default_headers={
        "X-HF-Bill-To": "{{ billTo }}"
    }
{% endif %}
)

stream = client.chat.completions.create(
    model="{{ providerModelId }}",
{{ inputs.asPythonString }}
    stream=True,
)

for chunk in stream:
    print(chunk.choices[0].delta.content, end="")`},requests:{basic:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

output = query({
    "inputs": {{ providerInputs.asObj.inputs }},
}) `,basicAudio:`def query(filename):
    with open(filename, "rb") as f:
        data = f.read()
    response = requests.post(API_URL, headers={"Content-Type": "audio/flac", **headers}, data=data)
    return response.json()

output = query({{ providerInputs.asObj.inputs }})`,basicImage:`def query(filename):
    with open(filename, "rb") as f:
        data = f.read()
    response = requests.post(API_URL, headers={"Content-Type": "image/jpeg", **headers}, data=data)
    return response.json()

output = query({{ providerInputs.asObj.inputs }})`,conversational:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

response = query({
{{ providerInputs.asJsonString }}
})

print(response["choices"][0]["message"])`,conversationalStream:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload, stream=True)
    for line in response.iter_lines():
        if not line.startswith(b"data:"):
            continue
        if line.strip() == b"data: [DONE]":
            return
        yield json.loads(line.decode("utf-8").lstrip("data:").rstrip("/n"))

chunks = query({
{{ providerInputs.asJsonString }},
    "stream": True,
})

for chunk in chunks:
    print(chunk["choices"][0]["delta"]["content"], end="")`,documentQuestionAnswering:`def query(payload):
    with open(payload["image"], "rb") as f:
        img = f.read()
        payload["image"] = base64.b64encode(img).decode("utf-8")
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

output = query({
    "inputs": {
        "image": "{{ inputs.asObj.image }}",
        "question": "{{ inputs.asObj.question }}",
    },
}) `,imageToImage:`def query(payload):
    with open(payload["inputs"], "rb") as f:
        img = f.read()
        payload["inputs"] = base64.b64encode(img).decode("utf-8")
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

image_bytes = query({
{{ providerInputs.asJsonString }}
})

# You can access the image with PIL.Image for example
import io
from PIL import Image
image = Image.open(io.BytesIO(image_bytes)) `,importRequests:`{% if importBase64 %}
import base64
{% endif %}
{% if importJson %}
import json
{% endif %}
import requests

API_URL = "{{ fullUrl }}"
headers = {
    "Authorization": "{{ authorizationHeader }}",
{% if billTo %}
    "X-HF-Bill-To": "{{ billTo }}"
{% endif %}
}`,tabular:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

response = query({
    "inputs": {
        "data": {{ providerInputs.asObj.inputs }}
    },
}) `,textToAudio:`{% if model.library_name == "transformers" %}
def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

audio_bytes = query({
    "inputs": {{ providerInputs.asObj.inputs }},
})
# You can access the audio with IPython.display for example
from IPython.display import Audio
Audio(audio_bytes)
{% else %}
def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

audio, sampling_rate = query({
    "inputs": {{ providerInputs.asObj.inputs }},
})
# You can access the audio with IPython.display for example
from IPython.display import Audio
Audio(audio, rate=sampling_rate)
{% endif %} `,textToImage:`{% if provider == "hf-inference" %}
def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

image_bytes = query({
    "inputs": {{ providerInputs.asObj.inputs }},
})

# You can access the image with PIL.Image for example
import io
from PIL import Image
image = Image.open(io.BytesIO(image_bytes))
{% endif %}`,zeroShotClassification:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

output = query({
    "inputs": {{ providerInputs.asObj.inputs }},
    "parameters": {"candidate_labels": ["refund", "legal", "faq"]},
}) `,zeroShotImageClassification:`def query(data):
    with open(data["image_path"], "rb") as f:
        img = f.read()
    payload={
        "parameters": data["parameters"],
        "inputs": base64.b64encode(img).decode("utf-8")
    }
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

output = query({
    "image_path": {{ providerInputs.asObj.inputs }},
    "parameters": {"candidate_labels": ["cat", "dog", "llama"]},
}) `}},sh:{curl:{basic:`curl {{ fullUrl }} \\
    -X POST \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: application/json' \\
{% if billTo %}
    -H 'X-HF-Bill-To: {{ billTo }}' \\
{% endif %}
    -d '{
{{ providerInputs.asCurlString }}
    }'`,basicAudio:`curl {{ fullUrl }} \\
    -X POST \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: audio/flac' \\
{% if billTo %}
    -H 'X-HF-Bill-To: {{ billTo }}' \\
{% endif %}
    --data-binary @{{ providerInputs.asObj.inputs }}`,basicImage:`curl {{ fullUrl }} \\
    -X POST \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: image/jpeg' \\
{% if billTo %}
    -H 'X-HF-Bill-To: {{ billTo }}' \\
{% endif %}
    --data-binary @{{ providerInputs.asObj.inputs }}`,conversational:`curl {{ fullUrl }} \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: application/json' \\
{% if billTo %}
    -H 'X-HF-Bill-To: {{ billTo }}' \\
{% endif %}
    -d '{
{{ providerInputs.asCurlString }},
        "stream": false
    }'`,conversationalStream:`curl {{ fullUrl }} \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: application/json' \\
{% if billTo %}
    -H 'X-HF-Bill-To: {{ billTo }}' \\
{% endif %}
    -d '{
{{ providerInputs.asCurlString }},
        "stream": true
    }'`,zeroShotClassification:`curl {{ fullUrl }} \\
    -X POST \\
    -d '{"inputs": {{ providerInputs.asObj.inputs }}, "parameters": {"candidate_labels": ["refund", "legal", "faq"]}}' \\
    -H 'Content-Type: application/json' \\
    -H 'Authorization: {{ authorizationHeader }}'
{% if billTo %} \\
    -H 'X-HF-Bill-To: {{ billTo }}'
{% endif %}`}}},Xs=["huggingface_hub","fal_client","requests","openai"],Ys=["fetch","huggingface.js","openai"],Zs=["curl"],Gs={js:[...Ys],python:[...Xs],sh:[...Zs]},el=(e,t,a)=>{var i,n;return((n=(i=Jt[e])==null?void 0:i[t])==null?void 0:n[a])!==void 0},nt=(e,t,a)=>{var n,o;const i=(o=(n=Jt[e])==null?void 0:n[t])==null?void 0:o[a];if(!i)throw new Error(`Template not found: ${e}/${t}/${a}`);return r=>new Na(i).render({...r})},tl=nt("python","huggingface_hub","importInferenceClient"),al=nt("python","requests","importRequests"),Pt={"audio-classification":"audio_classification","audio-to-audio":"audio_to_audio","automatic-speech-recognition":"automatic_speech_recognition","document-question-answering":"document_question_answering","feature-extraction":"feature_extraction","fill-mask":"fill_mask","image-classification":"image_classification","image-segmentation":"image_segmentation","image-to-image":"image_to_image","image-to-text":"image_to_text","object-detection":"object_detection","question-answering":"question_answering","sentence-similarity":"sentence_similarity",summarization:"summarization","table-question-answering":"table_question_answering","tabular-classification":"tabular_classification","tabular-regression":"tabular_regression","text-classification":"text_classification","text-generation":"text_generation","text-to-image":"text_to_image","text-to-speech":"text_to_speech","text-to-video":"text_to_video","token-classification":"token_classification",translation:"translation","visual-question-answering":"visual_question_answering","zero-shot-classification":"zero_shot_classification","zero-shot-image-classification":"zero_shot_image_classification"},Nt={"automatic-speech-recognition":"automaticSpeechRecognition","feature-extraction":"featureExtraction","fill-mask":"fillMask","image-classification":"imageClassification","question-answering":"questionAnswering","sentence-similarity":"sentenceSimilarity",summarization:"summarization","table-question-answering":"tableQuestionAnswering","text-classification":"textClassification","text-generation":"textGeneration","text2text-generation":"textGeneration","token-classification":"tokenClassification",translation:"translation"},M=(e,t)=>(a,i,n,o,r)=>{var S;const p=(o==null?void 0:o.providerId)??a.id;let u=a.pipeline_tag;a.pipeline_tag&&["text-generation","image-text-to-text"].includes(a.pipeline_tag)&&a.tags.includes("conversational")&&(e=r!=null&&r.streaming?"conversationalStream":"conversational",t=ol,u="conversational");let d;try{d=I(n,u)}catch(N){return console.error(`Failed to get provider helper for ${n} (${u})`,N),[]}const c=t?t(a,r):{inputs:Ae(a)},l=ze(p,d,{accessToken:i,provider:n,...c},o,{task:u,billTo:r==null?void 0:r.billTo});let f=c;const y=l.info.body;if(typeof y=="string")try{f=JSON.parse(y)}catch(N){console.error("Failed to parse body as JSON",N)}const k={accessToken:i,authorizationHeader:(S=l.info.headers)==null?void 0:S.Authorization,baseUrl:sl(l.url,"/chat/completions"),fullUrl:l.url,inputs:{asObj:c,asCurlString:K(c,"curl"),asJsonString:K(c,"json"),asPythonString:K(c,"python"),asTsString:K(c,"ts")},providerInputs:{asObj:f,asCurlString:K(f,"curl"),asJsonString:K(f,"json"),asPythonString:K(f,"python"),asTsString:K(f,"ts")},model:a,provider:n,providerModelId:p??a.id,billTo:r==null?void 0:r.billTo};return ar.map(N=>Gs[N].map(O=>{if(!el(N,O,e))return;const Z=nt(N,O,e);if(O==="huggingface_hub"&&e.includes("basic")){if(!(a.pipeline_tag&&a.pipeline_tag in Pt))return;k.methodName=Pt[a.pipeline_tag]}if(O==="huggingface.js"&&e.includes("basic")){if(!(a.pipeline_tag&&a.pipeline_tag in Nt))return;k.methodName=Nt[a.pipeline_tag]}let B=Z(k).trim();if(B)return O==="huggingface_hub"?B=`${tl({...k})}

${B}`:O==="requests"&&(B=`${al({...k,importBase64:B.includes("base64"),importJson:B.includes("json.")})}

${B}`),{language:N,client:O,content:B}}).filter(O=>O!==void 0)).flat()},il=e=>JSON.parse(Ae(e)),nl=e=>{const t=JSON.parse(Ae(e));return{inputs:t.image,parameters:{prompt:t.prompt}}},ol=(e,t)=>({messages:(t==null?void 0:t.messages)??Ae(e),...t!=null&&t.temperature?{temperature:t==null?void 0:t.temperature}:void 0,max_tokens:(t==null?void 0:t.max_tokens)??512,...t!=null&&t.top_p?{top_p:t==null?void 0:t.top_p}:void 0}),Ee={"audio-classification":M("basicAudio"),"audio-to-audio":M("basicAudio"),"automatic-speech-recognition":M("basicAudio"),"document-question-answering":M("documentQuestionAnswering",il),"feature-extraction":M("basic"),"fill-mask":M("basic"),"image-classification":M("basicImage"),"image-segmentation":M("basicImage"),"image-text-to-text":M("conversational"),"image-to-image":M("imageToImage",nl),"image-to-text":M("basicImage"),"object-detection":M("basicImage"),"question-answering":M("basic"),"sentence-similarity":M("basic"),summarization:M("basic"),"tabular-classification":M("tabular"),"tabular-regression":M("tabular"),"table-question-answering":M("basic"),"text-classification":M("basic"),"text-generation":M("basic"),"text-to-audio":M("textToAudio"),"text-to-image":M("textToImage"),"text-to-speech":M("textToAudio"),"text-to-video":M("textToVideo"),"text2text-generation":M("basic"),"token-classification":M("basic"),translation:M("basic"),"zero-shot-classification":M("zeroShotClassification"),"zero-shot-image-classification":M("zeroShotImageClassification")};function rl(e,t,a,i,n){var o;return e.pipeline_tag&&e.pipeline_tag in Ee?((o=Ee[e.pipeline_tag])==null?void 0:o.call(Ee,e,t,a,i,n))??[]:[]}function K(e,t){switch(t){case"curl":return jt(K(e,"json"));case"json":return JSON.stringify(e,null,4).split(`
`).slice(1,-1).join(`
`);case"python":return jt(Object.entries(e).map(([a,i])=>{const n=JSON.stringify(i,null,4).replace(/"/g,'"');return`${a}=${n},`}).join(`
`));case"ts":return We(e).split(`
`).slice(1,-1).join(`
`);default:throw new Error(`Unsupported format: ${t}`)}}function We(e,t){return t=t??0,typeof e!="object"||e===null?JSON.stringify(e):Array.isArray(e)?`[
${e.map(o=>{const r=We(o,t+1);return`${" ".repeat(4*(t+1))}${r},`}).join(`
`)}
${" ".repeat(4*t)}]`:`{
${Object.entries(e).map(([n,o])=>{const r=We(o,t+1),p=/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(n)?n:`"${n}"`;return`${" ".repeat(4*(t+1))}${p}: ${r},`}).join(`
`)}
${" ".repeat(4*t)}}`}function jt(e){return e.split(`
`).map(t=>" ".repeat(4)+t).join(`
`)}function sl(e,t){return e.endsWith(t)?e.slice(0,-t.length):e}export{ul as E,pl as H};
