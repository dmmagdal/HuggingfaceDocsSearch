var s;const t=((s=globalThis.__sveltekit_1js1a73)==null?void 0:s.base)??"/docs/transformers/main/it";var a;const e=((a=globalThis.__sveltekit_1js1a73)==null?void 0:a.assets)??t;export{e as a,t as b};
