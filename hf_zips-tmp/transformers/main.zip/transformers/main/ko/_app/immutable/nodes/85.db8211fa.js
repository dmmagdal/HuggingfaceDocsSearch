import{s as Zr,o as Lr,n as F}from"../chunks/scheduler.bdbef820.js";import{S as Br,i as Gr,g as d,s as o,r as h,A as Hr,h as c,f as s,c as a,j,u as f,x as m,k as x,l as Nr,y as i,a as r,v as g,d as _,t as M,w as y}from"../chunks/index.33f81d56.js";import{T as ae}from"../chunks/Tip.34194030.js";import{D as W}from"../chunks/Docstring.abcbe1ac.js";import{C as le}from"../chunks/CodeBlock.3bad7fc9.js";import{E as sn}from"../chunks/ExampleCodeBlock.16b3b633.js";import{P as Rr}from"../chunks/PipelineTag.d2f354cd.js";import{H as J,E as Xr}from"../chunks/getInferenceSnippets.64cd9466.js";function Vr(v){let n,b;return n=new le({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyME1pc3RyYWxNb2RlbCUyQyUyME1pc3RyYWxDb25maWclMEElMEElMjMlMjBJbml0aWFsaXppbmclMjBhJTIwTWlzdHJhbCUyMDdCJTIwc3R5bGUlMjBjb25maWd1cmF0aW9uJTBBY29uZmlndXJhdGlvbiUyMCUzRCUyME1pc3RyYWxDb25maWcoKSUwQSUwQSUyMyUyMEluaXRpYWxpemluZyUyMGElMjBtb2RlbCUyMGZyb20lMjB0aGUlMjBNaXN0cmFsJTIwN0IlMjBzdHlsZSUyMGNvbmZpZ3VyYXRpb24lMEFtb2RlbCUyMCUzRCUyME1pc3RyYWxNb2RlbChjb25maWd1cmF0aW9uKSUwQSUwQSUyMyUyMEFjY2Vzc2luZyUyMHRoZSUyMG1vZGVsJTIwY29uZmlndXJhdGlvbiUwQWNvbmZpZ3VyYXRpb24lMjAlM0QlMjBtb2RlbC5jb25maWc=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> MistralModel, MistralConfig

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a Mistral 7B style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = MistralConfig()

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a model from the Mistral 7B style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MistralModel(configuration)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Accessing the model configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = model.config`,wrap:!1}}),{c(){h(n.$$.fragment)},l(l){f(n.$$.fragment,l)},m(l,u){g(n,l,u),b=!0},p:F,i(l){b||(_(n.$$.fragment,l),b=!0)},o(l){M(n.$$.fragment,l),b=!1},d(l){y(n,l)}}}function Sr(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function Pr(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function Er(v){let n,b="Example:",l,u,w;return u=new le({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBNaXN0cmFsRm9yQ2F1c2FsTE0lMEElMEFtb2RlbCUyMCUzRCUyME1pc3RyYWxGb3JDYXVzYWxMTS5mcm9tX3ByZXRyYWluZWQoJTIybWV0YS1taXN0cmFsJTJGTWlzdHJhbC0yLTdiLWhmJTIyKSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMm1ldGEtbWlzdHJhbCUyRk1pc3RyYWwtMi03Yi1oZiUyMiklMEElMEFwcm9tcHQlMjAlM0QlMjAlMjJIZXklMkMlMjBhcmUlMjB5b3UlMjBjb25zY2lvdXMlM0YlMjBDYW4lMjB5b3UlMjB0YWxrJTIwdG8lMjBtZSUzRiUyMiUwQWlucHV0cyUyMCUzRCUyMHRva2VuaXplcihwcm9tcHQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyKSUwQSUwQSUyMyUyMEdlbmVyYXRlJTBBZ2VuZXJhdGVfaWRzJTIwJTNEJTIwbW9kZWwuZ2VuZXJhdGUoaW5wdXRzLmlucHV0X2lkcyUyQyUyMG1heF9sZW5ndGglM0QzMCklMEF0b2tlbml6ZXIuYmF0Y2hfZGVjb2RlKGdlbmVyYXRlX2lkcyUyQyUyMHNraXBfc3BlY2lhbF90b2tlbnMlM0RUcnVlJTJDJTIwY2xlYW5fdXBfdG9rZW5pemF0aW9uX3NwYWNlcyUzREZhbHNlKSU1QjAlNUQ=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, MistralForCausalLM

<span class="hljs-meta">&gt;&gt;&gt; </span>model = MistralForCausalLM.from_pretrained(<span class="hljs-string">&quot;meta-mistral/Mistral-2-7b-hf&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;meta-mistral/Mistral-2-7b-hf&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>prompt = <span class="hljs-string">&quot;Hey, are you conscious? Can you talk to me?&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(prompt, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Generate</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>generate_ids = model.generate(inputs.input_ids, max_length=<span class="hljs-number">30</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.batch_decode(generate_ids, skip_special_tokens=<span class="hljs-literal">True</span>, clean_up_tokenization_spaces=<span class="hljs-literal">False</span>)[<span class="hljs-number">0</span>]
<span class="hljs-string">&quot;Hey, are you conscious? Can you talk to me?\\nI&#x27;m not conscious, but I can talk to you.&quot;</span>`,wrap:!1}}),{c(){n=d("p"),n.textContent=b,l=o(),h(u.$$.fragment)},l(p){n=c(p,"P",{"data-svelte-h":!0}),m(n)!=="svelte-11lpom8"&&(n.textContent=b),l=a(p),f(u.$$.fragment,p)},m(p,k){r(p,n,k),r(p,l,k),g(u,p,k),w=!0},p:F,i(p){w||(_(u.$$.fragment,p),w=!0)},o(p){M(u.$$.fragment,p),w=!1},d(p){p&&(s(n),s(l)),y(u,p)}}}function Qr(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function Yr(v){let n,b="Example of single-label classification:",l,u,w;return u=new le({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b1Rva2VuaXplciUyQyUyME1pc3RyYWxGb3JTZXF1ZW5jZUNsYXNzaWZpY2F0aW9uJTBBJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIybWlzdHJhbGFpJTJGTWlzdHJhbC03Qi12MC4xJTIyKSUwQW1vZGVsJTIwJTNEJTIwTWlzdHJhbEZvclNlcXVlbmNlQ2xhc3NpZmljYXRpb24uZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItdjAuMSUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTIySGVsbG8lMkMlMjBteSUyMGRvZyUyMGlzJTIwY3V0ZSUyMiUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpJTBBJTBBd2l0aCUyMHRvcmNoLm5vX2dyYWQoKSUzQSUwQSUyMCUyMCUyMCUyMGxvZ2l0cyUyMCUzRCUyMG1vZGVsKCoqaW5wdXRzKS5sb2dpdHMlMEElMEFwcmVkaWN0ZWRfY2xhc3NfaWQlMjAlM0QlMjBsb2dpdHMuYXJnbWF4KCkuaXRlbSgpJTBBbW9kZWwuY29uZmlnLmlkMmxhYmVsJTVCcHJlZGljdGVkX2NsYXNzX2lkJTVEJTBBJTBBJTIzJTIwVG8lMjB0cmFpbiUyMGElMjBtb2RlbCUyMG9uJTIwJTYwbnVtX2xhYmVscyU2MCUyMGNsYXNzZXMlMkMlMjB5b3UlMjBjYW4lMjBwYXNzJTIwJTYwbnVtX2xhYmVscyUzRG51bV9sYWJlbHMlNjAlMjB0byUyMCU2MC5mcm9tX3ByZXRyYWluZWQoLi4uKSU2MCUwQW51bV9sYWJlbHMlMjAlM0QlMjBsZW4obW9kZWwuY29uZmlnLmlkMmxhYmVsKSUwQW1vZGVsJTIwJTNEJTIwTWlzdHJhbEZvclNlcXVlbmNlQ2xhc3NpZmljYXRpb24uZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItdjAuMSUyMiUyQyUyMG51bV9sYWJlbHMlM0RudW1fbGFiZWxzKSUwQSUwQWxhYmVscyUyMCUzRCUyMHRvcmNoLnRlbnNvciglNUIxJTVEKSUwQWxvc3MlMjAlM0QlMjBtb2RlbCgqKmlucHV0cyUyQyUyMGxhYmVscyUzRGxhYmVscykubG9zcyUwQXJvdW5kKGxvc3MuaXRlbSgpJTJDJTIwMik=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, MistralForSequenceClassification

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MistralForSequenceClassification.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">with</span> torch.no_grad():
<span class="hljs-meta">... </span>    logits = model(**inputs).logits

<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_class_id = logits.argmax().item()
<span class="hljs-meta">&gt;&gt;&gt; </span>model.config.id2label[predicted_class_id]
...

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># To train a model on \`num_labels\` classes, you can pass \`num_labels=num_labels\` to \`.from_pretrained(...)\`</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>num_labels = <span class="hljs-built_in">len</span>(model.config.id2label)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MistralForSequenceClassification.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>, num_labels=num_labels)

<span class="hljs-meta">&gt;&gt;&gt; </span>labels = torch.tensor([<span class="hljs-number">1</span>])
<span class="hljs-meta">&gt;&gt;&gt; </span>loss = model(**inputs, labels=labels).loss
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">round</span>(loss.item(), <span class="hljs-number">2</span>)
...`,wrap:!1}}),{c(){n=d("p"),n.textContent=b,l=o(),h(u.$$.fragment)},l(p){n=c(p,"P",{"data-svelte-h":!0}),m(n)!=="svelte-ykxpe4"&&(n.textContent=b),l=a(p),f(u.$$.fragment,p)},m(p,k){r(p,n,k),r(p,l,k),g(u,p,k),w=!0},p:F,i(p){w||(_(u.$$.fragment,p),w=!0)},o(p){M(u.$$.fragment,p),w=!1},d(p){p&&(s(n),s(l)),y(u,p)}}}function Ar(v){let n,b="Example of multi-label classification:",l,u,w;return u=new le({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b1Rva2VuaXplciUyQyUyME1pc3RyYWxGb3JTZXF1ZW5jZUNsYXNzaWZpY2F0aW9uJTBBJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIybWlzdHJhbGFpJTJGTWlzdHJhbC03Qi12MC4xJTIyKSUwQW1vZGVsJTIwJTNEJTIwTWlzdHJhbEZvclNlcXVlbmNlQ2xhc3NpZmljYXRpb24uZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItdjAuMSUyMiUyQyUyMHByb2JsZW1fdHlwZSUzRCUyMm11bHRpX2xhYmVsX2NsYXNzaWZpY2F0aW9uJTIyKSUwQSUwQWlucHV0cyUyMCUzRCUyMHRva2VuaXplciglMjJIZWxsbyUyQyUyMG15JTIwZG9nJTIwaXMlMjBjdXRlJTIyJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMiklMEElMEF3aXRoJTIwdG9yY2gubm9fZ3JhZCgpJTNBJTBBJTIwJTIwJTIwJTIwbG9naXRzJTIwJTNEJTIwbW9kZWwoKippbnB1dHMpLmxvZ2l0cyUwQSUwQXByZWRpY3RlZF9jbGFzc19pZHMlMjAlM0QlMjB0b3JjaC5hcmFuZ2UoMCUyQyUyMGxvZ2l0cy5zaGFwZSU1Qi0xJTVEKSU1QnRvcmNoLnNpZ21vaWQobG9naXRzKS5zcXVlZXplKGRpbSUzRDApJTIwJTNFJTIwMC41JTVEJTBBJTBBJTIzJTIwVG8lMjB0cmFpbiUyMGElMjBtb2RlbCUyMG9uJTIwJTYwbnVtX2xhYmVscyU2MCUyMGNsYXNzZXMlMkMlMjB5b3UlMjBjYW4lMjBwYXNzJTIwJTYwbnVtX2xhYmVscyUzRG51bV9sYWJlbHMlNjAlMjB0byUyMCU2MC5mcm9tX3ByZXRyYWluZWQoLi4uKSU2MCUwQW51bV9sYWJlbHMlMjAlM0QlMjBsZW4obW9kZWwuY29uZmlnLmlkMmxhYmVsKSUwQW1vZGVsJTIwJTNEJTIwTWlzdHJhbEZvclNlcXVlbmNlQ2xhc3NpZmljYXRpb24uZnJvbV9wcmV0cmFpbmVkKCUwQSUyMCUyMCUyMCUyMCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItdjAuMSUyMiUyQyUyMG51bV9sYWJlbHMlM0RudW1fbGFiZWxzJTJDJTIwcHJvYmxlbV90eXBlJTNEJTIybXVsdGlfbGFiZWxfY2xhc3NpZmljYXRpb24lMjIlMEEpJTBBJTBBbGFiZWxzJTIwJTNEJTIwdG9yY2guc3VtKCUwQSUyMCUyMCUyMCUyMHRvcmNoLm5uLmZ1bmN0aW9uYWwub25lX2hvdChwcmVkaWN0ZWRfY2xhc3NfaWRzJTVCTm9uZSUyQyUyMCUzQSU1RC5jbG9uZSgpJTJDJTIwbnVtX2NsYXNzZXMlM0RudW1fbGFiZWxzKSUyQyUyMGRpbSUzRDElMEEpLnRvKHRvcmNoLmZsb2F0KSUwQWxvc3MlMjAlM0QlMjBtb2RlbCgqKmlucHV0cyUyQyUyMGxhYmVscyUzRGxhYmVscykubG9zcw==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, MistralForSequenceClassification

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MistralForSequenceClassification.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>, problem_type=<span class="hljs-string">&quot;multi_label_classification&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">with</span> torch.no_grad():
<span class="hljs-meta">... </span>    logits = model(**inputs).logits

<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_class_ids = torch.arange(<span class="hljs-number">0</span>, logits.shape[-<span class="hljs-number">1</span>])[torch.sigmoid(logits).squeeze(dim=<span class="hljs-number">0</span>) &gt; <span class="hljs-number">0.5</span>]

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># To train a model on \`num_labels\` classes, you can pass \`num_labels=num_labels\` to \`.from_pretrained(...)\`</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>num_labels = <span class="hljs-built_in">len</span>(model.config.id2label)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MistralForSequenceClassification.from_pretrained(
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>, num_labels=num_labels, problem_type=<span class="hljs-string">&quot;multi_label_classification&quot;</span>
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>labels = torch.<span class="hljs-built_in">sum</span>(
<span class="hljs-meta">... </span>    torch.nn.functional.one_hot(predicted_class_ids[<span class="hljs-literal">None</span>, :].clone(), num_classes=num_labels), dim=<span class="hljs-number">1</span>
<span class="hljs-meta">... </span>).to(torch.<span class="hljs-built_in">float</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>loss = model(**inputs, labels=labels).loss`,wrap:!1}}),{c(){n=d("p"),n.textContent=b,l=o(),h(u.$$.fragment)},l(p){n=c(p,"P",{"data-svelte-h":!0}),m(n)!=="svelte-1l8e32d"&&(n.textContent=b),l=a(p),f(u.$$.fragment,p)},m(p,k){r(p,n,k),r(p,l,k),g(u,p,k),w=!0},p:F,i(p){w||(_(u.$$.fragment,p),w=!0)},o(p){M(u.$$.fragment,p),w=!1},d(p){p&&(s(n),s(l)),y(u,p)}}}function Or(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function Dr(v){let n,b="Example:",l,u,w;return u=new le({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBNaXN0cmFsRm9yVG9rZW5DbGFzc2lmaWNhdGlvbiUwQWltcG9ydCUyMHRvcmNoJTBBJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIybWlzdHJhbGFpJTJGTWlzdHJhbC03Qi12MC4xJTIyKSUwQW1vZGVsJTIwJTNEJTIwTWlzdHJhbEZvclRva2VuQ2xhc3NpZmljYXRpb24uZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItdjAuMSUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTBBJTIwJTIwJTIwJTIwJTIySHVnZ2luZ0ZhY2UlMjBpcyUyMGElMjBjb21wYW55JTIwYmFzZWQlMjBpbiUyMFBhcmlzJTIwYW5kJTIwTmV3JTIwWW9yayUyMiUyQyUyMGFkZF9zcGVjaWFsX3Rva2VucyUzREZhbHNlJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMiUwQSklMEElMEF3aXRoJTIwdG9yY2gubm9fZ3JhZCgpJTNBJTBBJTIwJTIwJTIwJTIwbG9naXRzJTIwJTNEJTIwbW9kZWwoKippbnB1dHMpLmxvZ2l0cyUwQSUwQXByZWRpY3RlZF90b2tlbl9jbGFzc19pZHMlMjAlM0QlMjBsb2dpdHMuYXJnbWF4KC0xKSUwQSUwQSUyMyUyME5vdGUlMjB0aGF0JTIwdG9rZW5zJTIwYXJlJTIwY2xhc3NpZmllZCUyMHJhdGhlciUyMHRoZW4lMjBpbnB1dCUyMHdvcmRzJTIwd2hpY2glMjBtZWFucyUyMHRoYXQlMEElMjMlMjB0aGVyZSUyMG1pZ2h0JTIwYmUlMjBtb3JlJTIwcHJlZGljdGVkJTIwdG9rZW4lMjBjbGFzc2VzJTIwdGhhbiUyMHdvcmRzLiUwQSUyMyUyME11bHRpcGxlJTIwdG9rZW4lMjBjbGFzc2VzJTIwbWlnaHQlMjBhY2NvdW50JTIwZm9yJTIwdGhlJTIwc2FtZSUyMHdvcmQlMEFwcmVkaWN0ZWRfdG9rZW5zX2NsYXNzZXMlMjAlM0QlMjAlNUJtb2RlbC5jb25maWcuaWQybGFiZWwlNUJ0Lml0ZW0oKSU1RCUyMGZvciUyMHQlMjBpbiUyMHByZWRpY3RlZF90b2tlbl9jbGFzc19pZHMlNUIwJTVEJTVEJTBBcHJlZGljdGVkX3Rva2Vuc19jbGFzc2VzJTBBJTBBbGFiZWxzJTIwJTNEJTIwcHJlZGljdGVkX3Rva2VuX2NsYXNzX2lkcyUwQWxvc3MlMjAlM0QlMjBtb2RlbCgqKmlucHV0cyUyQyUyMGxhYmVscyUzRGxhYmVscykubG9zcyUwQXJvdW5kKGxvc3MuaXRlbSgpJTJDJTIwMik=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, MistralForTokenClassification
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MistralForTokenClassification.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;HuggingFace is a company based in Paris and New York&quot;</span>, add_special_tokens=<span class="hljs-literal">False</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">with</span> torch.no_grad():
<span class="hljs-meta">... </span>    logits = model(**inputs).logits

<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_token_class_ids = logits.argmax(-<span class="hljs-number">1</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Note that tokens are classified rather then input words which means that</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># there might be more predicted token classes than words.</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Multiple token classes might account for the same word</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_tokens_classes = [model.config.id2label[t.item()] <span class="hljs-keyword">for</span> t <span class="hljs-keyword">in</span> predicted_token_class_ids[<span class="hljs-number">0</span>]]
<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_tokens_classes
...

<span class="hljs-meta">&gt;&gt;&gt; </span>labels = predicted_token_class_ids
<span class="hljs-meta">&gt;&gt;&gt; </span>loss = model(**inputs, labels=labels).loss
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">round</span>(loss.item(), <span class="hljs-number">2</span>)
...`,wrap:!1}}),{c(){n=d("p"),n.textContent=b,l=o(),h(u.$$.fragment)},l(p){n=c(p,"P",{"data-svelte-h":!0}),m(n)!=="svelte-11lpom8"&&(n.textContent=b),l=a(p),f(u.$$.fragment,p)},m(p,k){r(p,n,k),r(p,l,k),g(u,p,k),w=!0},p:F,i(p){w||(_(u.$$.fragment,p),w=!0)},o(p){M(u.$$.fragment,p),w=!1},d(p){p&&(s(n),s(l)),y(u,p)}}}function Kr(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function ei(v){let n,b=`This example uses a random model as the real ones are all very big. To get proper results, you should use
mistralai/Mistral-7B-v0.1 instead of ksmcg/Mistral-tiny. If you get out-of-memory when loading that checkpoint, you can try
adding <code>device_map=&quot;auto&quot;</code> in the <code>from_pretrained</code> call.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-p3ymc5"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function ti(v){let n,b="Example:",l,u,w;return u=new le({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBGbGF4TWlzdHJhbE1vZGVsJTBBJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIya3NtY2clMkZNaXN0cmFsLXRpbnklMjIpJTBBbW9kZWwlMjAlM0QlMjBGbGF4TWlzdHJhbE1vZGVsLmZyb21fcHJldHJhaW5lZCglMjJrc21jZyUyRk1pc3RyYWwtdGlueSUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTIySGVsbG8lMkMlMjBteSUyMGRvZyUyMGlzJTIwY3V0ZSUyMiUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIyamF4JTIyKSUwQW91dHB1dHMlMjAlM0QlMjBtb2RlbCgqKmlucHV0cyklMEElMEFsYXN0X2hpZGRlbl9zdGF0ZXMlMjAlM0QlMjBvdXRwdXRzLmxhc3RfaGlkZGVuX3N0YXRl",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, FlaxMistralModel

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;ksmcg/Mistral-tiny&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxMistralModel.from_pretrained(<span class="hljs-string">&quot;ksmcg/Mistral-tiny&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;jax&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_states = outputs.last_hidden_state`,wrap:!1}}),{c(){n=d("p"),n.textContent=b,l=o(),h(u.$$.fragment)},l(p){n=c(p,"P",{"data-svelte-h":!0}),m(n)!=="svelte-11lpom8"&&(n.textContent=b),l=a(p),f(u.$$.fragment,p)},m(p,k){r(p,n,k),r(p,l,k),g(u,p,k),w=!0},p:F,i(p){w||(_(u.$$.fragment,p),w=!0)},o(p){M(u.$$.fragment,p),w=!1},d(p){p&&(s(n),s(l)),y(u,p)}}}function ni(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function si(v){let n,b=`This example uses a random model as the real ones are all very big. To get proper results, you should use
mistralai/Mistral-7B-v0.1 instead of ksmcg/Mistral-tiny. If you get out-of-memory when loading that checkpoint, you can try
adding <code>device_map=&quot;auto&quot;</code> in the <code>from_pretrained</code> call.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-p3ymc5"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function oi(v){let n,b="Example:",l,u,w;return u=new le({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBGbGF4TWlzdHJhbEZvckNhdXNhbExNJTBBJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIya3NtY2clMkZNaXN0cmFsLXRpbnklMjIpJTBBbW9kZWwlMjAlM0QlMjBGbGF4TWlzdHJhbEZvckNhdXNhbExNLmZyb21fcHJldHJhaW5lZCglMjJrc21jZyUyRk1pc3RyYWwtdGlueSUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTIySGVsbG8lMkMlMjBteSUyMGRvZyUyMGlzJTIwY3V0ZSUyMiUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIybnAlMjIpJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKCoqaW5wdXRzKSUwQSUwQSUyMyUyMHJldHJpZXZlJTIwbG9ndHMlMjBmb3IlMjBuZXh0JTIwdG9rZW4lMEFuZXh0X3Rva2VuX2xvZ2l0cyUyMCUzRCUyMG91dHB1dHMubG9naXRzJTVCJTNBJTJDJTIwLTElNUQ=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, FlaxMistralForCausalLM

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;ksmcg/Mistral-tiny&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxMistralForCausalLM.from_pretrained(<span class="hljs-string">&quot;ksmcg/Mistral-tiny&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;np&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># retrieve logts for next token</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>next_token_logits = outputs.logits[:, -<span class="hljs-number">1</span>]`,wrap:!1}}),{c(){n=d("p"),n.textContent=b,l=o(),h(u.$$.fragment)},l(p){n=c(p,"P",{"data-svelte-h":!0}),m(n)!=="svelte-11lpom8"&&(n.textContent=b),l=a(p),f(u.$$.fragment,p)},m(p,k){r(p,n,k),r(p,l,k),g(u,p,k),w=!0},p:F,i(p){w||(_(u.$$.fragment,p),w=!0)},o(p){M(u.$$.fragment,p),w=!1},d(p){p&&(s(n),s(l)),y(u,p)}}}function ai(v){let n,b="TensorFlow models and layers in <code>model</code> accept two formats as input:",l,u,w="<li>having all inputs as keyword arguments (like PyTorch models), or</li> <li>having all inputs as a list, tuple or dict in the first positional argument.</li>",p,k,pe=`The reason the second format is supported is that Keras methods prefer this format when passing inputs to models
and layers. Because of this support, when using methods like <code>model.fit()</code> things should “just work” for you - just
pass your inputs and labels in any format that <code>model.fit()</code> supports! If, however, you want to use the second
format outside of Keras methods like <code>fit()</code> and <code>predict()</code>, such as when creating your own layers or models with
the Keras <code>Functional</code> API, there are three possibilities you can use to gather all the input Tensors in the first
positional argument:`,B,Z,me=`<li>a single Tensor with <code>input_ids</code> only and nothing else: <code>model(input_ids)</code></li> <li>a list of varying length with one or several input Tensors IN THE ORDER given in the docstring:
<code>model([input_ids, attention_mask])</code> or <code>model([input_ids, attention_mask, token_type_ids])</code></li> <li>a dictionary with one or several input Tensors associated to the input names given in the docstring:
<code>model({&quot;input_ids&quot;: input_ids, &quot;token_type_ids&quot;: token_type_ids})</code></li>`,G,L,ue=`Note that when creating models and layers with
<a href="https://keras.io/guides/making_new_layers_and_models_via_subclassing/" rel="nofollow">subclassing</a> then you don’t need to worry
about any of this, as you can just pass inputs like you would to any other Python function!`;return{c(){n=d("p"),n.innerHTML=b,l=o(),u=d("ul"),u.innerHTML=w,p=o(),k=d("p"),k.innerHTML=pe,B=o(),Z=d("ul"),Z.innerHTML=me,G=o(),L=d("p"),L.innerHTML=ue},l(T){n=c(T,"P",{"data-svelte-h":!0}),m(n)!=="svelte-q09ipl"&&(n.innerHTML=b),l=a(T),u=c(T,"UL",{"data-svelte-h":!0}),m(u)!=="svelte-qm1t26"&&(u.innerHTML=w),p=a(T),k=c(T,"P",{"data-svelte-h":!0}),m(k)!=="svelte-1v9qsc5"&&(k.innerHTML=pe),B=a(T),Z=c(T,"UL",{"data-svelte-h":!0}),m(Z)!=="svelte-15scerc"&&(Z.innerHTML=me),G=a(T),L=c(T,"P",{"data-svelte-h":!0}),m(L)!=="svelte-1an3odd"&&(L.innerHTML=ue)},m(T,$){r(T,n,$),r(T,l,$),r(T,u,$),r(T,p,$),r(T,k,$),r(T,B,$),r(T,Z,$),r(T,G,$),r(T,L,$)},p:F,d(T){T&&(s(n),s(l),s(u),s(p),s(k),s(B),s(Z),s(G),s(L))}}}function ri(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function ii(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function li(v){let n,b="TensorFlow models and layers in <code>model</code> accept two formats as input:",l,u,w="<li>having all inputs as keyword arguments (like PyTorch models), or</li> <li>having all inputs as a list, tuple or dict in the first positional argument.</li>",p,k,pe=`The reason the second format is supported is that Keras methods prefer this format when passing inputs to models
and layers. Because of this support, when using methods like <code>model.fit()</code> things should “just work” for you - just
pass your inputs and labels in any format that <code>model.fit()</code> supports! If, however, you want to use the second
format outside of Keras methods like <code>fit()</code> and <code>predict()</code>, such as when creating your own layers or models with
the Keras <code>Functional</code> API, there are three possibilities you can use to gather all the input Tensors in the first
positional argument:`,B,Z,me=`<li>a single Tensor with <code>input_ids</code> only and nothing else: <code>model(input_ids)</code></li> <li>a list of varying length with one or several input Tensors IN THE ORDER given in the docstring:
<code>model([input_ids, attention_mask])</code> or <code>model([input_ids, attention_mask, token_type_ids])</code></li> <li>a dictionary with one or several input Tensors associated to the input names given in the docstring:
<code>model({&quot;input_ids&quot;: input_ids, &quot;token_type_ids&quot;: token_type_ids})</code></li>`,G,L,ue=`Note that when creating models and layers with
<a href="https://keras.io/guides/making_new_layers_and_models_via_subclassing/" rel="nofollow">subclassing</a> then you don’t need to worry
about any of this, as you can just pass inputs like you would to any other Python function!`;return{c(){n=d("p"),n.innerHTML=b,l=o(),u=d("ul"),u.innerHTML=w,p=o(),k=d("p"),k.innerHTML=pe,B=o(),Z=d("ul"),Z.innerHTML=me,G=o(),L=d("p"),L.innerHTML=ue},l(T){n=c(T,"P",{"data-svelte-h":!0}),m(n)!=="svelte-q09ipl"&&(n.innerHTML=b),l=a(T),u=c(T,"UL",{"data-svelte-h":!0}),m(u)!=="svelte-qm1t26"&&(u.innerHTML=w),p=a(T),k=c(T,"P",{"data-svelte-h":!0}),m(k)!=="svelte-1v9qsc5"&&(k.innerHTML=pe),B=a(T),Z=c(T,"UL",{"data-svelte-h":!0}),m(Z)!=="svelte-15scerc"&&(Z.innerHTML=me),G=a(T),L=c(T,"P",{"data-svelte-h":!0}),m(L)!=="svelte-1an3odd"&&(L.innerHTML=ue)},m(T,$){r(T,n,$),r(T,l,$),r(T,u,$),r(T,p,$),r(T,k,$),r(T,B,$),r(T,Z,$),r(T,G,$),r(T,L,$)},p:F,d(T){T&&(s(n),s(l),s(u),s(p),s(k),s(B),s(Z),s(G),s(L))}}}function di(v){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=d("p"),n.innerHTML=b},l(l){n=c(l,"P",{"data-svelte-h":!0}),m(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(l,u){r(l,n,u)},p:F,d(l){l&&s(n)}}}function ci(v){let n,b,l,u,w,p,k,pe,B,Z='미스트랄은 Albert Jiang, Alexandre Sablayrolles, Arthur Mensch, Chris Bamford, Devendra Singh Chaplot, Diego de las Casas, Florian Bressand, Gianna Lengyel, Guillaume Lample, Lélio Renard Lavaud, Lucile Saulnier, Marie-Anne Lachaux, Pierre Stock, Teven Le Scao, Thibaut Lavril, Thomas Wang, Timothée Lacroix, William El Sayed가 작성한 <a href="https://mistral.ai/news/announcing-mistral-7b/" rel="nofollow">이 블로그 포스트</a>에서 소개되었습니다.',me,G,L="블로그 포스트의 서두는 다음과 같습니다:",ue,T,$="<em>미스트랄 AI팀은 현존하는 언어 모델 중 크기 대비 가장 강력한 미스트랄7B를 출시하게 되어 자랑스럽습니다.</em>",An,Ve,ka='미스트랄-7B는 <a href="https://mistral.ai/" rel="nofollow">mistral.ai</a>에서 출시한 첫 번째 대규모 언어 모델(LLM)입니다.',On,Se,Dn,Pe,wa="미스트랄-7B는 다음과 같은 구조적 특징을 가진 디코더 전용 트랜스포머입니다:",Kn,Ee,va="<li>슬라이딩 윈도우 어텐션: 8k 컨텍스트 길이와 고정 캐시 크기로 훈련되었으며, 이론상 128K 토큰의 어텐션 범위를 가집니다.</li> <li>GQA(Grouped Query Attention): 더 빠른 추론이 가능하고 더 작은 크기의 캐시를 사용합니다.</li> <li>바이트 폴백(Byte-fallback) BPE 토크나이저: 문자들이 절대 어휘 목록 외의 토큰으로 매핑되지 않도록 보장합니다.</li>",es,Qe,$a='더 자세한 내용은 <a href="https://mistral.ai/news/announcing-mistral-7b/" rel="nofollow">출시 블로그 포스트</a>를 참조하세요.',ts,Ye,ns,Ae,Ca="<code>미스트랄-7B</code>는 아파치 2.0 라이선스로 출시되었습니다.",ss,Oe,os,De,ja="미스트랄 AI팀은 다음 3가지 체크포인트를 공개했습니다:",as,Ke,xa='<li>기본 모델인 <a href="https://huggingface.co/mistralai/Mistral-7B-v0.1" rel="nofollow">미스트랄-7B-v0.1</a>은 인터넷 규모의 데이터에서 다음 토큰을 예측하도록 사전 훈련되었습니다.</li> <li>지시 조정 모델인 <a href="https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.1" rel="nofollow">미스트랄-7B-Instruct-v0.1</a>은 지도 미세 조정(SFT)과 직접 선호도 최적화(DPO)를 사용한 채팅에 최적화된 기본 모델입니다.</li> <li>개선된 지시 조정 모델인 <a href="https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.2" rel="nofollow">미스트랄-7B-Instruct-v0.2</a>는 v1을 개선한 버전입니다.</li>',rs,et,Ja="기본 모델은 다음과 같이 사용할 수 있습니다:",is,tt,ls,nt,Fa="지시 조정 모델은 다음과 같이 사용할 수 있습니다:",ds,st,cs,ot,za='지시 조정 모델은 입력이 올바른 형식으로 준비되도록 <a href="../chat_templating">채팅 템플릿</a>을 적용해야 합니다.',ps,at,ms,rt,Ua='위의 코드 스니펫들은 어떤 최적화 기법도 사용하지 않은 추론 과정을 보여줍니다. 하지만 모델 내부에서 사용되는 어텐션 메커니즘의 더 빠른 구현인 <a href="../perf_train_gpu_one.md#flash-attention-2">플래시 어텐션2</a>을 활용하면 모델의 속도를 크게 높일 수 있습니다.',us,it,Ia="먼저, 슬라이딩 윈도우 어텐션 기능을 포함하는 플래시 어텐션2의 최신 버전을 설치해야 합니다.",hs,lt,fs,dt,qa='하드웨어와 플래시 어텐션2의 호환여부를 확인하세요. 이에 대한 자세한 내용은 <a href="https://github.com/Dao-AILab/flash-attention" rel="nofollow">플래시 어텐션 저장소</a>의 공식 문서에서 확인할 수 있습니다. 또한 모델을 반정밀도(예: <code>torch.float16</code>)로 불러와야합니다.',gs,ct,Wa="플래시 어텐션2를 사용하여 모델을 불러오고 실행하려면 아래 코드 스니펫을 참조하세요:",_s,pt,Ms,mt,ys,ut,Za="다음은 <code>mistralai/Mistral-7B-v0.1</code> 체크포인트를 사용한 트랜스포머의 기본 구현과 플래시 어텐션2 버전 모델 사이의 순수 추론 시간을 비교한 예상 속도 향상 다이어그램입니다.",bs,we,La='<img src="https://huggingface.co/datasets/ybelkada/documentation-images/resolve/main/mistral-7b-inference-large-seqlen.png"/>',Ts,ht,ks,ft,Ba="현재 구현은 슬라이딩 윈도우 어텐션 메커니즘과 메모리 효율적인 캐시 관리 기능을 지원합니다. 슬라이딩 윈도우 어텐션을 활성화하려면, 슬라이딩 윈도우 어텐션과 호환되는<code>flash-attn</code>(<code>&gt;=2.3.0</code>)버전을 사용하면 됩니다.",ws,gt,Ga="또한 플래시 어텐션2 모델은 더 메모리 효율적인 캐시 슬라이싱 메커니즘을 사용합니다. 미스트랄 모델의 공식 구현에서 권장하는 롤링 캐시 메커니즘을 따라, 캐시 크기를 고정(<code>self.config.sliding_window</code>)으로 유지하고, <code>padding_side=&quot;left&quot;</code>인 경우에만 배치 생성(batch generation)을 지원하며, 현재 토큰의 절대 위치를 사용해 위치 임베딩을 계산합니다.",vs,_t,$s,Mt,Ha='미스트랄 모델은 70억 개의 파라미터를 가지고 있어, 절반의 정밀도(float16)로 약 14GB의 GPU RAM이 필요합니다. 각 파라미터가 2바이트로 저장되기 때문입니다. 하지만 <a href="../quantization.md">양자화</a>를 사용하면 모델 크기를 줄일 수 있습니다. 모델을 4비트(즉, 파라미터당 반 바이트)로 양자화하면 약 3.5GB의 RAM만 필요합니다.',Cs,yt,Na='모델을 양자화하는 것은 <code>quantization_config</code>를 모델에 전달하는 것만큼 간단합니다. 아래에서는 BitsAndBytes 양자화를 사용하지만, 다른 양자화 방법은 <a href="../quantization.md">이 페이지</a>를 참고하세요:',js,bt,xs,Tt,Ra=`이 모델은 <a href="https://huggingface.co/ybelkada" rel="nofollow">Younes Belkada</a>와 <a href="https://huggingface.co/ArthurZ" rel="nofollow">Arthur Zucker</a>가 기여했습니다.
원본 코드는 <a href="https://github.com/mistralai/mistral-src" rel="nofollow">이곳</a>에서 확인할 수 있습니다.`,Js,kt,Fs,wt,Xa="미스트랄을 시작하는 데 도움이 되는 Hugging Face와 community 자료 목록(🌎로 표시됨) 입니다. 여기에 포함될 자료를 제출하고 싶으시다면 PR(Pull Request)를 열어주세요. 리뷰해 드리겠습니다! 자료는 기존 자료를 복제하는 대신 새로운 내용을 담고 있어야 합니다.",zs,vt,Us,$t,Va='<li>미스트랄-7B의 지도형 미세조정(SFT)을 수행하는 데모 노트북은 <a href="https://github.com/NielsRogge/Transformers-Tutorials/blob/master/Mistral/Supervised_fine_tuning_(SFT)_of_an_LLM_using_Hugging_Face_tooling.ipynb" rel="nofollow">이곳</a>에서 확인할 수 있습니다. 🌎</li> <li>2024년에 Hugging Face 도구를 사용해 LLM을 미세 조정하는 방법에 대한 <a href="https://www.philschmid.de/fine-tune-llms-in-2024-with-trl" rel="nofollow">블로그 포스트</a>. 🌎</li> <li>Hugging Face의 <a href="https://github.com/huggingface/alignment-handbook" rel="nofollow">정렬(Alignment) 핸드북</a>에는 미스트랄-7B를 사용한 지도형 미세 조정(SFT) 및 직접 선호 최적화(DPO)를 수행하기 위한 스크립트와 레시피가 포함되어 있습니다. 여기에는 단일 GPU에서 QLoRa 및 다중 GPU를 사용한 전체 미세 조정을 위한 스크립트가 포함되어 있습니다.</li> <li><a href="../tasks/language_modeling">인과적 언어 모델링 작업 가이드</a></li>',Is,Ct,qs,V,jt,no,on,Sa=`This is the configuration class to store the configuration of a <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralModel">MistralModel</a>. It is used to instantiate an
Mistral model according to the specified arguments, defining the model architecture. Instantiating a configuration
with the defaults will yield a similar configuration to that of the Mistral-7B-v0.1 or Mistral-7B-Instruct-v0.1.`,so,an,Pa='<a href="https://huggingface.co/mistralai/Mistral-7B-v0.1" rel="nofollow">mistralai/Mistral-7B-v0.1</a> <a href="https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.1" rel="nofollow">mistralai/Mistral-7B-Instruct-v0.1</a>',oo,rn,Ea=`Configuration objects inherit from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> and can be used to control the model outputs. Read the
documentation from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> for more information.`,ao,ve,Ws,xt,Zs,S,Jt,ro,ln,Qa="The bare Mistral Model outputting raw hidden-states without any specific head on top.",io,dn,Ya=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,lo,cn,Aa=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,co,he,Ft,po,pn,Oa='The <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralModel">MistralModel</a> forward method, overrides the <code>__call__</code> special method.',mo,$e,Ls,zt,Bs,P,Ut,uo,mn,Da="The Mistral Model for causal language modeling.",ho,un,Ka=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,fo,hn,er=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,go,re,It,_o,fn,tr='The <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralForCausalLM">MistralForCausalLM</a> forward method, overrides the <code>__call__</code> special method.',Mo,Ce,yo,je,Gs,qt,Hs,z,Wt,bo,gn,nr="The Mistral Model transformer with a sequence classification head on top (linear layer).",To,_n,sr=`<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralForSequenceClassification">MistralForSequenceClassification</a> uses the last token in order to do the classification, as other causal models
(e.g. GPT-2) do.`,ko,Mn,or=`Since it does classification on the last token, it requires to know the position of the last token. If a
<code>pad_token_id</code> is defined in the configuration, it finds the last token that is not a padding token in each row. If
no <code>pad_token_id</code> is defined, it simply takes the last value in each row of the batch. Since it cannot guess the
padding tokens when <code>inputs_embeds</code> are passed instead of <code>input_ids</code>, it does the same (take the last value in
each row of the batch).`,wo,yn,ar=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,vo,bn,rr=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,$o,Y,Zt,Co,Tn,ir='The <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralForSequenceClassification">MistralForSequenceClassification</a> forward method, overrides the <code>__call__</code> special method.',jo,xe,xo,Je,Jo,Fe,Ns,Lt,Rs,E,Bt,Fo,kn,lr=`The Mistral transformer with a token classification head on top (a linear layer on top of the hidden-states
output) e.g. for Named-Entity-Recognition (NER) tasks.`,zo,wn,dr=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Uo,vn,cr=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,Io,ie,Gt,qo,$n,pr='The <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralForTokenClassification">MistralForTokenClassification</a> forward method, overrides the <code>__call__</code> special method.',Wo,ze,Zo,Ue,Xs,Ht,Vs,U,Nt,Lo,Cn,mr="The bare Mistral Model transformer outputting raw hidden-states without any specific head on top.",Bo,jn,ur=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Go,xn,hr=`This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.`,Ho,Jn,fr="Finally, this model supports inherent JAX features such as:",No,Fn,gr='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',Ro,A,Rt,Xo,zn,_r="The <code>FlaxMistralPreTrainedModel</code> forward method, overrides the <code>__call__</code> special method.",Vo,Ie,So,qe,Po,We,Ss,Xt,Ps,I,Vt,Eo,Un,Mr="The Mistral Model transformer with a language modeling head (linear layer) on top.",Qo,In,yr=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Yo,qn,br=`This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.`,Ao,Wn,Tr="Finally, this model supports inherent JAX features such as:",Oo,Zn,kr='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',Do,O,St,Ko,Ln,wr="The <code>FlaxMistralPreTrainedModel</code> forward method, overrides the <code>__call__</code> special method.",ea,Ze,ta,Le,na,Be,Es,Pt,Qs,H,Et,sa,Bn,vr="The bare Mistral Model outputting raw hidden-states without any specific head on top.",oa,Gn,$r=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel">TFPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,aa,Hn,Cr=`This model is also a <a href="https://www.tensorflow.org/api_docs/python/tf/keras/Model" rel="nofollow">keras.Model</a> subclass. Use it
as a regular TF 2.0 Keras Model and refer to the TF 2.0 documentation for all matter related to general usage and
behavior.`,ra,Ge,ia,fe,Qt,la,Nn,jr='The <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.TFMistralModel">TFMistralModel</a> forward method, overrides the <code>__call__</code> special method.',da,He,Ys,Yt,As,Me,At,ca,ge,Ot,pa,Rn,xr='The <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.TFMistralForCausalLM">TFMistralForCausalLM</a> forward method, overrides the <code>__call__</code> special method.',ma,Ne,Os,Dt,Ds,C,Kt,ua,Xn,Jr="The Mistral Model transformer with a sequence classification head on top (linear layer).",ha,Vn,Fr=`<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralForSequenceClassification">MistralForSequenceClassification</a> uses the last token in order to do the classification, as other causal models
(e.g. GPT-2) do.`,fa,Sn,zr=`Since it does classification on the last token, it requires to know the position of the last token. If a
<code>pad_token_id</code> is defined in the configuration, it finds the last token that is not a padding token in each row. If
no <code>pad_token_id</code> is defined, it simply takes the last value in each row of the batch. Since it cannot guess the
padding tokens when <code>inputs_embeds</code> are passed instead of <code>input_ids</code>, it does the same (take the last value in
each row of the batch).`,ga,Pn,Ur=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel">TFPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,_a,En,Ir=`This model is also a <a href="https://www.tensorflow.org/api_docs/python/tf/keras/Model" rel="nofollow">keras.Model</a> subclass. Use it
as a regular TF 2.0 Keras Model and refer to the TF 2.0 documentation for all matter related to general usage and
behavior.`,Ma,Re,ya,_e,en,ba,Qn,qr='The <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.TFMistralForSequenceClassification">TFMistralForSequenceClassification</a> forward method, overrides the <code>__call__</code> special method.',Ta,Xe,Ks,tn,eo,Yn,to;return w=new J({props:{title:"Mistral",local:"mistral",headingTag:"h1"}}),k=new J({props:{title:"개요",local:"overview",headingTag:"h2"}}),Se=new J({props:{title:"아키텍처 세부사항",local:"architectural-details",headingTag:"h3"}}),Ye=new J({props:{title:"라이선스",local:"license",headingTag:"h3"}}),Oe=new J({props:{title:"사용 팁",local:"usage-tips",headingTag:"h2"}}),tt=new le({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Nb2RlbEZvckNhdXNhbExNJTJDJTIwQXV0b1Rva2VuaXplciUwQSUwQW1vZGVsJTIwJTNEJTIwQXV0b01vZGVsRm9yQ2F1c2FsTE0uZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItdjAuMSUyMiUyQyUyMGRldmljZV9tYXAlM0QlMjJhdXRvJTIyKSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItdjAuMSUyMiklMEElMEFwcm9tcHQlMjAlM0QlMjAlMjJNeSUyMGZhdm91cml0ZSUyMGNvbmRpbWVudCUyMGlzJTIyJTBBJTBBbW9kZWxfaW5wdXRzJTIwJTNEJTIwdG9rZW5pemVyKCU1QnByb21wdCU1RCUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpLnRvKCUyMmN1ZGElMjIpJTBBbW9kZWwudG8oZGV2aWNlKSUwQSUwQWdlbmVyYXRlZF9pZHMlMjAlM0QlMjBtb2RlbC5nZW5lcmF0ZSgqKm1vZGVsX2lucHV0cyUyQyUyMG1heF9uZXdfdG9rZW5zJTNEMTAwJTJDJTIwZG9fc2FtcGxlJTNEVHJ1ZSklMEF0b2tlbml6ZXIuYmF0Y2hfZGVjb2RlKGdlbmVyYXRlZF9pZHMpJTVCMCU1RA==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoModelForCausalLM, AutoTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>model = AutoModelForCausalLM.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>, device_map=<span class="hljs-string">&quot;auto&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>prompt = <span class="hljs-string">&quot;My favourite condiment is&quot;</span>

<span class="hljs-meta">&gt;&gt;&gt; </span>model_inputs = tokenizer([prompt], return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).to(<span class="hljs-string">&quot;cuda&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model.to(device)

<span class="hljs-meta">&gt;&gt;&gt; </span>generated_ids = model.generate(**model_inputs, max_new_tokens=<span class="hljs-number">100</span>, do_sample=<span class="hljs-literal">True</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.batch_decode(generated_ids)[<span class="hljs-number">0</span>]
<span class="hljs-string">&quot;My favourite condiment is to ...&quot;</span>`,wrap:!1}}),st=new le({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Nb2RlbEZvckNhdXNhbExNJTJDJTIwQXV0b1Rva2VuaXplciUwQSUwQW1vZGVsJTIwJTNEJTIwQXV0b01vZGVsRm9yQ2F1c2FsTE0uZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItSW5zdHJ1Y3QtdjAuMiUyMiUyQyUyMGRldmljZV9tYXAlM0QlMjJhdXRvJTIyKSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItSW5zdHJ1Y3QtdjAuMiUyMiklMEElMEFtZXNzYWdlcyUyMCUzRCUyMCU1QiUwQSUyMCUyMCUyMCUyMCU3QiUyMnJvbGUlMjIlM0ElMjAlMjJ1c2VyJTIyJTJDJTIwJTIyY29udGVudCUyMiUzQSUyMCUyMldoYXQlMjBpcyUyMHlvdXIlMjBmYXZvdXJpdGUlMjBjb25kaW1lbnQlM0YlMjIlN0QlMkMlMEElMjAlMjAlMjAlMjAlN0IlMjJyb2xlJTIyJTNBJTIwJTIyYXNzaXN0YW50JTIyJTJDJTIwJTIyY29udGVudCUyMiUzQSUyMCUyMldlbGwlMkMlMjBJJ20lMjBxdWl0ZSUyMHBhcnRpYWwlMjB0byUyMGElMjBnb29kJTIwc3F1ZWV6ZSUyMG9mJTIwZnJlc2glMjBsZW1vbiUyMGp1aWNlLiUyMEl0JTIwYWRkcyUyMGp1c3QlMjB0aGUlMjByaWdodCUyMGFtb3VudCUyMG9mJTIwemVzdHklMjBmbGF2b3VyJTIwdG8lMjB3aGF0ZXZlciUyMEknbSUyMGNvb2tpbmclMjB1cCUyMGluJTIwdGhlJTIwa2l0Y2hlbiElMjIlN0QlMkMlMEElMjAlMjAlMjAlMjAlN0IlMjJyb2xlJTIyJTNBJTIwJTIydXNlciUyMiUyQyUyMCUyMmNvbnRlbnQlMjIlM0ElMjAlMjJEbyUyMHlvdSUyMGhhdmUlMjBtYXlvbm5haXNlJTIwcmVjaXBlcyUzRiUyMiU3RCUwQSU1RCUwQSUwQW1vZGVsX2lucHV0cyUyMCUzRCUyMHRva2VuaXplci5hcHBseV9jaGF0X3RlbXBsYXRlKG1lc3NhZ2VzJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMikudG8oJTIyY3VkYSUyMiklMEElMEFnZW5lcmF0ZWRfaWRzJTIwJTNEJTIwbW9kZWwuZ2VuZXJhdGUobW9kZWxfaW5wdXRzJTJDJTIwbWF4X25ld190b2tlbnMlM0QxMDAlMkMlMjBkb19zYW1wbGUlM0RUcnVlKSUwQXRva2VuaXplci5iYXRjaF9kZWNvZGUoZ2VuZXJhdGVkX2lkcyklNUIwJTVE",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoModelForCausalLM, AutoTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>model = AutoModelForCausalLM.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-Instruct-v0.2&quot;</span>, device_map=<span class="hljs-string">&quot;auto&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-Instruct-v0.2&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>messages = [
<span class="hljs-meta">... </span>    {<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;user&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: <span class="hljs-string">&quot;What is your favourite condiment?&quot;</span>},
<span class="hljs-meta">... </span>    {<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;assistant&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: <span class="hljs-string">&quot;Well, I&#x27;m quite partial to a good squeeze of fresh lemon juice. It adds just the right amount of zesty flavour to whatever I&#x27;m cooking up in the kitchen!&quot;</span>},
<span class="hljs-meta">... </span>    {<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;user&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: <span class="hljs-string">&quot;Do you have mayonnaise recipes?&quot;</span>}
<span class="hljs-meta">... </span>]

<span class="hljs-meta">&gt;&gt;&gt; </span>model_inputs = tokenizer.apply_chat_template(messages, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).to(<span class="hljs-string">&quot;cuda&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>generated_ids = model.generate(model_inputs, max_new_tokens=<span class="hljs-number">100</span>, do_sample=<span class="hljs-literal">True</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.batch_decode(generated_ids)[<span class="hljs-number">0</span>]
<span class="hljs-string">&quot;Mayonnaise can be made as follows: (...)&quot;</span>`,wrap:!1}}),at=new J({props:{title:"플래시 어텐션을 이용한 미스트랄 속도향상",local:"speeding-up-mistral-by-using-flash-attention",headingTag:"h2"}}),lt=new le({props:{code:"cGlwJTIwaW5zdGFsbCUyMC1VJTIwZmxhc2gtYXR0biUyMC0tbm8tYnVpbGQtaXNvbGF0aW9u",highlighted:"pip install -U flash-attn --no-build-isolation",wrap:!1}}),pt=new le({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b01vZGVsRm9yQ2F1c2FsTE0lMkMlMjBBdXRvVG9rZW5pemVyJTBBJTBBbW9kZWwlMjAlM0QlMjBBdXRvTW9kZWxGb3JDYXVzYWxMTS5mcm9tX3ByZXRyYWluZWQoJTIybWlzdHJhbGFpJTJGTWlzdHJhbC03Qi12MC4xJTIyJTJDJTIwdG9yY2hfZHR5cGUlM0R0b3JjaC5mbG9hdDE2JTJDJTIwYXR0bl9pbXBsZW1lbnRhdGlvbiUzRCUyMmZsYXNoX2F0dGVudGlvbl8yJTIyJTJDJTIwZGV2aWNlX21hcCUzRCUyMmF1dG8lMjIpJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIybWlzdHJhbGFpJTJGTWlzdHJhbC03Qi12MC4xJTIyKSUwQSUwQXByb21wdCUyMCUzRCUyMCUyMk15JTIwZmF2b3VyaXRlJTIwY29uZGltZW50JTIwaXMlMjIlMEElMEFtb2RlbF9pbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTVCcHJvbXB0JTVEJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMikudG8oJTIyY3VkYSUyMiklMEFtb2RlbC50byhkZXZpY2UpJTBBJTBBZ2VuZXJhdGVkX2lkcyUyMCUzRCUyMG1vZGVsLmdlbmVyYXRlKCoqbW9kZWxfaW5wdXRzJTJDJTIwbWF4X25ld190b2tlbnMlM0QxMDAlMkMlMjBkb19zYW1wbGUlM0RUcnVlKSUwQXRva2VuaXplci5iYXRjaF9kZWNvZGUoZ2VuZXJhdGVkX2lkcyklNUIwJTVE",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoModelForCausalLM, AutoTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>model = AutoModelForCausalLM.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>, torch_dtype=torch.float16, attn_implementation=<span class="hljs-string">&quot;flash_attention_2&quot;</span>, device_map=<span class="hljs-string">&quot;auto&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-v0.1&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>prompt = <span class="hljs-string">&quot;My favourite condiment is&quot;</span>

<span class="hljs-meta">&gt;&gt;&gt; </span>model_inputs = tokenizer([prompt], return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).to(<span class="hljs-string">&quot;cuda&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model.to(device)

<span class="hljs-meta">&gt;&gt;&gt; </span>generated_ids = model.generate(**model_inputs, max_new_tokens=<span class="hljs-number">100</span>, do_sample=<span class="hljs-literal">True</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.batch_decode(generated_ids)[<span class="hljs-number">0</span>]
<span class="hljs-string">&quot;My favourite condiment is to (...)&quot;</span>`,wrap:!1}}),mt=new J({props:{title:"기대하는 속도 향상",local:"expected-speedups",headingTag:"h3"}}),ht=new J({props:{title:"슬라이딩 윈도우 어텐션",local:"sliding-window-attention",headingTag:"h3"}}),_t=new J({props:{title:"양자화로 미스트랄 크기 줄이기",local:"shrinking-down-mistral-using-quantization",headingTag:"h2"}}),bt=new le({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b01vZGVsRm9yQ2F1c2FsTE0lMkMlMjBBdXRvVG9rZW5pemVyJTJDJTIwQml0c0FuZEJ5dGVzQ29uZmlnJTBBJTBBJTIzJTIwc3BlY2lmeSUyMGhvdyUyMHRvJTIwcXVhbnRpemUlMjB0aGUlMjBtb2RlbCUwQXF1YW50aXphdGlvbl9jb25maWclMjAlM0QlMjBCaXRzQW5kQnl0ZXNDb25maWcoJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwbG9hZF9pbl80Yml0JTNEVHJ1ZSUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGJuYl80Yml0X3F1YW50X3R5cGUlM0QlMjJuZjQlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBibmJfNGJpdF9jb21wdXRlX2R0eXBlJTNEJTIydG9yY2guZmxvYXQxNiUyMiUyQyUwQSklMEElMEFtb2RlbCUyMCUzRCUyMEF1dG9Nb2RlbEZvckNhdXNhbExNLmZyb21fcHJldHJhaW5lZCglMjJtaXN0cmFsYWklMkZNaXN0cmFsLTdCLUluc3RydWN0LXYwLjIlMjIlMkMlMjBxdWFudGl6YXRpb25fY29uZmlnJTNEVHJ1ZSUyQyUyMGRldmljZV9tYXAlM0QlMjJhdXRvJTIyKSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMm1pc3RyYWxhaSUyRk1pc3RyYWwtN0ItSW5zdHJ1Y3QtdjAuMiUyMiklMEElMEFwcm9tcHQlMjAlM0QlMjAlMjJNeSUyMGZhdm91cml0ZSUyMGNvbmRpbWVudCUyMGlzJTIyJTBBJTBBbWVzc2FnZXMlMjAlM0QlMjAlNUIlMEElMjAlMjAlMjAlMjAlN0IlMjJyb2xlJTIyJTNBJTIwJTIydXNlciUyMiUyQyUyMCUyMmNvbnRlbnQlMjIlM0ElMjAlMjJXaGF0JTIwaXMlMjB5b3VyJTIwZmF2b3VyaXRlJTIwY29uZGltZW50JTNGJTIyJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTdCJTIycm9sZSUyMiUzQSUyMCUyMmFzc2lzdGFudCUyMiUyQyUyMCUyMmNvbnRlbnQlMjIlM0ElMjAlMjJXZWxsJTJDJTIwSSdtJTIwcXVpdGUlMjBwYXJ0aWFsJTIwdG8lMjBhJTIwZ29vZCUyMHNxdWVlemUlMjBvZiUyMGZyZXNoJTIwbGVtb24lMjBqdWljZS4lMjBJdCUyMGFkZHMlMjBqdXN0JTIwdGhlJTIwcmlnaHQlMjBhbW91bnQlMjBvZiUyMHplc3R5JTIwZmxhdm91ciUyMHRvJTIwd2hhdGV2ZXIlMjBJJ20lMjBjb29raW5nJTIwdXAlMjBpbiUyMHRoZSUyMGtpdGNoZW4hJTIyJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTdCJTIycm9sZSUyMiUzQSUyMCUyMnVzZXIlMjIlMkMlMjAlMjJjb250ZW50JTIyJTNBJTIwJTIyRG8lMjB5b3UlMjBoYXZlJTIwbWF5b25uYWlzZSUyMHJlY2lwZXMlM0YlMjIlN0QlMEElNUQlMEElMEFtb2RlbF9pbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIuYXBwbHlfY2hhdF90ZW1wbGF0ZShtZXNzYWdlcyUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpLnRvKCUyMmN1ZGElMjIpJTBBJTBBZ2VuZXJhdGVkX2lkcyUyMCUzRCUyMG1vZGVsLmdlbmVyYXRlKG1vZGVsX2lucHV0cyUyQyUyMG1heF9uZXdfdG9rZW5zJTNEMTAwJTJDJTIwZG9fc2FtcGxlJTNEVHJ1ZSklMEF0b2tlbml6ZXIuYmF0Y2hfZGVjb2RlKGdlbmVyYXRlZF9pZHMpJTVCMCU1RA==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># specify how to quantize the model</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>quantization_config = BitsAndBytesConfig(
<span class="hljs-meta">... </span>        load_in_4bit=<span class="hljs-literal">True</span>,
<span class="hljs-meta">... </span>        bnb_4bit_quant_type=<span class="hljs-string">&quot;nf4&quot;</span>,
<span class="hljs-meta">... </span>        bnb_4bit_compute_dtype=<span class="hljs-string">&quot;torch.float16&quot;</span>,
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>model = AutoModelForCausalLM.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-Instruct-v0.2&quot;</span>, quantization_config=<span class="hljs-literal">True</span>, device_map=<span class="hljs-string">&quot;auto&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;mistralai/Mistral-7B-Instruct-v0.2&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>prompt = <span class="hljs-string">&quot;My favourite condiment is&quot;</span>

<span class="hljs-meta">&gt;&gt;&gt; </span>messages = [
<span class="hljs-meta">... </span>    {<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;user&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: <span class="hljs-string">&quot;What is your favourite condiment?&quot;</span>},
<span class="hljs-meta">... </span>    {<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;assistant&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: <span class="hljs-string">&quot;Well, I&#x27;m quite partial to a good squeeze of fresh lemon juice. It adds just the right amount of zesty flavour to whatever I&#x27;m cooking up in the kitchen!&quot;</span>},
<span class="hljs-meta">... </span>    {<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;user&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: <span class="hljs-string">&quot;Do you have mayonnaise recipes?&quot;</span>}
<span class="hljs-meta">... </span>]

<span class="hljs-meta">&gt;&gt;&gt; </span>model_inputs = tokenizer.apply_chat_template(messages, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).to(<span class="hljs-string">&quot;cuda&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>generated_ids = model.generate(model_inputs, max_new_tokens=<span class="hljs-number">100</span>, do_sample=<span class="hljs-literal">True</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.batch_decode(generated_ids)[<span class="hljs-number">0</span>]
<span class="hljs-string">&quot;The expected output&quot;</span>`,wrap:!1}}),kt=new J({props:{title:"리소스",local:"resources",headingTag:"h2"}}),vt=new Rr({props:{pipeline:"text-generation"}}),Ct=new J({props:{title:"MistralConfig",local:"transformers.MistralConfig ][ transformers.MistralConfig",headingTag:"h2"}}),jt=new W({props:{name:"class transformers.MistralConfig",anchor:"transformers.MistralConfig",parameters:[{name:"vocab_size",val:" = 32000"},{name:"hidden_size",val:" = 4096"},{name:"intermediate_size",val:" = 14336"},{name:"num_hidden_layers",val:" = 32"},{name:"num_attention_heads",val:" = 32"},{name:"num_key_value_heads",val:" = 8"},{name:"head_dim",val:" = None"},{name:"hidden_act",val:" = 'silu'"},{name:"max_position_embeddings",val:" = 131072"},{name:"initializer_range",val:" = 0.02"},{name:"rms_norm_eps",val:" = 1e-06"},{name:"use_cache",val:" = True"},{name:"pad_token_id",val:" = None"},{name:"bos_token_id",val:" = 1"},{name:"eos_token_id",val:" = 2"},{name:"tie_word_embeddings",val:" = False"},{name:"rope_theta",val:" = 10000.0"},{name:"sliding_window",val:" = 4096"},{name:"attention_dropout",val:" = 0.0"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.MistralConfig.vocab_size",description:`<strong>vocab_size</strong> (<code>int</code>, <em>optional</em>, defaults to 32000) &#x2014;
Vocabulary size of the Mistral model. Defines the number of different tokens that can be represented by the
<code>inputs_ids</code> passed when calling <a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralModel">MistralModel</a>`,name:"vocab_size"},{anchor:"transformers.MistralConfig.hidden_size",description:`<strong>hidden_size</strong> (<code>int</code>, <em>optional</em>, defaults to 4096) &#x2014;
Dimension of the hidden representations.`,name:"hidden_size"},{anchor:"transformers.MistralConfig.intermediate_size",description:`<strong>intermediate_size</strong> (<code>int</code>, <em>optional</em>, defaults to 14336) &#x2014;
Dimension of the MLP representations.`,name:"intermediate_size"},{anchor:"transformers.MistralConfig.num_hidden_layers",description:`<strong>num_hidden_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 32) &#x2014;
Number of hidden layers in the Transformer encoder.`,name:"num_hidden_layers"},{anchor:"transformers.MistralConfig.num_attention_heads",description:`<strong>num_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 32) &#x2014;
Number of attention heads for each attention layer in the Transformer encoder.`,name:"num_attention_heads"},{anchor:"transformers.MistralConfig.num_key_value_heads",description:`<strong>num_key_value_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 8) &#x2014;
This is the number of key_value heads that should be used to implement Grouped Query Attention. If
<code>num_key_value_heads=num_attention_heads</code>, the model will use Multi Head Attention (MHA), if
<code>num_key_value_heads=1</code> the model will use Multi Query Attention (MQA) otherwise GQA is used. When
converting a multi-head checkpoint to a GQA checkpoint, each group key and value head should be constructed
by meanpooling all the original heads within that group. For more details, check out <a href="https://huggingface.co/papers/2305.13245" rel="nofollow">this
paper</a>. If it is not specified, will default to <code>8</code>.`,name:"num_key_value_heads"},{anchor:"transformers.MistralConfig.head_dim",description:`<strong>head_dim</strong> (<code>int</code>, <em>optional</em>, defaults to <code>hidden_size // num_attention_heads</code>) &#x2014;
The attention head dimension.`,name:"head_dim"},{anchor:"transformers.MistralConfig.hidden_act",description:`<strong>hidden_act</strong> (<code>str</code> or <code>function</code>, <em>optional</em>, defaults to <code>&quot;silu&quot;</code>) &#x2014;
The non-linear activation function (function or string) in the decoder.`,name:"hidden_act"},{anchor:"transformers.MistralConfig.max_position_embeddings",description:`<strong>max_position_embeddings</strong> (<code>int</code>, <em>optional</em>, defaults to <code>4096*32</code>) &#x2014;
The maximum sequence length that this model might ever be used with. Mistral&#x2019;s sliding window attention
allows sequence of up to 4096*32 tokens.`,name:"max_position_embeddings"},{anchor:"transformers.MistralConfig.initializer_range",description:`<strong>initializer_range</strong> (<code>float</code>, <em>optional</em>, defaults to 0.02) &#x2014;
The standard deviation of the truncated_normal_initializer for initializing all weight matrices.`,name:"initializer_range"},{anchor:"transformers.MistralConfig.rms_norm_eps",description:`<strong>rms_norm_eps</strong> (<code>float</code>, <em>optional</em>, defaults to 1e-06) &#x2014;
The epsilon used by the rms normalization layers.`,name:"rms_norm_eps"},{anchor:"transformers.MistralConfig.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether or not the model should return the last key/values attentions (not used by all models). Only
relevant if <code>config.is_decoder=True</code>.`,name:"use_cache"},{anchor:"transformers.MistralConfig.pad_token_id",description:`<strong>pad_token_id</strong> (<code>int</code>, <em>optional</em>) &#x2014;
The id of the padding token.`,name:"pad_token_id"},{anchor:"transformers.MistralConfig.bos_token_id",description:`<strong>bos_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 1) &#x2014;
The id of the &#x201C;beginning-of-sequence&#x201D; token.`,name:"bos_token_id"},{anchor:"transformers.MistralConfig.eos_token_id",description:`<strong>eos_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 2) &#x2014;
The id of the &#x201C;end-of-sequence&#x201D; token.`,name:"eos_token_id"},{anchor:"transformers.MistralConfig.tie_word_embeddings",description:`<strong>tie_word_embeddings</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether the model&#x2019;s input and output word embeddings should be tied.`,name:"tie_word_embeddings"},{anchor:"transformers.MistralConfig.rope_theta",description:`<strong>rope_theta</strong> (<code>float</code>, <em>optional</em>, defaults to 10000.0) &#x2014;
The base period of the RoPE embeddings.`,name:"rope_theta"},{anchor:"transformers.MistralConfig.sliding_window",description:`<strong>sliding_window</strong> (<code>int</code>, <em>optional</em>, defaults to 4096) &#x2014;
Sliding window attention window size. If not specified, will default to <code>4096</code>.`,name:"sliding_window"},{anchor:"transformers.MistralConfig.attention_dropout",description:`<strong>attention_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout ratio for the attention probabilities.`,name:"attention_dropout"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/configuration_mistral.py#L24"}}),ve=new sn({props:{anchor:"transformers.MistralConfig.example",$$slots:{default:[Vr]},$$scope:{ctx:v}}}),xt=new J({props:{title:"MistralModel",local:"transformers.MistralModel ][ transformers.MistralModel",headingTag:"h2"}}),Jt=new W({props:{name:"class transformers.MistralModel",anchor:"transformers.MistralModel",parameters:[{name:"config",val:": MistralConfig"}],parametersDescription:[{anchor:"transformers.MistralModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig">MistralConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_mistral.py#L321"}}),Ft=new W({props:{name:"forward",anchor:"transformers.MistralModel.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"},{name:"**flash_attn_kwargs",val:": typing_extensions.Unpack[transformers.modeling_flash_attention_utils.FlashAttentionKwargs]"}],parametersDescription:[{anchor:"transformers.MistralModel.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.MistralModel.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.MistralModel.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.MistralModel.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.MistralModel.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.MistralModel.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.MistralModel.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.MistralModel.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.MistralModel.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_mistral.py#L345",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.BaseModelOutputWithPast"
>transformers.modeling_outputs.BaseModelOutputWithPast</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig"
>MistralConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if
<code>config.is_encoder_decoder=True</code> in the cross-attention blocks) that can be used (see <code>past_key_values</code>
input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.BaseModelOutputWithPast"
>transformers.modeling_outputs.BaseModelOutputWithPast</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),$e=new ae({props:{$$slots:{default:[Sr]},$$scope:{ctx:v}}}),zt=new J({props:{title:"MistralForCausalLM",local:"transformers.MistralForCausalLM ][ transformers.MistralForCausalLM",headingTag:"h2"}}),Ut=new W({props:{name:"class transformers.MistralForCausalLM",anchor:"transformers.MistralForCausalLM",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.MistralForCausalLM.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralForCausalLM">MistralForCausalLM</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_mistral.py#L450"}}),It=new W({props:{name:"forward",anchor:"transformers.MistralForCausalLM.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"},{name:"logits_to_keep",val:": typing.Union[int, torch.Tensor] = 0"},{name:"**kwargs",val:": typing_extensions.Unpack[transformers.models.mistral.modeling_mistral.KwargsForCausalLM]"}],parametersDescription:[{anchor:"transformers.MistralForCausalLM.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.MistralForCausalLM.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.MistralForCausalLM.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.MistralForCausalLM.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.MistralForCausalLM.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.MistralForCausalLM.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the masked language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code> or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored
(masked), the loss is only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"},{anchor:"transformers.MistralForCausalLM.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.MistralForCausalLM.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.MistralForCausalLM.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.MistralForCausalLM.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"},{anchor:"transformers.MistralForCausalLM.forward.logits_to_keep",description:`<strong>logits_to_keep</strong> (<code>Union[int, torch.Tensor]</code>, defaults to <code>0</code>) &#x2014;
If an <code>int</code>, compute logits for the last <code>logits_to_keep</code> tokens. If <code>0</code>, calculate logits for all
<code>input_ids</code> (special case). Only last token logits are needed for generation, and calculating them only for that
token can save memory, which becomes pretty significant for long sequences or large vocabulary size.
If a <code>torch.Tensor</code>, must be 1D corresponding to the indices to keep in the sequence length dimension.
This is useful when using packed tensor format (single dimension for batch and sequence length).`,name:"logits_to_keep"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_mistral.py#L483",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.CausalLMOutputWithPast"
>transformers.modeling_outputs.CausalLMOutputWithPast</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig"
>MistralConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Language modeling loss (for next-token prediction).</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks) that can be used (see
<code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.CausalLMOutputWithPast"
>transformers.modeling_outputs.CausalLMOutputWithPast</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Ce=new ae({props:{$$slots:{default:[Pr]},$$scope:{ctx:v}}}),je=new sn({props:{anchor:"transformers.MistralForCausalLM.forward.example",$$slots:{default:[Er]},$$scope:{ctx:v}}}),qt=new J({props:{title:"MistralForSequenceClassification",local:"transformers.MistralForSequenceClassification ][ transformers.MistralForSequenceClassification",headingTag:"h2"}}),Wt=new W({props:{name:"class transformers.MistralForSequenceClassification",anchor:"transformers.MistralForSequenceClassification",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.MistralForSequenceClassification.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralForSequenceClassification">MistralForSequenceClassification</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_mistral.py#L630"}}),Zt=new W({props:{name:"forward",anchor:"transformers.MistralForSequenceClassification.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.MistralForSequenceClassification.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.MistralForSequenceClassification.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.MistralForSequenceClassification.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.MistralForSequenceClassification.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.MistralForSequenceClassification.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.MistralForSequenceClassification.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size,)</code>, <em>optional</em>) &#x2014;
Labels for computing the sequence classification/regression loss. Indices should be in <code>[0, ..., config.num_labels - 1]</code>. If <code>config.num_labels == 1</code> a regression loss is computed (Mean-Square loss), If
<code>config.num_labels &gt; 1</code> a classification loss is computed (Cross-Entropy).`,name:"labels"},{anchor:"transformers.MistralForSequenceClassification.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.MistralForSequenceClassification.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.MistralForSequenceClassification.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_mistral.py#L660",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>transformers.modeling_outputs.SequenceClassifierOutputWithPast</code> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig"
>MistralConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Classification (or regression if config.num_labels==1) loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, config.num_labels)</code>) — Classification (or regression if config.num_labels==1) scores (before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks) that can be used (see
<code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>transformers.modeling_outputs.SequenceClassifierOutputWithPast</code> or <code>tuple(torch.FloatTensor)</code></p>
`}}),xe=new ae({props:{$$slots:{default:[Qr]},$$scope:{ctx:v}}}),Je=new sn({props:{anchor:"transformers.MistralForSequenceClassification.forward.example",$$slots:{default:[Yr]},$$scope:{ctx:v}}}),Fe=new sn({props:{anchor:"transformers.MistralForSequenceClassification.forward.example-2",$$slots:{default:[Ar]},$$scope:{ctx:v}}}),Lt=new J({props:{title:"MistralForTokenClassification",local:"transformers.MistralForTokenClassification ][ transformers.MistralForTokenClassification",headingTag:"h2"}}),Bt=new W({props:{name:"class transformers.MistralForTokenClassification",anchor:"transformers.MistralForTokenClassification",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.MistralForTokenClassification.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralForTokenClassification">MistralForTokenClassification</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_mistral.py#L559"}}),Gt=new W({props:{name:"forward",anchor:"transformers.MistralForTokenClassification.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.MistralForTokenClassification.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.MistralForTokenClassification.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.MistralForTokenClassification.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.MistralForTokenClassification.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.MistralForTokenClassification.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.MistralForTokenClassification.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size,)</code>, <em>optional</em>) &#x2014;
Labels for computing the sequence classification/regression loss. Indices should be in <code>[0, ..., config.num_labels - 1]</code>. If <code>config.num_labels == 1</code> a regression loss is computed (Mean-Square loss), If
<code>config.num_labels &gt; 1</code> a classification loss is computed (Cross-Entropy).`,name:"labels"},{anchor:"transformers.MistralForTokenClassification.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.MistralForTokenClassification.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.MistralForTokenClassification.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_mistral.py#L583",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.TokenClassifierOutput"
>transformers.modeling_outputs.TokenClassifierOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig"
>MistralConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided)  — Classification loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.num_labels)</code>) — Classification scores (before SoftMax).</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.TokenClassifierOutput"
>transformers.modeling_outputs.TokenClassifierOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),ze=new ae({props:{$$slots:{default:[Or]},$$scope:{ctx:v}}}),Ue=new sn({props:{anchor:"transformers.MistralForTokenClassification.forward.example",$$slots:{default:[Dr]},$$scope:{ctx:v}}}),Ht=new J({props:{title:"FlaxMistralModel",local:"transformers.FlaxMistralModel ][ transformers.FlaxMistralModel",headingTag:"h2"}}),Nt=new W({props:{name:"class transformers.FlaxMistralModel",anchor:"transformers.FlaxMistralModel",parameters:[{name:"config",val:": MistralConfig"},{name:"input_shape",val:": typing.Tuple = (1, 1)"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxMistralModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig">MistralConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxMistralModel.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code>, or
<code>jax.numpy.bfloat16</code>.</p>
<p>This can be used to enable mixed-precision training or half-precision inference on GPUs or TPUs. If
specified all the computation will be performed with the given <code>dtype</code>.</p>
<p><strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong></p>
<p>If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a> and
<a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_flax_mistral.py#L636"}}),Rt=new W({props:{name:"__call__",anchor:"transformers.FlaxMistralModel.__call__",parameters:[{name:"input_ids",val:""},{name:"attention_mask",val:" = None"},{name:"position_ids",val:" = None"},{name:"params",val:": typing.Optional[dict] = None"},{name:"past_key_values",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"},{name:"train",val:": bool = False"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.FlaxMistralModel.__call__.input_ids",description:`<strong>input_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, input_ids_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.FlaxMistralModel.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a></p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p>If <code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).</p>
<p>If you want to change padding behavior, you should read <code>modeling_opt._prepare_decoder_attention_mask</code>
and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more
information on the default strategy.</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"attention_mask"},{anchor:"transformers.FlaxMistralModel.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, input_ids_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.FlaxMistralModel.__call__.past_key_values",description:`<strong>past_key_values</strong> (<code>Dict[str, np.ndarray]</code>, <em>optional</em>, returned by <code>init_cache</code> or when passing previous <code>past_key_values</code>) &#x2014;
Dictionary of pre-computed hidden-states (key and values in the attention blocks) that can be used for fast
auto-regressive decoding. Pre-computed key and value hidden-states are of shape <em>[batch_size, max_length]</em>.`,name:"past_key_values"},{anchor:"transformers.FlaxMistralModel.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxMistralModel.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxMistralModel.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_flax_mistral.py#L458",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxBaseModelOutputWithPast"
>transformers.modeling_flax_outputs.FlaxBaseModelOutputWithPast</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig"
>MistralConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the model.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Dict[str, jnp.ndarray]</code>) — Dictionary of pre-computed hidden-states (key and values in the attention blocks) that can be used for fast
auto-regressive decoding. Pre-computed key and value hidden-states are of shape <em>[batch_size, max_length]</em>.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxBaseModelOutputWithPast"
>transformers.modeling_flax_outputs.FlaxBaseModelOutputWithPast</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Ie=new ae({props:{$$slots:{default:[Kr]},$$scope:{ctx:v}}}),qe=new ae({props:{warning:!0,$$slots:{default:[ei]},$$scope:{ctx:v}}}),We=new sn({props:{anchor:"transformers.FlaxMistralModel.__call__.example",$$slots:{default:[ti]},$$scope:{ctx:v}}}),Xt=new J({props:{title:"FlaxMistralForCausalLM",local:"transformers.FlaxMistralForCausalLM ][ transformers.FlaxMistralForCausalLM",headingTag:"h2"}}),Vt=new W({props:{name:"class transformers.FlaxMistralForCausalLM",anchor:"transformers.FlaxMistralForCausalLM",parameters:[{name:"config",val:": MistralConfig"},{name:"input_shape",val:": typing.Tuple = (1, 1)"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxMistralForCausalLM.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig">MistralConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxMistralForCausalLM.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code>, or
<code>jax.numpy.bfloat16</code>.</p>
<p>This can be used to enable mixed-precision training or half-precision inference on GPUs or TPUs. If
specified all the computation will be performed with the given <code>dtype</code>.</p>
<p><strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong></p>
<p>If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a> and
<a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_flax_mistral.py#L698"}}),St=new W({props:{name:"__call__",anchor:"transformers.FlaxMistralForCausalLM.__call__",parameters:[{name:"input_ids",val:""},{name:"attention_mask",val:" = None"},{name:"position_ids",val:" = None"},{name:"params",val:": typing.Optional[dict] = None"},{name:"past_key_values",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"},{name:"train",val:": bool = False"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.FlaxMistralForCausalLM.__call__.input_ids",description:`<strong>input_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, input_ids_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.FlaxMistralForCausalLM.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a></p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p>If <code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).</p>
<p>If you want to change padding behavior, you should read <code>modeling_opt._prepare_decoder_attention_mask</code>
and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more
information on the default strategy.</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"attention_mask"},{anchor:"transformers.FlaxMistralForCausalLM.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, input_ids_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.FlaxMistralForCausalLM.__call__.past_key_values",description:`<strong>past_key_values</strong> (<code>Dict[str, np.ndarray]</code>, <em>optional</em>, returned by <code>init_cache</code> or when passing previous <code>past_key_values</code>) &#x2014;
Dictionary of pre-computed hidden-states (key and values in the attention blocks) that can be used for fast
auto-regressive decoding. Pre-computed key and value hidden-states are of shape <em>[batch_size, max_length]</em>.`,name:"past_key_values"},{anchor:"transformers.FlaxMistralForCausalLM.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxMistralForCausalLM.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxMistralForCausalLM.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_flax_mistral.py#L458",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxCausalLMOutputWithCrossAttentions"
>transformers.modeling_flax_outputs.FlaxCausalLMOutputWithCrossAttentions</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig"
>MistralConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>logits</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Cross attentions weights after the attention softmax, used to compute the weighted average in the
cross-attention heads.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>tuple(tuple(jnp.ndarray))</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — Tuple of <code>jnp.ndarray</code> tuples of length <code>config.n_layers</code>, with each tuple containing the cached key, value
states of the self-attention and the cross-attention layers if model is used in encoder-decoder setting.
Only relevant if <code>config.is_decoder = True</code>.</p>
<p>Contains pre-computed hidden-states (key and values in the attention blocks) that can be used (see
<code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxCausalLMOutputWithCrossAttentions"
>transformers.modeling_flax_outputs.FlaxCausalLMOutputWithCrossAttentions</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Ze=new ae({props:{$$slots:{default:[ni]},$$scope:{ctx:v}}}),Le=new ae({props:{warning:!0,$$slots:{default:[si]},$$scope:{ctx:v}}}),Be=new sn({props:{anchor:"transformers.FlaxMistralForCausalLM.__call__.example",$$slots:{default:[oi]},$$scope:{ctx:v}}}),Pt=new J({props:{title:"TFMistralModel",local:"transformers.TFMistralModel ][ transformers.TFMistralModel",headingTag:"h2"}}),Et=new W({props:{name:"class transformers.TFMistralModel",anchor:"transformers.TFMistralModel",parameters:[{name:"config",val:": MistralConfig"},{name:"*inputs",val:""},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.TFMistralModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig">MistralConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_tf_mistral.py#L760"}}),Ge=new ae({props:{$$slots:{default:[ai]},$$scope:{ctx:v}}}),Qt=new W({props:{name:"call",anchor:"transformers.TFMistralModel.call",parameters:[{name:"input_ids",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"attention_mask",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"position_ids",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"past_key_values",val:": typing.Optional[typing.List[tensorflow.python.framework.tensor.Tensor]] = None"},{name:"inputs_embeds",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.TFMistralModel.call.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.TFMistralModel.call.attention_mask",description:`<strong>attention_mask</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a></p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p>If <code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).</p>
<p>If you want to change padding behavior, you should read <code>modeling_opt._prepare_decoder_attention_mask</code>
and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more
information on the default strategy.</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"attention_mask"},{anchor:"transformers.TFMistralModel.call.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.TFMistralModel.call.past_key_values",description:`<strong>past_key_values</strong> (<code>Cache</code> or <code>tuple(tuple(tf.Tensor))</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>One formats is allowed:</p>
<ul>
<li>Tuple of <code>tuple(tf.Tensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.TFMistralModel.call.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.TFMistralModel.call.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.TFMistralModel.call.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.TFMistralModel.call.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.TFMistralModel.call.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_tf_mistral.py#L769"}}),He=new ae({props:{$$slots:{default:[ri]},$$scope:{ctx:v}}}),Yt=new J({props:{title:"TFMistralForCausalLM",local:"transformers.TFMistralForCausalLM ][ transformers.TFMistralForCausalLM",headingTag:"h2"}}),At=new W({props:{name:"class transformers.TFMistralForCausalLM",anchor:"transformers.TFMistralForCausalLM",parameters:[{name:"config",val:""},{name:"*inputs",val:""},{name:"**kwargs",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_tf_mistral.py#L805"}}),Ot=new W({props:{name:"call",anchor:"transformers.TFMistralForCausalLM.call",parameters:[{name:"input_ids",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"attention_mask",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"position_ids",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"past_key_values",val:": typing.Optional[typing.List[tensorflow.python.framework.tensor.Tensor]] = None"},{name:"inputs_embeds",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"labels",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.TFMistralForCausalLM.call.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.TFMistralForCausalLM.call.attention_mask",description:`<strong>attention_mask</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a></p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p>If <code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).</p>
<p>If you want to change padding behavior, you should read <code>modeling_opt._prepare_decoder_attention_mask</code>
and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more
information on the default strategy.</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"attention_mask"},{anchor:"transformers.TFMistralForCausalLM.call.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.TFMistralForCausalLM.call.past_key_values",description:`<strong>past_key_values</strong> (<code>Cache</code> or <code>tuple(tuple(tf.Tensor))</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>One formats is allowed:</p>
<ul>
<li>Tuple of <code>tuple(tf.Tensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.TFMistralForCausalLM.call.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.TFMistralForCausalLM.call.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.TFMistralForCausalLM.call.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.TFMistralForCausalLM.call.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.TFMistralForCausalLM.call.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.TFMistralForCausalLM.call.labels",description:`<strong>labels</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the masked language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code>
or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored
(masked), the loss is only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_tf_mistral.py#L836"}}),Ne=new ae({props:{$$slots:{default:[ii]},$$scope:{ctx:v}}}),Dt=new J({props:{title:"TFMistralForSequenceClassification",local:"transformers.TFMistralForSequenceClassification ][ transformers.TFMistralForSequenceClassification",headingTag:"h2"}}),Kt=new W({props:{name:"class transformers.TFMistralForSequenceClassification",anchor:"transformers.TFMistralForSequenceClassification",parameters:[{name:"config",val:""},{name:"*inputs",val:""},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.TFMistralForSequenceClassification.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/mistral#transformers.MistralConfig">MistralConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_tf_mistral.py#L927"}}),Re=new ae({props:{$$slots:{default:[li]},$$scope:{ctx:v}}}),en=new W({props:{name:"call",anchor:"transformers.TFMistralForSequenceClassification.call",parameters:[{name:"input_ids",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"attention_mask",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"position_ids",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"past_key_values",val:": typing.Optional[typing.List[tensorflow.python.framework.tensor.Tensor]] = None"},{name:"inputs_embeds",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"labels",val:": typing.Optional[tensorflow.python.framework.tensor.Tensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.TFMistralForSequenceClassification.call.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.TFMistralForSequenceClassification.call.attention_mask",description:`<strong>attention_mask</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a></p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p>If <code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).</p>
<p>If you want to change padding behavior, you should read <code>modeling_opt._prepare_decoder_attention_mask</code>
and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more
information on the default strategy.</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"attention_mask"},{anchor:"transformers.TFMistralForSequenceClassification.call.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.TFMistralForSequenceClassification.call.past_key_values",description:`<strong>past_key_values</strong> (<code>Cache</code> or <code>tuple(tuple(tf.Tensor))</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>One formats is allowed:</p>
<ul>
<li>Tuple of <code>tuple(tf.Tensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.TFMistralForSequenceClassification.call.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.TFMistralForSequenceClassification.call.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.TFMistralForSequenceClassification.call.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.TFMistralForSequenceClassification.call.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.TFMistralForSequenceClassification.call.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.TFMistralForSequenceClassification.call.labels",description:`<strong>labels</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the masked language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code> or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored
(masked), the loss is only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/mistral/modeling_tf_mistral.py#L961"}}),Xe=new ae({props:{$$slots:{default:[di]},$$scope:{ctx:v}}}),tn=new Xr({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/mistral.md"}}),{c(){n=d("meta"),b=o(),l=d("p"),u=o(),h(w.$$.fragment),p=o(),h(k.$$.fragment),pe=o(),B=d("p"),B.innerHTML=Z,me=o(),G=d("p"),G.textContent=L,ue=o(),T=d("p"),T.innerHTML=$,An=o(),Ve=d("p"),Ve.innerHTML=ka,On=o(),h(Se.$$.fragment),Dn=o(),Pe=d("p"),Pe.textContent=wa,Kn=o(),Ee=d("ul"),Ee.innerHTML=va,es=o(),Qe=d("p"),Qe.innerHTML=$a,ts=o(),h(Ye.$$.fragment),ns=o(),Ae=d("p"),Ae.innerHTML=Ca,ss=o(),h(Oe.$$.fragment),os=o(),De=d("p"),De.textContent=ja,as=o(),Ke=d("ul"),Ke.innerHTML=xa,rs=o(),et=d("p"),et.textContent=Ja,is=o(),h(tt.$$.fragment),ls=o(),nt=d("p"),nt.textContent=Fa,ds=o(),h(st.$$.fragment),cs=o(),ot=d("p"),ot.innerHTML=za,ps=o(),h(at.$$.fragment),ms=o(),rt=d("p"),rt.innerHTML=Ua,us=o(),it=d("p"),it.textContent=Ia,hs=o(),h(lt.$$.fragment),fs=o(),dt=d("p"),dt.innerHTML=qa,gs=o(),ct=d("p"),ct.textContent=Wa,_s=o(),h(pt.$$.fragment),Ms=o(),h(mt.$$.fragment),ys=o(),ut=d("p"),ut.innerHTML=Za,bs=o(),we=d("div"),we.innerHTML=La,Ts=o(),h(ht.$$.fragment),ks=o(),ft=d("p"),ft.innerHTML=Ba,ws=o(),gt=d("p"),gt.innerHTML=Ga,vs=o(),h(_t.$$.fragment),$s=o(),Mt=d("p"),Mt.innerHTML=Ha,Cs=o(),yt=d("p"),yt.innerHTML=Na,js=o(),h(bt.$$.fragment),xs=o(),Tt=d("p"),Tt.innerHTML=Ra,Js=o(),h(kt.$$.fragment),Fs=o(),wt=d("p"),wt.textContent=Xa,zs=o(),h(vt.$$.fragment),Us=o(),$t=d("ul"),$t.innerHTML=Va,Is=o(),h(Ct.$$.fragment),qs=o(),V=d("div"),h(jt.$$.fragment),no=o(),on=d("p"),on.innerHTML=Sa,so=o(),an=d("p"),an.innerHTML=Pa,oo=o(),rn=d("p"),rn.innerHTML=Ea,ao=o(),h(ve.$$.fragment),Ws=o(),h(xt.$$.fragment),Zs=o(),S=d("div"),h(Jt.$$.fragment),ro=o(),ln=d("p"),ln.textContent=Qa,io=o(),dn=d("p"),dn.innerHTML=Ya,lo=o(),cn=d("p"),cn.innerHTML=Aa,co=o(),he=d("div"),h(Ft.$$.fragment),po=o(),pn=d("p"),pn.innerHTML=Oa,mo=o(),h($e.$$.fragment),Ls=o(),h(zt.$$.fragment),Bs=o(),P=d("div"),h(Ut.$$.fragment),uo=o(),mn=d("p"),mn.textContent=Da,ho=o(),un=d("p"),un.innerHTML=Ka,fo=o(),hn=d("p"),hn.innerHTML=er,go=o(),re=d("div"),h(It.$$.fragment),_o=o(),fn=d("p"),fn.innerHTML=tr,Mo=o(),h(Ce.$$.fragment),yo=o(),h(je.$$.fragment),Gs=o(),h(qt.$$.fragment),Hs=o(),z=d("div"),h(Wt.$$.fragment),bo=o(),gn=d("p"),gn.textContent=nr,To=o(),_n=d("p"),_n.innerHTML=sr,ko=o(),Mn=d("p"),Mn.innerHTML=or,wo=o(),yn=d("p"),yn.innerHTML=ar,vo=o(),bn=d("p"),bn.innerHTML=rr,$o=o(),Y=d("div"),h(Zt.$$.fragment),Co=o(),Tn=d("p"),Tn.innerHTML=ir,jo=o(),h(xe.$$.fragment),xo=o(),h(Je.$$.fragment),Jo=o(),h(Fe.$$.fragment),Ns=o(),h(Lt.$$.fragment),Rs=o(),E=d("div"),h(Bt.$$.fragment),Fo=o(),kn=d("p"),kn.textContent=lr,zo=o(),wn=d("p"),wn.innerHTML=dr,Uo=o(),vn=d("p"),vn.innerHTML=cr,Io=o(),ie=d("div"),h(Gt.$$.fragment),qo=o(),$n=d("p"),$n.innerHTML=pr,Wo=o(),h(ze.$$.fragment),Zo=o(),h(Ue.$$.fragment),Xs=o(),h(Ht.$$.fragment),Vs=o(),U=d("div"),h(Nt.$$.fragment),Lo=o(),Cn=d("p"),Cn.textContent=mr,Bo=o(),jn=d("p"),jn.innerHTML=ur,Go=o(),xn=d("p"),xn.innerHTML=hr,Ho=o(),Jn=d("p"),Jn.textContent=fr,No=o(),Fn=d("ul"),Fn.innerHTML=gr,Ro=o(),A=d("div"),h(Rt.$$.fragment),Xo=o(),zn=d("p"),zn.innerHTML=_r,Vo=o(),h(Ie.$$.fragment),So=o(),h(qe.$$.fragment),Po=o(),h(We.$$.fragment),Ss=o(),h(Xt.$$.fragment),Ps=o(),I=d("div"),h(Vt.$$.fragment),Eo=o(),Un=d("p"),Un.textContent=Mr,Qo=o(),In=d("p"),In.innerHTML=yr,Yo=o(),qn=d("p"),qn.innerHTML=br,Ao=o(),Wn=d("p"),Wn.textContent=Tr,Oo=o(),Zn=d("ul"),Zn.innerHTML=kr,Do=o(),O=d("div"),h(St.$$.fragment),Ko=o(),Ln=d("p"),Ln.innerHTML=wr,ea=o(),h(Ze.$$.fragment),ta=o(),h(Le.$$.fragment),na=o(),h(Be.$$.fragment),Es=o(),h(Pt.$$.fragment),Qs=o(),H=d("div"),h(Et.$$.fragment),sa=o(),Bn=d("p"),Bn.textContent=vr,oa=o(),Gn=d("p"),Gn.innerHTML=$r,aa=o(),Hn=d("p"),Hn.innerHTML=Cr,ra=o(),h(Ge.$$.fragment),ia=o(),fe=d("div"),h(Qt.$$.fragment),la=o(),Nn=d("p"),Nn.innerHTML=jr,da=o(),h(He.$$.fragment),Ys=o(),h(Yt.$$.fragment),As=o(),Me=d("div"),h(At.$$.fragment),ca=o(),ge=d("div"),h(Ot.$$.fragment),pa=o(),Rn=d("p"),Rn.innerHTML=xr,ma=o(),h(Ne.$$.fragment),Os=o(),h(Dt.$$.fragment),Ds=o(),C=d("div"),h(Kt.$$.fragment),ua=o(),Xn=d("p"),Xn.textContent=Jr,ha=o(),Vn=d("p"),Vn.innerHTML=Fr,fa=o(),Sn=d("p"),Sn.innerHTML=zr,ga=o(),Pn=d("p"),Pn.innerHTML=Ur,_a=o(),En=d("p"),En.innerHTML=Ir,Ma=o(),h(Re.$$.fragment),ya=o(),_e=d("div"),h(en.$$.fragment),ba=o(),Qn=d("p"),Qn.innerHTML=qr,Ta=o(),h(Xe.$$.fragment),Ks=o(),h(tn.$$.fragment),eo=o(),Yn=d("p"),this.h()},l(e){const t=Hr("svelte-u9bgzb",document.head);n=c(t,"META",{name:!0,content:!0}),t.forEach(s),b=a(e),l=c(e,"P",{}),j(l).forEach(s),u=a(e),f(w.$$.fragment,e),p=a(e),f(k.$$.fragment,e),pe=a(e),B=c(e,"P",{"data-svelte-h":!0}),m(B)!=="svelte-1jq94cn"&&(B.innerHTML=Z),me=a(e),G=c(e,"P",{"data-svelte-h":!0}),m(G)!=="svelte-182fnxo"&&(G.textContent=L),ue=a(e),T=c(e,"P",{"data-svelte-h":!0}),m(T)!=="svelte-v56qvn"&&(T.innerHTML=$),An=a(e),Ve=c(e,"P",{"data-svelte-h":!0}),m(Ve)!=="svelte-itjfst"&&(Ve.innerHTML=ka),On=a(e),f(Se.$$.fragment,e),Dn=a(e),Pe=c(e,"P",{"data-svelte-h":!0}),m(Pe)!=="svelte-1kc966i"&&(Pe.textContent=wa),Kn=a(e),Ee=c(e,"UL",{"data-svelte-h":!0}),m(Ee)!=="svelte-mor5gd"&&(Ee.innerHTML=va),es=a(e),Qe=c(e,"P",{"data-svelte-h":!0}),m(Qe)!=="svelte-1mq8l22"&&(Qe.innerHTML=$a),ts=a(e),f(Ye.$$.fragment,e),ns=a(e),Ae=c(e,"P",{"data-svelte-h":!0}),m(Ae)!=="svelte-8fcwwq"&&(Ae.innerHTML=Ca),ss=a(e),f(Oe.$$.fragment,e),os=a(e),De=c(e,"P",{"data-svelte-h":!0}),m(De)!=="svelte-82miud"&&(De.textContent=ja),as=a(e),Ke=c(e,"UL",{"data-svelte-h":!0}),m(Ke)!=="svelte-cesn61"&&(Ke.innerHTML=xa),rs=a(e),et=c(e,"P",{"data-svelte-h":!0}),m(et)!=="svelte-nj92a3"&&(et.textContent=Ja),is=a(e),f(tt.$$.fragment,e),ls=a(e),nt=c(e,"P",{"data-svelte-h":!0}),m(nt)!=="svelte-bi6uua"&&(nt.textContent=Fa),ds=a(e),f(st.$$.fragment,e),cs=a(e),ot=c(e,"P",{"data-svelte-h":!0}),m(ot)!=="svelte-sfd2l5"&&(ot.innerHTML=za),ps=a(e),f(at.$$.fragment,e),ms=a(e),rt=c(e,"P",{"data-svelte-h":!0}),m(rt)!=="svelte-q7klzk"&&(rt.innerHTML=Ua),us=a(e),it=c(e,"P",{"data-svelte-h":!0}),m(it)!=="svelte-ydii05"&&(it.textContent=Ia),hs=a(e),f(lt.$$.fragment,e),fs=a(e),dt=c(e,"P",{"data-svelte-h":!0}),m(dt)!=="svelte-1vqfaar"&&(dt.innerHTML=qa),gs=a(e),ct=c(e,"P",{"data-svelte-h":!0}),m(ct)!=="svelte-fhx3bl"&&(ct.textContent=Wa),_s=a(e),f(pt.$$.fragment,e),Ms=a(e),f(mt.$$.fragment,e),ys=a(e),ut=c(e,"P",{"data-svelte-h":!0}),m(ut)!=="svelte-15mvma8"&&(ut.innerHTML=Za),bs=a(e),we=c(e,"DIV",{style:!0,"data-svelte-h":!0}),m(we)!=="svelte-18u0t8d"&&(we.innerHTML=La),Ts=a(e),f(ht.$$.fragment,e),ks=a(e),ft=c(e,"P",{"data-svelte-h":!0}),m(ft)!=="svelte-1a5uezo"&&(ft.innerHTML=Ba),ws=a(e),gt=c(e,"P",{"data-svelte-h":!0}),m(gt)!=="svelte-6pz1dp"&&(gt.innerHTML=Ga),vs=a(e),f(_t.$$.fragment,e),$s=a(e),Mt=c(e,"P",{"data-svelte-h":!0}),m(Mt)!=="svelte-mldh40"&&(Mt.innerHTML=Ha),Cs=a(e),yt=c(e,"P",{"data-svelte-h":!0}),m(yt)!=="svelte-qdi6jq"&&(yt.innerHTML=Na),js=a(e),f(bt.$$.fragment,e),xs=a(e),Tt=c(e,"P",{"data-svelte-h":!0}),m(Tt)!=="svelte-ha0jr5"&&(Tt.innerHTML=Ra),Js=a(e),f(kt.$$.fragment,e),Fs=a(e),wt=c(e,"P",{"data-svelte-h":!0}),m(wt)!=="svelte-ddc6j0"&&(wt.textContent=Xa),zs=a(e),f(vt.$$.fragment,e),Us=a(e),$t=c(e,"UL",{"data-svelte-h":!0}),m($t)!=="svelte-gwzwmb"&&($t.innerHTML=Va),Is=a(e),f(Ct.$$.fragment,e),qs=a(e),V=c(e,"DIV",{class:!0});var D=j(V);f(jt.$$.fragment,D),no=a(D),on=c(D,"P",{"data-svelte-h":!0}),m(on)!=="svelte-q2r04i"&&(on.innerHTML=Sa),so=a(D),an=c(D,"P",{"data-svelte-h":!0}),m(an)!=="svelte-28p57e"&&(an.innerHTML=Pa),oo=a(D),rn=c(D,"P",{"data-svelte-h":!0}),m(rn)!=="svelte-qr3t5r"&&(rn.innerHTML=Ea),ao=a(D),f(ve.$$.fragment,D),D.forEach(s),Ws=a(e),f(xt.$$.fragment,e),Zs=a(e),S=c(e,"DIV",{class:!0});var K=j(S);f(Jt.$$.fragment,K),ro=a(K),ln=c(K,"P",{"data-svelte-h":!0}),m(ln)!=="svelte-1g3elk2"&&(ln.textContent=Qa),io=a(K),dn=c(K,"P",{"data-svelte-h":!0}),m(dn)!=="svelte-u3dlub"&&(dn.innerHTML=Ya),lo=a(K),cn=c(K,"P",{"data-svelte-h":!0}),m(cn)!=="svelte-hswkmf"&&(cn.innerHTML=Aa),co=a(K),he=c(K,"DIV",{class:!0});var ye=j(he);f(Ft.$$.fragment,ye),po=a(ye),pn=c(ye,"P",{"data-svelte-h":!0}),m(pn)!=="svelte-x7cums"&&(pn.innerHTML=Oa),mo=a(ye),f($e.$$.fragment,ye),ye.forEach(s),K.forEach(s),Ls=a(e),f(zt.$$.fragment,e),Bs=a(e),P=c(e,"DIV",{class:!0});var ee=j(P);f(Ut.$$.fragment,ee),uo=a(ee),mn=c(ee,"P",{"data-svelte-h":!0}),m(mn)!=="svelte-2fpz9j"&&(mn.textContent=Da),ho=a(ee),un=c(ee,"P",{"data-svelte-h":!0}),m(un)!=="svelte-u3dlub"&&(un.innerHTML=Ka),fo=a(ee),hn=c(ee,"P",{"data-svelte-h":!0}),m(hn)!=="svelte-hswkmf"&&(hn.innerHTML=er),go=a(ee),re=c(ee,"DIV",{class:!0});var de=j(re);f(It.$$.fragment,de),_o=a(de),fn=c(de,"P",{"data-svelte-h":!0}),m(fn)!=="svelte-r5xkl4"&&(fn.innerHTML=tr),Mo=a(de),f(Ce.$$.fragment,de),yo=a(de),f(je.$$.fragment,de),de.forEach(s),ee.forEach(s),Gs=a(e),f(qt.$$.fragment,e),Hs=a(e),z=c(e,"DIV",{class:!0});var N=j(z);f(Wt.$$.fragment,N),bo=a(N),gn=c(N,"P",{"data-svelte-h":!0}),m(gn)!=="svelte-1r7clz4"&&(gn.textContent=nr),To=a(N),_n=c(N,"P",{"data-svelte-h":!0}),m(_n)!=="svelte-tvkb3z"&&(_n.innerHTML=sr),ko=a(N),Mn=c(N,"P",{"data-svelte-h":!0}),m(Mn)!=="svelte-10ugs3m"&&(Mn.innerHTML=or),wo=a(N),yn=c(N,"P",{"data-svelte-h":!0}),m(yn)!=="svelte-u3dlub"&&(yn.innerHTML=ar),vo=a(N),bn=c(N,"P",{"data-svelte-h":!0}),m(bn)!=="svelte-hswkmf"&&(bn.innerHTML=rr),$o=a(N),Y=c(N,"DIV",{class:!0});var te=j(Y);f(Zt.$$.fragment,te),Co=a(te),Tn=c(te,"P",{"data-svelte-h":!0}),m(Tn)!=="svelte-144ng0m"&&(Tn.innerHTML=ir),jo=a(te),f(xe.$$.fragment,te),xo=a(te),f(Je.$$.fragment,te),Jo=a(te),f(Fe.$$.fragment,te),te.forEach(s),N.forEach(s),Ns=a(e),f(Lt.$$.fragment,e),Rs=a(e),E=c(e,"DIV",{class:!0});var ne=j(E);f(Bt.$$.fragment,ne),Fo=a(ne),kn=c(ne,"P",{"data-svelte-h":!0}),m(kn)!=="svelte-830o8y"&&(kn.textContent=lr),zo=a(ne),wn=c(ne,"P",{"data-svelte-h":!0}),m(wn)!=="svelte-u3dlub"&&(wn.innerHTML=dr),Uo=a(ne),vn=c(ne,"P",{"data-svelte-h":!0}),m(vn)!=="svelte-hswkmf"&&(vn.innerHTML=cr),Io=a(ne),ie=c(ne,"DIV",{class:!0});var ce=j(ie);f(Gt.$$.fragment,ce),qo=a(ce),$n=c(ce,"P",{"data-svelte-h":!0}),m($n)!=="svelte-tr24bu"&&($n.innerHTML=pr),Wo=a(ce),f(ze.$$.fragment,ce),Zo=a(ce),f(Ue.$$.fragment,ce),ce.forEach(s),ne.forEach(s),Xs=a(e),f(Ht.$$.fragment,e),Vs=a(e),U=c(e,"DIV",{class:!0});var R=j(U);f(Nt.$$.fragment,R),Lo=a(R),Cn=c(R,"P",{"data-svelte-h":!0}),m(Cn)!=="svelte-1vqhmd7"&&(Cn.textContent=mr),Bo=a(R),jn=c(R,"P",{"data-svelte-h":!0}),m(jn)!=="svelte-11z45y7"&&(jn.innerHTML=ur),Go=a(R),xn=c(R,"P",{"data-svelte-h":!0}),m(xn)!=="svelte-idybz1"&&(xn.innerHTML=hr),Ho=a(R),Jn=c(R,"P",{"data-svelte-h":!0}),m(Jn)!=="svelte-1pplc4a"&&(Jn.textContent=fr),No=a(R),Fn=c(R,"UL",{"data-svelte-h":!0}),m(Fn)!=="svelte-1w7z84m"&&(Fn.innerHTML=gr),Ro=a(R),A=c(R,"DIV",{class:!0});var se=j(A);f(Rt.$$.fragment,se),Xo=a(se),zn=c(se,"P",{"data-svelte-h":!0}),m(zn)!=="svelte-dti72j"&&(zn.innerHTML=_r),Vo=a(se),f(Ie.$$.fragment,se),So=a(se),f(qe.$$.fragment,se),Po=a(se),f(We.$$.fragment,se),se.forEach(s),R.forEach(s),Ss=a(e),f(Xt.$$.fragment,e),Ps=a(e),I=c(e,"DIV",{class:!0});var X=j(I);f(Vt.$$.fragment,X),Eo=a(X),Un=c(X,"P",{"data-svelte-h":!0}),m(Un)!=="svelte-lgxco8"&&(Un.textContent=Mr),Qo=a(X),In=c(X,"P",{"data-svelte-h":!0}),m(In)!=="svelte-11z45y7"&&(In.innerHTML=yr),Yo=a(X),qn=c(X,"P",{"data-svelte-h":!0}),m(qn)!=="svelte-idybz1"&&(qn.innerHTML=br),Ao=a(X),Wn=c(X,"P",{"data-svelte-h":!0}),m(Wn)!=="svelte-1pplc4a"&&(Wn.textContent=Tr),Oo=a(X),Zn=c(X,"UL",{"data-svelte-h":!0}),m(Zn)!=="svelte-1w7z84m"&&(Zn.innerHTML=kr),Do=a(X),O=c(X,"DIV",{class:!0});var oe=j(O);f(St.$$.fragment,oe),Ko=a(oe),Ln=c(oe,"P",{"data-svelte-h":!0}),m(Ln)!=="svelte-dti72j"&&(Ln.innerHTML=wr),ea=a(oe),f(Ze.$$.fragment,oe),ta=a(oe),f(Le.$$.fragment,oe),na=a(oe),f(Be.$$.fragment,oe),oe.forEach(s),X.forEach(s),Es=a(e),f(Pt.$$.fragment,e),Qs=a(e),H=c(e,"DIV",{class:!0});var Q=j(H);f(Et.$$.fragment,Q),sa=a(Q),Bn=c(Q,"P",{"data-svelte-h":!0}),m(Bn)!=="svelte-1g3elk2"&&(Bn.textContent=vr),oa=a(Q),Gn=c(Q,"P",{"data-svelte-h":!0}),m(Gn)!=="svelte-3ge3jn"&&(Gn.innerHTML=$r),aa=a(Q),Hn=c(Q,"P",{"data-svelte-h":!0}),m(Hn)!=="svelte-1be7e3c"&&(Hn.innerHTML=Cr),ra=a(Q),f(Ge.$$.fragment,Q),ia=a(Q),fe=c(Q,"DIV",{class:!0});var be=j(fe);f(Qt.$$.fragment,be),la=a(be),Nn=c(be,"P",{"data-svelte-h":!0}),m(Nn)!=="svelte-ojarxc"&&(Nn.innerHTML=jr),da=a(be),f(He.$$.fragment,be),be.forEach(s),Q.forEach(s),Ys=a(e),f(Yt.$$.fragment,e),As=a(e),Me=c(e,"DIV",{class:!0});var nn=j(Me);f(At.$$.fragment,nn),ca=a(nn),ge=c(nn,"DIV",{class:!0});var Te=j(ge);f(Ot.$$.fragment,Te),pa=a(Te),Rn=c(Te,"P",{"data-svelte-h":!0}),m(Rn)!=="svelte-7p1hx0"&&(Rn.innerHTML=xr),ma=a(Te),f(Ne.$$.fragment,Te),Te.forEach(s),nn.forEach(s),Os=a(e),f(Dt.$$.fragment,e),Ds=a(e),C=c(e,"DIV",{class:!0});var q=j(C);f(Kt.$$.fragment,q),ua=a(q),Xn=c(q,"P",{"data-svelte-h":!0}),m(Xn)!=="svelte-1r7clz4"&&(Xn.textContent=Jr),ha=a(q),Vn=c(q,"P",{"data-svelte-h":!0}),m(Vn)!=="svelte-tvkb3z"&&(Vn.innerHTML=Fr),fa=a(q),Sn=c(q,"P",{"data-svelte-h":!0}),m(Sn)!=="svelte-10ugs3m"&&(Sn.innerHTML=zr),ga=a(q),Pn=c(q,"P",{"data-svelte-h":!0}),m(Pn)!=="svelte-3ge3jn"&&(Pn.innerHTML=Ur),_a=a(q),En=c(q,"P",{"data-svelte-h":!0}),m(En)!=="svelte-1be7e3c"&&(En.innerHTML=Ir),Ma=a(q),f(Re.$$.fragment,q),ya=a(q),_e=c(q,"DIV",{class:!0});var ke=j(_e);f(en.$$.fragment,ke),ba=a(ke),Qn=c(ke,"P",{"data-svelte-h":!0}),m(Qn)!=="svelte-6mlkpi"&&(Qn.innerHTML=qr),Ta=a(ke),f(Xe.$$.fragment,ke),ke.forEach(s),q.forEach(s),Ks=a(e),f(tn.$$.fragment,e),eo=a(e),Yn=c(e,"P",{}),j(Yn).forEach(s),this.h()},h(){x(n,"name","hf:doc:metadata"),x(n,"content",pi),Nr(we,"text-align","center"),x(V,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(he,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(S,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(re,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(P,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(Y,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(z,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(ie,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(E,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(A,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(U,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(O,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(I,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(fe,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(H,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(ge,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(Me,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(_e,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),x(C,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,t){i(document.head,n),r(e,b,t),r(e,l,t),r(e,u,t),g(w,e,t),r(e,p,t),g(k,e,t),r(e,pe,t),r(e,B,t),r(e,me,t),r(e,G,t),r(e,ue,t),r(e,T,t),r(e,An,t),r(e,Ve,t),r(e,On,t),g(Se,e,t),r(e,Dn,t),r(e,Pe,t),r(e,Kn,t),r(e,Ee,t),r(e,es,t),r(e,Qe,t),r(e,ts,t),g(Ye,e,t),r(e,ns,t),r(e,Ae,t),r(e,ss,t),g(Oe,e,t),r(e,os,t),r(e,De,t),r(e,as,t),r(e,Ke,t),r(e,rs,t),r(e,et,t),r(e,is,t),g(tt,e,t),r(e,ls,t),r(e,nt,t),r(e,ds,t),g(st,e,t),r(e,cs,t),r(e,ot,t),r(e,ps,t),g(at,e,t),r(e,ms,t),r(e,rt,t),r(e,us,t),r(e,it,t),r(e,hs,t),g(lt,e,t),r(e,fs,t),r(e,dt,t),r(e,gs,t),r(e,ct,t),r(e,_s,t),g(pt,e,t),r(e,Ms,t),g(mt,e,t),r(e,ys,t),r(e,ut,t),r(e,bs,t),r(e,we,t),r(e,Ts,t),g(ht,e,t),r(e,ks,t),r(e,ft,t),r(e,ws,t),r(e,gt,t),r(e,vs,t),g(_t,e,t),r(e,$s,t),r(e,Mt,t),r(e,Cs,t),r(e,yt,t),r(e,js,t),g(bt,e,t),r(e,xs,t),r(e,Tt,t),r(e,Js,t),g(kt,e,t),r(e,Fs,t),r(e,wt,t),r(e,zs,t),g(vt,e,t),r(e,Us,t),r(e,$t,t),r(e,Is,t),g(Ct,e,t),r(e,qs,t),r(e,V,t),g(jt,V,null),i(V,no),i(V,on),i(V,so),i(V,an),i(V,oo),i(V,rn),i(V,ao),g(ve,V,null),r(e,Ws,t),g(xt,e,t),r(e,Zs,t),r(e,S,t),g(Jt,S,null),i(S,ro),i(S,ln),i(S,io),i(S,dn),i(S,lo),i(S,cn),i(S,co),i(S,he),g(Ft,he,null),i(he,po),i(he,pn),i(he,mo),g($e,he,null),r(e,Ls,t),g(zt,e,t),r(e,Bs,t),r(e,P,t),g(Ut,P,null),i(P,uo),i(P,mn),i(P,ho),i(P,un),i(P,fo),i(P,hn),i(P,go),i(P,re),g(It,re,null),i(re,_o),i(re,fn),i(re,Mo),g(Ce,re,null),i(re,yo),g(je,re,null),r(e,Gs,t),g(qt,e,t),r(e,Hs,t),r(e,z,t),g(Wt,z,null),i(z,bo),i(z,gn),i(z,To),i(z,_n),i(z,ko),i(z,Mn),i(z,wo),i(z,yn),i(z,vo),i(z,bn),i(z,$o),i(z,Y),g(Zt,Y,null),i(Y,Co),i(Y,Tn),i(Y,jo),g(xe,Y,null),i(Y,xo),g(Je,Y,null),i(Y,Jo),g(Fe,Y,null),r(e,Ns,t),g(Lt,e,t),r(e,Rs,t),r(e,E,t),g(Bt,E,null),i(E,Fo),i(E,kn),i(E,zo),i(E,wn),i(E,Uo),i(E,vn),i(E,Io),i(E,ie),g(Gt,ie,null),i(ie,qo),i(ie,$n),i(ie,Wo),g(ze,ie,null),i(ie,Zo),g(Ue,ie,null),r(e,Xs,t),g(Ht,e,t),r(e,Vs,t),r(e,U,t),g(Nt,U,null),i(U,Lo),i(U,Cn),i(U,Bo),i(U,jn),i(U,Go),i(U,xn),i(U,Ho),i(U,Jn),i(U,No),i(U,Fn),i(U,Ro),i(U,A),g(Rt,A,null),i(A,Xo),i(A,zn),i(A,Vo),g(Ie,A,null),i(A,So),g(qe,A,null),i(A,Po),g(We,A,null),r(e,Ss,t),g(Xt,e,t),r(e,Ps,t),r(e,I,t),g(Vt,I,null),i(I,Eo),i(I,Un),i(I,Qo),i(I,In),i(I,Yo),i(I,qn),i(I,Ao),i(I,Wn),i(I,Oo),i(I,Zn),i(I,Do),i(I,O),g(St,O,null),i(O,Ko),i(O,Ln),i(O,ea),g(Ze,O,null),i(O,ta),g(Le,O,null),i(O,na),g(Be,O,null),r(e,Es,t),g(Pt,e,t),r(e,Qs,t),r(e,H,t),g(Et,H,null),i(H,sa),i(H,Bn),i(H,oa),i(H,Gn),i(H,aa),i(H,Hn),i(H,ra),g(Ge,H,null),i(H,ia),i(H,fe),g(Qt,fe,null),i(fe,la),i(fe,Nn),i(fe,da),g(He,fe,null),r(e,Ys,t),g(Yt,e,t),r(e,As,t),r(e,Me,t),g(At,Me,null),i(Me,ca),i(Me,ge),g(Ot,ge,null),i(ge,pa),i(ge,Rn),i(ge,ma),g(Ne,ge,null),r(e,Os,t),g(Dt,e,t),r(e,Ds,t),r(e,C,t),g(Kt,C,null),i(C,ua),i(C,Xn),i(C,ha),i(C,Vn),i(C,fa),i(C,Sn),i(C,ga),i(C,Pn),i(C,_a),i(C,En),i(C,Ma),g(Re,C,null),i(C,ya),i(C,_e),g(en,_e,null),i(_e,ba),i(_e,Qn),i(_e,Ta),g(Xe,_e,null),r(e,Ks,t),g(tn,e,t),r(e,eo,t),r(e,Yn,t),to=!0},p(e,[t]){const D={};t&2&&(D.$$scope={dirty:t,ctx:e}),ve.$set(D);const K={};t&2&&(K.$$scope={dirty:t,ctx:e}),$e.$set(K);const ye={};t&2&&(ye.$$scope={dirty:t,ctx:e}),Ce.$set(ye);const ee={};t&2&&(ee.$$scope={dirty:t,ctx:e}),je.$set(ee);const de={};t&2&&(de.$$scope={dirty:t,ctx:e}),xe.$set(de);const N={};t&2&&(N.$$scope={dirty:t,ctx:e}),Je.$set(N);const te={};t&2&&(te.$$scope={dirty:t,ctx:e}),Fe.$set(te);const ne={};t&2&&(ne.$$scope={dirty:t,ctx:e}),ze.$set(ne);const ce={};t&2&&(ce.$$scope={dirty:t,ctx:e}),Ue.$set(ce);const R={};t&2&&(R.$$scope={dirty:t,ctx:e}),Ie.$set(R);const se={};t&2&&(se.$$scope={dirty:t,ctx:e}),qe.$set(se);const X={};t&2&&(X.$$scope={dirty:t,ctx:e}),We.$set(X);const oe={};t&2&&(oe.$$scope={dirty:t,ctx:e}),Ze.$set(oe);const Q={};t&2&&(Q.$$scope={dirty:t,ctx:e}),Le.$set(Q);const be={};t&2&&(be.$$scope={dirty:t,ctx:e}),Be.$set(be);const nn={};t&2&&(nn.$$scope={dirty:t,ctx:e}),Ge.$set(nn);const Te={};t&2&&(Te.$$scope={dirty:t,ctx:e}),He.$set(Te);const q={};t&2&&(q.$$scope={dirty:t,ctx:e}),Ne.$set(q);const ke={};t&2&&(ke.$$scope={dirty:t,ctx:e}),Re.$set(ke);const Wr={};t&2&&(Wr.$$scope={dirty:t,ctx:e}),Xe.$set(Wr)},i(e){to||(_(w.$$.fragment,e),_(k.$$.fragment,e),_(Se.$$.fragment,e),_(Ye.$$.fragment,e),_(Oe.$$.fragment,e),_(tt.$$.fragment,e),_(st.$$.fragment,e),_(at.$$.fragment,e),_(lt.$$.fragment,e),_(pt.$$.fragment,e),_(mt.$$.fragment,e),_(ht.$$.fragment,e),_(_t.$$.fragment,e),_(bt.$$.fragment,e),_(kt.$$.fragment,e),_(vt.$$.fragment,e),_(Ct.$$.fragment,e),_(jt.$$.fragment,e),_(ve.$$.fragment,e),_(xt.$$.fragment,e),_(Jt.$$.fragment,e),_(Ft.$$.fragment,e),_($e.$$.fragment,e),_(zt.$$.fragment,e),_(Ut.$$.fragment,e),_(It.$$.fragment,e),_(Ce.$$.fragment,e),_(je.$$.fragment,e),_(qt.$$.fragment,e),_(Wt.$$.fragment,e),_(Zt.$$.fragment,e),_(xe.$$.fragment,e),_(Je.$$.fragment,e),_(Fe.$$.fragment,e),_(Lt.$$.fragment,e),_(Bt.$$.fragment,e),_(Gt.$$.fragment,e),_(ze.$$.fragment,e),_(Ue.$$.fragment,e),_(Ht.$$.fragment,e),_(Nt.$$.fragment,e),_(Rt.$$.fragment,e),_(Ie.$$.fragment,e),_(qe.$$.fragment,e),_(We.$$.fragment,e),_(Xt.$$.fragment,e),_(Vt.$$.fragment,e),_(St.$$.fragment,e),_(Ze.$$.fragment,e),_(Le.$$.fragment,e),_(Be.$$.fragment,e),_(Pt.$$.fragment,e),_(Et.$$.fragment,e),_(Ge.$$.fragment,e),_(Qt.$$.fragment,e),_(He.$$.fragment,e),_(Yt.$$.fragment,e),_(At.$$.fragment,e),_(Ot.$$.fragment,e),_(Ne.$$.fragment,e),_(Dt.$$.fragment,e),_(Kt.$$.fragment,e),_(Re.$$.fragment,e),_(en.$$.fragment,e),_(Xe.$$.fragment,e),_(tn.$$.fragment,e),to=!0)},o(e){M(w.$$.fragment,e),M(k.$$.fragment,e),M(Se.$$.fragment,e),M(Ye.$$.fragment,e),M(Oe.$$.fragment,e),M(tt.$$.fragment,e),M(st.$$.fragment,e),M(at.$$.fragment,e),M(lt.$$.fragment,e),M(pt.$$.fragment,e),M(mt.$$.fragment,e),M(ht.$$.fragment,e),M(_t.$$.fragment,e),M(bt.$$.fragment,e),M(kt.$$.fragment,e),M(vt.$$.fragment,e),M(Ct.$$.fragment,e),M(jt.$$.fragment,e),M(ve.$$.fragment,e),M(xt.$$.fragment,e),M(Jt.$$.fragment,e),M(Ft.$$.fragment,e),M($e.$$.fragment,e),M(zt.$$.fragment,e),M(Ut.$$.fragment,e),M(It.$$.fragment,e),M(Ce.$$.fragment,e),M(je.$$.fragment,e),M(qt.$$.fragment,e),M(Wt.$$.fragment,e),M(Zt.$$.fragment,e),M(xe.$$.fragment,e),M(Je.$$.fragment,e),M(Fe.$$.fragment,e),M(Lt.$$.fragment,e),M(Bt.$$.fragment,e),M(Gt.$$.fragment,e),M(ze.$$.fragment,e),M(Ue.$$.fragment,e),M(Ht.$$.fragment,e),M(Nt.$$.fragment,e),M(Rt.$$.fragment,e),M(Ie.$$.fragment,e),M(qe.$$.fragment,e),M(We.$$.fragment,e),M(Xt.$$.fragment,e),M(Vt.$$.fragment,e),M(St.$$.fragment,e),M(Ze.$$.fragment,e),M(Le.$$.fragment,e),M(Be.$$.fragment,e),M(Pt.$$.fragment,e),M(Et.$$.fragment,e),M(Ge.$$.fragment,e),M(Qt.$$.fragment,e),M(He.$$.fragment,e),M(Yt.$$.fragment,e),M(At.$$.fragment,e),M(Ot.$$.fragment,e),M(Ne.$$.fragment,e),M(Dt.$$.fragment,e),M(Kt.$$.fragment,e),M(Re.$$.fragment,e),M(en.$$.fragment,e),M(Xe.$$.fragment,e),M(tn.$$.fragment,e),to=!1},d(e){e&&(s(b),s(l),s(u),s(p),s(pe),s(B),s(me),s(G),s(ue),s(T),s(An),s(Ve),s(On),s(Dn),s(Pe),s(Kn),s(Ee),s(es),s(Qe),s(ts),s(ns),s(Ae),s(ss),s(os),s(De),s(as),s(Ke),s(rs),s(et),s(is),s(ls),s(nt),s(ds),s(cs),s(ot),s(ps),s(ms),s(rt),s(us),s(it),s(hs),s(fs),s(dt),s(gs),s(ct),s(_s),s(Ms),s(ys),s(ut),s(bs),s(we),s(Ts),s(ks),s(ft),s(ws),s(gt),s(vs),s($s),s(Mt),s(Cs),s(yt),s(js),s(xs),s(Tt),s(Js),s(Fs),s(wt),s(zs),s(Us),s($t),s(Is),s(qs),s(V),s(Ws),s(Zs),s(S),s(Ls),s(Bs),s(P),s(Gs),s(Hs),s(z),s(Ns),s(Rs),s(E),s(Xs),s(Vs),s(U),s(Ss),s(Ps),s(I),s(Es),s(Qs),s(H),s(Ys),s(As),s(Me),s(Os),s(Ds),s(C),s(Ks),s(eo),s(Yn)),s(n),y(w,e),y(k,e),y(Se,e),y(Ye,e),y(Oe,e),y(tt,e),y(st,e),y(at,e),y(lt,e),y(pt,e),y(mt,e),y(ht,e),y(_t,e),y(bt,e),y(kt,e),y(vt,e),y(Ct,e),y(jt),y(ve),y(xt,e),y(Jt),y(Ft),y($e),y(zt,e),y(Ut),y(It),y(Ce),y(je),y(qt,e),y(Wt),y(Zt),y(xe),y(Je),y(Fe),y(Lt,e),y(Bt),y(Gt),y(ze),y(Ue),y(Ht,e),y(Nt),y(Rt),y(Ie),y(qe),y(We),y(Xt,e),y(Vt),y(St),y(Ze),y(Le),y(Be),y(Pt,e),y(Et),y(Ge),y(Qt),y(He),y(Yt,e),y(At),y(Ot),y(Ne),y(Dt,e),y(Kt),y(Re),y(en),y(Xe),y(tn,e)}}}const pi='{"title":"Mistral","local":"mistral","sections":[{"title":"개요","local":"overview","sections":[{"title":"아키텍처 세부사항","local":"architectural-details","sections":[],"depth":3},{"title":"라이선스","local":"license","sections":[],"depth":3}],"depth":2},{"title":"사용 팁","local":"usage-tips","sections":[],"depth":2},{"title":"플래시 어텐션을 이용한 미스트랄 속도향상","local":"speeding-up-mistral-by-using-flash-attention","sections":[{"title":"기대하는 속도 향상","local":"expected-speedups","sections":[],"depth":3},{"title":"슬라이딩 윈도우 어텐션","local":"sliding-window-attention","sections":[],"depth":3}],"depth":2},{"title":"양자화로 미스트랄 크기 줄이기","local":"shrinking-down-mistral-using-quantization","sections":[],"depth":2},{"title":"리소스","local":"resources","sections":[],"depth":2},{"title":"MistralConfig","local":"transformers.MistralConfig ][ transformers.MistralConfig","sections":[],"depth":2},{"title":"MistralModel","local":"transformers.MistralModel ][ transformers.MistralModel","sections":[],"depth":2},{"title":"MistralForCausalLM","local":"transformers.MistralForCausalLM ][ transformers.MistralForCausalLM","sections":[],"depth":2},{"title":"MistralForSequenceClassification","local":"transformers.MistralForSequenceClassification ][ transformers.MistralForSequenceClassification","sections":[],"depth":2},{"title":"MistralForTokenClassification","local":"transformers.MistralForTokenClassification ][ transformers.MistralForTokenClassification","sections":[],"depth":2},{"title":"FlaxMistralModel","local":"transformers.FlaxMistralModel ][ transformers.FlaxMistralModel","sections":[],"depth":2},{"title":"FlaxMistralForCausalLM","local":"transformers.FlaxMistralForCausalLM ][ transformers.FlaxMistralForCausalLM","sections":[],"depth":2},{"title":"TFMistralModel","local":"transformers.TFMistralModel ][ transformers.TFMistralModel","sections":[],"depth":2},{"title":"TFMistralForCausalLM","local":"transformers.TFMistralForCausalLM ][ transformers.TFMistralForCausalLM","sections":[],"depth":2},{"title":"TFMistralForSequenceClassification","local":"transformers.TFMistralForSequenceClassification ][ transformers.TFMistralForSequenceClassification","sections":[],"depth":2}],"depth":1}';function mi(v){return Lr(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Ti extends Br{constructor(n){super(),Gr(this,n,mi,ci,Zr,{})}}export{Ti as component};
