import{s as Ct,o as jt,n as Be}from"../chunks/scheduler.bdbef820.js";import{S as $t,i as It,g as i,s,r as h,A as Ft,h as d,f as o,c as a,j as re,u as f,x as m,k as le,y as c,a as n,v as g,d as b,t as _,w as y}from"../chunks/index.33f81d56.js";import{T as vt}from"../chunks/Tip.34194030.js";import{D as Me}from"../chunks/Docstring.abcbe1ac.js";import{C as Te}from"../chunks/CodeBlock.3bad7fc9.js";import{E as Ut}from"../chunks/ExampleCodeBlock.16b3b633.js";import{H as _e,E as Dt}from"../chunks/getInferenceSnippets.64cd9466.js";function Rt($){let r,T="Example:",p,u,M;return u=new Te({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMERicnhDb25maWclMkMlMjBEYnJ4TW9kZWwlMEElMEElMjMlMjBJbml0aWFsaXppbmclMjBhJTIwRGJyeCUyMGNvbmZpZ3VyYXRpb24lMEFjb25maWd1cmF0aW9uJTIwJTNEJTIwRGJyeENvbmZpZyhuX2xheWVycyUzRDIlMkMlMjBkX21vZGVsJTNEMjU2JTJDJTIwbl9oZWFkcyUzRDglMkMlMjB2b2NhYl9zaXplJTNEMTI4KSUwQSUwQSUyMyUyMEluaXRpYWxpemluZyUyMGElMjBtb2RlbCUyMCh3aXRoJTIwcmFuZG9tJTIwd2VpZ2h0cyklMjBmcm9tJTIwdGhlJTIwY29uZmlndXJhdGlvbiUwQW1vZGVsJTIwJTNEJTIwRGJyeE1vZGVsKGNvbmZpZ3VyYXRpb24pJTBBJTBBJTIzJTIwQWNjZXNzaW5nJTIwdGhlJTIwbW9kZWwlMjBjb25maWd1cmF0aW9uJTBBY29uZmlndXJhdGlvbiUyMCUzRCUyMG1vZGVsLmNvbmZpZw==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> DbrxConfig, DbrxModel

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a Dbrx configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = DbrxConfig(n_layers=<span class="hljs-number">2</span>, d_model=<span class="hljs-number">256</span>, n_heads=<span class="hljs-number">8</span>, vocab_size=<span class="hljs-number">128</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a model (with random weights) from the configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = DbrxModel(configuration)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Accessing the model configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = model.config`,wrap:!1}}),{c(){r=i("p"),r.textContent=T,p=s(),h(u.$$.fragment)},l(l){r=d(l,"P",{"data-svelte-h":!0}),m(r)!=="svelte-11lpom8"&&(r.textContent=T),p=a(l),f(u.$$.fragment,l)},m(l,w){n(l,r,w),n(l,p,w),g(u,l,w),M=!0},p:Be,i(l){M||(b(u.$$.fragment,l),M=!0)},o(l){_(u.$$.fragment,l),M=!1},d(l){l&&(o(r),o(p)),y(u,l)}}}function Zt($){let r,T=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){r=i("p"),r.innerHTML=T},l(p){r=d(p,"P",{"data-svelte-h":!0}),m(r)!=="svelte-fincs2"&&(r.innerHTML=T)},m(p,u){n(p,r,u)},p:Be,d(p){p&&o(r)}}}function zt($){let r,T=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){r=i("p"),r.innerHTML=T},l(p){r=d(p,"P",{"data-svelte-h":!0}),m(r)!=="svelte-fincs2"&&(r.innerHTML=T)},m(p,u){n(p,r,u)},p:Be,d(p){p&&o(r)}}}function Gt($){let r,T="Example:",p,u,M;return u=new Te({props:{code:"JTNFJTNFJTIwZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBEYnJ4Rm9yQ2F1c2FsTE0lMEElMEElM0UlM0UlMjBtb2RlbCUyMCUzRCUyMERicnhGb3JDYXVzYWxMTS5mcm9tX3ByZXRyYWluZWQoJTIyZGF0YWJyaWNrcyUyRmRicngtaW5zdHJ1Y3QlMjIpJTBBJTNFJTNFJTIwdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIyZGF0YWJyaWNrcyUyRmRicngtaW5zdHJ1Y3QlMjIpJTBBJTBBJTNFJTNFJTIwcHJvbXB0JTIwJTNEJTIwJTIySGV5JTJDJTIwYXJlJTIweW91JTIwY29uc2Npb3VzJTNGJTIwQ2FuJTIweW91JTIwdGFsayUyMHRvJTIwbWUlM0YlMjIlMEElM0UlM0UlMjBpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIocHJvbXB0JTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMiklMEElMEElM0UlM0UlMjAlMjMlMjBHZW5lcmF0ZSUwQSUzRSUzRSUyMGdlbmVyYXRlX2lkcyUyMCUzRCUyMG1vZGVsLmdlbmVyYXRlKGlucHV0cy5pbnB1dF9pZHMlMkMlMjBtYXhfbGVuZ3RoJTNEMzApJTBBJTNFJTNFJTIwdG9rZW5pemVyLmJhdGNoX2RlY29kZShnZW5lcmF0ZV9pZHMlMkMlMjBza2lwX3NwZWNpYWxfdG9rZW5zJTNEVHJ1ZSUyQyUyMGNsZWFuX3VwX3Rva2VuaXphdGlvbl9zcGFjZXMlM0RGYWxzZSklNUIwJTVEJTBBJTIySGV5JTJDJTIwYXJlJTIweW91JTIwY29uc2Npb3VzJTNGJTIwQ2FuJTIweW91JTIwdGFsayUyMHRvJTIwbWUlM0YlNUNuSSdtJTIwbm90JTIwY29uc2Npb3VzJTJDJTIwYnV0JTIwSSUyMGNhbiUyMHRhbGslMjB0byUyMHlvdS4lMjI=",highlighted:`&gt;&gt; <span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, DbrxForCausalLM

&gt;&gt; model = DbrxForCausalLM.from_pretrained(<span class="hljs-string">&quot;databricks/dbrx-instruct&quot;</span>)
&gt;&gt; tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;databricks/dbrx-instruct&quot;</span>)

&gt;&gt; prompt = <span class="hljs-string">&quot;Hey, are you conscious? Can you talk to me?&quot;</span>
&gt;&gt; inputs = tokenizer(prompt, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

&gt;&gt; <span class="hljs-comment"># Generate</span>
&gt;&gt; generate_ids = model.generate(inputs.input_ids, max_length=<span class="hljs-number">30</span>)
&gt;&gt; tokenizer.batch_decode(generate_ids, skip_special_tokens=<span class="hljs-literal">True</span>, clean_up_tokenization_spaces=<span class="hljs-literal">False</span>)[<span class="hljs-number">0</span>]
<span class="hljs-string">&quot;Hey, are you conscious? Can you talk to me?\\nI&#x27;m not conscious, but I can talk to you.&quot;</span>`,wrap:!1}}),{c(){r=i("p"),r.textContent=T,p=s(),h(u.$$.fragment)},l(l){r=d(l,"P",{"data-svelte-h":!0}),m(r)!=="svelte-11lpom8"&&(r.textContent=T),p=a(l),f(u.$$.fragment,l)},m(l,w){n(l,r,w),n(l,p,w),g(u,l,w),M=!0},p:Be,i(l){M||(b(u.$$.fragment,l),M=!0)},o(l){_(u.$$.fragment,l),M=!1},d(l){l&&(o(r),o(p)),y(u,l)}}}function Xt($){let r,T,p,u,M,l,w,we,X,lt=`DBRX는 <a href="https://www.isattentionallyouneed.com/" rel="nofollow">트랜스포머 기반의</a> 다음 토큰을 예측하는 디코더 전용 LLM 모델입니다.
총 132B 매개변수를 가진 <em>세밀한</em> 전문가 혼합(MoE) 아키텍처를 사용하며, 이 중 36B 매개변수가 입력마다 활성화됩니다.
12T 토큰의 텍스트와 코드 데이터로 사전 학습되었습니다.`,xe,W,it="Mixtral-8x7B와 Grok-1과 같은 다른 공개 MoE 모델들과 비교했을 때, DBRX는 더 많은 수의 작은 전문가들을 사용하는 세밀한 구조를 가지고 있습니다. DBRX는 16개의 전문가 중 4개를 선택하는 반면, Mixtral-8x7B와 Grok-1은 8개의 전문가 중 2개를 선택합니다.",ke,q,dt=`이는 65배 더 많은 전문가 조합을 가능하게 하며, 이를 통해 모델의 품질이 향상되는 것을 발견했습니다.
DBRX는 회전 위치 인코딩(RoPE), 게이트 선형 유닛(GLU), 그룹 쿼리 어텐션(GQA)을 사용합니다.
BPE 기반 모델이며 <a href="https://github.com/openai/tiktoken" rel="nofollow">tiktoken</a> 저장소에 설명된 GPT-4 토크나이저를 사용합니다.
이러한 선택들은 철저한 평가와 스케일링 실험을 기반으로 이루어졌습니다.`,Je,N,ct=`DBRX는 신중하게 선별된 12T 토큰의 데이터로 사전 학습되었으며, 최대 문맥 길이는 32K 토큰입니다.
이 데이터는 토큰 대비 MPT 계열 모델 학습에 사용된 데이터보다 최소 2배 이상 더 좋은 것으로 추정됩니다.
이 새로운 데이터셋은 데이터 처리를 위한 Apache Spark™와 Databricks 노트북, 그리고 데이터 관리와 거버넌스를 위한 Unity Catalog를 포함한 Databricks 도구 전체를 활용하여 개발되었습니다.
우리는 사전 학습을 위해 커리큘럼 학습을 사용했으며, 학습 중 데이터 믹스를 변경하는 방식이 모델 품질을 상당히 개선한다는 것을 발견했습니다.`,ve,E,pt='DBRX Instruct와 DBRX Base에 대한 더 자세한 정보는 이 <a href="https://www.databricks.com/blog/introducing-dbrx-new-state-art-open-llm" rel="nofollow">기술 블로그 포스트</a>에서 확인할 수 있습니다.',Ue,V,ut='이 모델은 <a href="https://huggingface.co/eitanturok" rel="nofollow">eitan-turok</a>와 <a href="https://huggingface.co/abhi-db" rel="nofollow">abhi-db</a>가 기여했습니다. 원본 코드는 <a href="https://github.com/databricks/dbrx-instruct" rel="nofollow">이곳</a>에서 찾을 수 있지만, 최신 버전이 아닐 수 있습니다.',Ce,B,je,L,mt="<code>generate()</code> 메소드는 DBRX를 사용하여 텍스트를 생성하는 데 사용될 수 있습니다. 표준 어텐션 구현, 플래시 어텐션, PyTorch의 스케일된 내적 어텐션(Scaled Dot-Product Attention)을 사용하여 생성할 수 있습니다. 후자의 두 어텐션 구현 방식은 처리 속도를 크게 높여줍니다.",$e,H,Ie,Q,ht='<code>pip install flash-attn</code>를 통해 플래시 어텐션을 설치하면, 더 빠른 생성이 가능합니다. (플래시 어텐션에 대한 HuggingFace 문서는 <a href="https://huggingface.co/docs/transformers/perf_infer_gpu_one#flashattention-2" rel="nofollow">이곳</a>에서 확인할 수 있습니다.)',Fe,Y,De,S,ft='PyTorch의 스케일된 내적 어텐션을 사용하여도 더 빠른 생성이 가능합니다. (스케일된 내적 어텐션에 대한 HuggingFace 문서는 <a href="https://huggingface.co/docs/transformers/perf_infer_gpu_one#pytorch-scaled-dot-product-attention" rel="nofollow">이곳</a>에서 확인할 수 있습니다.)',Re,P,Ze,A,ze,J,O,Le,ie,gt=`This is the configuration class to store the configuration of a <a href="/docs/transformers/main/ko/model_doc/dbrx#transformers.DbrxModel">DbrxModel</a>. It is used to instantiate a Dbrx model according to the
specified arguments, defining the model architecture. Instantiating a configuration with the
defaults will yield a different configuration to that of the <a href="https://huggingface.co/databricks/dbrx-instruct" rel="nofollow">databricks/dbrx-instruct</a> architecture.`,He,de,bt=`Configuration objects inherit from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> and can be used to control the model outputs. Read the
documentation from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> for more information.`,Qe,D,Ge,K,Xe,x,ee,Ye,ce,_t="The bare Dbrx Model outputting raw hidden-states without any specific head on top.",Se,pe,yt=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Pe,ue,Mt=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,Ae,I,te,Oe,me,Tt='The <a href="/docs/transformers/main/ko/model_doc/dbrx#transformers.DbrxModel">DbrxModel</a> forward method, overrides the <code>__call__</code> special method.',Ke,R,We,oe,qe,k,ne,et,he,wt="The DBRX Model transformer for causal language modeling.",tt,fe,xt=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,ot,ge,kt=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,nt,C,se,st,be,Jt='The <a href="/docs/transformers/main/ko/model_doc/dbrx#transformers.DbrxForCausalLM">DbrxForCausalLM</a> forward method, overrides the <code>__call__</code> special method.',at,Z,rt,z,Ne,ae,Ee,ye,Ve;return M=new _e({props:{title:"DBRX",local:"dbrx",headingTag:"h1"}}),w=new _e({props:{title:"개요",local:"overview",headingTag:"h2"}}),B=new _e({props:{title:"사용 예",local:"usage-examples",headingTag:"h2"}}),H=new Te({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMERicnhGb3JDYXVzYWxMTSUyQyUyMEF1dG9Ub2tlbml6ZXIlMEFpbXBvcnQlMjB0b3JjaCUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMmRhdGFicmlja3MlMkZkYnJ4LWluc3RydWN0JTIyJTJDJTIwdG9rZW4lM0QlMjJZT1VSX0hGX1RPS0VOJTIyKSUwQW1vZGVsJTIwJTNEJTIwRGJyeEZvckNhdXNhbExNLmZyb21fcHJldHJhaW5lZCglMEElMjAlMjAlMjAlMjAlMjJkYXRhYnJpY2tzJTJGZGJyeC1pbnN0cnVjdCUyMiUyQyUwQSUyMCUyMCUyMCUyMGRldmljZV9tYXAlM0QlMjJhdXRvJTIyJTJDJTBBJTIwJTIwJTIwJTIwdG9yY2hfZHR5cGUlM0R0b3JjaC5iZmxvYXQxNiUyQyUwQSUyMCUyMCUyMCUyMHRva2VuJTNEJTIyWU9VUl9IRl9UT0tFTiUyMiUyQyUwQSUyMCUyMCUyMCUyMCklMEElMEFpbnB1dF90ZXh0JTIwJTNEJTIwJTIyV2hhdCUyMGRvZXMlMjBpdCUyMHRha2UlMjB0byUyMGJ1aWxkJTIwYSUyMGdyZWF0JTIwTExNJTNGJTIyJTBBbWVzc2FnZXMlMjAlM0QlMjAlNUIlN0IlMjJyb2xlJTIyJTNBJTIwJTIydXNlciUyMiUyQyUyMCUyMmNvbnRlbnQlMjIlM0ElMjBpbnB1dF90ZXh0JTdEJTVEJTBBaW5wdXRfaWRzJTIwJTNEJTIwdG9rZW5pemVyLmFwcGx5X2NoYXRfdGVtcGxhdGUobWVzc2FnZXMlMkMlMjByZXR1cm5fZGljdCUzRFRydWUlMkMlMjB0b2tlbml6ZSUzRFRydWUlMkMlMjBhZGRfZ2VuZXJhdGlvbl9wcm9tcHQlM0RUcnVlJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMikudG8oJTIyY3VkYSUyMiklMEElMEFvdXRwdXRzJTIwJTNEJTIwbW9kZWwuZ2VuZXJhdGUoKippbnB1dF9pZHMlMkMlMjBtYXhfbmV3X3Rva2VucyUzRDIwMCklMEFwcmludCh0b2tlbml6ZXIuZGVjb2RlKG91dHB1dHMlNUIwJTVEKSk=",highlighted:`<span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> DbrxForCausalLM, AutoTokenizer
<span class="hljs-keyword">import</span> torch

tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;databricks/dbrx-instruct&quot;</span>, token=<span class="hljs-string">&quot;YOUR_HF_TOKEN&quot;</span>)
model = DbrxForCausalLM.from_pretrained(
    <span class="hljs-string">&quot;databricks/dbrx-instruct&quot;</span>,
    device_map=<span class="hljs-string">&quot;auto&quot;</span>,
    torch_dtype=torch.bfloat16,
    token=<span class="hljs-string">&quot;YOUR_HF_TOKEN&quot;</span>,
    )

input_text = <span class="hljs-string">&quot;What does it take to build a great LLM?&quot;</span>
messages = [{<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;user&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: input_text}]
input_ids = tokenizer.apply_chat_template(messages, return_dict=<span class="hljs-literal">True</span>, tokenize=<span class="hljs-literal">True</span>, add_generation_prompt=<span class="hljs-literal">True</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).to(<span class="hljs-string">&quot;cuda&quot;</span>)

outputs = model.generate(**input_ids, max_new_tokens=<span class="hljs-number">200</span>)
<span class="hljs-built_in">print</span>(tokenizer.decode(outputs[<span class="hljs-number">0</span>]))`,wrap:!1}}),Y=new Te({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMERicnhGb3JDYXVzYWxMTSUyQyUyMEF1dG9Ub2tlbml6ZXIlMEFpbXBvcnQlMjB0b3JjaCUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMmRhdGFicmlja3MlMkZkYnJ4LWluc3RydWN0JTIyJTJDJTIwdG9rZW4lM0QlMjJZT1VSX0hGX1RPS0VOJTIyKSUwQW1vZGVsJTIwJTNEJTIwRGJyeEZvckNhdXNhbExNLmZyb21fcHJldHJhaW5lZCglMEElMjAlMjAlMjAlMjAlMjJkYXRhYnJpY2tzJTJGZGJyeC1pbnN0cnVjdCUyMiUyQyUwQSUyMCUyMCUyMCUyMGRldmljZV9tYXAlM0QlMjJhdXRvJTIyJTJDJTBBJTIwJTIwJTIwJTIwdG9yY2hfZHR5cGUlM0R0b3JjaC5iZmxvYXQxNiUyQyUwQSUyMCUyMCUyMCUyMHRva2VuJTNEJTIyWU9VUl9IRl9UT0tFTiUyMiUyQyUwQSUyMCUyMCUyMCUyMGF0dG5faW1wbGVtZW50YXRpb24lM0QlMjJmbGFzaF9hdHRlbnRpb25fMiUyMiUyQyUwQSUyMCUyMCUyMCUyMCklMEElMEFpbnB1dF90ZXh0JTIwJTNEJTIwJTIyV2hhdCUyMGRvZXMlMjBpdCUyMHRha2UlMjB0byUyMGJ1aWxkJTIwYSUyMGdyZWF0JTIwTExNJTNGJTIyJTBBbWVzc2FnZXMlMjAlM0QlMjAlNUIlN0IlMjJyb2xlJTIyJTNBJTIwJTIydXNlciUyMiUyQyUyMCUyMmNvbnRlbnQlMjIlM0ElMjBpbnB1dF90ZXh0JTdEJTVEJTBBaW5wdXRfaWRzJTIwJTNEJTIwdG9rZW5pemVyLmFwcGx5X2NoYXRfdGVtcGxhdGUobWVzc2FnZXMlMkMlMjByZXR1cm5fZGljdCUzRFRydWUlMkMlMjB0b2tlbml6ZSUzRFRydWUlMkMlMjBhZGRfZ2VuZXJhdGlvbl9wcm9tcHQlM0RUcnVlJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMikudG8oJTIyY3VkYSUyMiklMEElMEFvdXRwdXRzJTIwJTNEJTIwbW9kZWwuZ2VuZXJhdGUoKippbnB1dF9pZHMlMkMlMjBtYXhfbmV3X3Rva2VucyUzRDIwMCklMEFwcmludCh0b2tlbml6ZXIuZGVjb2RlKG91dHB1dHMlNUIwJTVEKSk=",highlighted:`<span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> DbrxForCausalLM, AutoTokenizer
<span class="hljs-keyword">import</span> torch

tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;databricks/dbrx-instruct&quot;</span>, token=<span class="hljs-string">&quot;YOUR_HF_TOKEN&quot;</span>)
model = DbrxForCausalLM.from_pretrained(
    <span class="hljs-string">&quot;databricks/dbrx-instruct&quot;</span>,
    device_map=<span class="hljs-string">&quot;auto&quot;</span>,
    torch_dtype=torch.bfloat16,
    token=<span class="hljs-string">&quot;YOUR_HF_TOKEN&quot;</span>,
    attn_implementation=<span class="hljs-string">&quot;flash_attention_2&quot;</span>,
    )

input_text = <span class="hljs-string">&quot;What does it take to build a great LLM?&quot;</span>
messages = [{<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;user&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: input_text}]
input_ids = tokenizer.apply_chat_template(messages, return_dict=<span class="hljs-literal">True</span>, tokenize=<span class="hljs-literal">True</span>, add_generation_prompt=<span class="hljs-literal">True</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).to(<span class="hljs-string">&quot;cuda&quot;</span>)

outputs = model.generate(**input_ids, max_new_tokens=<span class="hljs-number">200</span>)
<span class="hljs-built_in">print</span>(tokenizer.decode(outputs[<span class="hljs-number">0</span>]))`,wrap:!1}}),P=new Te({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMERicnhGb3JDYXVzYWxMTSUyQyUyMEF1dG9Ub2tlbml6ZXIlMEFpbXBvcnQlMjB0b3JjaCUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMmRhdGFicmlja3MlMkZkYnJ4LWluc3RydWN0JTIyJTJDJTIwdG9rZW4lM0QlMjJZT1VSX0hGX1RPS0VOJTIyKSUwQW1vZGVsJTIwJTNEJTIwRGJyeEZvckNhdXNhbExNLmZyb21fcHJldHJhaW5lZCglMEElMjAlMjAlMjAlMjAlMjJkYXRhYnJpY2tzJTJGZGJyeC1pbnN0cnVjdCUyMiUyQyUwQSUyMCUyMCUyMCUyMGRldmljZV9tYXAlM0QlMjJhdXRvJTIyJTJDJTBBJTIwJTIwJTIwJTIwdG9yY2hfZHR5cGUlM0R0b3JjaC5iZmxvYXQxNiUyQyUwQSUyMCUyMCUyMCUyMHRva2VuJTNEJTIyWU9VUl9IRl9UT0tFTiUyMiUyQyUwQSUyMCUyMCUyMCUyMGF0dG5faW1wbGVtZW50YXRpb24lM0QlMjJzZHBhJTIyJTJDJTBBJTIwJTIwJTIwJTIwKSUwQSUwQWlucHV0X3RleHQlMjAlM0QlMjAlMjJXaGF0JTIwZG9lcyUyMGl0JTIwdGFrZSUyMHRvJTIwYnVpbGQlMjBhJTIwZ3JlYXQlMjBMTE0lM0YlMjIlMEFtZXNzYWdlcyUyMCUzRCUyMCU1QiU3QiUyMnJvbGUlMjIlM0ElMjAlMjJ1c2VyJTIyJTJDJTIwJTIyY29udGVudCUyMiUzQSUyMGlucHV0X3RleHQlN0QlNUQlMEFpbnB1dF9pZHMlMjAlM0QlMjB0b2tlbml6ZXIuYXBwbHlfY2hhdF90ZW1wbGF0ZShtZXNzYWdlcyUyQyUyMHJldHVybl9kaWN0JTNEVHJ1ZSUyQyUyMHRva2VuaXplJTNEVHJ1ZSUyQyUyMGFkZF9nZW5lcmF0aW9uX3Byb21wdCUzRFRydWUlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyKS50byglMjJjdWRhJTIyKSUwQSUwQW91dHB1dHMlMjAlM0QlMjBtb2RlbC5nZW5lcmF0ZSgqKmlucHV0X2lkcyUyQyUyMG1heF9uZXdfdG9rZW5zJTNEMjAwKSUwQXByaW50KHRva2VuaXplci5kZWNvZGUob3V0cHV0cyU1QjAlNUQpKQ==",highlighted:`<span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> DbrxForCausalLM, AutoTokenizer
<span class="hljs-keyword">import</span> torch

tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;databricks/dbrx-instruct&quot;</span>, token=<span class="hljs-string">&quot;YOUR_HF_TOKEN&quot;</span>)
model = DbrxForCausalLM.from_pretrained(
    <span class="hljs-string">&quot;databricks/dbrx-instruct&quot;</span>,
    device_map=<span class="hljs-string">&quot;auto&quot;</span>,
    torch_dtype=torch.bfloat16,
    token=<span class="hljs-string">&quot;YOUR_HF_TOKEN&quot;</span>,
    attn_implementation=<span class="hljs-string">&quot;sdpa&quot;</span>,
    )

input_text = <span class="hljs-string">&quot;What does it take to build a great LLM?&quot;</span>
messages = [{<span class="hljs-string">&quot;role&quot;</span>: <span class="hljs-string">&quot;user&quot;</span>, <span class="hljs-string">&quot;content&quot;</span>: input_text}]
input_ids = tokenizer.apply_chat_template(messages, return_dict=<span class="hljs-literal">True</span>, tokenize=<span class="hljs-literal">True</span>, add_generation_prompt=<span class="hljs-literal">True</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).to(<span class="hljs-string">&quot;cuda&quot;</span>)

outputs = model.generate(**input_ids, max_new_tokens=<span class="hljs-number">200</span>)
<span class="hljs-built_in">print</span>(tokenizer.decode(outputs[<span class="hljs-number">0</span>]))`,wrap:!1}}),A=new _e({props:{title:"DbrxConfig",local:"transformers.DbrxConfig ][ transformers.DbrxConfig",headingTag:"h2"}}),O=new Me({props:{name:"class transformers.DbrxConfig",anchor:"transformers.DbrxConfig",parameters:[{name:"d_model",val:": int = 2048"},{name:"n_heads",val:": int = 16"},{name:"n_layers",val:": int = 24"},{name:"max_seq_len",val:": int = 2048"},{name:"vocab_size",val:": int = 32000"},{name:"resid_pdrop",val:": float = 0.0"},{name:"emb_pdrop",val:": float = 0.0"},{name:"attn_config",val:": typing.Optional[transformers.models.dbrx.configuration_dbrx.DbrxAttentionConfig] = None"},{name:"ffn_config",val:": typing.Optional[transformers.models.dbrx.configuration_dbrx.DbrxFFNConfig] = None"},{name:"use_cache",val:": bool = True"},{name:"initializer_range",val:": float = 0.02"},{name:"output_router_logits",val:": bool = False"},{name:"**kwargs",val:": typing.Any"}],parametersDescription:[{anchor:"transformers.DbrxConfig.d_model",description:`<strong>d_model</strong> (<code>int</code>, <em>optional</em>, defaults to 2048) &#x2014;
Dimensionality of the embeddings and hidden states.`,name:"d_model"},{anchor:"transformers.DbrxConfig.n_heads",description:`<strong>n_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 16) &#x2014;
Number of attention heads for each attention layer in the Transformer encoder.`,name:"n_heads"},{anchor:"transformers.DbrxConfig.n_layers",description:`<strong>n_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 24) &#x2014;
Number of hidden layers in the Transformer encoder.`,name:"n_layers"},{anchor:"transformers.DbrxConfig.max_seq_len",description:`<strong>max_seq_len</strong> (<code>int</code>, <em>optional</em>, defaults to 2048) &#x2014;
The maximum sequence length of the model.`,name:"max_seq_len"},{anchor:"transformers.DbrxConfig.vocab_size",description:`<strong>vocab_size</strong> (<code>int</code>, <em>optional</em>, defaults to 32000) &#x2014;
Vocabulary size of the Dbrx model. Defines the maximum number of different tokens that can be represented by
the <code>inputs_ids</code> passed when calling <a href="/docs/transformers/main/ko/model_doc/dbrx#transformers.DbrxModel">DbrxModel</a>.`,name:"vocab_size"},{anchor:"transformers.DbrxConfig.resid_pdrop",description:`<strong>resid_pdrop</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout probability applied to the attention output before combining with residual.`,name:"resid_pdrop"},{anchor:"transformers.DbrxConfig.emb_pdrop",description:`<strong>emb_pdrop</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout probability for the embedding layer.`,name:"emb_pdrop"},{anchor:"transformers.DbrxConfig.attn_config",description:`<strong>attn_config</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
A dictionary used to configure the model&#x2019;s attention module.`,name:"attn_config"},{anchor:"transformers.DbrxConfig.ffn_config",description:`<strong>ffn_config</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
A dictionary used to configure the model&#x2019;s FFN module.`,name:"ffn_config"},{anchor:"transformers.DbrxConfig.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether or not the model should return the last key/values attentions (not used by all models).`,name:"use_cache"},{anchor:"transformers.DbrxConfig.initializer_range",description:`<strong>initializer_range</strong> (<code>float</code>, <em>optional</em>, defaults to 0.02) &#x2014;
The standard deviation of the truncated_normal_initializer for initializing all weight matrices.`,name:"initializer_range"},{anchor:"transformers.DbrxConfig.output_router_logits",description:`<strong>output_router_logits</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not the router logits should be returned by the model. Enabling this will also
allow the model to output the auxiliary loss. See <a href>here</a> for more details.`,name:"output_router_logits"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/dbrx/configuration_dbrx.py#L119"}}),D=new Ut({props:{anchor:"transformers.DbrxConfig.example",$$slots:{default:[Rt]},$$scope:{ctx:$}}}),K=new _e({props:{title:"DbrxModel",local:"transformers.DbrxModel ][ transformers.DbrxModel",headingTag:"h2"}}),ee=new Me({props:{name:"class transformers.DbrxModel",anchor:"transformers.DbrxModel",parameters:[{name:"config",val:": DbrxConfig"}],parametersDescription:[{anchor:"transformers.DbrxModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/dbrx#transformers.DbrxConfig">DbrxConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/dbrx/modeling_dbrx.py#L835"}}),te=new Me({props:{name:"forward",anchor:"transformers.DbrxModel.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.Tensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"output_router_logits",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.DbrxModel.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.DbrxModel.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.DbrxModel.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.DbrxModel.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.DbrxModel.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.DbrxModel.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.DbrxModel.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.DbrxModel.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.DbrxModel.forward.output_router_logits",description:`<strong>output_router_logits</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the logits of all the routers. They are useful for computing the router loss, and
should not be returned during inference.`,name:"output_router_logits"},{anchor:"transformers.DbrxModel.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.DbrxModel.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/dbrx/modeling_dbrx.py#L865",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>transformers.modeling_outputs.MoeModelOutputWithPast</code> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/dbrx#transformers.DbrxConfig"
>DbrxConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the model.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if
<code>config.is_encoder_decoder=True</code> in the cross-attention blocks) that can be used (see <code>past_key_values</code>
input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
<li>
<p><strong>router_logits</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_router_probs=True</code> and <code>config.add_router_probs=True</code> is passed or when <code>config.output_router_probs=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, sequence_length, num_experts)</code>.</p>
<p>Raw router logtis (post-softmax) that are computed by MoE routers, these terms are used to compute the auxiliary
loss for Mixture of Experts models.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>transformers.modeling_outputs.MoeModelOutputWithPast</code> or <code>tuple(torch.FloatTensor)</code></p>
`}}),R=new vt({props:{$$slots:{default:[Zt]},$$scope:{ctx:$}}}),oe=new _e({props:{title:"DbrxForCausalLM",local:"transformers.DbrxForCausalLM ][ transformers.DbrxForCausalLM",headingTag:"h2"}}),ne=new Me({props:{name:"class transformers.DbrxForCausalLM",anchor:"transformers.DbrxForCausalLM",parameters:[{name:"config",val:": DbrxConfig"}],parametersDescription:[{anchor:"transformers.DbrxForCausalLM.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/dbrx#transformers.DbrxConfig">DbrxConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/dbrx/modeling_dbrx.py#L1130"}}),se=new Me({props:{name:"forward",anchor:"transformers.DbrxForCausalLM.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.Tensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"output_router_logits",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"},{name:"logits_to_keep",val:": typing.Union[int, torch.Tensor] = 0"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.DbrxForCausalLM.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.DbrxForCausalLM.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.DbrxForCausalLM.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.DbrxForCausalLM.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.DbrxForCausalLM.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.DbrxForCausalLM.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the masked language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code> or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored
(masked), the loss is only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"},{anchor:"transformers.DbrxForCausalLM.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.DbrxForCausalLM.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.DbrxForCausalLM.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.DbrxForCausalLM.forward.output_router_logits",description:`<strong>output_router_logits</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the logits of all the routers. They are useful for computing the router loss, and
should not be returned during inference.`,name:"output_router_logits"},{anchor:"transformers.DbrxForCausalLM.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.DbrxForCausalLM.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"},{anchor:"transformers.DbrxForCausalLM.forward.logits_to_keep",description:`<strong>logits_to_keep</strong> (<code>Union[int, torch.Tensor]</code>, defaults to <code>0</code>) &#x2014;
If an <code>int</code>, compute logits for the last <code>logits_to_keep</code> tokens. If <code>0</code>, calculate logits for all
<code>input_ids</code> (special case). Only last token logits are needed for generation, and calculating them only for that
token can save memory, which becomes pretty significant for long sequences or large vocabulary size.
If a <code>torch.Tensor</code>, must be 1D corresponding to the indices to keep in the sequence length dimension.
This is useful when using packed tensor format (single dimension for batch and sequence length).`,name:"logits_to_keep"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/dbrx/modeling_dbrx.py#L1166",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>transformers.modeling_outputs.MoeCausalLMOutputWithPast</code> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/dbrx#transformers.DbrxConfig"
>DbrxConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Language modeling loss (for next-token prediction).</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>aux_loss</strong> (<code>torch.FloatTensor</code>, <em>optional</em>, returned when <code>labels</code> is provided) — aux_loss for the sparse modules.</p>
</li>
<li>
<p><strong>router_logits</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_router_probs=True</code> and <code>config.add_router_probs=True</code> is passed or when <code>config.output_router_probs=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, sequence_length, num_experts)</code>.</p>
<p>Raw router logtis (post-softmax) that are computed by MoE routers, these terms are used to compute the auxiliary
loss for Mixture of Experts models.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks) that can be used (see
<code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>transformers.modeling_outputs.MoeCausalLMOutputWithPast</code> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Z=new vt({props:{$$slots:{default:[zt]},$$scope:{ctx:$}}}),z=new Ut({props:{anchor:"transformers.DbrxForCausalLM.forward.example",$$slots:{default:[Gt]},$$scope:{ctx:$}}}),ae=new Dt({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/dbrx.md"}}),{c(){r=i("meta"),T=s(),p=i("p"),u=s(),h(M.$$.fragment),l=s(),h(w.$$.fragment),we=s(),X=i("p"),X.innerHTML=lt,xe=s(),W=i("p"),W.textContent=it,ke=s(),q=i("p"),q.innerHTML=dt,Je=s(),N=i("p"),N.textContent=ct,ve=s(),E=i("p"),E.innerHTML=pt,Ue=s(),V=i("p"),V.innerHTML=ut,Ce=s(),h(B.$$.fragment),je=s(),L=i("p"),L.innerHTML=mt,$e=s(),h(H.$$.fragment),Ie=s(),Q=i("p"),Q.innerHTML=ht,Fe=s(),h(Y.$$.fragment),De=s(),S=i("p"),S.innerHTML=ft,Re=s(),h(P.$$.fragment),Ze=s(),h(A.$$.fragment),ze=s(),J=i("div"),h(O.$$.fragment),Le=s(),ie=i("p"),ie.innerHTML=gt,He=s(),de=i("p"),de.innerHTML=bt,Qe=s(),h(D.$$.fragment),Ge=s(),h(K.$$.fragment),Xe=s(),x=i("div"),h(ee.$$.fragment),Ye=s(),ce=i("p"),ce.textContent=_t,Se=s(),pe=i("p"),pe.innerHTML=yt,Pe=s(),ue=i("p"),ue.innerHTML=Mt,Ae=s(),I=i("div"),h(te.$$.fragment),Oe=s(),me=i("p"),me.innerHTML=Tt,Ke=s(),h(R.$$.fragment),We=s(),h(oe.$$.fragment),qe=s(),k=i("div"),h(ne.$$.fragment),et=s(),he=i("p"),he.textContent=wt,tt=s(),fe=i("p"),fe.innerHTML=xt,ot=s(),ge=i("p"),ge.innerHTML=kt,nt=s(),C=i("div"),h(se.$$.fragment),st=s(),be=i("p"),be.innerHTML=Jt,at=s(),h(Z.$$.fragment),rt=s(),h(z.$$.fragment),Ne=s(),h(ae.$$.fragment),Ee=s(),ye=i("p"),this.h()},l(e){const t=Ft("svelte-u9bgzb",document.head);r=d(t,"META",{name:!0,content:!0}),t.forEach(o),T=a(e),p=d(e,"P",{}),re(p).forEach(o),u=a(e),f(M.$$.fragment,e),l=a(e),f(w.$$.fragment,e),we=a(e),X=d(e,"P",{"data-svelte-h":!0}),m(X)!=="svelte-1h8pj1r"&&(X.innerHTML=lt),xe=a(e),W=d(e,"P",{"data-svelte-h":!0}),m(W)!=="svelte-ukmgi2"&&(W.textContent=it),ke=a(e),q=d(e,"P",{"data-svelte-h":!0}),m(q)!=="svelte-13i7h5d"&&(q.innerHTML=dt),Je=a(e),N=d(e,"P",{"data-svelte-h":!0}),m(N)!=="svelte-1b4hd1o"&&(N.textContent=ct),ve=a(e),E=d(e,"P",{"data-svelte-h":!0}),m(E)!=="svelte-o02zb"&&(E.innerHTML=pt),Ue=a(e),V=d(e,"P",{"data-svelte-h":!0}),m(V)!=="svelte-10sduub"&&(V.innerHTML=ut),Ce=a(e),f(B.$$.fragment,e),je=a(e),L=d(e,"P",{"data-svelte-h":!0}),m(L)!=="svelte-8tc5hx"&&(L.innerHTML=mt),$e=a(e),f(H.$$.fragment,e),Ie=a(e),Q=d(e,"P",{"data-svelte-h":!0}),m(Q)!=="svelte-tkj1ki"&&(Q.innerHTML=ht),Fe=a(e),f(Y.$$.fragment,e),De=a(e),S=d(e,"P",{"data-svelte-h":!0}),m(S)!=="svelte-1747ujk"&&(S.innerHTML=ft),Re=a(e),f(P.$$.fragment,e),Ze=a(e),f(A.$$.fragment,e),ze=a(e),J=d(e,"DIV",{class:!0});var j=re(J);f(O.$$.fragment,j),Le=a(j),ie=d(j,"P",{"data-svelte-h":!0}),m(ie)!=="svelte-1n2g04i"&&(ie.innerHTML=gt),He=a(j),de=d(j,"P",{"data-svelte-h":!0}),m(de)!=="svelte-qr3t5r"&&(de.innerHTML=bt),Qe=a(j),f(D.$$.fragment,j),j.forEach(o),Ge=a(e),f(K.$$.fragment,e),Xe=a(e),x=d(e,"DIV",{class:!0});var v=re(x);f(ee.$$.fragment,v),Ye=a(v),ce=d(v,"P",{"data-svelte-h":!0}),m(ce)!=="svelte-1msk8jg"&&(ce.textContent=_t),Se=a(v),pe=d(v,"P",{"data-svelte-h":!0}),m(pe)!=="svelte-u3dlub"&&(pe.innerHTML=yt),Pe=a(v),ue=d(v,"P",{"data-svelte-h":!0}),m(ue)!=="svelte-hswkmf"&&(ue.innerHTML=Mt),Ae=a(v),I=d(v,"DIV",{class:!0});var F=re(I);f(te.$$.fragment,F),Oe=a(F),me=d(F,"P",{"data-svelte-h":!0}),m(me)!=="svelte-1kbu5mq"&&(me.innerHTML=Tt),Ke=a(F),f(R.$$.fragment,F),F.forEach(o),v.forEach(o),We=a(e),f(oe.$$.fragment,e),qe=a(e),k=d(e,"DIV",{class:!0});var U=re(k);f(ne.$$.fragment,U),et=a(U),he=d(U,"P",{"data-svelte-h":!0}),m(he)!=="svelte-yq335u"&&(he.textContent=wt),tt=a(U),fe=d(U,"P",{"data-svelte-h":!0}),m(fe)!=="svelte-u3dlub"&&(fe.innerHTML=xt),ot=a(U),ge=d(U,"P",{"data-svelte-h":!0}),m(ge)!=="svelte-hswkmf"&&(ge.innerHTML=kt),nt=a(U),C=d(U,"DIV",{class:!0});var G=re(C);f(se.$$.fragment,G),st=a(G),be=d(G,"P",{"data-svelte-h":!0}),m(be)!=="svelte-ln9fpq"&&(be.innerHTML=Jt),at=a(G),f(Z.$$.fragment,G),rt=a(G),f(z.$$.fragment,G),G.forEach(o),U.forEach(o),Ne=a(e),f(ae.$$.fragment,e),Ee=a(e),ye=d(e,"P",{}),re(ye).forEach(o),this.h()},h(){le(r,"name","hf:doc:metadata"),le(r,"content",Wt),le(J,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),le(I,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),le(x,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),le(C,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),le(k,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,t){c(document.head,r),n(e,T,t),n(e,p,t),n(e,u,t),g(M,e,t),n(e,l,t),g(w,e,t),n(e,we,t),n(e,X,t),n(e,xe,t),n(e,W,t),n(e,ke,t),n(e,q,t),n(e,Je,t),n(e,N,t),n(e,ve,t),n(e,E,t),n(e,Ue,t),n(e,V,t),n(e,Ce,t),g(B,e,t),n(e,je,t),n(e,L,t),n(e,$e,t),g(H,e,t),n(e,Ie,t),n(e,Q,t),n(e,Fe,t),g(Y,e,t),n(e,De,t),n(e,S,t),n(e,Re,t),g(P,e,t),n(e,Ze,t),g(A,e,t),n(e,ze,t),n(e,J,t),g(O,J,null),c(J,Le),c(J,ie),c(J,He),c(J,de),c(J,Qe),g(D,J,null),n(e,Ge,t),g(K,e,t),n(e,Xe,t),n(e,x,t),g(ee,x,null),c(x,Ye),c(x,ce),c(x,Se),c(x,pe),c(x,Pe),c(x,ue),c(x,Ae),c(x,I),g(te,I,null),c(I,Oe),c(I,me),c(I,Ke),g(R,I,null),n(e,We,t),g(oe,e,t),n(e,qe,t),n(e,k,t),g(ne,k,null),c(k,et),c(k,he),c(k,tt),c(k,fe),c(k,ot),c(k,ge),c(k,nt),c(k,C),g(se,C,null),c(C,st),c(C,be),c(C,at),g(Z,C,null),c(C,rt),g(z,C,null),n(e,Ne,t),g(ae,e,t),n(e,Ee,t),n(e,ye,t),Ve=!0},p(e,[t]){const j={};t&2&&(j.$$scope={dirty:t,ctx:e}),D.$set(j);const v={};t&2&&(v.$$scope={dirty:t,ctx:e}),R.$set(v);const F={};t&2&&(F.$$scope={dirty:t,ctx:e}),Z.$set(F);const U={};t&2&&(U.$$scope={dirty:t,ctx:e}),z.$set(U)},i(e){Ve||(b(M.$$.fragment,e),b(w.$$.fragment,e),b(B.$$.fragment,e),b(H.$$.fragment,e),b(Y.$$.fragment,e),b(P.$$.fragment,e),b(A.$$.fragment,e),b(O.$$.fragment,e),b(D.$$.fragment,e),b(K.$$.fragment,e),b(ee.$$.fragment,e),b(te.$$.fragment,e),b(R.$$.fragment,e),b(oe.$$.fragment,e),b(ne.$$.fragment,e),b(se.$$.fragment,e),b(Z.$$.fragment,e),b(z.$$.fragment,e),b(ae.$$.fragment,e),Ve=!0)},o(e){_(M.$$.fragment,e),_(w.$$.fragment,e),_(B.$$.fragment,e),_(H.$$.fragment,e),_(Y.$$.fragment,e),_(P.$$.fragment,e),_(A.$$.fragment,e),_(O.$$.fragment,e),_(D.$$.fragment,e),_(K.$$.fragment,e),_(ee.$$.fragment,e),_(te.$$.fragment,e),_(R.$$.fragment,e),_(oe.$$.fragment,e),_(ne.$$.fragment,e),_(se.$$.fragment,e),_(Z.$$.fragment,e),_(z.$$.fragment,e),_(ae.$$.fragment,e),Ve=!1},d(e){e&&(o(T),o(p),o(u),o(l),o(we),o(X),o(xe),o(W),o(ke),o(q),o(Je),o(N),o(ve),o(E),o(Ue),o(V),o(Ce),o(je),o(L),o($e),o(Ie),o(Q),o(Fe),o(De),o(S),o(Re),o(Ze),o(ze),o(J),o(Ge),o(Xe),o(x),o(We),o(qe),o(k),o(Ne),o(Ee),o(ye)),o(r),y(M,e),y(w,e),y(B,e),y(H,e),y(Y,e),y(P,e),y(A,e),y(O),y(D),y(K,e),y(ee),y(te),y(R),y(oe,e),y(ne),y(se),y(Z),y(z),y(ae,e)}}}const Wt='{"title":"DBRX","local":"dbrx","sections":[{"title":"개요","local":"overview","sections":[],"depth":2},{"title":"사용 예","local":"usage-examples","sections":[],"depth":2},{"title":"DbrxConfig","local":"transformers.DbrxConfig ][ transformers.DbrxConfig","sections":[],"depth":2},{"title":"DbrxModel","local":"transformers.DbrxModel ][ transformers.DbrxModel","sections":[],"depth":2},{"title":"DbrxForCausalLM","local":"transformers.DbrxForCausalLM ][ transformers.DbrxForCausalLM","sections":[],"depth":2}],"depth":1}';function qt($){return jt(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Yt extends $t{constructor(r){super(),It(this,r,qt,Xt,Ct,{})}}export{Yt as component};
