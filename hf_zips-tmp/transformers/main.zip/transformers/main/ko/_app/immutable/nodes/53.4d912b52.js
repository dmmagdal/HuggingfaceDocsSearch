import{s as vt,o as Tt,n as _e}from"../chunks/scheduler.bdbef820.js";import{S as wt,i as jt,g as m,s as l,r as g,A as kt,h as u,f as n,c as i,j as ne,u as _,x as T,k as se,y as d,a as c,v as y,d as b,t as M,w as v}from"../chunks/index.33f81d56.js";import{T as ot}from"../chunks/Tip.34194030.js";import{D as be}from"../chunks/Docstring.abcbe1ac.js";import{C as Ve}from"../chunks/CodeBlock.3bad7fc9.js";import{E as ze}from"../chunks/ExampleCodeBlock.16b3b633.js";import{H as ge,E as Jt}from"../chunks/getInferenceSnippets.64cd9466.js";function Ct(w){let o,h;return o=new Ve({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9mb3JtZXJDb25maWclMkMlMjBBdXRvZm9ybWVyTW9kZWwlMEElMEElMjMlMjBJbml0aWFsaXppbmclMjBhJTIwZGVmYXVsdCUyMEF1dG9mb3JtZXIlMjBjb25maWd1cmF0aW9uJTBBY29uZmlndXJhdGlvbiUyMCUzRCUyMEF1dG9mb3JtZXJDb25maWcoKSUwQSUwQSUyMyUyMFJhbmRvbWx5JTIwaW5pdGlhbGl6aW5nJTIwYSUyMG1vZGVsJTIwKHdpdGglMjByYW5kb20lMjB3ZWlnaHRzKSUyMGZyb20lMjB0aGUlMjBjb25maWd1cmF0aW9uJTBBbW9kZWwlMjAlM0QlMjBBdXRvZm9ybWVyTW9kZWwoY29uZmlndXJhdGlvbiklMEElMEElMjMlMjBBY2Nlc3NpbmclMjB0aGUlMjBtb2RlbCUyMGNvbmZpZ3VyYXRpb24lMEFjb25maWd1cmF0aW9uJTIwJTNEJTIwbW9kZWwuY29uZmln",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoformerConfig, AutoformerModel

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a default Autoformer configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = AutoformerConfig()

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Randomly initializing a model (with random weights) from the configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = AutoformerModel(configuration)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Accessing the model configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = model.config`,wrap:!1}}),{c(){g(o.$$.fragment)},l(s){_(o.$$.fragment,s)},m(s,r){y(o,s,r),h=!0},p:_e,i(s){h||(b(o.$$.fragment,s),h=!0)},o(s){M(o.$$.fragment,s),h=!1},d(s){v(o,s)}}}function xt(w){let o,h=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=m("p"),o.innerHTML=h},l(s){o=u(s,"P",{"data-svelte-h":!0}),T(o)!=="svelte-fincs2"&&(o.innerHTML=h)},m(s,r){c(s,o,r)},p:_e,d(s){s&&n(o)}}}function Ut(w){let o,h="Examples:",s,r,p;return r=new Ve({props:{code:"ZnJvbSUyMGh1Z2dpbmdmYWNlX2h1YiUyMGltcG9ydCUyMGhmX2h1Yl9kb3dubG9hZCUwQWltcG9ydCUyMHRvcmNoJTBBZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9mb3JtZXJNb2RlbCUwQSUwQWZpbGUlMjAlM0QlMjBoZl9odWJfZG93bmxvYWQoJTBBJTIwJTIwJTIwJTIwcmVwb19pZCUzRCUyMmhmLWludGVybmFsLXRlc3RpbmclMkZ0b3VyaXNtLW1vbnRobHktYmF0Y2glMjIlMkMlMjBmaWxlbmFtZSUzRCUyMnRyYWluLWJhdGNoLnB0JTIyJTJDJTIwcmVwb190eXBlJTNEJTIyZGF0YXNldCUyMiUwQSklMEFiYXRjaCUyMCUzRCUyMHRvcmNoLmxvYWQoZmlsZSklMEElMEFtb2RlbCUyMCUzRCUyMEF1dG9mb3JtZXJNb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIyaHVnZ2luZ2ZhY2UlMkZhdXRvZm9ybWVyLXRvdXJpc20tbW9udGhseSUyMiklMEElMEElMjMlMjBkdXJpbmclMjB0cmFpbmluZyUyQyUyMG9uZSUyMHByb3ZpZGVzJTIwYm90aCUyMHBhc3QlMjBhbmQlMjBmdXR1cmUlMjB2YWx1ZXMlMEElMjMlMjBhcyUyMHdlbGwlMjBhcyUyMHBvc3NpYmxlJTIwYWRkaXRpb25hbCUyMGZlYXR1cmVzJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKCUwQSUyMCUyMCUyMCUyMHBhc3RfdmFsdWVzJTNEYmF0Y2glNUIlMjJwYXN0X3ZhbHVlcyUyMiU1RCUyQyUwQSUyMCUyMCUyMCUyMHBhc3RfdGltZV9mZWF0dXJlcyUzRGJhdGNoJTVCJTIycGFzdF90aW1lX2ZlYXR1cmVzJTIyJTVEJTJDJTBBJTIwJTIwJTIwJTIwcGFzdF9vYnNlcnZlZF9tYXNrJTNEYmF0Y2glNUIlMjJwYXN0X29ic2VydmVkX21hc2slMjIlNUQlMkMlMEElMjAlMjAlMjAlMjBzdGF0aWNfY2F0ZWdvcmljYWxfZmVhdHVyZXMlM0RiYXRjaCU1QiUyMnN0YXRpY19jYXRlZ29yaWNhbF9mZWF0dXJlcyUyMiU1RCUyQyUwQSUyMCUyMCUyMCUyMGZ1dHVyZV92YWx1ZXMlM0RiYXRjaCU1QiUyMmZ1dHVyZV92YWx1ZXMlMjIlNUQlMkMlMEElMjAlMjAlMjAlMjBmdXR1cmVfdGltZV9mZWF0dXJlcyUzRGJhdGNoJTVCJTIyZnV0dXJlX3RpbWVfZmVhdHVyZXMlMjIlNUQlMkMlMEEpJTBBJTBBbGFzdF9oaWRkZW5fc3RhdGUlMjAlM0QlMjBvdXRwdXRzLmxhc3RfaGlkZGVuX3N0YXRl",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> huggingface_hub <span class="hljs-keyword">import</span> hf_hub_download
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoformerModel

<span class="hljs-meta">&gt;&gt;&gt; </span>file = hf_hub_download(
<span class="hljs-meta">... </span>    repo_id=<span class="hljs-string">&quot;hf-internal-testing/tourism-monthly-batch&quot;</span>, filename=<span class="hljs-string">&quot;train-batch.pt&quot;</span>, repo_type=<span class="hljs-string">&quot;dataset&quot;</span>
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>batch = torch.load(file)

<span class="hljs-meta">&gt;&gt;&gt; </span>model = AutoformerModel.from_pretrained(<span class="hljs-string">&quot;huggingface/autoformer-tourism-monthly&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># during training, one provides both past and future values</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># as well as possible additional features</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(
<span class="hljs-meta">... </span>    past_values=batch[<span class="hljs-string">&quot;past_values&quot;</span>],
<span class="hljs-meta">... </span>    past_time_features=batch[<span class="hljs-string">&quot;past_time_features&quot;</span>],
<span class="hljs-meta">... </span>    past_observed_mask=batch[<span class="hljs-string">&quot;past_observed_mask&quot;</span>],
<span class="hljs-meta">... </span>    static_categorical_features=batch[<span class="hljs-string">&quot;static_categorical_features&quot;</span>],
<span class="hljs-meta">... </span>    future_values=batch[<span class="hljs-string">&quot;future_values&quot;</span>],
<span class="hljs-meta">... </span>    future_time_features=batch[<span class="hljs-string">&quot;future_time_features&quot;</span>],
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_state = outputs.last_hidden_state`,wrap:!1}}),{c(){o=m("p"),o.textContent=h,s=l(),g(r.$$.fragment)},l(t){o=u(t,"P",{"data-svelte-h":!0}),T(o)!=="svelte-kvfsh7"&&(o.textContent=h),s=i(t),_(r.$$.fragment,t)},m(t,f){c(t,o,f),c(t,s,f),y(r,t,f),p=!0},p:_e,i(t){p||(b(r.$$.fragment,t),p=!0)},o(t){M(r.$$.fragment,t),p=!1},d(t){t&&(n(o),n(s)),v(r,t)}}}function Zt(w){let o,h=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=m("p"),o.innerHTML=h},l(s){o=u(s,"P",{"data-svelte-h":!0}),T(o)!=="svelte-fincs2"&&(o.innerHTML=h)},m(s,r){c(s,o,r)},p:_e,d(s){s&&n(o)}}}function $t(w){let o,h="Examples:",s,r,p;return r=new Ve({props:{code:"ZnJvbSUyMGh1Z2dpbmdmYWNlX2h1YiUyMGltcG9ydCUyMGhmX2h1Yl9kb3dubG9hZCUwQWltcG9ydCUyMHRvcmNoJTBBZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9mb3JtZXJGb3JQcmVkaWN0aW9uJTBBJTBBZmlsZSUyMCUzRCUyMGhmX2h1Yl9kb3dubG9hZCglMEElMjAlMjAlMjAlMjByZXBvX2lkJTNEJTIyaGYtaW50ZXJuYWwtdGVzdGluZyUyRnRvdXJpc20tbW9udGhseS1iYXRjaCUyMiUyQyUyMGZpbGVuYW1lJTNEJTIydHJhaW4tYmF0Y2gucHQlMjIlMkMlMjByZXBvX3R5cGUlM0QlMjJkYXRhc2V0JTIyJTBBKSUwQWJhdGNoJTIwJTNEJTIwdG9yY2gubG9hZChmaWxlKSUwQSUwQW1vZGVsJTIwJTNEJTIwQXV0b2Zvcm1lckZvclByZWRpY3Rpb24uZnJvbV9wcmV0cmFpbmVkKCUyMmh1Z2dpbmdmYWNlJTJGYXV0b2Zvcm1lci10b3VyaXNtLW1vbnRobHklMjIpJTBBJTBBJTIzJTIwZHVyaW5nJTIwdHJhaW5pbmclMkMlMjBvbmUlMjBwcm92aWRlcyUyMGJvdGglMjBwYXN0JTIwYW5kJTIwZnV0dXJlJTIwdmFsdWVzJTBBJTIzJTIwYXMlMjB3ZWxsJTIwYXMlMjBwb3NzaWJsZSUyMGFkZGl0aW9uYWwlMjBmZWF0dXJlcyUwQW91dHB1dHMlMjAlM0QlMjBtb2RlbCglMEElMjAlMjAlMjAlMjBwYXN0X3ZhbHVlcyUzRGJhdGNoJTVCJTIycGFzdF92YWx1ZXMlMjIlNUQlMkMlMEElMjAlMjAlMjAlMjBwYXN0X3RpbWVfZmVhdHVyZXMlM0RiYXRjaCU1QiUyMnBhc3RfdGltZV9mZWF0dXJlcyUyMiU1RCUyQyUwQSUyMCUyMCUyMCUyMHBhc3Rfb2JzZXJ2ZWRfbWFzayUzRGJhdGNoJTVCJTIycGFzdF9vYnNlcnZlZF9tYXNrJTIyJTVEJTJDJTBBJTIwJTIwJTIwJTIwc3RhdGljX2NhdGVnb3JpY2FsX2ZlYXR1cmVzJTNEYmF0Y2glNUIlMjJzdGF0aWNfY2F0ZWdvcmljYWxfZmVhdHVyZXMlMjIlNUQlMkMlMEElMjAlMjAlMjAlMjBmdXR1cmVfdmFsdWVzJTNEYmF0Y2glNUIlMjJmdXR1cmVfdmFsdWVzJTIyJTVEJTJDJTBBJTIwJTIwJTIwJTIwZnV0dXJlX3RpbWVfZmVhdHVyZXMlM0RiYXRjaCU1QiUyMmZ1dHVyZV90aW1lX2ZlYXR1cmVzJTIyJTVEJTJDJTBBKSUwQSUwQWxvc3MlMjAlM0QlMjBvdXRwdXRzLmxvc3MlMEFsb3NzLmJhY2t3YXJkKCklMEElMEElMjMlMjBkdXJpbmclMjBpbmZlcmVuY2UlMkMlMjBvbmUlMjBvbmx5JTIwcHJvdmlkZXMlMjBwYXN0JTIwdmFsdWVzJTBBJTIzJTIwYXMlMjB3ZWxsJTIwYXMlMjBwb3NzaWJsZSUyMGFkZGl0aW9uYWwlMjBmZWF0dXJlcyUwQSUyMyUyMHRoZSUyMG1vZGVsJTIwYXV0b3JlZ3Jlc3NpdmVseSUyMGdlbmVyYXRlcyUyMGZ1dHVyZSUyMHZhbHVlcyUwQW91dHB1dHMlMjAlM0QlMjBtb2RlbC5nZW5lcmF0ZSglMEElMjAlMjAlMjAlMjBwYXN0X3ZhbHVlcyUzRGJhdGNoJTVCJTIycGFzdF92YWx1ZXMlMjIlNUQlMkMlMEElMjAlMjAlMjAlMjBwYXN0X3RpbWVfZmVhdHVyZXMlM0RiYXRjaCU1QiUyMnBhc3RfdGltZV9mZWF0dXJlcyUyMiU1RCUyQyUwQSUyMCUyMCUyMCUyMHBhc3Rfb2JzZXJ2ZWRfbWFzayUzRGJhdGNoJTVCJTIycGFzdF9vYnNlcnZlZF9tYXNrJTIyJTVEJTJDJTBBJTIwJTIwJTIwJTIwc3RhdGljX2NhdGVnb3JpY2FsX2ZlYXR1cmVzJTNEYmF0Y2glNUIlMjJzdGF0aWNfY2F0ZWdvcmljYWxfZmVhdHVyZXMlMjIlNUQlMkMlMEElMjAlMjAlMjAlMjBmdXR1cmVfdGltZV9mZWF0dXJlcyUzRGJhdGNoJTVCJTIyZnV0dXJlX3RpbWVfZmVhdHVyZXMlMjIlNUQlMkMlMEEpJTBBJTBBbWVhbl9wcmVkaWN0aW9uJTIwJTNEJTIwb3V0cHV0cy5zZXF1ZW5jZXMubWVhbihkaW0lM0QxKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> huggingface_hub <span class="hljs-keyword">import</span> hf_hub_download
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoformerForPrediction

<span class="hljs-meta">&gt;&gt;&gt; </span>file = hf_hub_download(
<span class="hljs-meta">... </span>    repo_id=<span class="hljs-string">&quot;hf-internal-testing/tourism-monthly-batch&quot;</span>, filename=<span class="hljs-string">&quot;train-batch.pt&quot;</span>, repo_type=<span class="hljs-string">&quot;dataset&quot;</span>
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>batch = torch.load(file)

<span class="hljs-meta">&gt;&gt;&gt; </span>model = AutoformerForPrediction.from_pretrained(<span class="hljs-string">&quot;huggingface/autoformer-tourism-monthly&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># during training, one provides both past and future values</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># as well as possible additional features</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(
<span class="hljs-meta">... </span>    past_values=batch[<span class="hljs-string">&quot;past_values&quot;</span>],
<span class="hljs-meta">... </span>    past_time_features=batch[<span class="hljs-string">&quot;past_time_features&quot;</span>],
<span class="hljs-meta">... </span>    past_observed_mask=batch[<span class="hljs-string">&quot;past_observed_mask&quot;</span>],
<span class="hljs-meta">... </span>    static_categorical_features=batch[<span class="hljs-string">&quot;static_categorical_features&quot;</span>],
<span class="hljs-meta">... </span>    future_values=batch[<span class="hljs-string">&quot;future_values&quot;</span>],
<span class="hljs-meta">... </span>    future_time_features=batch[<span class="hljs-string">&quot;future_time_features&quot;</span>],
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>loss = outputs.loss
<span class="hljs-meta">&gt;&gt;&gt; </span>loss.backward()

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># during inference, one only provides past values</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># as well as possible additional features</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># the model autoregressively generates future values</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model.generate(
<span class="hljs-meta">... </span>    past_values=batch[<span class="hljs-string">&quot;past_values&quot;</span>],
<span class="hljs-meta">... </span>    past_time_features=batch[<span class="hljs-string">&quot;past_time_features&quot;</span>],
<span class="hljs-meta">... </span>    past_observed_mask=batch[<span class="hljs-string">&quot;past_observed_mask&quot;</span>],
<span class="hljs-meta">... </span>    static_categorical_features=batch[<span class="hljs-string">&quot;static_categorical_features&quot;</span>],
<span class="hljs-meta">... </span>    future_time_features=batch[<span class="hljs-string">&quot;future_time_features&quot;</span>],
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>mean_prediction = outputs.sequences.mean(dim=<span class="hljs-number">1</span>)`,wrap:!1}}),{c(){o=m("p"),o.textContent=h,s=l(),g(r.$$.fragment)},l(t){o=u(t,"P",{"data-svelte-h":!0}),T(o)!=="svelte-kvfsh7"&&(o.textContent=h),s=i(t),_(r.$$.fragment,t)},m(t,f){c(t,o,f),c(t,s,f),y(r,t,f),p=!0},p:_e,i(t){p||(b(r.$$.fragment,t),p=!0)},o(t){M(r.$$.fragment,t),p=!1},d(t){t&&(n(o),n(s)),v(r,t)}}}function At(w){let o,h="is equal to 1), initialize the model and call as shown below:",s,r,p;return r=new Ve({props:{code:"ZnJvbSUyMGh1Z2dpbmdmYWNlX2h1YiUyMGltcG9ydCUyMGhmX2h1Yl9kb3dubG9hZCUwQWltcG9ydCUyMHRvcmNoJTBBZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9mb3JtZXJDb25maWclMkMlMjBBdXRvZm9ybWVyRm9yUHJlZGljdGlvbiUwQSUwQWZpbGUlMjAlM0QlMjBoZl9odWJfZG93bmxvYWQoJTBBJTIwJTIwJTIwJTIwcmVwb19pZCUzRCUyMmhmLWludGVybmFsLXRlc3RpbmclMkZ0b3VyaXNtLW1vbnRobHktYmF0Y2glMjIlMkMlMjBmaWxlbmFtZSUzRCUyMnRyYWluLWJhdGNoLnB0JTIyJTJDJTIwcmVwb190eXBlJTNEJTIyZGF0YXNldCUyMiUwQSklMEFiYXRjaCUyMCUzRCUyMHRvcmNoLmxvYWQoZmlsZSklMEElMEElMjMlMjBjaGVjayUyMG51bWJlciUyMG9mJTIwc3RhdGljJTIwcmVhbCUyMGZlYXR1cmVzJTBBbnVtX3N0YXRpY19yZWFsX2ZlYXR1cmVzJTIwJTNEJTIwYmF0Y2glNUIlMjJzdGF0aWNfcmVhbF9mZWF0dXJlcyUyMiU1RC5zaGFwZSU1Qi0xJTVEJTBBJTBBJTIzJTIwbG9hZCUyMGNvbmZpZ3VyYXRpb24lMjBvZiUyMHByZXRyYWluZWQlMjBtb2RlbCUyMGFuZCUyMG92ZXJyaWRlJTIwbnVtX3N0YXRpY19yZWFsX2ZlYXR1cmVzJTBBY29uZmlndXJhdGlvbiUyMCUzRCUyMEF1dG9mb3JtZXJDb25maWcuZnJvbV9wcmV0cmFpbmVkKCUwQSUyMCUyMCUyMCUyMCUyMmh1Z2dpbmdmYWNlJTJGYXV0b2Zvcm1lci10b3VyaXNtLW1vbnRobHklMjIlMkMlMEElMjAlMjAlMjAlMjBudW1fc3RhdGljX3JlYWxfZmVhdHVyZXMlM0RudW1fc3RhdGljX3JlYWxfZmVhdHVyZXMlMkMlMEEpJTBBJTIzJTIwd2UlMjBhbHNvJTIwbmVlZCUyMHRvJTIwdXBkYXRlJTIwZmVhdHVyZV9zaXplJTIwYXMlMjBpdCUyMGlzJTIwbm90JTIwcmVjYWxjdWxhdGVkJTBBY29uZmlndXJhdGlvbi5mZWF0dXJlX3NpemUlMjAlMkIlM0QlMjBudW1fc3RhdGljX3JlYWxfZmVhdHVyZXMlMEElMEFtb2RlbCUyMCUzRCUyMEF1dG9mb3JtZXJGb3JQcmVkaWN0aW9uKGNvbmZpZ3VyYXRpb24pJTBBJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKCUwQSUyMCUyMCUyMCUyMHBhc3RfdmFsdWVzJTNEYmF0Y2glNUIlMjJwYXN0X3ZhbHVlcyUyMiU1RCUyQyUwQSUyMCUyMCUyMCUyMHBhc3RfdGltZV9mZWF0dXJlcyUzRGJhdGNoJTVCJTIycGFzdF90aW1lX2ZlYXR1cmVzJTIyJTVEJTJDJTBBJTIwJTIwJTIwJTIwcGFzdF9vYnNlcnZlZF9tYXNrJTNEYmF0Y2glNUIlMjJwYXN0X29ic2VydmVkX21hc2slMjIlNUQlMkMlMEElMjAlMjAlMjAlMjBzdGF0aWNfY2F0ZWdvcmljYWxfZmVhdHVyZXMlM0RiYXRjaCU1QiUyMnN0YXRpY19jYXRlZ29yaWNhbF9mZWF0dXJlcyUyMiU1RCUyQyUwQSUyMCUyMCUyMCUyMHN0YXRpY19yZWFsX2ZlYXR1cmVzJTNEYmF0Y2glNUIlMjJzdGF0aWNfcmVhbF9mZWF0dXJlcyUyMiU1RCUyQyUwQSUyMCUyMCUyMCUyMGZ1dHVyZV92YWx1ZXMlM0RiYXRjaCU1QiUyMmZ1dHVyZV92YWx1ZXMlMjIlNUQlMkMlMEElMjAlMjAlMjAlMjBmdXR1cmVfdGltZV9mZWF0dXJlcyUzRGJhdGNoJTVCJTIyZnV0dXJlX3RpbWVfZmVhdHVyZXMlMjIlNUQlMkMlMEEp",highlighted:`<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python"><span class="hljs-keyword">from</span> huggingface_hub <span class="hljs-keyword">import</span> hf_hub_download</span>
<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python"><span class="hljs-keyword">import</span> torch</span>
<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python"><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoformerConfig, AutoformerForPrediction</span>

<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python">file = hf_hub_download(</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    repo_id=<span class="hljs-string">&quot;hf-internal-testing/tourism-monthly-batch&quot;</span>, filename=<span class="hljs-string">&quot;train-batch.pt&quot;</span>, repo_type=<span class="hljs-string">&quot;dataset&quot;</span></span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">)</span>
<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python">batch = torch.load(file)</span>

<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python"><span class="hljs-comment"># check number of static real features</span></span>
<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python">num_static_real_features = batch[<span class="hljs-string">&quot;static_real_features&quot;</span>].shape[-<span class="hljs-number">1</span>]</span>

<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python"><span class="hljs-comment"># load configuration of pretrained model and override num_static_real_features</span></span>
<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python">configuration = AutoformerConfig.from_pretrained(</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    <span class="hljs-string">&quot;huggingface/autoformer-tourism-monthly&quot;</span>,</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    num_static_real_features=num_static_real_features,</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">)</span>
<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python"><span class="hljs-comment"># we also need to update feature_size as it is not recalculated</span></span>
<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python">configuration.feature_size += num_static_real_features</span>

<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python">model = AutoformerForPrediction(configuration)</span>

<span class="hljs-meta prompt_">&gt;&gt;&gt;</span> <span class="language-python">outputs = model(</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    past_values=batch[<span class="hljs-string">&quot;past_values&quot;</span>],</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    past_time_features=batch[<span class="hljs-string">&quot;past_time_features&quot;</span>],</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    past_observed_mask=batch[<span class="hljs-string">&quot;past_observed_mask&quot;</span>],</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    static_categorical_features=batch[<span class="hljs-string">&quot;static_categorical_features&quot;</span>],</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    static_real_features=batch[<span class="hljs-string">&quot;static_real_features&quot;</span>],</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    future_values=batch[<span class="hljs-string">&quot;future_values&quot;</span>],</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">    future_time_features=batch[<span class="hljs-string">&quot;future_time_features&quot;</span>],</span>
<span class="hljs-meta prompt_">...</span> <span class="language-python">)</span>`,wrap:!1}}),{c(){o=m("p"),o.textContent=h,s=l(),g(r.$$.fragment)},l(t){o=u(t,"P",{"data-svelte-h":!0}),T(o)!=="svelte-1hzwtfu"&&(o.textContent=h),s=i(t),_(r.$$.fragment,t)},m(t,f){c(t,o,f),c(t,s,f),y(r,t,f),p=!0},p:_e,i(t){p||(b(r.$$.fragment,t),p=!0)},o(t){M(r.$$.fragment,t),p=!1},d(t){t&&(n(o),n(s)),v(r,t)}}}function Ft(w){let o,h=`The AutoformerForPrediction can also use static_real_features. To do so, set num_static_real_features in
AutoformerConfig based on number of such features in the dataset (in case of tourism_monthly dataset it`,s,r,p;return r=new ze({props:{anchor:"transformers.AutoformerForPrediction.forward.example-2",$$slots:{default:[At]},$$scope:{ctx:w}}}),{c(){o=m("p"),o.textContent=h,s=l(),g(r.$$.fragment)},l(t){o=u(t,"P",{"data-svelte-h":!0}),T(o)!=="svelte-14i5hlv"&&(o.textContent=h),s=i(t),_(r.$$.fragment,t)},m(t,f){c(t,o,f),c(t,s,f),y(r,t,f),p=!0},p(t,f){const G={};f&2&&(G.$$scope={dirty:f,ctx:t}),r.$set(G)},i(t){p||(b(r.$$.fragment,t),p=!0)},o(t){M(r.$$.fragment,t),p=!1},d(t){t&&(n(o),n(s)),v(r,t)}}}function Xt(w){let o,h,s,r,p,t,f,G,N,at='The Autoformer 모델은 Haixu Wu, Jiehui Xu, Jianmin Wang, Mingsheng Long가 제안한 <a href="https://huggingface.co/papers/2106.13008" rel="nofollow">오토포머: 장기 시계열 예측을 위한 자기상관 분해 트랜스포머</a> 라는 논문에서 소개 되었습니다.',Me,q,nt="이 모델은 트랜스포머를 심층 분해 아키텍처로 확장하여, 예측 과정에서 추세와 계절성 요소를 점진적으로 분해할 수 있습니다.",ve,Y,st="해당 논문의 초록입니다:",Te,I,rt="<em>예측 시간을 연장하는 것은 극한 기상 조기 경보 및 장기 에너지 소비 계획과 같은 실제 응용 프로그램에 중요한 요구 사항입니다. 본 논문은 시계열의 장기 예측 문제를 연구합니다. 기존의 트랜스포머 기반 모델들은 장거리 종속성을 발견하기 위해 다양한 셀프 어텐션 메커니즘을 채택합니다. 그러나 장기 미래의 복잡한 시간적 패턴으로 인해 모델이 신뢰할 수 있는 종속성을 찾기 어렵습니다. 또한, 트랜스포머는 긴 시계열의 효율성을 위해 점별 셀프 어텐션의 희소 버전을 채택해야 하므로 정보 활용의 병목 현상이 발생합니다. 우리는 트랜스포머를 넘어서 자기상관 메커니즘을 갖춘 새로운 분해 아키텍처인 Autoformer를 설계했습니다. 우리는 시계열 분해의 전처리 관행을 깨고 이를 심층 모델의 기본 내부 블록으로 혁신했습니다. 이 설계는 Autoformer에 복잡한 시계열에 대한 점진적 분해 능력을 부여합니다. 또한, 확률 과정 이론에서 영감을 받아 시계열의 주기성을 기반으로 자기상관 메커니즘을 설계했으며, 이는 하위 시계열 수준에서 종속성 발견과 표현 집계를 수행합니다. 자기상관은 효율성과 정확도 면에서 셀프 어텐션를 능가합니다. 장기 예측에서 Autoformer는 에너지, 교통, 경제, 날씨, 질병 등 5가지 실용적 응용 분야를 포괄하는 6개 벤치마크에서 38%의 상대적 개선으로 최첨단 정확도를 달성했습니다.</em>",we,E,lt=`이 모델은 <a href="https://huggingface.co/elisim" rel="nofollow">elisim</a>과 <a href="https://huggingface.co/kashif" rel="nofollow">kashif</a>에 의해 기여 되었습니다.
원본 코드는 <a href="https://github.com/thuml/Autoformer" rel="nofollow">이곳</a>에서 확인할 수 있습니다.`,je,H,ke,P,it="시작하는 데 도움이 되는 Hugging Face와 community 자료 목록(🌎로 표시됨) 입니다. 여기에 포함될 자료를 제출하고 싶으시다면 PR(Pull Request)를 열어주세요. 리뷰 해드리겠습니다! 자료는 기존 자료를 복제하는 대신 새로운 내용을 담고 있어야 합니다.",Je,S,ct='<li>HuggingFace 블로그에서 Autoformer 포스트를 확인하세요: <a href="https://huggingface.co/blog/autoformer" rel="nofollow">네, 그렇습니다, 트랜스포머는 시계열 예측에 효과적입니다(+ Autoformer)</a></li>',Ce,Q,xe,C,L,Be,re,dt=`This is the configuration class to store the configuration of an <a href="/docs/transformers/main/ko/model_doc/autoformer#transformers.AutoformerModel">AutoformerModel</a>. It is used to instantiate an
Autoformer model according to the specified arguments, defining the model architecture. Instantiating a
configuration with the defaults will yield a similar configuration to that of the Autoformer
<a href="https://huggingface.co/huggingface/autoformer-tourism-monthly" rel="nofollow">huggingface/autoformer-tourism-monthly</a>
architecture.`,Re,le,mt=`Configuration objects inherit from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> can be used to control the model outputs. Read the
documentation from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> for more information.`,Ge,X,Ue,D,Ze,j,O,Ne,ie,ut="The bare Autoformer Model outputting raw hidden-states without any specific head on top.",qe,ce,ht=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Ye,de,pt=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,Ie,$,K,Ee,me,ft='The <a href="/docs/transformers/main/ko/model_doc/autoformer#transformers.AutoformerModel">AutoformerModel</a> forward method, overrides the <code>__call__</code> special method.',He,W,Pe,z,$e,ee,Ae,k,te,Se,ue,gt="The Autoformer Model with a distribution head on top for time-series forecasting.",Qe,he,_t=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Le,pe,yt=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,De,J,oe,Oe,fe,bt='The <a href="/docs/transformers/main/ko/model_doc/autoformer#transformers.AutoformerForPrediction">AutoformerForPrediction</a> forward method, overrides the <code>__call__</code> special method.',Ke,V,et,B,tt,R,Fe,ae,Xe,ye,We;return p=new ge({props:{title:"Autoformer",local:"autoformer",headingTag:"h1"}}),f=new ge({props:{title:"개요",local:"overview",headingTag:"h2"}}),H=new ge({props:{title:"자료",local:"resources",headingTag:"h2"}}),Q=new ge({props:{title:"AutoformerConfig",local:"transformers.AutoformerConfig ][ transformers.AutoformerConfig",headingTag:"h2"}}),L=new be({props:{name:"class transformers.AutoformerConfig",anchor:"transformers.AutoformerConfig",parameters:[{name:"prediction_length",val:": typing.Optional[int] = None"},{name:"context_length",val:": typing.Optional[int] = None"},{name:"distribution_output",val:": str = 'student_t'"},{name:"loss",val:": str = 'nll'"},{name:"input_size",val:": int = 1"},{name:"lags_sequence",val:": typing.List[int] = [1, 2, 3, 4, 5, 6, 7]"},{name:"scaling",val:": bool = True"},{name:"num_time_features",val:": int = 0"},{name:"num_dynamic_real_features",val:": int = 0"},{name:"num_static_categorical_features",val:": int = 0"},{name:"num_static_real_features",val:": int = 0"},{name:"cardinality",val:": typing.Optional[typing.List[int]] = None"},{name:"embedding_dimension",val:": typing.Optional[typing.List[int]] = None"},{name:"d_model",val:": int = 64"},{name:"encoder_attention_heads",val:": int = 2"},{name:"decoder_attention_heads",val:": int = 2"},{name:"encoder_layers",val:": int = 2"},{name:"decoder_layers",val:": int = 2"},{name:"encoder_ffn_dim",val:": int = 32"},{name:"decoder_ffn_dim",val:": int = 32"},{name:"activation_function",val:": str = 'gelu'"},{name:"dropout",val:": float = 0.1"},{name:"encoder_layerdrop",val:": float = 0.1"},{name:"decoder_layerdrop",val:": float = 0.1"},{name:"attention_dropout",val:": float = 0.1"},{name:"activation_dropout",val:": float = 0.1"},{name:"num_parallel_samples",val:": int = 100"},{name:"init_std",val:": float = 0.02"},{name:"use_cache",val:": bool = True"},{name:"is_encoder_decoder",val:" = True"},{name:"label_length",val:": int = 10"},{name:"moving_average",val:": int = 25"},{name:"autocorrelation_factor",val:": int = 3"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.AutoformerConfig.prediction_length",description:`<strong>prediction_length</strong> (<code>int</code>) &#x2014;
The prediction length for the decoder. In other words, the prediction horizon of the model.`,name:"prediction_length"},{anchor:"transformers.AutoformerConfig.context_length",description:`<strong>context_length</strong> (<code>int</code>, <em>optional</em>, defaults to <code>prediction_length</code>) &#x2014;
The context length for the encoder. If unset, the context length will be the same as the
<code>prediction_length</code>.`,name:"context_length"},{anchor:"transformers.AutoformerConfig.distribution_output",description:`<strong>distribution_output</strong> (<code>string</code>, <em>optional</em>, defaults to <code>&quot;student_t&quot;</code>) &#x2014;
The distribution emission head for the model. Could be either &#x201C;student_t&#x201D;, &#x201C;normal&#x201D; or &#x201C;negative_binomial&#x201D;.`,name:"distribution_output"},{anchor:"transformers.AutoformerConfig.loss",description:`<strong>loss</strong> (<code>string</code>, <em>optional</em>, defaults to <code>&quot;nll&quot;</code>) &#x2014;
The loss function for the model corresponding to the <code>distribution_output</code> head. For parametric
distributions it is the negative log likelihood (nll) - which currently is the only supported one.`,name:"loss"},{anchor:"transformers.AutoformerConfig.input_size",description:`<strong>input_size</strong> (<code>int</code>, <em>optional</em>, defaults to 1) &#x2014;
The size of the target variable which by default is 1 for univariate targets. Would be &gt; 1 in case of
multivariate targets.`,name:"input_size"},{anchor:"transformers.AutoformerConfig.lags_sequence",description:`<strong>lags_sequence</strong> (<code>list[int]</code>, <em>optional</em>, defaults to <code>[1, 2, 3, 4, 5, 6, 7]</code>) &#x2014;
The lags of the input time series as covariates often dictated by the frequency. Default is <code>[1, 2, 3, 4, 5, 6, 7]</code>.`,name:"lags_sequence"},{anchor:"transformers.AutoformerConfig.scaling",description:`<strong>scaling</strong> (<code>bool</code>, <em>optional</em> defaults to <code>True</code>) &#x2014;
Whether to scale the input targets.`,name:"scaling"},{anchor:"transformers.AutoformerConfig.num_time_features",description:`<strong>num_time_features</strong> (<code>int</code>, <em>optional</em>, defaults to 0) &#x2014;
The number of time features in the input time series.`,name:"num_time_features"},{anchor:"transformers.AutoformerConfig.num_dynamic_real_features",description:`<strong>num_dynamic_real_features</strong> (<code>int</code>, <em>optional</em>, defaults to 0) &#x2014;
The number of dynamic real valued features.`,name:"num_dynamic_real_features"},{anchor:"transformers.AutoformerConfig.num_static_categorical_features",description:`<strong>num_static_categorical_features</strong> (<code>int</code>, <em>optional</em>, defaults to 0) &#x2014;
The number of static categorical features.`,name:"num_static_categorical_features"},{anchor:"transformers.AutoformerConfig.num_static_real_features",description:`<strong>num_static_real_features</strong> (<code>int</code>, <em>optional</em>, defaults to 0) &#x2014;
The number of static real valued features.`,name:"num_static_real_features"},{anchor:"transformers.AutoformerConfig.cardinality",description:`<strong>cardinality</strong> (<code>list[int]</code>, <em>optional</em>) &#x2014;
The cardinality (number of different values) for each of the static categorical features. Should be a list
of integers, having the same length as <code>num_static_categorical_features</code>. Cannot be <code>None</code> if
<code>num_static_categorical_features</code> is &gt; 0.`,name:"cardinality"},{anchor:"transformers.AutoformerConfig.embedding_dimension",description:`<strong>embedding_dimension</strong> (<code>list[int]</code>, <em>optional</em>) &#x2014;
The dimension of the embedding for each of the static categorical features. Should be a list of integers,
having the same length as <code>num_static_categorical_features</code>. Cannot be <code>None</code> if
<code>num_static_categorical_features</code> is &gt; 0.`,name:"embedding_dimension"},{anchor:"transformers.AutoformerConfig.d_model",description:`<strong>d_model</strong> (<code>int</code>, <em>optional</em>, defaults to 64) &#x2014;
Dimensionality of the transformer layers.`,name:"d_model"},{anchor:"transformers.AutoformerConfig.encoder_layers",description:`<strong>encoder_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 2) &#x2014;
Number of encoder layers.`,name:"encoder_layers"},{anchor:"transformers.AutoformerConfig.decoder_layers",description:`<strong>decoder_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 2) &#x2014;
Number of decoder layers.`,name:"decoder_layers"},{anchor:"transformers.AutoformerConfig.encoder_attention_heads",description:`<strong>encoder_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 2) &#x2014;
Number of attention heads for each attention layer in the Transformer encoder.`,name:"encoder_attention_heads"},{anchor:"transformers.AutoformerConfig.decoder_attention_heads",description:`<strong>decoder_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 2) &#x2014;
Number of attention heads for each attention layer in the Transformer decoder.`,name:"decoder_attention_heads"},{anchor:"transformers.AutoformerConfig.encoder_ffn_dim",description:`<strong>encoder_ffn_dim</strong> (<code>int</code>, <em>optional</em>, defaults to 32) &#x2014;
Dimension of the &#x201C;intermediate&#x201D; (often named feed-forward) layer in encoder.`,name:"encoder_ffn_dim"},{anchor:"transformers.AutoformerConfig.decoder_ffn_dim",description:`<strong>decoder_ffn_dim</strong> (<code>int</code>, <em>optional</em>, defaults to 32) &#x2014;
Dimension of the &#x201C;intermediate&#x201D; (often named feed-forward) layer in decoder.`,name:"decoder_ffn_dim"},{anchor:"transformers.AutoformerConfig.activation_function",description:`<strong>activation_function</strong> (<code>str</code> or <code>function</code>, <em>optional</em>, defaults to <code>&quot;gelu&quot;</code>) &#x2014;
The non-linear activation function (function or string) in the encoder and decoder. If string, <code>&quot;gelu&quot;</code> and
<code>&quot;relu&quot;</code> are supported.`,name:"activation_function"},{anchor:"transformers.AutoformerConfig.dropout",description:`<strong>dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.1) &#x2014;
The dropout probability for all fully connected layers in the encoder, and decoder.`,name:"dropout"},{anchor:"transformers.AutoformerConfig.encoder_layerdrop",description:`<strong>encoder_layerdrop</strong> (<code>float</code>, <em>optional</em>, defaults to 0.1) &#x2014;
The dropout probability for the attention and fully connected layers for each encoder layer.`,name:"encoder_layerdrop"},{anchor:"transformers.AutoformerConfig.decoder_layerdrop",description:`<strong>decoder_layerdrop</strong> (<code>float</code>, <em>optional</em>, defaults to 0.1) &#x2014;
The dropout probability for the attention and fully connected layers for each decoder layer.`,name:"decoder_layerdrop"},{anchor:"transformers.AutoformerConfig.attention_dropout",description:`<strong>attention_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.1) &#x2014;
The dropout probability for the attention probabilities.`,name:"attention_dropout"},{anchor:"transformers.AutoformerConfig.activation_dropout",description:`<strong>activation_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.1) &#x2014;
The dropout probability used between the two layers of the feed-forward networks.`,name:"activation_dropout"},{anchor:"transformers.AutoformerConfig.num_parallel_samples",description:`<strong>num_parallel_samples</strong> (<code>int</code>, <em>optional</em>, defaults to 100) &#x2014;
The number of samples to generate in parallel for each time step of inference.`,name:"num_parallel_samples"},{anchor:"transformers.AutoformerConfig.init_std",description:`<strong>init_std</strong> (<code>float</code>, <em>optional</em>, defaults to 0.02) &#x2014;
The standard deviation of the truncated normal weight initialization distribution.`,name:"init_std"},{anchor:"transformers.AutoformerConfig.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether to use the past key/values attentions (if applicable to the model) to speed up decoding.`,name:"use_cache"},{anchor:"transformers.AutoformerConfig.label_length",description:`<strong>label_length</strong> (<code>int</code>, <em>optional</em>, defaults to 10) &#x2014;
Start token length of the Autoformer decoder, which is used for direct multi-step prediction (i.e.
non-autoregressive generation).`,name:"label_length"},{anchor:"transformers.AutoformerConfig.moving_average",description:`<strong>moving_average</strong> (<code>int</code>, <em>optional</em>, defaults to 25) &#x2014;
The window size of the moving average. In practice, it&#x2019;s the kernel size in AvgPool1d of the Decomposition
Layer.`,name:"moving_average"},{anchor:"transformers.AutoformerConfig.autocorrelation_factor",description:`<strong>autocorrelation_factor</strong> (<code>int</code>, <em>optional</em>, defaults to 3) &#x2014;
&#x201C;Attention&#x201D; (i.e. AutoCorrelation mechanism) factor which is used to find top k autocorrelations delays.
It&#x2019;s recommended in the paper to set it to a number between 1 and 5.`,name:"autocorrelation_factor"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/autoformer/configuration_autoformer.py#L26"}}),X=new ze({props:{anchor:"transformers.AutoformerConfig.example",$$slots:{default:[Ct]},$$scope:{ctx:w}}}),D=new ge({props:{title:"AutoformerModel",local:"transformers.AutoformerModel ][ transformers.AutoformerModel",headingTag:"h2"}}),O=new be({props:{name:"class transformers.AutoformerModel",anchor:"transformers.AutoformerModel",parameters:[{name:"config",val:": AutoformerConfig"}],parametersDescription:[{anchor:"transformers.AutoformerModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/autoformer#transformers.AutoformerConfig">AutoformerConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/autoformer/modeling_autoformer.py#L1299"}}),K=new be({props:{name:"forward",anchor:"transformers.AutoformerModel.forward",parameters:[{name:"past_values",val:": Tensor"},{name:"past_time_features",val:": Tensor"},{name:"past_observed_mask",val:": Tensor"},{name:"static_categorical_features",val:": typing.Optional[torch.Tensor] = None"},{name:"static_real_features",val:": typing.Optional[torch.Tensor] = None"},{name:"future_values",val:": typing.Optional[torch.Tensor] = None"},{name:"future_time_features",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_attention_mask",val:": typing.Optional[torch.LongTensor] = None"},{name:"head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"cross_attn_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"encoder_outputs",val:": typing.Optional[typing.List[torch.FloatTensor]] = None"},{name:"past_key_values",val:": typing.Optional[typing.List[torch.FloatTensor]] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.AutoformerModel.forward.past_values",description:`<strong>past_values</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>) &#x2014;
Past values of the time series, that serve as context in order to predict the future. These values may
contain lags, i.e. additional values from the past which are added in order to serve as &#x201C;extra context&#x201D;.
The <code>past_values</code> is what the Transformer encoder gets as input (with optional additional features, such as
<code>static_categorical_features</code>, <code>static_real_features</code>, <code>past_time_features</code>).</p>
<p>The sequence length here is equal to <code>context_length</code> + <code>max(config.lags_sequence)</code>.</p>
<p>Missing values need to be replaced with zeros.`,name:"past_values"},{anchor:"transformers.AutoformerModel.forward.past_time_features",description:`<strong>past_time_features</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length, num_features)</code>, <em>optional</em>) &#x2014;
Optional time features, which the model internally will add to <code>past_values</code>. These could be things like
&#x201C;month of year&#x201D;, &#x201C;day of the month&#x201D;, etc. encoded as vectors (for instance as Fourier features). These
could also be so-called &#x201C;age&#x201D; features, which basically help the model know &#x201C;at which point in life&#x201D; a
time-series is. Age features have small values for distant past time steps and increase monotonically the
more we approach the current time step.</p>
<p>These features serve as the &#x201C;positional encodings&#x201D; of the inputs. So contrary to a model like BERT, where
the position encodings are learned from scratch internally as parameters of the model, the Time Series
Transformer requires to provide additional time features.</p>
<p>The Autoformer only learns additional embeddings for <code>static_categorical_features</code>.`,name:"past_time_features"},{anchor:"transformers.AutoformerModel.forward.past_observed_mask",description:`<strong>past_observed_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Boolean mask to indicate which <code>past_values</code> were observed and which were missing. Mask values selected in
<code>[0, 1]</code>:</p>
<ul>
<li>1 for values that are <strong>observed</strong>,</li>
<li>0 for values that are <strong>missing</strong> (i.e. NaNs that were replaced by zeros).</li>
</ul>`,name:"past_observed_mask"},{anchor:"transformers.AutoformerModel.forward.static_categorical_features",description:`<strong>static_categorical_features</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, number of static categorical features)</code>, <em>optional</em>) &#x2014;
Optional static categorical features for which the model will learn an embedding, which it will add to the
values of the time series.</p>
<p>Static categorical features are features which have the same value for all time steps (static over time).</p>
<p>A typical example of a static categorical feature is a time series ID.`,name:"static_categorical_features"},{anchor:"transformers.AutoformerModel.forward.static_real_features",description:`<strong>static_real_features</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, number of static real features)</code>, <em>optional</em>) &#x2014;
Optional static real features which the model will add to the values of the time series.</p>
<p>Static real features are features which have the same value for all time steps (static over time).</p>
<p>A typical example of a static real feature is promotion information.`,name:"static_real_features"},{anchor:"transformers.AutoformerModel.forward.future_values",description:`<strong>future_values</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, prediction_length)</code>) &#x2014;
Future values of the time series, that serve as labels for the model. The <code>future_values</code> is what the
Transformer needs to learn to output, given the <code>past_values</code>.</p>
<p>See the demo notebook and code snippets for details.</p>
<p>Missing values need to be replaced with zeros.`,name:"future_values"},{anchor:"transformers.AutoformerModel.forward.future_time_features",description:`<strong>future_time_features</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, prediction_length, num_features)</code>, <em>optional</em>) &#x2014;
Optional time features, which the model internally will add to <code>future_values</code>. These could be things like
&#x201C;month of year&#x201D;, &#x201C;day of the month&#x201D;, etc. encoded as vectors (for instance as Fourier features). These
could also be so-called &#x201C;age&#x201D; features, which basically help the model know &#x201C;at which point in life&#x201D; a
time-series is. Age features have small values for distant past time steps and increase monotonically the
more we approach the current time step.</p>
<p>These features serve as the &#x201C;positional encodings&#x201D; of the inputs. So contrary to a model like BERT, where
the position encodings are learned from scratch internally as parameters of the model, the Time Series
Transformer requires to provide additional features.</p>
<p>The Autoformer only learns additional embeddings for <code>static_categorical_features</code>.`,name:"future_time_features"},{anchor:"transformers.AutoformerModel.forward.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on certain token indices. By default, a causal mask will be used, to
make sure the model can only look at previous inputs in order to predict the future.`,name:"decoder_attention_mask"},{anchor:"transformers.AutoformerModel.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.Tensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.AutoformerModel.forward.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.AutoformerModel.forward.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.AutoformerModel.forward.encoder_outputs",description:"<strong>encoder_outputs</strong> (<code>List[torch.FloatTensor]</code>)<code>, *optional*) -- Tuple consists of </code>last_hidden_state<code>, </code>hidden_states<code>(*optional*) and</code>attentions<code>(*optional*)</code>last_hidden_state<code>of shape</code>(batch_size, sequence_length, hidden_size)` (<em>optional</em>) is a sequence of\nhidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.",name:"encoder_outputs"},{anchor:"transformers.AutoformerModel.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>List[torch.FloatTensor]</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.AutoformerModel.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.AutoformerModel.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.AutoformerModel.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.AutoformerModel.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/autoformer/modeling_autoformer.py#L1474",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>transformers.models.autoformer.modeling_autoformer.AutoformerModelOutput</code> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/autoformer#transformers.AutoformerConfig"
>AutoformerConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the decoder of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>trend</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Trend tensor for each time series.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>tuple(tuple(torch.FloatTensor))</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of shape
<code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>) and 2 additional tensors of shape
<code>(batch_size, num_heads, encoder_sequence_length, embed_size_per_head)</code>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>loc</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size,)</code> or <code>(batch_size, input_size)</code>, <em>optional</em>) — Shift values of each time series’ context window which is used to give the model inputs of the same
magnitude and then used to shift back to the original magnitude.</p>
</li>
<li>
<p><strong>scale</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size,)</code> or <code>(batch_size, input_size)</code>, <em>optional</em>) — Scaling values of each time series’ context window which is used to give the model inputs of the same
magnitude and then used to rescale back to the original magnitude.</p>
</li>
<li>
<p><strong>static_features:</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, feature size)</code>, <em>optional</em>) — Static features of each time series’ in a batch which are copied to the covariates at inference time.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>transformers.models.autoformer.modeling_autoformer.AutoformerModelOutput</code> or <code>tuple(torch.FloatTensor)</code></p>
`}}),W=new ot({props:{$$slots:{default:[xt]},$$scope:{ctx:w}}}),z=new ze({props:{anchor:"transformers.AutoformerModel.forward.example",$$slots:{default:[Ut]},$$scope:{ctx:w}}}),ee=new ge({props:{title:"AutoformerForPrediction",local:"transformers.AutoformerForPrediction ][ transformers.AutoformerForPrediction",headingTag:"h2"}}),te=new be({props:{name:"class transformers.AutoformerForPrediction",anchor:"transformers.AutoformerForPrediction",parameters:[{name:"config",val:": AutoformerConfig"}],parametersDescription:[{anchor:"transformers.AutoformerForPrediction.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/autoformer#transformers.AutoformerConfig">AutoformerConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/autoformer/modeling_autoformer.py#L1698"}}),oe=new be({props:{name:"forward",anchor:"transformers.AutoformerForPrediction.forward",parameters:[{name:"past_values",val:": Tensor"},{name:"past_time_features",val:": Tensor"},{name:"past_observed_mask",val:": Tensor"},{name:"static_categorical_features",val:": typing.Optional[torch.Tensor] = None"},{name:"static_real_features",val:": typing.Optional[torch.Tensor] = None"},{name:"future_values",val:": typing.Optional[torch.Tensor] = None"},{name:"future_time_features",val:": typing.Optional[torch.Tensor] = None"},{name:"future_observed_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_attention_mask",val:": typing.Optional[torch.LongTensor] = None"},{name:"head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"cross_attn_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"encoder_outputs",val:": typing.Optional[typing.List[torch.FloatTensor]] = None"},{name:"past_key_values",val:": typing.Optional[typing.List[torch.FloatTensor]] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.AutoformerForPrediction.forward.past_values",description:`<strong>past_values</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>) &#x2014;
Past values of the time series, that serve as context in order to predict the future. These values may
contain lags, i.e. additional values from the past which are added in order to serve as &#x201C;extra context&#x201D;.
The <code>past_values</code> is what the Transformer encoder gets as input (with optional additional features, such as
<code>static_categorical_features</code>, <code>static_real_features</code>, <code>past_time_features</code>).</p>
<p>The sequence length here is equal to <code>context_length</code> + <code>max(config.lags_sequence)</code>.</p>
<p>Missing values need to be replaced with zeros.`,name:"past_values"},{anchor:"transformers.AutoformerForPrediction.forward.past_time_features",description:`<strong>past_time_features</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length, num_features)</code>, <em>optional</em>) &#x2014;
Optional time features, which the model internally will add to <code>past_values</code>. These could be things like
&#x201C;month of year&#x201D;, &#x201C;day of the month&#x201D;, etc. encoded as vectors (for instance as Fourier features). These
could also be so-called &#x201C;age&#x201D; features, which basically help the model know &#x201C;at which point in life&#x201D; a
time-series is. Age features have small values for distant past time steps and increase monotonically the
more we approach the current time step.</p>
<p>These features serve as the &#x201C;positional encodings&#x201D; of the inputs. So contrary to a model like BERT, where
the position encodings are learned from scratch internally as parameters of the model, the Time Series
Transformer requires to provide additional time features.</p>
<p>The Autoformer only learns additional embeddings for <code>static_categorical_features</code>.`,name:"past_time_features"},{anchor:"transformers.AutoformerForPrediction.forward.past_observed_mask",description:`<strong>past_observed_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Boolean mask to indicate which <code>past_values</code> were observed and which were missing. Mask values selected in
<code>[0, 1]</code>:</p>
<ul>
<li>1 for values that are <strong>observed</strong>,</li>
<li>0 for values that are <strong>missing</strong> (i.e. NaNs that were replaced by zeros).</li>
</ul>`,name:"past_observed_mask"},{anchor:"transformers.AutoformerForPrediction.forward.static_categorical_features",description:`<strong>static_categorical_features</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, number of static categorical features)</code>, <em>optional</em>) &#x2014;
Optional static categorical features for which the model will learn an embedding, which it will add to the
values of the time series.</p>
<p>Static categorical features are features which have the same value for all time steps (static over time).</p>
<p>A typical example of a static categorical feature is a time series ID.`,name:"static_categorical_features"},{anchor:"transformers.AutoformerForPrediction.forward.static_real_features",description:`<strong>static_real_features</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, number of static real features)</code>, <em>optional</em>) &#x2014;
Optional static real features which the model will add to the values of the time series.</p>
<p>Static real features are features which have the same value for all time steps (static over time).</p>
<p>A typical example of a static real feature is promotion information.`,name:"static_real_features"},{anchor:"transformers.AutoformerForPrediction.forward.future_values",description:`<strong>future_values</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, prediction_length)</code>) &#x2014;
Future values of the time series, that serve as labels for the model. The <code>future_values</code> is what the
Transformer needs to learn to output, given the <code>past_values</code>.</p>
<p>See the demo notebook and code snippets for details.</p>
<p>Missing values need to be replaced with zeros.`,name:"future_values"},{anchor:"transformers.AutoformerForPrediction.forward.future_time_features",description:`<strong>future_time_features</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, prediction_length, num_features)</code>, <em>optional</em>) &#x2014;
Optional time features, which the model internally will add to <code>future_values</code>. These could be things like
&#x201C;month of year&#x201D;, &#x201C;day of the month&#x201D;, etc. encoded as vectors (for instance as Fourier features). These
could also be so-called &#x201C;age&#x201D; features, which basically help the model know &#x201C;at which point in life&#x201D; a
time-series is. Age features have small values for distant past time steps and increase monotonically the
more we approach the current time step.</p>
<p>These features serve as the &#x201C;positional encodings&#x201D; of the inputs. So contrary to a model like BERT, where
the position encodings are learned from scratch internally as parameters of the model, the Time Series
Transformer requires to provide additional features.</p>
<p>The Autoformer only learns additional embeddings for <code>static_categorical_features</code>.`,name:"future_time_features"},{anchor:"transformers.AutoformerForPrediction.forward.future_observed_mask",description:`<strong>future_observed_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code> or <code>(batch_size, sequence_length, input_size)</code>, <em>optional</em>) &#x2014;
Boolean mask to indicate which <code>future_values</code> were observed and which were missing. Mask values selected
in <code>[0, 1]</code>:</p>
<ul>
<li>1 for values that are <strong>observed</strong>,</li>
<li>0 for values that are <strong>missing</strong> (i.e. NaNs that were replaced by zeros).</li>
</ul>
<p>This mask is used to filter out missing values for the final loss calculation.`,name:"future_observed_mask"},{anchor:"transformers.AutoformerForPrediction.forward.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on certain token indices. By default, a causal mask will be used, to
make sure the model can only look at previous inputs in order to predict the future.`,name:"decoder_attention_mask"},{anchor:"transformers.AutoformerForPrediction.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.Tensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.AutoformerForPrediction.forward.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.AutoformerForPrediction.forward.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.AutoformerForPrediction.forward.encoder_outputs",description:"<strong>encoder_outputs</strong> (<code>List[torch.FloatTensor]</code>)<code>, *optional*) -- Tuple consists of </code>last_hidden_state<code>, </code>hidden_states<code>(*optional*) and</code>attentions<code>(*optional*)</code>last_hidden_state<code>of shape</code>(batch_size, sequence_length, hidden_size)` (<em>optional</em>) is a sequence of\nhidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.",name:"encoder_outputs"},{anchor:"transformers.AutoformerForPrediction.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>List[torch.FloatTensor]</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.AutoformerForPrediction.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.AutoformerForPrediction.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.AutoformerForPrediction.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.AutoformerForPrediction.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/autoformer/modeling_autoformer.py#L1739",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqTSPredictionOutput"
>transformers.modeling_outputs.Seq2SeqTSPredictionOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/autoformer#transformers.AutoformerConfig"
>AutoformerConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when a <code>future_values</code> is provided) — Distributional loss.</p>
</li>
<li>
<p><strong>params</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, num_samples, num_params)</code>) — Parameters of the chosen distribution.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>EncoderDecoderCache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.EncoderDecoderCache"
>EncoderDecoderCache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>loc</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size,)</code> or <code>(batch_size, input_size)</code>, <em>optional</em>) — Shift values of each time series’ context window which is used to give the model inputs of the same
magnitude and then used to shift back to the original magnitude.</p>
</li>
<li>
<p><strong>scale</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size,)</code> or <code>(batch_size, input_size)</code>, <em>optional</em>) — Scaling values of each time series’ context window which is used to give the model inputs of the same
magnitude and then used to rescale back to the original magnitude.</p>
</li>
<li>
<p><strong>static_features</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, feature size)</code>, <em>optional</em>) — Static features of each time series’ in a batch which are copied to the covariates at inference time.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqTSPredictionOutput"
>transformers.modeling_outputs.Seq2SeqTSPredictionOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),V=new ot({props:{$$slots:{default:[Zt]},$$scope:{ctx:w}}}),B=new ze({props:{anchor:"transformers.AutoformerForPrediction.forward.example",$$slots:{default:[$t]},$$scope:{ctx:w}}}),R=new ot({props:{$$slots:{default:[Ft]},$$scope:{ctx:w}}}),ae=new Jt({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/autoformer.md"}}),{c(){o=m("meta"),h=l(),s=m("p"),r=l(),g(p.$$.fragment),t=l(),g(f.$$.fragment),G=l(),N=m("p"),N.innerHTML=at,Me=l(),q=m("p"),q.textContent=nt,ve=l(),Y=m("p"),Y.textContent=st,Te=l(),I=m("p"),I.innerHTML=rt,we=l(),E=m("p"),E.innerHTML=lt,je=l(),g(H.$$.fragment),ke=l(),P=m("p"),P.textContent=it,Je=l(),S=m("ul"),S.innerHTML=ct,Ce=l(),g(Q.$$.fragment),xe=l(),C=m("div"),g(L.$$.fragment),Be=l(),re=m("p"),re.innerHTML=dt,Re=l(),le=m("p"),le.innerHTML=mt,Ge=l(),g(X.$$.fragment),Ue=l(),g(D.$$.fragment),Ze=l(),j=m("div"),g(O.$$.fragment),Ne=l(),ie=m("p"),ie.textContent=ut,qe=l(),ce=m("p"),ce.innerHTML=ht,Ye=l(),de=m("p"),de.innerHTML=pt,Ie=l(),$=m("div"),g(K.$$.fragment),Ee=l(),me=m("p"),me.innerHTML=ft,He=l(),g(W.$$.fragment),Pe=l(),g(z.$$.fragment),$e=l(),g(ee.$$.fragment),Ae=l(),k=m("div"),g(te.$$.fragment),Se=l(),ue=m("p"),ue.textContent=gt,Qe=l(),he=m("p"),he.innerHTML=_t,Le=l(),pe=m("p"),pe.innerHTML=yt,De=l(),J=m("div"),g(oe.$$.fragment),Oe=l(),fe=m("p"),fe.innerHTML=bt,Ke=l(),g(V.$$.fragment),et=l(),g(B.$$.fragment),tt=l(),g(R.$$.fragment),Fe=l(),g(ae.$$.fragment),Xe=l(),ye=m("p"),this.h()},l(e){const a=kt("svelte-u9bgzb",document.head);o=u(a,"META",{name:!0,content:!0}),a.forEach(n),h=i(e),s=u(e,"P",{}),ne(s).forEach(n),r=i(e),_(p.$$.fragment,e),t=i(e),_(f.$$.fragment,e),G=i(e),N=u(e,"P",{"data-svelte-h":!0}),T(N)!=="svelte-4ycyx4"&&(N.innerHTML=at),Me=i(e),q=u(e,"P",{"data-svelte-h":!0}),T(q)!=="svelte-me1687"&&(q.textContent=nt),ve=i(e),Y=u(e,"P",{"data-svelte-h":!0}),T(Y)!=="svelte-un5jih"&&(Y.textContent=st),Te=i(e),I=u(e,"P",{"data-svelte-h":!0}),T(I)!=="svelte-16n8wwn"&&(I.innerHTML=rt),we=i(e),E=u(e,"P",{"data-svelte-h":!0}),T(E)!=="svelte-zg1910"&&(E.innerHTML=lt),je=i(e),_(H.$$.fragment,e),ke=i(e),P=u(e,"P",{"data-svelte-h":!0}),T(P)!=="svelte-rx2qeg"&&(P.textContent=it),Je=i(e),S=u(e,"UL",{"data-svelte-h":!0}),T(S)!=="svelte-1igau7n"&&(S.innerHTML=ct),Ce=i(e),_(Q.$$.fragment,e),xe=i(e),C=u(e,"DIV",{class:!0});var A=ne(C);_(L.$$.fragment,A),Be=i(A),re=u(A,"P",{"data-svelte-h":!0}),T(re)!=="svelte-t6wxy0"&&(re.innerHTML=dt),Re=i(A),le=u(A,"P",{"data-svelte-h":!0}),T(le)!=="svelte-vtbbmk"&&(le.innerHTML=mt),Ge=i(A),_(X.$$.fragment,A),A.forEach(n),Ue=i(e),_(D.$$.fragment,e),Ze=i(e),j=u(e,"DIV",{class:!0});var x=ne(j);_(O.$$.fragment,x),Ne=i(x),ie=u(x,"P",{"data-svelte-h":!0}),T(ie)!=="svelte-c8j2uu"&&(ie.textContent=ut),qe=i(x),ce=u(x,"P",{"data-svelte-h":!0}),T(ce)!=="svelte-u3dlub"&&(ce.innerHTML=ht),Ye=i(x),de=u(x,"P",{"data-svelte-h":!0}),T(de)!=="svelte-hswkmf"&&(de.innerHTML=pt),Ie=i(x),$=u(x,"DIV",{class:!0});var F=ne($);_(K.$$.fragment,F),Ee=i(F),me=u(F,"P",{"data-svelte-h":!0}),T(me)!=="svelte-12lsosk"&&(me.innerHTML=ft),He=i(F),_(W.$$.fragment,F),Pe=i(F),_(z.$$.fragment,F),F.forEach(n),x.forEach(n),$e=i(e),_(ee.$$.fragment,e),Ae=i(e),k=u(e,"DIV",{class:!0});var U=ne(k);_(te.$$.fragment,U),Se=i(U),ue=u(U,"P",{"data-svelte-h":!0}),T(ue)!=="svelte-1gxg89a"&&(ue.textContent=gt),Qe=i(U),he=u(U,"P",{"data-svelte-h":!0}),T(he)!=="svelte-u3dlub"&&(he.innerHTML=_t),Le=i(U),pe=u(U,"P",{"data-svelte-h":!0}),T(pe)!=="svelte-hswkmf"&&(pe.innerHTML=yt),De=i(U),J=u(U,"DIV",{class:!0});var Z=ne(J);_(oe.$$.fragment,Z),Oe=i(Z),fe=u(Z,"P",{"data-svelte-h":!0}),T(fe)!=="svelte-14yic70"&&(fe.innerHTML=bt),Ke=i(Z),_(V.$$.fragment,Z),et=i(Z),_(B.$$.fragment,Z),tt=i(Z),_(R.$$.fragment,Z),Z.forEach(n),U.forEach(n),Fe=i(e),_(ae.$$.fragment,e),Xe=i(e),ye=u(e,"P",{}),ne(ye).forEach(n),this.h()},h(){se(o,"name","hf:doc:metadata"),se(o,"content",Wt),se(C,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),se($,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),se(j,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),se(J,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),se(k,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,a){d(document.head,o),c(e,h,a),c(e,s,a),c(e,r,a),y(p,e,a),c(e,t,a),y(f,e,a),c(e,G,a),c(e,N,a),c(e,Me,a),c(e,q,a),c(e,ve,a),c(e,Y,a),c(e,Te,a),c(e,I,a),c(e,we,a),c(e,E,a),c(e,je,a),y(H,e,a),c(e,ke,a),c(e,P,a),c(e,Je,a),c(e,S,a),c(e,Ce,a),y(Q,e,a),c(e,xe,a),c(e,C,a),y(L,C,null),d(C,Be),d(C,re),d(C,Re),d(C,le),d(C,Ge),y(X,C,null),c(e,Ue,a),y(D,e,a),c(e,Ze,a),c(e,j,a),y(O,j,null),d(j,Ne),d(j,ie),d(j,qe),d(j,ce),d(j,Ye),d(j,de),d(j,Ie),d(j,$),y(K,$,null),d($,Ee),d($,me),d($,He),y(W,$,null),d($,Pe),y(z,$,null),c(e,$e,a),y(ee,e,a),c(e,Ae,a),c(e,k,a),y(te,k,null),d(k,Se),d(k,ue),d(k,Qe),d(k,he),d(k,Le),d(k,pe),d(k,De),d(k,J),y(oe,J,null),d(J,Oe),d(J,fe),d(J,Ke),y(V,J,null),d(J,et),y(B,J,null),d(J,tt),y(R,J,null),c(e,Fe,a),y(ae,e,a),c(e,Xe,a),c(e,ye,a),We=!0},p(e,[a]){const A={};a&2&&(A.$$scope={dirty:a,ctx:e}),X.$set(A);const x={};a&2&&(x.$$scope={dirty:a,ctx:e}),W.$set(x);const F={};a&2&&(F.$$scope={dirty:a,ctx:e}),z.$set(F);const U={};a&2&&(U.$$scope={dirty:a,ctx:e}),V.$set(U);const Z={};a&2&&(Z.$$scope={dirty:a,ctx:e}),B.$set(Z);const Mt={};a&2&&(Mt.$$scope={dirty:a,ctx:e}),R.$set(Mt)},i(e){We||(b(p.$$.fragment,e),b(f.$$.fragment,e),b(H.$$.fragment,e),b(Q.$$.fragment,e),b(L.$$.fragment,e),b(X.$$.fragment,e),b(D.$$.fragment,e),b(O.$$.fragment,e),b(K.$$.fragment,e),b(W.$$.fragment,e),b(z.$$.fragment,e),b(ee.$$.fragment,e),b(te.$$.fragment,e),b(oe.$$.fragment,e),b(V.$$.fragment,e),b(B.$$.fragment,e),b(R.$$.fragment,e),b(ae.$$.fragment,e),We=!0)},o(e){M(p.$$.fragment,e),M(f.$$.fragment,e),M(H.$$.fragment,e),M(Q.$$.fragment,e),M(L.$$.fragment,e),M(X.$$.fragment,e),M(D.$$.fragment,e),M(O.$$.fragment,e),M(K.$$.fragment,e),M(W.$$.fragment,e),M(z.$$.fragment,e),M(ee.$$.fragment,e),M(te.$$.fragment,e),M(oe.$$.fragment,e),M(V.$$.fragment,e),M(B.$$.fragment,e),M(R.$$.fragment,e),M(ae.$$.fragment,e),We=!1},d(e){e&&(n(h),n(s),n(r),n(t),n(G),n(N),n(Me),n(q),n(ve),n(Y),n(Te),n(I),n(we),n(E),n(je),n(ke),n(P),n(Je),n(S),n(Ce),n(xe),n(C),n(Ue),n(Ze),n(j),n($e),n(Ae),n(k),n(Fe),n(Xe),n(ye)),n(o),v(p,e),v(f,e),v(H,e),v(Q,e),v(L),v(X),v(D,e),v(O),v(K),v(W),v(z),v(ee,e),v(te),v(oe),v(V),v(B),v(R),v(ae,e)}}}const Wt='{"title":"Autoformer","local":"autoformer","sections":[{"title":"개요","local":"overview","sections":[],"depth":2},{"title":"자료","local":"resources","sections":[],"depth":2},{"title":"AutoformerConfig","local":"transformers.AutoformerConfig ][ transformers.AutoformerConfig","sections":[],"depth":2},{"title":"AutoformerModel","local":"transformers.AutoformerModel ][ transformers.AutoformerModel","sections":[],"depth":2},{"title":"AutoformerForPrediction","local":"transformers.AutoformerForPrediction ][ transformers.AutoformerForPrediction","sections":[],"depth":2}],"depth":1}';function zt(w){return Tt(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class It extends wt{constructor(o){super(),jt(this,o,zt,Xt,vt,{})}}export{It as component};
