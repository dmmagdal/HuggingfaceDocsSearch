import{s as fi,o as gi,n as C}from"../chunks/scheduler.bdbef820.js";import{S as _i,i as yi,g as d,s,r as m,A as bi,h as l,f as r,c as a,j as x,u,x as b,k as M,y as t,a as h,v as f,d as g,t as _,w as y}from"../chunks/index.33f81d56.js";import{T as he}from"../chunks/Tip.34194030.js";import{D as $}from"../chunks/Docstring.abcbe1ac.js";import{C as te}from"../chunks/CodeBlock.3bad7fc9.js";import{E as ne}from"../chunks/ExampleCodeBlock.16b3b633.js";import{H as Z,E as ki}from"../chunks/getInferenceSnippets.64cd9466.js";function Ti(v){let o,k="Example:",c,p,T;return p=new te({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMFdoaXNwZXJDb25maWclMkMlMjBXaGlzcGVyTW9kZWwlMEElMEElMjMlMjBJbml0aWFsaXppbmclMjBhJTIwV2hpc3BlciUyMHRpbnklMjBzdHlsZSUyMGNvbmZpZ3VyYXRpb24lMEFjb25maWd1cmF0aW9uJTIwJTNEJTIwV2hpc3BlckNvbmZpZygpJTBBJTBBJTIzJTIwSW5pdGlhbGl6aW5nJTIwYSUyMG1vZGVsJTIwKHdpdGglMjByYW5kb20lMjB3ZWlnaHRzKSUyMGZyb20lMjB0aGUlMjB0aW55JTIwc3R5bGUlMjBjb25maWd1cmF0aW9uJTBBbW9kZWwlMjAlM0QlMjBXaGlzcGVyTW9kZWwoY29uZmlndXJhdGlvbiklMEElMEElMjMlMjBBY2Nlc3NpbmclMjB0aGUlMjBtb2RlbCUyMGNvbmZpZ3VyYXRpb24lMEFjb25maWd1cmF0aW9uJTIwJTNEJTIwbW9kZWwuY29uZmln",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> WhisperConfig, WhisperModel

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a Whisper tiny style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = WhisperConfig()

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a model (with random weights) from the tiny style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = WhisperModel(configuration)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Accessing the model configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = model.config`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-11lpom8"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function wi(v){let o,k="update the prefix tokens as required when fine-tuning. Example:",c,p,T;return p=new te({props:{code:"JTIzJTIwaW5zdGFudGlhdGUlMjB0aGUlMjB0b2tlbml6ZXIlMjBhbmQlMjBzZXQlMjB0aGUlMjBwcmVmaXglMjB0b2tlbiUyMHRvJTIwU3BhbmlzaCUwQXRva2VuaXplciUyMCUzRCUyMFdoaXNwZXJUb2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMm9wZW5haSUyRndoaXNwZXItdGlueSUyMiUyQyUyMGxhbmd1YWdlJTNEJTIyc3BhbmlzaCUyMiklMEElMjMlMjBub3clMjBzd2l0Y2glMjB0aGUlMjBwcmVmaXglMjB0b2tlbiUyMGZyb20lMjBTcGFuaXNoJTIwdG8lMjBGcmVuY2glMEF0b2tlbml6ZXIuc2V0X3ByZWZpeF90b2tlbnMobGFuZ3VhZ2UlM0QlMjJmcmVuY2glMjIp",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># instantiate the tokenizer and set the prefix token to Spanish</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = WhisperTokenizer.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny&quot;</span>, language=<span class="hljs-string">&quot;spanish&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># now switch the prefix token from Spanish to French</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.set_prefix_tokens(language=<span class="hljs-string">&quot;french&quot;</span>)`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-14u5irj"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function vi(v){let o,k="update the prefix tokens as required when fine-tuning. Example:",c,p,T;return p=new te({props:{code:"JTIzJTIwaW5zdGFudGlhdGUlMjB0aGUlMjB0b2tlbml6ZXIlMjBhbmQlMjBzZXQlMjB0aGUlMjBwcmVmaXglMjB0b2tlbiUyMHRvJTIwU3BhbmlzaCUwQXRva2VuaXplciUyMCUzRCUyMFdoaXNwZXJUb2tlbml6ZXJGYXN0LmZyb21fcHJldHJhaW5lZCglMjJvcGVuYWklMkZ3aGlzcGVyLXRpbnklMjIlMkMlMjBsYW5ndWFnZSUzRCUyMnNwYW5pc2glMjIpJTBBJTIzJTIwbm93JTIwc3dpdGNoJTIwdGhlJTIwcHJlZml4JTIwdG9rZW4lMjBmcm9tJTIwU3BhbmlzaCUyMHRvJTIwRnJlbmNoJTBBdG9rZW5pemVyLnNldF9wcmVmaXhfdG9rZW5zKGxhbmd1YWdlJTNEJTIyZnJlbmNoJTIyKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># instantiate the tokenizer and set the prefix token to Spanish</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = WhisperTokenizerFast.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny&quot;</span>, language=<span class="hljs-string">&quot;spanish&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># now switch the prefix token from Spanish to French</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.set_prefix_tokens(language=<span class="hljs-string">&quot;french&quot;</span>)`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-14u5irj"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function xi(v){let o,k=`This class method is simply calling the feature extractor
<a href="/docs/transformers/main/ko/main_classes/feature_extractor#transformers.FeatureExtractionMixin.from_pretrained">from_pretrained()</a>, image processor
<a href="/docs/transformers/main/ko/internal/image_processing_utils#transformers.ImageProcessingMixin">ImageProcessingMixin</a> and the tokenizer
<code>~tokenization_utils_base.PreTrainedTokenizer.from_pretrained</code> methods. Please refer to the docstrings of the
methods above for more information.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-m71e3l"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function Mi(v){let o,k=`This class method is simply calling <a href="/docs/transformers/main/ko/main_classes/feature_extractor#transformers.FeatureExtractionMixin.save_pretrained">save_pretrained()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.save_pretrained">save_pretrained()</a>. Please refer to the docstrings of the
methods above for more information.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-6ezuwc"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function $i(v){let o,k=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-fincs2"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function Wi(v){let o,k="Example:",c,p,T;return p=new te({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b0ZlYXR1cmVFeHRyYWN0b3IlMkMlMjBXaGlzcGVyTW9kZWwlMEFmcm9tJTIwZGF0YXNldHMlMjBpbXBvcnQlMjBsb2FkX2RhdGFzZXQlMEElMEFtb2RlbCUyMCUzRCUyMFdoaXNwZXJNb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIyb3BlbmFpJTJGd2hpc3Blci1iYXNlJTIyKSUwQWZlYXR1cmVfZXh0cmFjdG9yJTIwJTNEJTIwQXV0b0ZlYXR1cmVFeHRyYWN0b3IuZnJvbV9wcmV0cmFpbmVkKCUyMm9wZW5haSUyRndoaXNwZXItYmFzZSUyMiklMEFkcyUyMCUzRCUyMGxvYWRfZGF0YXNldCglMjJoZi1pbnRlcm5hbC10ZXN0aW5nJTJGbGlicmlzcGVlY2hfYXNyX2R1bW15JTIyJTJDJTIwJTIyY2xlYW4lMjIlMkMlMjBzcGxpdCUzRCUyMnZhbGlkYXRpb24lMjIpJTBBaW5wdXRzJTIwJTNEJTIwZmVhdHVyZV9leHRyYWN0b3IoZHMlNUIwJTVEJTVCJTIyYXVkaW8lMjIlNUQlNUIlMjJhcnJheSUyMiU1RCUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpJTBBaW5wdXRfZmVhdHVyZXMlMjAlM0QlMjBpbnB1dHMuaW5wdXRfZmVhdHVyZXMlMEFkZWNvZGVyX2lucHV0X2lkcyUyMCUzRCUyMHRvcmNoLnRlbnNvciglNUIlNUIxJTJDJTIwMSU1RCU1RCklMjAqJTIwbW9kZWwuY29uZmlnLmRlY29kZXJfc3RhcnRfdG9rZW5faWQlMEFsYXN0X2hpZGRlbl9zdGF0ZSUyMCUzRCUyMG1vZGVsKGlucHV0X2ZlYXR1cmVzJTJDJTIwZGVjb2Rlcl9pbnB1dF9pZHMlM0RkZWNvZGVyX2lucHV0X2lkcykubGFzdF9oaWRkZW5fc3RhdGUlMEFsaXN0KGxhc3RfaGlkZGVuX3N0YXRlLnNoYXBlKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoFeatureExtractor, WhisperModel
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> datasets <span class="hljs-keyword">import</span> load_dataset

<span class="hljs-meta">&gt;&gt;&gt; </span>model = WhisperModel.from_pretrained(<span class="hljs-string">&quot;openai/whisper-base&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>feature_extractor = AutoFeatureExtractor.from_pretrained(<span class="hljs-string">&quot;openai/whisper-base&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>ds = load_dataset(<span class="hljs-string">&quot;hf-internal-testing/librispeech_asr_dummy&quot;</span>, <span class="hljs-string">&quot;clean&quot;</span>, split=<span class="hljs-string">&quot;validation&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = feature_extractor(ds[<span class="hljs-number">0</span>][<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;array&quot;</span>], return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>input_features = inputs.input_features
<span class="hljs-meta">&gt;&gt;&gt; </span>decoder_input_ids = torch.tensor([[<span class="hljs-number">1</span>, <span class="hljs-number">1</span>]]) * model.config.decoder_start_token_id
<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_state = model(input_features, decoder_input_ids=decoder_input_ids).last_hidden_state
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">list</span>(last_hidden_state.shape)
[<span class="hljs-number">1</span>, <span class="hljs-number">2</span>, <span class="hljs-number">512</span>]`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-11lpom8"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function Fi(v){let o,k=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-fincs2"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function zi(v){let o,k="Example:",c,p,T;return p=new te({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b1Byb2Nlc3NvciUyQyUyMFdoaXNwZXJGb3JDb25kaXRpb25hbEdlbmVyYXRpb24lMEFmcm9tJTIwZGF0YXNldHMlMjBpbXBvcnQlMjBsb2FkX2RhdGFzZXQlMEElMEFwcm9jZXNzb3IlMjAlM0QlMjBBdXRvUHJvY2Vzc29yLmZyb21fcHJldHJhaW5lZCglMjJvcGVuYWklMkZ3aGlzcGVyLXRpbnkuZW4lMjIpJTBBbW9kZWwlMjAlM0QlMjBXaGlzcGVyRm9yQ29uZGl0aW9uYWxHZW5lcmF0aW9uLmZyb21fcHJldHJhaW5lZCglMjJvcGVuYWklMkZ3aGlzcGVyLXRpbnkuZW4lMjIpJTBBJTBBZHMlMjAlM0QlMjBsb2FkX2RhdGFzZXQoJTIyaGYtaW50ZXJuYWwtdGVzdGluZyUyRmxpYnJpc3BlZWNoX2Fzcl9kdW1teSUyMiUyQyUyMCUyMmNsZWFuJTIyJTJDJTIwc3BsaXQlM0QlMjJ2YWxpZGF0aW9uJTIyKSUwQSUwQWlucHV0cyUyMCUzRCUyMHByb2Nlc3NvcihkcyU1QjAlNUQlNUIlMjJhdWRpbyUyMiU1RCU1QiUyMmFycmF5JTIyJTVEJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMiklMEFpbnB1dF9mZWF0dXJlcyUyMCUzRCUyMGlucHV0cy5pbnB1dF9mZWF0dXJlcyUwQSUwQWdlbmVyYXRlZF9pZHMlMjAlM0QlMjBtb2RlbC5nZW5lcmF0ZShpbnB1dHMlM0RpbnB1dF9mZWF0dXJlcyklMEElMEF0cmFuc2NyaXB0aW9uJTIwJTNEJTIwcHJvY2Vzc29yLmJhdGNoX2RlY29kZShnZW5lcmF0ZWRfaWRzJTJDJTIwc2tpcF9zcGVjaWFsX3Rva2VucyUzRFRydWUpJTVCMCU1RCUwQXRyYW5zY3JpcHRpb24=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoProcessor, WhisperForConditionalGeneration
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> datasets <span class="hljs-keyword">import</span> load_dataset

<span class="hljs-meta">&gt;&gt;&gt; </span>processor = AutoProcessor.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny.en&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = WhisperForConditionalGeneration.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny.en&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>ds = load_dataset(<span class="hljs-string">&quot;hf-internal-testing/librispeech_asr_dummy&quot;</span>, <span class="hljs-string">&quot;clean&quot;</span>, split=<span class="hljs-string">&quot;validation&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = processor(ds[<span class="hljs-number">0</span>][<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;array&quot;</span>], return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>input_features = inputs.input_features

<span class="hljs-meta">&gt;&gt;&gt; </span>generated_ids = model.generate(inputs=input_features)

<span class="hljs-meta">&gt;&gt;&gt; </span>transcription = processor.batch_decode(generated_ids, skip_special_tokens=<span class="hljs-literal">True</span>)[<span class="hljs-number">0</span>]
<span class="hljs-meta">&gt;&gt;&gt; </span>transcription
<span class="hljs-string">&#x27; Mr. Quilter is the apostle of the middle classes, and we are glad to welcome his gospel.&#x27;</span>`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-11lpom8"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function Ci(v){let o,k=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-fincs2"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function ji(v){let o,k="Example:",c,p,T;return p=new te({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b0ZlYXR1cmVFeHRyYWN0b3IlMkMlMjBXaGlzcGVyRm9yQXVkaW9DbGFzc2lmaWNhdGlvbiUwQWZyb20lMjBkYXRhc2V0cyUyMGltcG9ydCUyMGxvYWRfZGF0YXNldCUwQSUwQWZlYXR1cmVfZXh0cmFjdG9yJTIwJTNEJTIwQXV0b0ZlYXR1cmVFeHRyYWN0b3IuZnJvbV9wcmV0cmFpbmVkKCUyMnNhbmNoaXQtZ2FuZGhpJTJGd2hpc3Blci1tZWRpdW0tZmxldXJzLWxhbmctaWQlMjIpJTBBbW9kZWwlMjAlM0QlMjBXaGlzcGVyRm9yQXVkaW9DbGFzc2lmaWNhdGlvbi5mcm9tX3ByZXRyYWluZWQoJTIyc2FuY2hpdC1nYW5kaGklMkZ3aGlzcGVyLW1lZGl1bS1mbGV1cnMtbGFuZy1pZCUyMiklMEElMEFkcyUyMCUzRCUyMGxvYWRfZGF0YXNldCglMjJnb29nbGUlMkZmbGV1cnMlMjIlMkMlMjAlMjJhbGwlMjIlMkMlMjBzcGxpdCUzRCUyMnZhbGlkYXRpb24lMjIlMkMlMjBzdHJlYW1pbmclM0RUcnVlKSUwQXNhbXBsZSUyMCUzRCUyMG5leHQoaXRlcihkcykpJTBBJTBBaW5wdXRzJTIwJTNEJTIwZmVhdHVyZV9leHRyYWN0b3IoJTBBJTIwJTIwJTIwJTIwc2FtcGxlJTVCJTIyYXVkaW8lMjIlNUQlNUIlMjJhcnJheSUyMiU1RCUyQyUyMHNhbXBsaW5nX3JhdGUlM0RzYW1wbGUlNUIlMjJhdWRpbyUyMiU1RCU1QiUyMnNhbXBsaW5nX3JhdGUlMjIlNUQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyJTBBKSUwQWlucHV0X2ZlYXR1cmVzJTIwJTNEJTIwaW5wdXRzLmlucHV0X2ZlYXR1cmVzJTBBJTBBd2l0aCUyMHRvcmNoLm5vX2dyYWQoKSUzQSUwQSUyMCUyMCUyMCUyMGxvZ2l0cyUyMCUzRCUyMG1vZGVsKGlucHV0X2ZlYXR1cmVzKS5sb2dpdHMlMEElMEFwcmVkaWN0ZWRfY2xhc3NfaWRzJTIwJTNEJTIwdG9yY2guYXJnbWF4KGxvZ2l0cykuaXRlbSgpJTBBcHJlZGljdGVkX2xhYmVsJTIwJTNEJTIwbW9kZWwuY29uZmlnLmlkMmxhYmVsJTVCcHJlZGljdGVkX2NsYXNzX2lkcyU1RCUwQXByZWRpY3RlZF9sYWJlbA==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoFeatureExtractor, WhisperForAudioClassification
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> datasets <span class="hljs-keyword">import</span> load_dataset

<span class="hljs-meta">&gt;&gt;&gt; </span>feature_extractor = AutoFeatureExtractor.from_pretrained(<span class="hljs-string">&quot;sanchit-gandhi/whisper-medium-fleurs-lang-id&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = WhisperForAudioClassification.from_pretrained(<span class="hljs-string">&quot;sanchit-gandhi/whisper-medium-fleurs-lang-id&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>ds = load_dataset(<span class="hljs-string">&quot;google/fleurs&quot;</span>, <span class="hljs-string">&quot;all&quot;</span>, split=<span class="hljs-string">&quot;validation&quot;</span>, streaming=<span class="hljs-literal">True</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>sample = <span class="hljs-built_in">next</span>(<span class="hljs-built_in">iter</span>(ds))

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = feature_extractor(
<span class="hljs-meta">... </span>    sample[<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;array&quot;</span>], sampling_rate=sample[<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;sampling_rate&quot;</span>], return_tensors=<span class="hljs-string">&quot;pt&quot;</span>
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>input_features = inputs.input_features

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">with</span> torch.no_grad():
<span class="hljs-meta">... </span>    logits = model(input_features).logits

<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_class_ids = torch.argmax(logits).item()
<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_label = model.config.id2label[predicted_class_ids]
<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_label
<span class="hljs-string">&#x27;Afrikaans&#x27;</span>`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-11lpom8"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function qi(v){let o,k=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-fincs2"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function Ji(v){let o,k="Example:",c,p,T;return p=new te({props:{code:"aW1wb3J0JTIwdGVuc29yZmxvdyUyMGFzJTIwdGYlMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwVEZXaGlzcGVyTW9kZWwlMkMlMjBBdXRvRmVhdHVyZUV4dHJhY3RvciUwQWZyb20lMjBkYXRhc2V0cyUyMGltcG9ydCUyMGxvYWRfZGF0YXNldCUwQSUwQW1vZGVsJTIwJTNEJTIwVEZXaGlzcGVyTW9kZWwuZnJvbV9wcmV0cmFpbmVkKCUyMm9wZW5haSUyRndoaXNwZXItYmFzZSUyMiklMEFmZWF0dXJlX2V4dHJhY3RvciUyMCUzRCUyMEF1dG9GZWF0dXJlRXh0cmFjdG9yLmZyb21fcHJldHJhaW5lZCglMjJvcGVuYWklMkZ3aGlzcGVyLWJhc2UlMjIpJTBBZHMlMjAlM0QlMjBsb2FkX2RhdGFzZXQoJTIyaGYtaW50ZXJuYWwtdGVzdGluZyUyRmxpYnJpc3BlZWNoX2Fzcl9kdW1teSUyMiUyQyUyMCUyMmNsZWFuJTIyJTJDJTIwc3BsaXQlM0QlMjJ2YWxpZGF0aW9uJTIyKSUwQWlucHV0cyUyMCUzRCUyMGZlYXR1cmVfZXh0cmFjdG9yKGRzJTVCMCU1RCU1QiUyMmF1ZGlvJTIyJTVEJTVCJTIyYXJyYXklMjIlNUQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnRmJTIyKSUwQWlucHV0X2ZlYXR1cmVzJTIwJTNEJTIwaW5wdXRzLmlucHV0X2ZlYXR1cmVzJTBBZGVjb2Rlcl9pbnB1dF9pZHMlMjAlM0QlMjB0Zi5jb252ZXJ0X3RvX3RlbnNvciglNUIlNUIxJTJDJTIwMSU1RCU1RCklMjAqJTIwbW9kZWwuY29uZmlnLmRlY29kZXJfc3RhcnRfdG9rZW5faWQlMEFsYXN0X2hpZGRlbl9zdGF0ZSUyMCUzRCUyMG1vZGVsKGlucHV0X2ZlYXR1cmVzJTJDJTIwZGVjb2Rlcl9pbnB1dF9pZHMlM0RkZWNvZGVyX2lucHV0X2lkcykubGFzdF9oaWRkZW5fc3RhdGUlMEFsaXN0KGxhc3RfaGlkZGVuX3N0YXRlLnNoYXBlKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> tensorflow <span class="hljs-keyword">as</span> tf
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> TFWhisperModel, AutoFeatureExtractor
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> datasets <span class="hljs-keyword">import</span> load_dataset

<span class="hljs-meta">&gt;&gt;&gt; </span>model = TFWhisperModel.from_pretrained(<span class="hljs-string">&quot;openai/whisper-base&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>feature_extractor = AutoFeatureExtractor.from_pretrained(<span class="hljs-string">&quot;openai/whisper-base&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>ds = load_dataset(<span class="hljs-string">&quot;hf-internal-testing/librispeech_asr_dummy&quot;</span>, <span class="hljs-string">&quot;clean&quot;</span>, split=<span class="hljs-string">&quot;validation&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = feature_extractor(ds[<span class="hljs-number">0</span>][<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;array&quot;</span>], return_tensors=<span class="hljs-string">&quot;tf&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>input_features = inputs.input_features
<span class="hljs-meta">&gt;&gt;&gt; </span>decoder_input_ids = tf.convert_to_tensor([[<span class="hljs-number">1</span>, <span class="hljs-number">1</span>]]) * model.config.decoder_start_token_id
<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_state = model(input_features, decoder_input_ids=decoder_input_ids).last_hidden_state
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">list</span>(last_hidden_state.shape)
[<span class="hljs-number">1</span>, <span class="hljs-number">2</span>, <span class="hljs-number">512</span>]`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-11lpom8"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function Ii(v){let o,k=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-fincs2"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function Gi(v){let o,k="Example:",c,p,T;return p=new te({props:{code:"aW1wb3J0JTIwdGVuc29yZmxvdyUyMGFzJTIwdGYlMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b1Byb2Nlc3NvciUyQyUyMFRGV2hpc3BlckZvckNvbmRpdGlvbmFsR2VuZXJhdGlvbiUwQWZyb20lMjBkYXRhc2V0cyUyMGltcG9ydCUyMGxvYWRfZGF0YXNldCUwQSUwQXByb2Nlc3NvciUyMCUzRCUyMEF1dG9Qcm9jZXNzb3IuZnJvbV9wcmV0cmFpbmVkKCUyMm9wZW5haSUyRndoaXNwZXItdGlueS5lbiUyMiklMEFtb2RlbCUyMCUzRCUyMFRGV2hpc3BlckZvckNvbmRpdGlvbmFsR2VuZXJhdGlvbi5mcm9tX3ByZXRyYWluZWQoJTIyb3BlbmFpJTJGd2hpc3Blci10aW55LmVuJTIyKSUwQSUwQWRzJTIwJTNEJTIwbG9hZF9kYXRhc2V0KCUyMmhmLWludGVybmFsLXRlc3RpbmclMkZsaWJyaXNwZWVjaF9hc3JfZHVtbXklMjIlMkMlMjAlMjJjbGVhbiUyMiUyQyUyMHNwbGl0JTNEJTIydmFsaWRhdGlvbiUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjBwcm9jZXNzb3IoZHMlNUIwJTVEJTVCJTIyYXVkaW8lMjIlNUQlNUIlMjJhcnJheSUyMiU1RCUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIydGYlMjIpJTBBaW5wdXRfZmVhdHVyZXMlMjAlM0QlMjBpbnB1dHMuaW5wdXRfZmVhdHVyZXMlMEElMEFnZW5lcmF0ZWRfaWRzJTIwJTNEJTIwbW9kZWwuZ2VuZXJhdGUoaW5wdXRfZmVhdHVyZXMlM0RpbnB1dF9mZWF0dXJlcyklMEElMEF0cmFuc2NyaXB0aW9uJTIwJTNEJTIwcHJvY2Vzc29yLmJhdGNoX2RlY29kZShnZW5lcmF0ZWRfaWRzJTJDJTIwc2tpcF9zcGVjaWFsX3Rva2VucyUzRFRydWUpJTVCMCU1RCUwQXRyYW5zY3JpcHRpb24=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> tensorflow <span class="hljs-keyword">as</span> tf
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoProcessor, TFWhisperForConditionalGeneration
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> datasets <span class="hljs-keyword">import</span> load_dataset

<span class="hljs-meta">&gt;&gt;&gt; </span>processor = AutoProcessor.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny.en&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = TFWhisperForConditionalGeneration.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny.en&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>ds = load_dataset(<span class="hljs-string">&quot;hf-internal-testing/librispeech_asr_dummy&quot;</span>, <span class="hljs-string">&quot;clean&quot;</span>, split=<span class="hljs-string">&quot;validation&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = processor(ds[<span class="hljs-number">0</span>][<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;array&quot;</span>], return_tensors=<span class="hljs-string">&quot;tf&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>input_features = inputs.input_features

<span class="hljs-meta">&gt;&gt;&gt; </span>generated_ids = model.generate(input_features=input_features)

<span class="hljs-meta">&gt;&gt;&gt; </span>transcription = processor.batch_decode(generated_ids, skip_special_tokens=<span class="hljs-literal">True</span>)[<span class="hljs-number">0</span>]
<span class="hljs-meta">&gt;&gt;&gt; </span>transcription
<span class="hljs-string">&#x27; Mr. Quilter is the apostle of the middle classes, and we are glad to welcome his gospel.&#x27;</span>`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-11lpom8"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function Ui(v){let o,k=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-fincs2"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function Ni(v){let o,k="Example:",c,p,T;return p=new te({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBGbGF4V2hpc3Blck1vZGVsJTBBJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIyb3BlbmFpJTJGd2hpc3Blci10aW55JTIyKSUwQW1vZGVsJTIwJTNEJTIwRmxheFdoaXNwZXJNb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIyb3BlbmFpJTJGd2hpc3Blci10aW55JTIyKSUwQSUwQWlucHV0cyUyMCUzRCUyMHRva2VuaXplciglMjJIZWxsbyUyQyUyMG15JTIwZG9nJTIwaXMlMjBjdXRlJTIyJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJqYXglMjIpJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKCoqaW5wdXRzKSUwQSUwQWxhc3RfaGlkZGVuX3N0YXRlcyUyMCUzRCUyMG91dHB1dHMubGFzdF9oaWRkZW5fc3RhdGU=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, FlaxWhisperModel

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxWhisperModel.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;jax&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_states = outputs.last_hidden_state`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-11lpom8"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function Zi(v){let o,k=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-fincs2"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function Xi(v){let o,k="Transcription example:",c,p,T;return p=new te({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMFdoaXNwZXJQcm9jZXNzb3IlMkMlMjBGbGF4V2hpc3BlckZvckNvbmRpdGlvbmFsR2VuZXJhdGlvbiUwQWZyb20lMjBkYXRhc2V0cyUyMGltcG9ydCUyMGxvYWRfZGF0YXNldCUwQSUwQXByb2Nlc3NvciUyMCUzRCUyMFdoaXNwZXJQcm9jZXNzb3IuZnJvbV9wcmV0cmFpbmVkKCUyMm9wZW5haSUyRndoaXNwZXItdGlueS5lbiUyMiklMEFtb2RlbCUyMCUzRCUyMEZsYXhXaGlzcGVyRm9yQ29uZGl0aW9uYWxHZW5lcmF0aW9uLmZyb21fcHJldHJhaW5lZCglMjJvcGVuYWklMkZ3aGlzcGVyLXRpbnkuZW4lMjIlMkMlMjBmcm9tX3B0JTNEVHJ1ZSklMEFkcyUyMCUzRCUyMGxvYWRfZGF0YXNldCglMjJoZi1pbnRlcm5hbC10ZXN0aW5nJTJGbGlicmlzcGVlY2hfYXNyX2R1bW15JTIyJTJDJTIwJTIyY2xlYW4lMjIlMkMlMjBzcGxpdCUzRCUyMnZhbGlkYXRpb24lMjIpJTBBaW5wdXRzJTIwJTNEJTIwcHJvY2Vzc29yKGRzJTVCMCU1RCU1QiUyMmF1ZGlvJTIyJTVEJTVCJTIyYXJyYXklMjIlNUQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMm5wJTIyKSUwQWlucHV0X2ZlYXR1cmVzJTIwJTNEJTIwaW5wdXRzLmlucHV0X2ZlYXR1cmVzJTBBZ2VuZXJhdGVkX2lkcyUyMCUzRCUyMG1vZGVsLmdlbmVyYXRlKGlucHV0X2lkcyUzRGlucHV0X2ZlYXR1cmVzKSUwQXRyYW5zY3JpcHRpb24lMjAlM0QlMjBwcm9jZXNzb3IuYmF0Y2hfZGVjb2RlKGdlbmVyYXRlZF9pZHMlMkMlMjBza2lwX3NwZWNpYWxfdG9rZW5zJTNEVHJ1ZSklNUIwJTVEJTBBdHJhbnNjcmlwdGlvbg==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> WhisperProcessor, FlaxWhisperForConditionalGeneration
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> datasets <span class="hljs-keyword">import</span> load_dataset

<span class="hljs-meta">&gt;&gt;&gt; </span>processor = WhisperProcessor.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny.en&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxWhisperForConditionalGeneration.from_pretrained(<span class="hljs-string">&quot;openai/whisper-tiny.en&quot;</span>, from_pt=<span class="hljs-literal">True</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>ds = load_dataset(<span class="hljs-string">&quot;hf-internal-testing/librispeech_asr_dummy&quot;</span>, <span class="hljs-string">&quot;clean&quot;</span>, split=<span class="hljs-string">&quot;validation&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = processor(ds[<span class="hljs-number">0</span>][<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;array&quot;</span>], return_tensors=<span class="hljs-string">&quot;np&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>input_features = inputs.input_features
<span class="hljs-meta">&gt;&gt;&gt; </span>generated_ids = model.generate(input_ids=input_features)
<span class="hljs-meta">&gt;&gt;&gt; </span>transcription = processor.batch_decode(generated_ids, skip_special_tokens=<span class="hljs-literal">True</span>)[<span class="hljs-number">0</span>]
<span class="hljs-meta">&gt;&gt;&gt; </span>transcription
<span class="hljs-string">&#x27; Mr. Quilter is the apostle of the middle classes, and we are glad to welcome his gospel.&#x27;</span>`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-yrk4pw"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function Ri(v){let o,k=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){o=d("p"),o.innerHTML=k},l(c){o=l(c,"P",{"data-svelte-h":!0}),b(o)!=="svelte-fincs2"&&(o.innerHTML=k)},m(c,p){h(c,o,p)},p:C,d(c){c&&r(o)}}}function Li(v){let o,k="Transcription example:",c,p,T;return p=new te({props:{code:"aW1wb3J0JTIwamF4Lm51bXB5JTIwYXMlMjBqbnAlMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b0ZlYXR1cmVFeHRyYWN0b3IlMkMlMjBGbGF4V2hpc3BlckZvckF1ZGlvQ2xhc3NpZmljYXRpb24lMEFmcm9tJTIwZGF0YXNldHMlMjBpbXBvcnQlMjBsb2FkX2RhdGFzZXQlMEElMEFmZWF0dXJlX2V4dHJhY3RvciUyMCUzRCUyMEF1dG9GZWF0dXJlRXh0cmFjdG9yLmZyb21fcHJldHJhaW5lZCglMjJzYW5jaGl0LWdhbmRoaSUyRndoaXNwZXItbWVkaXVtLWZsZXVycy1sYW5nLWlkJTIyKSUwQW1vZGVsJTIwJTNEJTIwRmxheFdoaXNwZXJGb3JBdWRpb0NsYXNzaWZpY2F0aW9uLmZyb21fcHJldHJhaW5lZCglMEElMjAlMjAlMjAlMjAlMjJzYW5jaGl0LWdhbmRoaSUyRndoaXNwZXItbWVkaXVtLWZsZXVycy1sYW5nLWlkJTIyJTJDJTIwZnJvbV9wdCUzRFRydWUlMEEpJTBBZHMlMjAlM0QlMjBsb2FkX2RhdGFzZXQoJTIyZ29vZ2xlJTJGZmxldXJzJTIyJTJDJTIwJTIyYWxsJTIyJTJDJTIwc3BsaXQlM0QlMjJ2YWxpZGF0aW9uJTIyJTJDJTIwc3RyZWFtaW5nJTNEVHJ1ZSUyQyUyMHRydXN0X3JlbW90ZV9jb2RlJTNEVHJ1ZSklMEElMEFzYW1wbGUlMjAlM0QlMjBuZXh0KGl0ZXIoZHMpKSUwQSUwQWlucHV0cyUyMCUzRCUyMGZlYXR1cmVfZXh0cmFjdG9yKCUwQSUyMCUyMCUyMCUyMHNhbXBsZSU1QiUyMmF1ZGlvJTIyJTVEJTVCJTIyYXJyYXklMjIlNUQlMkMlMjBzYW1wbGluZ19yYXRlJTNEc2FtcGxlJTVCJTIyYXVkaW8lMjIlNUQlNUIlMjJzYW1wbGluZ19yYXRlJTIyJTVEJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJucCUyMiUwQSklMEFpbnB1dF9mZWF0dXJlcyUyMCUzRCUyMGlucHV0cy5pbnB1dF9mZWF0dXJlcyUwQSUwQWxvZ2l0cyUyMCUzRCUyMG1vZGVsKGlucHV0X2ZlYXR1cmVzKS5sb2dpdHMlMEElMEFwcmVkaWN0ZWRfY2xhc3NfaWRzJTIwJTNEJTIwam5wLmFyZ21heChsb2dpdHMpLml0ZW0oKSUwQXByZWRpY3RlZF9sYWJlbCUyMCUzRCUyMG1vZGVsLmNvbmZpZy5pZDJsYWJlbCU1QnByZWRpY3RlZF9jbGFzc19pZHMlNUQlMEFwcmVkaWN0ZWRfbGFiZWw=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> jax.numpy <span class="hljs-keyword">as</span> jnp
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoFeatureExtractor, FlaxWhisperForAudioClassification
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> datasets <span class="hljs-keyword">import</span> load_dataset

<span class="hljs-meta">&gt;&gt;&gt; </span>feature_extractor = AutoFeatureExtractor.from_pretrained(<span class="hljs-string">&quot;sanchit-gandhi/whisper-medium-fleurs-lang-id&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxWhisperForAudioClassification.from_pretrained(
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;sanchit-gandhi/whisper-medium-fleurs-lang-id&quot;</span>, from_pt=<span class="hljs-literal">True</span>
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>ds = load_dataset(<span class="hljs-string">&quot;google/fleurs&quot;</span>, <span class="hljs-string">&quot;all&quot;</span>, split=<span class="hljs-string">&quot;validation&quot;</span>, streaming=<span class="hljs-literal">True</span>, trust_remote_code=<span class="hljs-literal">True</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>sample = <span class="hljs-built_in">next</span>(<span class="hljs-built_in">iter</span>(ds))

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = feature_extractor(
<span class="hljs-meta">... </span>    sample[<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;array&quot;</span>], sampling_rate=sample[<span class="hljs-string">&quot;audio&quot;</span>][<span class="hljs-string">&quot;sampling_rate&quot;</span>], return_tensors=<span class="hljs-string">&quot;np&quot;</span>
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>input_features = inputs.input_features

<span class="hljs-meta">&gt;&gt;&gt; </span>logits = model(input_features).logits

<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_class_ids = jnp.argmax(logits).item()
<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_label = model.config.id2label[predicted_class_ids]
<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_label
<span class="hljs-string">&#x27;af_za&#x27;</span>`,wrap:!1}}),{c(){o=d("p"),o.textContent=k,c=s(),m(p.$$.fragment)},l(n){o=l(n,"P",{"data-svelte-h":!0}),b(o)!=="svelte-yrk4pw"&&(o.textContent=k),c=a(n),u(p.$$.fragment,n)},m(n,w){h(n,o,w),h(n,c,w),f(p,n,w),T=!0},p:C,i(n){T||(g(p.$$.fragment,n),T=!0)},o(n){_(p.$$.fragment,n),T=!1},d(n){n&&(r(o),r(c)),y(p,n)}}}function Vi(v){let o,k,c,p,T,n,w,Cn,dt,ir='Whisper 모델은 Alec Radford, Jong Wook Kim, Tao Xu, Greg Brockman, Christine McLeavey, Ilya Sutskever에 의해 <a href="https://cdn.openai.com/papers/whisper.pdf" rel="nofollow">Robust Speech Recognition via Large-Scale Weak Supervision</a>에서 제안되었습니다.',jn,lt,dr="논문의 초록은 다음과 같습니다:",qn,ct,lr="<em>우리는 인터넷에서 대량의 오디오를 글로 옮긴 것을 예측하도록 간단히 훈련된 음성 처리 시스템의 성능을 연구합니다. 68만 시간의 다국어 및 다중 작업 지도(multitask supervision)에 확장했을 때, 결과 모델은 표준 벤치마크에 잘 일반화되며, 미세 조정이 필요 없는 제로샷 전송 설정에서 이전의 완전히 지도된(fully-supervised) 결과와 경쟁할 수 있는 경우가 많습니다. 사람과 비교하면, 이 모델은 사람의 정확도와 견고성에 근접합니다. 우리는 강력한 음성 처리를 위한 추가 작업의 기반이 될 모델과 추론 코드를 공개합니다.</em>",Jn,pt,cr="팁:",In,ht,pr='<li><p>이 모델은 일반적으로 별도의 미세 조정 없이도 잘 작동합니다.</p></li> <li><p>아키텍처는 고전적인 인코더-디코더 아키텍처를 따르기 때문에, 추론을 위해 <a href="/docs/transformers/main/ko/main_classes/text_generation#transformers.GenerationMixin.generate">generate()</a> 함수를 사용합니다.</p></li> <li><p>현재 추론은 짧은 형식에만 구현되어 있으며, 오디오는 30초 미만의 세그먼트로 미리 분할되어야 합니다. 타임스탬프를 포함한 긴 형식에 대한 추론은 향후 릴리스에서 구현될 예정입니다.</p></li> <li><p><a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperProcessor">WhisperProcessor</a>를 사용하여 모델에 사용할 오디오를 준비하고, 예측된 ID를 텍스트로 디코딩할 수 있습니다.</p></li> <li><p>모델과 프로세서를 변환하려면 다음을 사용하는 것이 좋습니다:</p></li>',Gn,mt,Un,ut,hr=`스크립트는 OpenAI 체크포인트에서 필요한 모든 매개변수를 자동으로 결정합니다. OpenAI 변환을 수행하려면 <code>tiktoken</code> 라이브러리를 설치해야 합니다.
라이브러리를 설치해야 OpenAI 토큰화기를 <code>tokenizers</code> 버전으로 변환할 수 있습니다.`,Nn,ft,mr=`이 모델은 <a href="https://huggingface.co/ArthurZ" rel="nofollow">Arthur Zucker</a>에 의해 제공되었습니다. 이 모델의 Tensorflow 버전은 <a href="https://huggingface.co/amyeroberts" rel="nofollow">amyeroberts</a>에 의해 제공되었습니다.
원본 코드는 <a href="https://github.com/openai/whisper" rel="nofollow">여기</a>에서 찾을 수 있습니다.`,Zn,gt,Xn,X,_t,us,vo,ur=`This is the configuration class to store the configuration of a <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperModel">WhisperModel</a>. It is used to instantiate a
Whisper model according to the specified arguments, defining the model architecture. Instantiating a configuration
with the defaults will yield a similar configuration to that of the Whisper
<a href="https://huggingface.co/openai/whisper-tiny" rel="nofollow">openai/whisper-tiny</a> architecture.`,fs,xo,fr=`Configuration objects inherit from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> and can be used to control the model outputs. Read the
documentation from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> for more information.`,gs,be,Rn,yt,Ln,W,bt,_s,Mo,gr="Construct a Whisper tokenizer.",ys,$o,_r=`This tokenizer inherits from <code>PreTrainedTokenizer</code> which contains some of the main methods. Users should refer to
the superclass for more information regarding such methods.`,bs,se,kt,ks,Wo,yr="Override the prefix tokens appended to the start of the label sequence. This method can be used standalone to",Ts,ke,ws,Te,Tt,vs,Fo,br="Build model inputs from a sequence by appending eos_token_id.",xs,we,wt,Ms,zo,kr=`Retrieve sequence ids from a token list that has no special tokens added. This method is called when adding
special tokens using the tokenizer <code>prepare_for_model</code> method.`,$s,ae,vt,Ws,Co,Tr=`Create the token type IDs corresponding to the sequences passed. <a href="../glossary#token-type-ids">What are token type
IDs?</a>`,Fs,jo,wr="Should be overridden in a subclass if the model has a special way of building those.",zs,qo,xt,Vn,Mt,En,F,$t,Cs,Jo,vr="Construct a “fast” Whisper tokenizer (backed by HuggingFace’s <em>tokenizers</em> library).",js,Io,xr=`This tokenizer inherits from <code>PreTrainedTokenizerFast</code> which contains most of the main methods. Users should
refer to this superclass for more information regarding those methods.`,qs,re,Wt,Js,Go,Mr="Override the prefix tokens appended to the start of the label sequence. This method can be used standalone to",Is,ve,Gs,xe,Ft,Us,Uo,$r="Build model inputs from a sequence by appending eos_token_id.",Ns,Me,zt,Zs,No,Wr=`Retrieve sequence ids from a token list that has no special tokens added. This method is called when adding
special tokens using the tokenizer <code>prepare_for_model</code> method.`,Xs,ie,Ct,Rs,Zo,Fr=`Create the token type IDs corresponding to the sequences passed. <a href="../glossary#token-type-ids">What are token type
IDs?</a>`,Ls,Xo,zr="Should be overridden in a subclass if the model has a special way of building those.",Vs,Ro,jt,Hn,qt,Pn,G,Jt,Es,Lo,Cr="Constructs a Whisper feature extractor.",Hs,Vo,jr=`This feature extractor inherits from <a href="/docs/transformers/main/ko/main_classes/feature_extractor#transformers.SequenceFeatureExtractor">SequenceFeatureExtractor</a> which contains
most of the main methods. Users should refer to this superclass for more information regarding those methods.`,Ps,Eo,qr="This class extracts mel-filter bank features from raw speech using a custom numpy implementation of the <code>Short Time Fourier Transform</code> which should match pytorch’s <code>torch.stft</code> equivalent.",Bs,$e,It,Ss,Ho,Jr=`Main method to featurize and prepare for the model one or several sequence(s). Implementation uses PyTorch for
the STFT computation if available, otherwise a slower NumPy based one.`,Bn,Gt,Sn,z,Ut,As,Po,Ir=`Constructs a Whisper processor which wraps a Whisper feature extractor and a Whisper tokenizer into a single
processor.`,Ys,Bo,Gr=`<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperProcessor">WhisperProcessor</a> offers all the functionalities of <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor">WhisperFeatureExtractor</a> and <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperTokenizer">WhisperTokenizer</a>. See
the <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperProcessor.__call__"><strong>call</strong>()</a> and <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperProcessor.decode">decode()</a> for more information.`,Ds,We,Nt,Os,So,Ur=`Forwards the <code>audio</code> argument to WhisperFeatureExtractor’s <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a> and the <code>text</code>
argument to <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__"><strong>call</strong>()</a>. Please refer to the docstring of the above two methods for more
information.`,Qs,de,Zt,Ks,Ao,Nr="Instantiate a processor associated with a pretrained model.",ea,Fe,ta,le,Xt,oa,Yo,Zr=`Saves the attributes of this processor (feature extractor, tokenizer…) in the specified directory so that it
can be reloaded using the <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperProcessor.from_pretrained">from_pretrained()</a> method.`,na,ze,sa,Ce,Rt,aa,Do,Xr=`This method forwards all its arguments to WhisperTokenizer’s <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.batch_decode">batch_decode()</a>. Please
refer to the docstring of this method for more information.`,ra,je,Lt,ia,Oo,Rr=`This method forwards all its arguments to WhisperTokenizer’s <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.decode">decode()</a>. Please refer to
the docstring of this method for more information.`,An,Vt,Yn,I,Et,da,Qo,Lr="The bare Whisper Model outputting raw hidden-states without any specific head on top.",la,Ko,Vr=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,ca,en,Er=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,pa,B,Ht,ha,tn,Hr='The <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperModel">WhisperModel</a> forward method, overrides the <code>__call__</code> special method.',ma,qe,ua,Je,fa,Ie,Pt,ga,on,Pr=`Masks extracted features along time axis and/or along feature axis according to
<a href="https://huggingface.co/papers/1904.08779" rel="nofollow">SpecAugment</a>.`,Dn,Bt,On,U,St,_a,nn,Br="The Whisper Model with a language modeling head. Can be used for automatic speech recognition.",ya,sn,Sr=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,ba,an,Ar=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,ka,S,At,Ta,rn,Yr='The <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperForConditionalGeneration">WhisperForConditionalGeneration</a> forward method, overrides the <code>__call__</code> special method.',wa,Ge,va,Ue,Qn,Yt,Kn,N,Dt,xa,dn,Dr=`Whisper Encoder Model with a sequence classification head on top (a linear layer over the pooled output) for tasks
like SUPERB Keyword Spotting.`,Ma,ln,Or=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,$a,cn,Qr=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,Wa,A,Ot,Fa,pn,Kr='The <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperForAudioClassification">WhisperForAudioClassification</a> forward method, overrides the <code>__call__</code> special method.',za,Ne,Ca,Ze,es,Qt,ts,R,Kt,ja,hn,ei=`The bare Whisper Model outputting raw hidden-states without any specific head on top.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel">TFPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,qa,mn,ti=`This model is also a <a href="https://www.tensorflow.org/api_docs/python/tf/keras/Model" rel="nofollow">keras.Model</a> subclass. Use it
as a regular TF 2.0 Keras Model and refer to the TF 2.0 documentation for all matter related to general usage and
behavior.`,Ja,Y,eo,Ia,un,oi='The <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.TFWhisperModel">TFWhisperModel</a> forward method, overrides the <code>__call__</code> special method.',Ga,Xe,Ua,Re,os,to,ns,L,oo,Na,fn,ni=`The Whisper Model with a language modeling head. Can be used for automatic speech recognition.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel">TFPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Za,gn,si=`This model is also a <a href="https://www.tensorflow.org/api_docs/python/tf/keras/Model" rel="nofollow">keras.Model</a> subclass. Use it
as a regular TF 2.0 Keras Model and refer to the TF 2.0 documentation for all matter related to general usage and
behavior.`,Xa,D,no,Ra,_n,ai='The <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.TFWhisperForConditionalGeneration">TFWhisperForConditionalGeneration</a> forward method, overrides the <code>__call__</code> special method.',La,Le,Va,Ve,ss,so,as,V,ao,Ea,yn,ri=`The bare Whisper Model transformer outputting raw hidden-states without any specific head on top.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its models (such as downloading or saving, resizing the input embeddings, pruning heads
etc.) This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.
Finally, this model supports inherent JAX features such as:`,Ha,bn,ii='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',Pa,O,ro,Ba,kn,di="The <code>FlaxWhisperPreTrainedModel</code> forward method, overrides the <code>__call__</code> special method.",Sa,Ee,Aa,He,rs,io,is,E,lo,Ya,Tn,li=`The Whisper Model with a language modeling head.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its models (such as downloading or saving, resizing the input embeddings, pruning heads
etc.) This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.
Finally, this model supports inherent JAX features such as:`,Da,wn,ci='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',Oa,Q,co,Qa,vn,pi="The <code>FlaxWhisperPreTrainedModel</code> forward method, overrides the <code>__call__</code> special method.",Ka,Pe,er,Be,ds,po,ls,H,ho,tr,xn,hi=`The Whisper Model with an audio classification head on top.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its models (such as downloading or saving, resizing the input embeddings, pruning heads
etc.) This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.
Finally, this model supports inherent JAX features such as:`,or,Mn,mi='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',nr,K,mo,sr,$n,ui='The <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.FlaxWhisperForAudioClassification">FlaxWhisperForAudioClassification</a> forward method, overrides the <code>__call__</code> special method.',ar,Se,rr,Ae,cs,uo,ps,Wn,hs;return T=new Z({props:{title:"Whisper",local:"whisper",headingTag:"h1"}}),w=new Z({props:{title:"개요",local:"overview",headingTag:"h2"}}),mt=new te({props:{code:"cHl0aG9uJTIwc3JjJTJGdHJhbnNmb3JtZXJzJTJGbW9kZWxzJTJGd2hpc3BlciUyRmNvbnZlcnRfb3BlbmFpX3RvX2hmLnB5JTIwLS1jaGVja3BvaW50X3BhdGglMjAlMjIlMjIlMjAtLXB5dG9yY2hfZHVtcF9mb2xkZXJfcGF0aCUyMCUyMkFydGh1ciUyRndoaXNwZXItMyUyMiUyMC0tY29udmVydF9wcmVwcm9jZXNzb3IlMjBUcnVl",highlighted:'python src/transformers/models/whisper/convert_openai_to_hf.py --checkpoint_path <span class="hljs-string">&quot;&quot;</span> --pytorch_dump_folder_path <span class="hljs-string">&quot;Arthur/whisper-3&quot;</span> --convert_preprocessor True',wrap:!1}}),gt=new Z({props:{title:"WhisperConfig",local:"whisperconfig ][ transformers.WhisperConfig",headingTag:"h2"}}),_t=new $({props:{name:"class transformers.WhisperConfig",anchor:"transformers.WhisperConfig",parameters:[{name:"vocab_size",val:" = 51865"},{name:"num_mel_bins",val:" = 80"},{name:"encoder_layers",val:" = 4"},{name:"encoder_attention_heads",val:" = 6"},{name:"decoder_layers",val:" = 4"},{name:"decoder_attention_heads",val:" = 6"},{name:"decoder_ffn_dim",val:" = 1536"},{name:"encoder_ffn_dim",val:" = 1536"},{name:"encoder_layerdrop",val:" = 0.0"},{name:"decoder_layerdrop",val:" = 0.0"},{name:"decoder_start_token_id",val:" = 50257"},{name:"use_cache",val:" = True"},{name:"is_encoder_decoder",val:" = True"},{name:"activation_function",val:" = 'gelu'"},{name:"d_model",val:" = 384"},{name:"dropout",val:" = 0.0"},{name:"attention_dropout",val:" = 0.0"},{name:"activation_dropout",val:" = 0.0"},{name:"init_std",val:" = 0.02"},{name:"scale_embedding",val:" = False"},{name:"max_source_positions",val:" = 1500"},{name:"max_target_positions",val:" = 448"},{name:"pad_token_id",val:" = 50256"},{name:"bos_token_id",val:" = 50256"},{name:"eos_token_id",val:" = 50256"},{name:"suppress_tokens",val:" = None"},{name:"begin_suppress_tokens",val:" = [220, 50256]"},{name:"use_weighted_layer_sum",val:" = False"},{name:"classifier_proj_size",val:" = 256"},{name:"apply_spec_augment",val:" = False"},{name:"mask_time_prob",val:" = 0.05"},{name:"mask_time_length",val:" = 10"},{name:"mask_time_min_masks",val:" = 2"},{name:"mask_feature_prob",val:" = 0.0"},{name:"mask_feature_length",val:" = 10"},{name:"mask_feature_min_masks",val:" = 0"},{name:"median_filter_width",val:" = 7"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.WhisperConfig.vocab_size",description:`<strong>vocab_size</strong> (<code>int</code>, <em>optional</em>, defaults to 51865) &#x2014;
Vocabulary size of the Whisper model. Defines the number of different tokens that can be represented by the
<code>decoder_input_ids</code> passed when calling <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperModel">WhisperModel</a>`,name:"vocab_size"},{anchor:"transformers.WhisperConfig.num_mel_bins",description:`<strong>num_mel_bins</strong> (<code>int</code>, <em>optional</em>, defaults to 80) &#x2014;
Number of mel features used per input features. Should correspond to the value used in the
<code>WhisperProcessor</code> class.`,name:"num_mel_bins"},{anchor:"transformers.WhisperConfig.encoder_layers",description:`<strong>encoder_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 4) &#x2014;
Number of encoder layers.`,name:"encoder_layers"},{anchor:"transformers.WhisperConfig.decoder_layers",description:`<strong>decoder_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 4) &#x2014;
Number of decoder layers.`,name:"decoder_layers"},{anchor:"transformers.WhisperConfig.encoder_attention_heads",description:`<strong>encoder_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 6) &#x2014;
Number of attention heads for each attention layer in the Transformer encoder.`,name:"encoder_attention_heads"},{anchor:"transformers.WhisperConfig.decoder_attention_heads",description:`<strong>decoder_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 6) &#x2014;
Number of attention heads for each attention layer in the Transformer decoder.`,name:"decoder_attention_heads"},{anchor:"transformers.WhisperConfig.encoder_ffn_dim",description:`<strong>encoder_ffn_dim</strong> (<code>int</code>, <em>optional</em>, defaults to 1536) &#x2014;
Dimensionality of the &#x201C;intermediate&#x201D; (often named feed-forward) layer in encoder.`,name:"encoder_ffn_dim"},{anchor:"transformers.WhisperConfig.decoder_ffn_dim",description:`<strong>decoder_ffn_dim</strong> (<code>int</code>, <em>optional</em>, defaults to 1536) &#x2014;
Dimensionality of the &#x201C;intermediate&#x201D; (often named feed-forward) layer in decoder.`,name:"decoder_ffn_dim"},{anchor:"transformers.WhisperConfig.encoder_layerdrop",description:`<strong>encoder_layerdrop</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The LayerDrop probability for the encoder. See the [LayerDrop paper](see <a href="https://huggingface.co/papers/1909.11556" rel="nofollow">https://huggingface.co/papers/1909.11556</a>)
for more details.`,name:"encoder_layerdrop"},{anchor:"transformers.WhisperConfig.decoder_layerdrop",description:`<strong>decoder_layerdrop</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The LayerDrop probability for the decoder. See the [LayerDrop paper](see <a href="https://huggingface.co/papers/1909.11556" rel="nofollow">https://huggingface.co/papers/1909.11556</a>)
for more details.`,name:"decoder_layerdrop"},{anchor:"transformers.WhisperConfig.decoder_start_token_id",description:`<strong>decoder_start_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 50257) &#x2014;
Corresponds to the &#x201D;&lt;|startoftranscript|&gt;&#x201D; token, which is automatically used when no <code>decoder_input_ids</code>
are provided to the <code>generate</code> function. It is used to guide the model\`s generation process depending on
the task.`,name:"decoder_start_token_id"},{anchor:"transformers.WhisperConfig.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether or not the model should return the last key/values attentions (not used by all models).`,name:"use_cache"},{anchor:"transformers.WhisperConfig.is_encoder_decoder",description:`<strong>is_encoder_decoder</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether the model is used as an encoder/decoder or not.`,name:"is_encoder_decoder"},{anchor:"transformers.WhisperConfig.activation_function",description:`<strong>activation_function</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;gelu&quot;</code>) &#x2014;
The non-linear activation function (function or string) in the encoder and pooler. If string, <code>&quot;gelu&quot;</code>,
<code>&quot;relu&quot;</code>, <code>&quot;silu&quot;</code> and <code>&quot;gelu_new&quot;</code> are supported.`,name:"activation_function"},{anchor:"transformers.WhisperConfig.d_model",description:`<strong>d_model</strong> (<code>int</code>, <em>optional</em>, defaults to 384) &#x2014;
Dimensionality of the layers.`,name:"d_model"},{anchor:"transformers.WhisperConfig.dropout",description:`<strong>dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.1) &#x2014;
The dropout probability for all fully connected layers in the embeddings, encoder, and pooler.`,name:"dropout"},{anchor:"transformers.WhisperConfig.attention_dropout",description:`<strong>attention_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout ratio for the attention probabilities.`,name:"attention_dropout"},{anchor:"transformers.WhisperConfig.activation_dropout",description:`<strong>activation_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout ratio for activations inside the fully connected layer.`,name:"activation_dropout"},{anchor:"transformers.WhisperConfig.init_std",description:`<strong>init_std</strong> (<code>float</code>, <em>optional</em>, defaults to 0.02) &#x2014;
The standard deviation of the truncated_normal_initializer for initializing all weight matrices.`,name:"init_std"},{anchor:"transformers.WhisperConfig.scale_embedding",description:`<strong>scale_embedding</strong> (<code>bool</code>, <em>optional</em>, defaults to False) &#x2014;
Scale embeddings by diving by sqrt(d_model).`,name:"scale_embedding"},{anchor:"transformers.WhisperConfig.max_source_positions",description:`<strong>max_source_positions</strong> (<code>int</code>, <em>optional</em>, defaults to 1500) &#x2014;
The maximum sequence length of log-mel filter-bank features that this model might ever be used with.`,name:"max_source_positions"},{anchor:"transformers.WhisperConfig.max_target_positions",description:`<strong>max_target_positions</strong> (<code>int</code>, <em>optional</em>, defaults to 448) &#x2014;
The maximum sequence length that this model might ever be used with. Typically set this to something large
just in case (e.g., 512 or 1024 or 2048).`,name:"max_target_positions"},{anchor:"transformers.WhisperConfig.pad_token_id",description:`<strong>pad_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 50256) &#x2014;
Padding token id.`,name:"pad_token_id"},{anchor:"transformers.WhisperConfig.bos_token_id",description:`<strong>bos_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 50256) &#x2014;
Begin of stream token id.`,name:"bos_token_id"},{anchor:"transformers.WhisperConfig.eos_token_id",description:`<strong>eos_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 50256) &#x2014;
End of stream token id.`,name:"eos_token_id"},{anchor:"transformers.WhisperConfig.suppress_tokens",description:`<strong>suppress_tokens</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
A list containing the non-speech tokens that will be used by the logit processor in the <code>generate</code>
function. NON_SPEECH_TOKENS and NON_SPEECH_TOKENS_MULTI each correspond to the <code>english-only</code> and the
<code>multilingual</code> model.`,name:"suppress_tokens"},{anchor:"transformers.WhisperConfig.begin_suppress_tokens",description:`<strong>begin_suppress_tokens</strong> (<code>List[int]</code>, <em>optional</em>, defaults to <code>[220,50256]</code>) &#x2014;
A list containing tokens that will be suppressed at the beginning of the sampling process. Initialized as
the token for <code>&quot; &quot;</code> (<code>blank_token_id</code>) and the <code>eos_token_id</code>`,name:"begin_suppress_tokens"},{anchor:"transformers.WhisperConfig.use_weighted_layer_sum",description:`<strong>use_weighted_layer_sum</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether to use a weighted average of layer outputs with learned weights. Only relevant when using an
instance of <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperForAudioClassification">WhisperForAudioClassification</a>.`,name:"use_weighted_layer_sum"},{anchor:"transformers.WhisperConfig.classifier_proj_size",description:`<strong>classifier_proj_size</strong> (<code>int</code>, <em>optional</em>, defaults to 256) &#x2014;
Dimensionality of the projection before token mean-pooling for classification. Only relevant when using an
instance of <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperForAudioClassification">WhisperForAudioClassification</a>.`,name:"classifier_proj_size"},{anchor:"transformers.WhisperConfig.apply_spec_augment",description:`<strong>apply_spec_augment</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether to apply <em>SpecAugment</em> data augmentation to the outputs of the feature encoder. For reference see
<a href="https://huggingface.co/papers/1904.08779" rel="nofollow">SpecAugment: A Simple Data Augmentation Method for Automatic Speech
Recognition</a>.`,name:"apply_spec_augment"},{anchor:"transformers.WhisperConfig.mask_time_prob",description:`<strong>mask_time_prob</strong> (<code>float</code>, <em>optional</em>, defaults to 0.05) &#x2014;
Percentage (between 0 and 1) of all feature vectors along the time axis which will be masked. The masking
procedure generates <code>mask_time_prob*len(time_axis)/mask_time_length</code> independent masks over the axis. If
reasoning from the probability of each feature vector to be chosen as the start of the vector span to be
masked, <em>mask_time_prob</em> should be <code>prob_vector_start*mask_time_length</code>. Note that overlap may decrease the
actual percentage of masked vectors. This is only relevant if <code>apply_spec_augment == True</code>.`,name:"mask_time_prob"},{anchor:"transformers.WhisperConfig.mask_time_length",description:`<strong>mask_time_length</strong> (<code>int</code>, <em>optional</em>, defaults to 10) &#x2014;
Length of vector span along the time axis.`,name:"mask_time_length"},{anchor:"transformers.WhisperConfig.mask_time_min_masks",description:`<strong>mask_time_min_masks</strong> (<code>int</code>, <em>optional</em>, defaults to 2), &#x2014;
The minimum number of masks of length <code>mask_feature_length</code> generated along the time axis, each time step,
irrespectively of <code>mask_feature_prob</code>. Only relevant if &#x201D;mask_time_prob*len(time_axis)/mask_time_length &lt;
mask_time_min_masks&#x201D;`,name:"mask_time_min_masks"},{anchor:"transformers.WhisperConfig.mask_feature_prob",description:`<strong>mask_feature_prob</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
Percentage (between 0 and 1) of all feature vectors along the feature axis which will be masked. The
masking procedure generates <code>mask_feature_prob*len(feature_axis)/mask_time_length</code> independent masks over
the axis. If reasoning from the probability of each feature vector to be chosen as the start of the vector
span to be masked, <em>mask_feature_prob</em> should be <code>prob_vector_start*mask_feature_length</code>. Note that overlap
may decrease the actual percentage of masked vectors. This is only relevant if <code>apply_spec_augment is True</code>.`,name:"mask_feature_prob"},{anchor:"transformers.WhisperConfig.mask_feature_length",description:`<strong>mask_feature_length</strong> (<code>int</code>, <em>optional</em>, defaults to 10) &#x2014;
Length of vector span along the feature axis.`,name:"mask_feature_length"},{anchor:"transformers.WhisperConfig.mask_feature_min_masks",description:`<strong>mask_feature_min_masks</strong> (<code>int</code>, <em>optional</em>, defaults to 0), &#x2014;
The minimum number of masks of length <code>mask_feature_length</code> generated along the feature axis, each time
step, irrespectively of <code>mask_feature_prob</code>. Only relevant if
<code>mask_feature_prob*len(feature_axis)/mask_feature_length &lt; mask_feature_min_masks</code>.`,name:"mask_feature_min_masks"},{anchor:"transformers.WhisperConfig.median_filter_width",description:`<strong>median_filter_width</strong> (<code>int</code>, <em>optional</em>, defaults to 7) &#x2014;
Width of the median filter used to smoothen to cross-attention outputs when computing token timestamps.
Should be an odd number.`,name:"median_filter_width"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/configuration_whisper.py#L60"}}),be=new ne({props:{anchor:"transformers.WhisperConfig.example",$$slots:{default:[Ti]},$$scope:{ctx:v}}}),yt=new Z({props:{title:"WhisperTokenizer",local:"whispertokenizer ][ transformers.WhisperTokenizer",headingTag:"h2"}}),bt=new $({props:{name:"class transformers.WhisperTokenizer",anchor:"transformers.WhisperTokenizer",parameters:[{name:"vocab_file",val:""},{name:"merges_file",val:""},{name:"normalizer_file",val:" = None"},{name:"errors",val:" = 'replace'"},{name:"unk_token",val:" = '<|endoftext|>'"},{name:"bos_token",val:" = '<|endoftext|>'"},{name:"eos_token",val:" = '<|endoftext|>'"},{name:"pad_token",val:" = None"},{name:"add_prefix_space",val:" = False"},{name:"language",val:" = None"},{name:"task",val:" = None"},{name:"predict_timestamps",val:" = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.WhisperTokenizer.vocab_file",description:`<strong>vocab_file</strong> (<code>str</code>) &#x2014;
Path to the vocabulary file.`,name:"vocab_file"},{anchor:"transformers.WhisperTokenizer.merges_file",description:`<strong>merges_file</strong> (<code>str</code>) &#x2014;
Path to the merges file.`,name:"merges_file"},{anchor:"transformers.WhisperTokenizer.normalizer_file",description:`<strong>normalizer_file</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Path to the normalizer_file file.`,name:"normalizer_file"},{anchor:"transformers.WhisperTokenizer.errors",description:`<strong>errors</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;replace&quot;</code>) &#x2014;
Paradigm to follow when decoding bytes to UTF-8. See
<a href="https://docs.python.org/3/library/stdtypes.html#bytes.decode" rel="nofollow">bytes.decode</a> for more information.`,name:"errors"},{anchor:"transformers.WhisperTokenizer.unk_token",description:`<strong>unk_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.WhisperTokenizer.bos_token",description:`<strong>bos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The beginning of sequence token. The <code>decoder_start_token_id</code> is used to set the first token as
<code>&quot;&lt;|startoftranscript|&gt;&quot;</code> when generating.`,name:"bos_token"},{anchor:"transformers.WhisperTokenizer.eos_token",description:`<strong>eos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The end of sequence token.`,name:"eos_token"},{anchor:"transformers.WhisperTokenizer.pad_token",description:`<strong>pad_token</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The token used for padding, for example when batching sequences of different lengths.`,name:"pad_token"},{anchor:"transformers.WhisperTokenizer.add_prefix_space",description:`<strong>add_prefix_space</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to add an initial space to the input. This allows to treat the leading word just as any
other word.`,name:"add_prefix_space"},{anchor:"transformers.WhisperTokenizer.language",description:`<strong>language</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The language of the transcription text. The corresponding language id token is appended to the start of the
sequence for multilingual speech recognition and speech translation tasks, e.g. for Spanish the token
<code>&quot;&lt;|es|&gt;&quot;</code> is appended to the start of sequence. This should be used for multilingual fine-tuning only.`,name:"language"},{anchor:"transformers.WhisperTokenizer.task",description:`<strong>task</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Task identifier to append at the start of sequence (if any). This should be used for mulitlingual
fine-tuning, with <code>&quot;transcribe&quot;</code> for speech recognition and <code>&quot;translate&quot;</code> for speech translation.`,name:"task"},{anchor:"transformers.WhisperTokenizer.predict_timestamps",description:`<strong>predict_timestamps</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether to omit the <code>&lt;|notimestamps|&gt;</code> token at the start of the sequence.`,name:"predict_timestamps"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper.py#L210"}}),kt=new $({props:{name:"set_prefix_tokens",anchor:"transformers.WhisperTokenizer.set_prefix_tokens",parameters:[{name:"language",val:": typing.Optional[str] = None"},{name:"task",val:": typing.Optional[str] = None"},{name:"predict_timestamps",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.WhisperTokenizer.set_prefix_tokens.language",description:`<strong>language</strong> (<code>str</code>, <em>optional</em>, defaults to <code>None</code>) &#x2014;
The language of the transcription text.`,name:"language"},{anchor:"transformers.WhisperTokenizer.set_prefix_tokens.task",description:`<strong>task</strong> (<code>str</code>, <em>optional</em>, defaults to <code>None</code>) &#x2014;
Task identifier to append at the start of sequence (if any).`,name:"task"},{anchor:"transformers.WhisperTokenizer.set_prefix_tokens.predict_timestamps",description:`<strong>predict_timestamps</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>None</code>) &#x2014;
Whether to omit the <code>&lt;|notimestamps|&gt;</code> token at the start of the sequence.`,name:"predict_timestamps"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper.py#L380"}}),ke=new ne({props:{anchor:"transformers.WhisperTokenizer.set_prefix_tokens.example",$$slots:{default:[wi]},$$scope:{ctx:v}}}),Tt=new $({props:{name:"build_inputs_with_special_tokens",anchor:"transformers.WhisperTokenizer.build_inputs_with_special_tokens",parameters:[{name:"token_ids_0",val:""},{name:"token_ids_1",val:" = None"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper.py#L441"}}),wt=new $({props:{name:"get_special_tokens_mask",anchor:"transformers.WhisperTokenizer.get_special_tokens_mask",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"},{name:"already_has_special_tokens",val:": bool = False"}],parametersDescription:[{anchor:"transformers.WhisperTokenizer.get_special_tokens_mask.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs.`,name:"token_ids_0"},{anchor:"transformers.WhisperTokenizer.get_special_tokens_mask.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"},{anchor:"transformers.WhisperTokenizer.get_special_tokens_mask.already_has_special_tokens",description:`<strong>already_has_special_tokens</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not the token list is already formatted with special tokens for the model.`,name:"already_has_special_tokens"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper.py#L449",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A list of integers in the range [0, 1]: 1 for a special token, 0 for a sequence token.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),vt=new $({props:{name:"create_token_type_ids_from_sequences",anchor:"transformers.WhisperTokenizer.create_token_type_ids_from_sequences",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.WhisperTokenizer.create_token_type_ids_from_sequences.token_ids_0",description:"<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014; The first tokenized sequence.",name:"token_ids_0"},{anchor:"transformers.WhisperTokenizer.create_token_type_ids_from_sequences.token_ids_1",description:"<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014; The second tokenized sequence.",name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/tokenization_utils_base.py#L3376",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The token type ids.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),xt=new $({props:{name:"save_vocabulary",anchor:"transformers.WhisperTokenizer.save_vocabulary",parameters:[{name:"save_directory",val:": str"},{name:"filename_prefix",val:": typing.Optional[str] = None"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper.py#L801"}}),Mt=new Z({props:{title:"WhisperTokenizerFast",local:"whispertokenizerfast ][ transformers.WhisperTokenizerFast",headingTag:"h2"}}),$t=new $({props:{name:"class transformers.WhisperTokenizerFast",anchor:"transformers.WhisperTokenizerFast",parameters:[{name:"vocab_file",val:" = None"},{name:"merges_file",val:" = None"},{name:"normalizer_file",val:" = None"},{name:"tokenizer_file",val:" = None"},{name:"unk_token",val:" = '<|endoftext|>'"},{name:"bos_token",val:" = '<|endoftext|>'"},{name:"eos_token",val:" = '<|endoftext|>'"},{name:"add_prefix_space",val:" = False"},{name:"language",val:" = None"},{name:"task",val:" = None"},{name:"predict_timestamps",val:" = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.WhisperTokenizerFast.vocab_file",description:`<strong>vocab_file</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Path to the vocabulary file.`,name:"vocab_file"},{anchor:"transformers.WhisperTokenizerFast.merges_file",description:`<strong>merges_file</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Path to the merges file.`,name:"merges_file"},{anchor:"transformers.WhisperTokenizerFast.normalizer_file",description:`<strong>normalizer_file</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Path to the normalizer_file file.`,name:"normalizer_file"},{anchor:"transformers.WhisperTokenizerFast.tokenizer_file",description:`<strong>tokenizer_file</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Path to <a href="https://github.com/huggingface/tokenizers" rel="nofollow">tokenizers</a> file (generally has a .json extension) that
contains everything needed to load the tokenizer.`,name:"tokenizer_file"},{anchor:"transformers.WhisperTokenizerFast.unk_token",description:`<strong>unk_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.WhisperTokenizerFast.bos_token",description:`<strong>bos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The beginning of sequence token. The <code>decoder_start_token_id</code> is used to set the first token as
<code>&quot;&lt;|startoftranscript|&gt;&quot;</code> when generating.`,name:"bos_token"},{anchor:"transformers.WhisperTokenizerFast.eos_token",description:`<strong>eos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The end of sequence token.`,name:"eos_token"},{anchor:"transformers.WhisperTokenizerFast.add_prefix_space",description:`<strong>add_prefix_space</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to add an initial space to the input. This allows to treat the leading word just as any
other word. (Whisper tokenizer detect beginning of words by the preceding space).`,name:"add_prefix_space"},{anchor:"transformers.WhisperTokenizerFast.language",description:`<strong>language</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The language of the transcription text. The corresponding language id token is appended to the start of the
sequence for multilingual speech recognition and speech translation tasks, e.g. for Spanish the token
<code>&quot;&lt;|es|&gt;&quot;</code> is appended to the start of sequence. This should be used for multilingual fine-tuning only.`,name:"language"},{anchor:"transformers.WhisperTokenizerFast.task",description:`<strong>task</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Task identifier to append at the start of sequence (if any). This should be used for mulitlingual
fine-tuning, with <code>&quot;transcribe&quot;</code> for speech recognition and <code>&quot;translate&quot;</code> for speech translation.`,name:"task"},{anchor:"transformers.WhisperTokenizerFast.predict_timestamps",description:`<strong>predict_timestamps</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether to omit the <code>&lt;|notimestamps|&gt;</code> token at the start of the sequence.`,name:"predict_timestamps"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper_fast.py#L44"}}),Wt=new $({props:{name:"set_prefix_tokens",anchor:"transformers.WhisperTokenizerFast.set_prefix_tokens",parameters:[{name:"language",val:": typing.Optional[str] = None"},{name:"task",val:": typing.Optional[str] = None"},{name:"predict_timestamps",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.WhisperTokenizerFast.set_prefix_tokens.language",description:`<strong>language</strong> (<code>str</code>, <em>optional</em>, defaults to <code>None</code>) &#x2014;
The language of the transcription text.`,name:"language"},{anchor:"transformers.WhisperTokenizerFast.set_prefix_tokens.task",description:`<strong>task</strong> (<code>str</code>, <em>optional</em>, defaults to <code>None</code>) &#x2014;
Task identifier to append at the start of sequence (if any).`,name:"task"},{anchor:"transformers.WhisperTokenizerFast.set_prefix_tokens.predict_timestamps",description:`<strong>predict_timestamps</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>None</code>) &#x2014;
Whether to omit the <code>&lt;|notimestamps|&gt;</code> token at the start of the sequence.`,name:"predict_timestamps"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper_fast.py#L454"}}),ve=new ne({props:{anchor:"transformers.WhisperTokenizerFast.set_prefix_tokens.example",$$slots:{default:[vi]},$$scope:{ctx:v}}}),Ft=new $({props:{name:"build_inputs_with_special_tokens",anchor:"transformers.WhisperTokenizerFast.build_inputs_with_special_tokens",parameters:[{name:"token_ids_0",val:""},{name:"token_ids_1",val:" = None"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper_fast.py#L530"}}),zt=new $({props:{name:"get_special_tokens_mask",anchor:"transformers.WhisperTokenizerFast.get_special_tokens_mask",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"},{name:"already_has_special_tokens",val:": bool = False"}],parametersDescription:[{anchor:"transformers.WhisperTokenizerFast.get_special_tokens_mask.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs.`,name:"token_ids_0"},{anchor:"transformers.WhisperTokenizerFast.get_special_tokens_mask.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"},{anchor:"transformers.WhisperTokenizerFast.get_special_tokens_mask.already_has_special_tokens",description:`<strong>already_has_special_tokens</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not the token list is already formatted with special tokens for the model.`,name:"already_has_special_tokens"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper_fast.py#L538",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A list of integers in the range [0, 1]: 1 for a special token, 0 for a sequence token.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),Ct=new $({props:{name:"create_token_type_ids_from_sequences",anchor:"transformers.WhisperTokenizerFast.create_token_type_ids_from_sequences",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.WhisperTokenizerFast.create_token_type_ids_from_sequences.token_ids_0",description:"<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014; The first tokenized sequence.",name:"token_ids_0"},{anchor:"transformers.WhisperTokenizerFast.create_token_type_ids_from_sequences.token_ids_1",description:"<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014; The second tokenized sequence.",name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/tokenization_utils_base.py#L3376",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The token type ids.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),jt=new $({props:{name:"save_vocabulary",anchor:"transformers.WhisperTokenizerFast.save_vocabulary",parameters:[{name:"save_directory",val:": str"},{name:"filename_prefix",val:": typing.Optional[str] = None"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/tokenization_whisper_fast.py#L439"}}),qt=new Z({props:{title:"WhisperFeatureExtractor",local:"whisperfeatureextractor ][ transformers.WhisperFeatureExtractor",headingTag:"h2"}}),Jt=new $({props:{name:"class transformers.WhisperFeatureExtractor",anchor:"transformers.WhisperFeatureExtractor",parameters:[{name:"feature_size",val:" = 80"},{name:"sampling_rate",val:" = 16000"},{name:"hop_length",val:" = 160"},{name:"chunk_length",val:" = 30"},{name:"n_fft",val:" = 400"},{name:"padding_value",val:" = 0.0"},{name:"dither",val:" = 0.0"},{name:"return_attention_mask",val:" = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.WhisperFeatureExtractor.feature_size",description:`<strong>feature_size</strong> (<code>int</code>, <em>optional</em>, defaults to 80) &#x2014;
The feature dimension of the extracted features.`,name:"feature_size"},{anchor:"transformers.WhisperFeatureExtractor.sampling_rate",description:`<strong>sampling_rate</strong> (<code>int</code>, <em>optional</em>, defaults to 16000) &#x2014;
The sampling rate at which the audio files should be digitalized expressed in hertz (Hz).`,name:"sampling_rate"},{anchor:"transformers.WhisperFeatureExtractor.hop_length",description:`<strong>hop_length</strong> (<code>int</code>, <em>optional</em>, defaults to 160) &#x2014;
Length of the overlapping windows for the STFT used to obtain the Mel Frequency coefficients.`,name:"hop_length"},{anchor:"transformers.WhisperFeatureExtractor.chunk_length",description:`<strong>chunk_length</strong> (<code>int</code>, <em>optional</em>, defaults to 30) &#x2014;
The maximum number of chunks of <code>sampling_rate</code> samples used to trim and pad longer or shorter audio
sequences.`,name:"chunk_length"},{anchor:"transformers.WhisperFeatureExtractor.n_fft",description:`<strong>n_fft</strong> (<code>int</code>, <em>optional</em>, defaults to 400) &#x2014;
Size of the Fourier transform.`,name:"n_fft"},{anchor:"transformers.WhisperFeatureExtractor.padding_value",description:`<strong>padding_value</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
Padding value used to pad the audio. Should correspond to silences.`,name:"padding_value"},{anchor:"transformers.WhisperFeatureExtractor.dither",description:`<strong>dither</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
Adds dithering. In other words, adds a small Gaussian noise to each frame.
E.g. use 0.0001 to add dithering with a normal distribution centered
around 0.0 with standard deviation 0.0001 (assuming [-1,+1] range of raw_speech).
The value 0.0 means no dithering.
Dithering has similar effect as <code>spectrogram(mel_floor=...)</code>. It reduces
the high log_mel_fbank values for signals with hard-zero sections,
when VAD cutoff is present in the signal.`,name:"dither"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/feature_extraction_whisper.py#L36"}}),It=new $({props:{name:"__call__",anchor:"transformers.WhisperFeatureExtractor.__call__",parameters:[{name:"raw_speech",val:": typing.Union[numpy.ndarray, typing.List[float], typing.List[numpy.ndarray], typing.List[typing.List[float]]]"},{name:"truncation",val:": bool = True"},{name:"pad_to_multiple_of",val:": typing.Optional[int] = None"},{name:"return_tensors",val:": typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None"},{name:"return_attention_mask",val:": typing.Optional[bool] = None"},{name:"padding",val:": typing.Optional[str] = 'max_length'"},{name:"max_length",val:": typing.Optional[int] = None"},{name:"sampling_rate",val:": typing.Optional[int] = None"},{name:"do_normalize",val:": typing.Optional[bool] = None"},{name:"device",val:": typing.Optional[str] = 'cpu'"},{name:"return_token_timestamps",val:": typing.Optional[bool] = None"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.WhisperFeatureExtractor.__call__.raw_speech",description:`<strong>raw_speech</strong> (<code>np.ndarray</code>, <code>List[float]</code>, <code>List[np.ndarray]</code>, <code>List[List[float]]</code>) &#x2014;
The sequence or batch of sequences to be padded. Each sequence can be a numpy array, a list of float
values, a list of numpy arrays or a list of list of float values. Must be mono channel audio, not
stereo, i.e. single float per timestep.`,name:"raw_speech"},{anchor:"transformers.WhisperFeatureExtractor.__call__.truncation",description:`<strong>truncation</strong> (<code>bool</code>, <em>optional</em>, default to <code>True</code>) &#x2014;
Activates truncation to cut input sequences longer than <em>max_length</em> to <em>max_length</em>.`,name:"truncation"},{anchor:"transformers.WhisperFeatureExtractor.__call__.pad_to_multiple_of",description:`<strong>pad_to_multiple_of</strong> (<code>int</code>, <em>optional</em>, defaults to None) &#x2014;
If set will pad the sequence to a multiple of the provided value.</p>
<p>This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability
<code>&gt;= 7.5</code> (Volta), or on TPUs which benefit from having sequence lengths be a multiple of 128.`,name:"pad_to_multiple_of"},{anchor:"transformers.WhisperFeatureExtractor.__call__.return_attention_mask",description:`<strong>return_attention_mask</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether to return the attention mask. If left to the default, will return the attention mask according
to the specific feature_extractor&#x2019;s default.</p>
<p><a href="../glossary#attention-mask">What are attention masks?</a></p>
<div class="course-tip  bg-gradient-to-br dark:bg-gradient-to-r before:border-green-500 dark:before:border-green-800 from-green-50 dark:from-gray-900 to-white dark:to-gray-950 border border-green-50 text-green-700 dark:text-gray-400">
						
<p>For Whisper models, <code>attention_mask</code> should always be passed for batched inference, to avoid subtle
bugs.</p>

					</div>`,name:"return_attention_mask"},{anchor:"transformers.WhisperFeatureExtractor.__call__.return_tensors",description:`<strong>return_tensors</strong> (<code>str</code> or <a href="/docs/transformers/main/ko/internal/file_utils#transformers.TensorType">TensorType</a>, <em>optional</em>) &#x2014;
If set, will return tensors instead of list of python integers. Acceptable values are:</p>
<ul>
<li><code>&apos;tf&apos;</code>: Return TensorFlow <code>tf.constant</code> objects.</li>
<li><code>&apos;pt&apos;</code>: Return PyTorch <code>torch.Tensor</code> objects.</li>
<li><code>&apos;np&apos;</code>: Return Numpy <code>np.ndarray</code> objects.</li>
</ul>`,name:"return_tensors"},{anchor:"transformers.WhisperFeatureExtractor.__call__.sampling_rate",description:`<strong>sampling_rate</strong> (<code>int</code>, <em>optional</em>) &#x2014;
The sampling rate at which the <code>raw_speech</code> input was sampled. It is strongly recommended to pass
<code>sampling_rate</code> at the forward call to prevent silent errors and allow automatic speech recognition
pipeline.`,name:"sampling_rate"},{anchor:"transformers.WhisperFeatureExtractor.__call__.padding_value",description:`<strong>padding_value</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The value that is used to fill the padding values / vectors.`,name:"padding_value"},{anchor:"transformers.WhisperFeatureExtractor.__call__.do_normalize",description:`<strong>do_normalize</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to zero-mean unit-variance normalize the input. Normalizing can help to significantly
improve the performance of the model.`,name:"do_normalize"},{anchor:"transformers.WhisperFeatureExtractor.__call__.device",description:`<strong>device</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&apos;cpu&apos;</code>) &#x2014;
Specifies the device for computation of the log-mel spectrogram of audio signals in the
<code>_torch_extract_fbank_features</code> method. (e.g., &#x201C;cpu&#x201D;, &#x201C;cuda&#x201D;)`,name:"device"},{anchor:"transformers.WhisperFeatureExtractor.__call__.return_token_timestamps",description:`<strong>return_token_timestamps</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>None</code>) &#x2014;
Whether or not to return the number of frames of the input raw_speech.
These num_frames can be used by the model to compute word level timestamps.`,name:"return_token_timestamps"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/feature_extraction_whisper.py#L192"}}),Gt=new Z({props:{title:"WhisperProcessor",local:"whisperprocessor ][ transformers.WhisperProcessor",headingTag:"h2"}}),Ut=new $({props:{name:"class transformers.WhisperProcessor",anchor:"transformers.WhisperProcessor",parameters:[{name:"feature_extractor",val:""},{name:"tokenizer",val:""}],parametersDescription:[{anchor:"transformers.WhisperProcessor.feature_extractor",description:`<strong>feature_extractor</strong> (<code>WhisperFeatureExtractor</code>) &#x2014;
An instance of <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor">WhisperFeatureExtractor</a>. The feature extractor is a required input.`,name:"feature_extractor"},{anchor:"transformers.WhisperProcessor.tokenizer",description:`<strong>tokenizer</strong> (<code>WhisperTokenizer</code>) &#x2014;
An instance of <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperTokenizer">WhisperTokenizer</a>. The tokenizer is a required input.`,name:"tokenizer"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/processing_whisper.py#L22"}}),Nt=new $({props:{name:"__call__",anchor:"transformers.WhisperProcessor.__call__",parameters:[{name:"*args",val:""},{name:"**kwargs",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/processing_whisper.py#L48"}}),Zt=new $({props:{name:"from_pretrained",anchor:"transformers.WhisperProcessor.from_pretrained",parameters:[{name:"pretrained_model_name_or_path",val:": typing.Union[str, os.PathLike]"},{name:"cache_dir",val:": typing.Union[str, os.PathLike, NoneType] = None"},{name:"force_download",val:": bool = False"},{name:"local_files_only",val:": bool = False"},{name:"token",val:": typing.Union[str, bool, NoneType] = None"},{name:"revision",val:": str = 'main'"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.WhisperProcessor.from_pretrained.pretrained_model_name_or_path",description:`<strong>pretrained_model_name_or_path</strong> (<code>str</code> or <code>os.PathLike</code>) &#x2014;
This can be either:</p>
<ul>
<li>a string, the <em>model id</em> of a pretrained feature_extractor hosted inside a model repo on
huggingface.co.</li>
<li>a path to a <em>directory</em> containing a feature extractor file saved using the
<a href="/docs/transformers/main/ko/main_classes/feature_extractor#transformers.FeatureExtractionMixin.save_pretrained">save_pretrained()</a> method, e.g., <code>./my_model_directory/</code>.</li>
<li>a path or url to a saved feature extractor JSON <em>file</em>, e.g.,
<code>./my_model_directory/preprocessor_config.json</code>.</li>
</ul>`,name:"pretrained_model_name_or_path"},{anchor:"transformers.WhisperProcessor.from_pretrained.*kwargs",description:`*<strong>*kwargs</strong> &#x2014;
Additional keyword arguments passed along to both
<a href="/docs/transformers/main/ko/main_classes/feature_extractor#transformers.FeatureExtractionMixin.from_pretrained">from_pretrained()</a> and
<code>~tokenization_utils_base.PreTrainedTokenizer.from_pretrained</code>.`,name:"*kwargs"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/processing_utils.py#L1160"}}),Fe=new he({props:{$$slots:{default:[xi]},$$scope:{ctx:v}}}),Xt=new $({props:{name:"save_pretrained",anchor:"transformers.WhisperProcessor.save_pretrained",parameters:[{name:"save_directory",val:""},{name:"push_to_hub",val:": bool = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.WhisperProcessor.save_pretrained.save_directory",description:`<strong>save_directory</strong> (<code>str</code> or <code>os.PathLike</code>) &#x2014;
Directory where the feature extractor JSON file and the tokenizer files will be saved (directory will
be created if it does not exist).`,name:"save_directory"},{anchor:"transformers.WhisperProcessor.save_pretrained.push_to_hub",description:`<strong>push_to_hub</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to push your model to the Hugging Face model hub after saving it. You can specify the
repository you want to push to with <code>repo_id</code> (will default to the name of <code>save_directory</code> in your
namespace).`,name:"push_to_hub"},{anchor:"transformers.WhisperProcessor.save_pretrained.kwargs",description:`<strong>kwargs</strong> (<code>Dict[str, Any]</code>, <em>optional</em>) &#x2014;
Additional key word arguments passed along to the <a href="/docs/transformers/main/ko/main_classes/model#transformers.utils.PushToHubMixin.push_to_hub">push_to_hub()</a> method.`,name:"kwargs"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/processing_utils.py#L617"}}),ze=new he({props:{$$slots:{default:[Mi]},$$scope:{ctx:v}}}),Rt=new $({props:{name:"batch_decode",anchor:"transformers.WhisperProcessor.batch_decode",parameters:[{name:"*args",val:""},{name:"**kwargs",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/processing_whisper.py#L82"}}),Lt=new $({props:{name:"decode",anchor:"transformers.WhisperProcessor.decode",parameters:[{name:"*args",val:""},{name:"**kwargs",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/processing_whisper.py#L89"}}),Vt=new Z({props:{title:"WhisperModel",local:"whispermodel ][ transformers.WhisperModel",headingTag:"h2"}}),Et=new $({props:{name:"class transformers.WhisperModel",anchor:"transformers.WhisperModel",parameters:[{name:"config",val:": WhisperConfig"}],parametersDescription:[{anchor:"transformers.WhisperModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig">WhisperConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_whisper.py#L1028"}}),Ht=new $({props:{name:"forward",anchor:"transformers.WhisperModel.forward",parameters:[{name:"input_features",val:": typing.Optional[torch.FloatTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.LongTensor] = None"},{name:"decoder_input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"decoder_attention_mask",val:": typing.Optional[torch.LongTensor] = None"},{name:"head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"cross_attn_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"encoder_outputs",val:": typing.Optional[typing.Tuple[typing.Tuple[torch.FloatTensor]]] = None"},{name:"past_key_values",val:": typing.Union[transformers.cache_utils.EncoderDecoderCache, typing.Tuple[torch.FloatTensor], NoneType] = None"},{name:"decoder_inputs_embeds",val:": typing.Optional[typing.Tuple[torch.FloatTensor]] = None"},{name:"decoder_position_ids",val:": typing.Optional[typing.Tuple[torch.LongTensor]] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"}],parametersDescription:[{anchor:"transformers.WhisperModel.forward.input_features",description:`<strong>input_features</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, feature_size, sequence_length)</code>) &#x2014;
Float values mel features extracted from the raw speech waveform. Raw speech waveform can be obtained by
loading a <code>.flac</code> or <code>.wav</code> audio file into an array of type <code>List[float]</code> or a <code>numpy.ndarray</code>, <em>e.g.</em> via
the soundfile library (<code>pip install soundfile</code>). To prepare the array into <code>input_features</code>, the
<a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoFeatureExtractor">AutoFeatureExtractor</a> should be used for extracting the mel features, padding and conversion into a
tensor of type <code>torch.FloatTensor</code>. See <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a>`,name:"input_features"},{anchor:"transformers.WhisperModel.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.WhisperModel.forward.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperTokenizer">WhisperTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>Whisper uses the <code>decoder_start_token_id</code> as the starting token for <code>decoder_input_ids</code> generation. If
<code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).`,name:"decoder_input_ids"},{anchor:"transformers.WhisperModel.forward.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default.</p>
<p>If you want to change padding behavior, you should read
<code>modeling_whisper._prepare_decoder_attention_mask</code> and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the BART
paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.WhisperModel.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.Tensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.WhisperModel.forward.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.WhisperModel.forward.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.WhisperModel.forward.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>Tuple[Tuple[torch.FloatTensor]]</code>, <em>optional</em>) &#x2014;
Tuple consists of (<code>last_hidden_state</code>, <em>optional</em>: <code>hidden_states</code>, <em>optional</em>: <code>attentions</code>)
<code>last_hidden_state</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) is a sequence of
hidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.`,name:"encoder_outputs"},{anchor:"transformers.WhisperModel.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>Union[~cache_utils.EncoderDecoderCache, Tuple[torch.FloatTensor], NoneType]</code>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.WhisperModel.forward.decoder_inputs_embeds",description:`<strong>decoder_inputs_embeds</strong> (<code>Tuple[torch.FloatTensor]</code> of shape <code>(batch_size, target_sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>decoder_input_ids</code> you can choose to directly pass an embedded
representation. If <code>past_key_values</code> is used, optionally only the last <code>decoder_inputs_embeds</code> have to be
input (see <code>past_key_values</code>). This is useful if you want more control over how to convert
<code>decoder_input_ids</code> indices into associated vectors than the model&#x2019;s internal embedding lookup matrix.</p>
<p>If <code>decoder_input_ids</code> and <code>decoder_inputs_embeds</code> are both unset, <code>decoder_inputs_embeds</code> takes the value
of <code>inputs_embeds</code>.`,name:"decoder_inputs_embeds"},{anchor:"transformers.WhisperModel.forward.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>Tuple[torch.LongTensor]</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"decoder_position_ids"},{anchor:"transformers.WhisperModel.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.WhisperModel.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.WhisperModel.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.WhisperModel.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.WhisperModel.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_whisper.py#L1100",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqModelOutput"
>transformers.modeling_outputs.Seq2SeqModelOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig"
>WhisperConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the decoder of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>EncoderDecoderCache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.EncoderDecoderCache"
>EncoderDecoderCache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqModelOutput"
>transformers.modeling_outputs.Seq2SeqModelOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),qe=new he({props:{$$slots:{default:[$i]},$$scope:{ctx:v}}}),Je=new ne({props:{anchor:"transformers.WhisperModel.forward.example",$$slots:{default:[Wi]},$$scope:{ctx:v}}}),Pt=new $({props:{name:"_mask_input_features",anchor:"transformers.WhisperModel._mask_input_features",parameters:[{name:"input_features",val:": FloatTensor"},{name:"attention_mask",val:": typing.Optional[torch.LongTensor] = None"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_whisper.py#L1057"}}),Bt=new Z({props:{title:"WhisperForConditionalGeneration",local:"whisperforconditionalgeneration ][ transformers.WhisperForConditionalGeneration",headingTag:"h2"}}),St=new $({props:{name:"class transformers.WhisperForConditionalGeneration",anchor:"transformers.WhisperForConditionalGeneration",parameters:[{name:"config",val:": WhisperConfig"}],parametersDescription:[{anchor:"transformers.WhisperForConditionalGeneration.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig">WhisperConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_whisper.py#L1229"}}),At=new $({props:{name:"forward",anchor:"transformers.WhisperForConditionalGeneration.forward",parameters:[{name:"input_features",val:": typing.Optional[torch.FloatTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.LongTensor] = None"},{name:"decoder_input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"decoder_attention_mask",val:": typing.Optional[torch.LongTensor] = None"},{name:"head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"cross_attn_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"encoder_outputs",val:": typing.Optional[typing.Tuple[typing.Tuple[torch.FloatTensor]]] = None"},{name:"past_key_values",val:": typing.Union[transformers.cache_utils.EncoderDecoderCache, typing.Tuple[torch.FloatTensor], NoneType] = None"},{name:"decoder_inputs_embeds",val:": typing.Optional[typing.Tuple[torch.FloatTensor]] = None"},{name:"decoder_position_ids",val:": typing.Optional[typing.Tuple[torch.LongTensor]] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"}],parametersDescription:[{anchor:"transformers.WhisperForConditionalGeneration.forward.input_features",description:`<strong>input_features</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, feature_size, sequence_length)</code>) &#x2014;
Float values mel features extracted from the raw speech waveform. Raw speech waveform can be obtained by
loading a <code>.flac</code> or <code>.wav</code> audio file into an array of type <code>List[float]</code> or a <code>numpy.ndarray</code>, <em>e.g.</em> via
the soundfile library (<code>pip install soundfile</code>). To prepare the array into <code>input_features</code>, the
<a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoFeatureExtractor">AutoFeatureExtractor</a> should be used for extracting the mel features, padding and conversion into a
tensor of type <code>torch.FloatTensor</code>. See <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a>`,name:"input_features"},{anchor:"transformers.WhisperForConditionalGeneration.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.WhisperForConditionalGeneration.forward.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperTokenizer">WhisperTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>Whisper uses the <code>decoder_start_token_id</code> as the starting token for <code>decoder_input_ids</code> generation. If
<code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).`,name:"decoder_input_ids"},{anchor:"transformers.WhisperForConditionalGeneration.forward.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default.</p>
<p>If you want to change padding behavior, you should read
<code>modeling_whisper._prepare_decoder_attention_mask</code> and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the BART
paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.WhisperForConditionalGeneration.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.Tensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.WhisperForConditionalGeneration.forward.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.WhisperForConditionalGeneration.forward.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.WhisperForConditionalGeneration.forward.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>Tuple[Tuple[torch.FloatTensor]]</code>, <em>optional</em>) &#x2014;
Tuple consists of (<code>last_hidden_state</code>, <em>optional</em>: <code>hidden_states</code>, <em>optional</em>: <code>attentions</code>)
<code>last_hidden_state</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) is a sequence of
hidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.`,name:"encoder_outputs"},{anchor:"transformers.WhisperForConditionalGeneration.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>Union[~cache_utils.EncoderDecoderCache, Tuple[torch.FloatTensor], NoneType]</code>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.WhisperForConditionalGeneration.forward.decoder_inputs_embeds",description:`<strong>decoder_inputs_embeds</strong> (<code>Tuple[torch.FloatTensor]</code> of shape <code>(batch_size, target_sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>decoder_input_ids</code> you can choose to directly pass an embedded
representation. If <code>past_key_values</code> is used, optionally only the last <code>decoder_inputs_embeds</code> have to be
input (see <code>past_key_values</code>). This is useful if you want more control over how to convert
<code>decoder_input_ids</code> indices into associated vectors than the model&#x2019;s internal embedding lookup matrix.</p>
<p>If <code>decoder_input_ids</code> and <code>decoder_inputs_embeds</code> are both unset, <code>decoder_inputs_embeds</code> takes the value
of <code>inputs_embeds</code>.`,name:"decoder_inputs_embeds"},{anchor:"transformers.WhisperForConditionalGeneration.forward.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>Tuple[torch.LongTensor]</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"decoder_position_ids"},{anchor:"transformers.WhisperForConditionalGeneration.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code>
or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored (masked), the loss is
only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>. <code>sequence_length</code> should be smaller than or equal to <code>config.max_target_positions</code>.`,name:"labels"},{anchor:"transformers.WhisperForConditionalGeneration.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.WhisperForConditionalGeneration.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.WhisperForConditionalGeneration.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.WhisperForConditionalGeneration.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.WhisperForConditionalGeneration.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_whisper.py#L1269",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqLMOutput"
>transformers.modeling_outputs.Seq2SeqLMOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig"
>WhisperConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Language modeling loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>EncoderDecoderCache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.EncoderDecoderCache"
>EncoderDecoderCache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqLMOutput"
>transformers.modeling_outputs.Seq2SeqLMOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Ge=new he({props:{$$slots:{default:[Fi]},$$scope:{ctx:v}}}),Ue=new ne({props:{anchor:"transformers.WhisperForConditionalGeneration.forward.example",$$slots:{default:[zi]},$$scope:{ctx:v}}}),Yt=new Z({props:{title:"WhisperForAudioClassification",local:"whisperforaudioclassification ][ transformers.WhisperForAudioClassification",headingTag:"h2"}}),Dt=new $({props:{name:"class transformers.WhisperForAudioClassification",anchor:"transformers.WhisperForAudioClassification",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.WhisperForAudioClassification.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperForAudioClassification">WhisperForAudioClassification</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_whisper.py#L1580"}}),Ot=new $({props:{name:"forward",anchor:"transformers.WhisperForAudioClassification.forward",parameters:[{name:"input_features",val:": typing.Optional[torch.LongTensor] = None"},{name:"head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"encoder_outputs",val:": typing.Optional[typing.Tuple[typing.Tuple[torch.FloatTensor]]] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.WhisperForAudioClassification.forward.input_features",description:`<strong>input_features</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, feature_size, sequence_length)</code>) &#x2014;
Float values mel features extracted from the raw speech waveform. Raw speech waveform can be obtained by
loading a <code>.flac</code> or <code>.wav</code> audio file into an array of type <code>List[float]</code> or a <code>numpy.ndarray</code>, <em>e.g.</em> via
the soundfile library (<code>pip install soundfile</code>). To prepare the array into <code>input_features</code>, the
<a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoFeatureExtractor">AutoFeatureExtractor</a> should be used for extracting the mel features, padding and conversion into a
tensor of type <code>torch.FloatTensor</code>. See <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a>`,name:"input_features"},{anchor:"transformers.WhisperForAudioClassification.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.Tensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.WhisperForAudioClassification.forward.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>Tuple[Tuple[torch.FloatTensor]]</code>, <em>optional</em>) &#x2014;
Tuple consists of (<code>last_hidden_state</code>, <em>optional</em>: <code>hidden_states</code>, <em>optional</em>: <code>attentions</code>)
<code>last_hidden_state</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) is a sequence of
hidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.`,name:"encoder_outputs"},{anchor:"transformers.WhisperForAudioClassification.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size,)</code>, <em>optional</em>) &#x2014;
Labels for computing the sequence classification/regression loss. Indices should be in <code>[0, ..., config.num_labels - 1]</code>. If <code>config.num_labels == 1</code> a regression loss is computed (Mean-Square loss), If
<code>config.num_labels &gt; 1</code> a classification loss is computed (Cross-Entropy).`,name:"labels"},{anchor:"transformers.WhisperForAudioClassification.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.WhisperForAudioClassification.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.WhisperForAudioClassification.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_whisper.py#L1613",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.SequenceClassifierOutput"
>transformers.modeling_outputs.SequenceClassifierOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig"
>WhisperConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Classification (or regression if config.num_labels==1) loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, config.num_labels)</code>) — Classification (or regression if config.num_labels==1) scores (before SoftMax).</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.SequenceClassifierOutput"
>transformers.modeling_outputs.SequenceClassifierOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Ne=new he({props:{$$slots:{default:[Ci]},$$scope:{ctx:v}}}),Ze=new ne({props:{anchor:"transformers.WhisperForAudioClassification.forward.example",$$slots:{default:[ji]},$$scope:{ctx:v}}}),Qt=new Z({props:{title:"TFWhisperModel",local:"tfwhispermodel ][ transformers.TFWhisperModel",headingTag:"h2"}}),Kt=new $({props:{name:"class transformers.TFWhisperModel",anchor:"transformers.TFWhisperModel",parameters:[{name:"config",val:": WhisperConfig"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.TFWhisperModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig">WhisperConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_tf_whisper.py#L1225"}}),eo=new $({props:{name:"call",anchor:"transformers.TFWhisperModel.call",parameters:[{name:"input_features",val:": TFModelInputType | None = None"},{name:"decoder_input_ids",val:": np.ndarray | tf.Tensor | None = None"},{name:"decoder_attention_mask",val:": np.ndarray | tf.Tensor | None = None"},{name:"decoder_position_ids",val:": np.ndarray | tf.Tensor | None = None"},{name:"head_mask",val:": np.ndarray | tf.Tensor | None = None"},{name:"decoder_head_mask",val:": np.ndarray | tf.Tensor | None = None"},{name:"cross_attn_head_mask",val:": np.ndarray | tf.Tensor | None = None"},{name:"encoder_outputs",val:": Optional[Tuple[Tuple[Union[np.ndarray, tf.Tensor]]]] = None"},{name:"past_key_values",val:": Optional[Tuple[Tuple[Union[np.ndarray, tf.Tensor]]]] = None"},{name:"decoder_inputs_embeds",val:": Optional[Tuple[Union[np.ndarray, tf.Tensor]]] = None"},{name:"use_cache",val:": Optional[bool] = None"},{name:"output_attentions",val:": Optional[bool] = None"},{name:"output_hidden_states",val:": Optional[bool] = None"},{name:"return_dict",val:": Optional[bool] = None"},{name:"training",val:": bool = False"}],parametersDescription:[{anchor:"transformers.TFWhisperModel.call.input_features",description:`<strong>input_features</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, feature_size, sequence_length)</code>) &#x2014;
Float values of fbank features extracted from the raw speech waveform. Raw speech waveform can be obtained
by loading a <code>.flac</code> or <code>.wav</code> audio file into an array of type <code>List[float]</code> or a <code>numpy.ndarray</code>, <em>e.g.</em>
via the soundfile library (<code>pip install soundfile</code>). To prepare the array into <code>input_features</code>, the
<a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoFeatureExtractor">AutoFeatureExtractor</a> should be used for extracting the fbank features, padding and conversion into a
tensor of type <code>tf.Tensor</code>. See <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a>`,name:"input_features"},{anchor:"transformers.TFWhisperModel.call.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <code>SpeechToTextTokenizer</code>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>SpeechToText uses the <code>eos_token_id</code> as the starting token for <code>decoder_input_ids</code> generation. If
<code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).`,name:"decoder_input_ids"},{anchor:"transformers.TFWhisperModel.call.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default.</p>
<p>If you want to change padding behavior, you should read
<code>modeling_whisper._prepare_decoder_attention_mask</code> and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the
paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.TFWhisperModel.call.head_mask",description:`<strong>head_mask</strong> (<code>tf.Tensor</code> of shape <code>(encoder_layers, encoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the encoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.TFWhisperModel.call.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>tf.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.TFWhisperModel.call.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>tf.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.TFWhisperModel.call.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>tuple(tuple(tf.Tensor)</code>, <em>optional</em>) &#x2014;
Tuple consists of (<code>last_hidden_state</code>, <em>optional</em>: <code>hidden_states</code>, <em>optional</em>: <code>attentions</code>)
<code>last_hidden_state</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) is a sequence of
hidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.`,name:"encoder_outputs"},{anchor:"transformers.TFWhisperModel.call.past_key_values",description:`<strong>past_key_values</strong> (<code>tuple(tuple(tf.Tensor))</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) &#x2014;
Tuple of <code>tuple(tf.Tensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of shape
<code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>) and 2 additional tensors of shape
<code>(batch_size, num_heads, encoder_sequence_length, embed_size_per_head)</code>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>decoder_input_ids</code> (those that
don&#x2019;t have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all
<code>decoder_input_ids</code> of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.TFWhisperModel.call.decoder_inputs_embeds",description:`<strong>decoder_inputs_embeds</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>decoder_input_ids</code> you can choose to directly pass an embedded
representation. If <code>past_key_values</code> is used, optionally only the last <code>decoder_inputs_embeds</code> have to be
input (see <code>past_key_values</code>). This is useful if you want more control over how to convert
<code>decoder_input_ids</code> indices into associated vectors than the model&#x2019;s internal embedding lookup matrix.`,name:"decoder_inputs_embeds"},{anchor:"transformers.TFWhisperModel.call.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.TFWhisperModel.call.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.TFWhisperModel.call.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.TFWhisperModel.call.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_tf_whisper.py#L1253",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_tf_outputs.TFSeq2SeqModelOutput"
>transformers.modeling_tf_outputs.TFSeq2SeqModelOutput</a> or a tuple of <code>tf.Tensor</code> (if
<code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various elements depending on the
configuration (<a
  href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig"
>WhisperConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the decoder of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>List[tf.Tensor]</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — List of <code>tf.Tensor</code> of length <code>config.n_layers</code>, with each tensor of shape <code>(2, batch_size, num_heads, sequence_length, embed_size_per_head)</code>).</p>
<p>Contains pre-computed hidden-states (key and values in the attention blocks) of the decoder that can be
used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>tf.Tensor</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>tf.Tensor</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_tf_outputs.TFSeq2SeqModelOutput"
>transformers.modeling_tf_outputs.TFSeq2SeqModelOutput</a> or <code>tuple(tf.Tensor)</code></p>
`}}),Xe=new he({props:{$$slots:{default:[qi]},$$scope:{ctx:v}}}),Re=new ne({props:{anchor:"transformers.TFWhisperModel.call.example",$$slots:{default:[Ji]},$$scope:{ctx:v}}}),to=new Z({props:{title:"TFWhisperForConditionalGeneration",local:"tfwhisperforconditionalgeneration ][ transformers.TFWhisperForConditionalGeneration",headingTag:"h2"}}),oo=new $({props:{name:"class transformers.TFWhisperForConditionalGeneration",anchor:"transformers.TFWhisperForConditionalGeneration",parameters:[{name:"config",val:": WhisperConfig"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.TFWhisperForConditionalGeneration.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig">WhisperConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_tf_whisper.py#L1341"}}),no=new $({props:{name:"call",anchor:"transformers.TFWhisperForConditionalGeneration.call",parameters:[{name:"input_features",val:": TFModelInputType | None = None"},{name:"decoder_input_ids",val:": np.ndarray | tf.Tensor | None = None"},{name:"decoder_attention_mask",val:": np.ndarray | tf.Tensor | None = None"},{name:"decoder_position_ids",val:": np.ndarray | tf.Tensor | None = None"},{name:"head_mask",val:": np.ndarray | tf.Tensor | None = None"},{name:"decoder_head_mask",val:": np.ndarray | tf.Tensor | None = None"},{name:"cross_attn_head_mask",val:": np.ndarray | tf.Tensor | None = None"},{name:"encoder_outputs",val:": Optional[Tuple[Tuple[Union[np.ndarray, tf.Tensor]]]] = None"},{name:"past_key_values",val:": Optional[Tuple[Tuple[Union[np.ndarray, tf.Tensor]]]] = None"},{name:"decoder_inputs_embeds",val:": Optional[Tuple[Union[np.ndarray, tf.Tensor]]] = None"},{name:"labels",val:": np.ndarray | tf.Tensor | None = None"},{name:"use_cache",val:": Optional[bool] = None"},{name:"output_attentions",val:": Optional[bool] = None"},{name:"output_hidden_states",val:": Optional[bool] = None"},{name:"return_dict",val:": Optional[bool] = None"},{name:"training",val:": bool = False"}],parametersDescription:[{anchor:"transformers.TFWhisperForConditionalGeneration.call.input_features",description:`<strong>input_features</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, feature_size, sequence_length)</code>) &#x2014;
Float values of fbank features extracted from the raw speech waveform. Raw speech waveform can be obtained
by loading a <code>.flac</code> or <code>.wav</code> audio file into an array of type <code>List[float]</code> or a <code>numpy.ndarray</code>, <em>e.g.</em>
via the soundfile library (<code>pip install soundfile</code>). To prepare the array into <code>input_features</code>, the
<a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoFeatureExtractor">AutoFeatureExtractor</a> should be used for extracting the fbank features, padding and conversion into a
tensor of type <code>tf.Tensor</code>. See <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a>`,name:"input_features"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <code>SpeechToTextTokenizer</code>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>SpeechToText uses the <code>eos_token_id</code> as the starting token for <code>decoder_input_ids</code> generation. If
<code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).`,name:"decoder_input_ids"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default.</p>
<p>If you want to change padding behavior, you should read
<code>modeling_whisper._prepare_decoder_attention_mask</code> and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the
paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.head_mask",description:`<strong>head_mask</strong> (<code>tf.Tensor</code> of shape <code>(encoder_layers, encoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the encoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>tf.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>tf.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>tuple(tuple(tf.Tensor)</code>, <em>optional</em>) &#x2014;
Tuple consists of (<code>last_hidden_state</code>, <em>optional</em>: <code>hidden_states</code>, <em>optional</em>: <code>attentions</code>)
<code>last_hidden_state</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) is a sequence of
hidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.`,name:"encoder_outputs"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.past_key_values",description:`<strong>past_key_values</strong> (<code>tuple(tuple(tf.Tensor))</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) &#x2014;
Tuple of <code>tuple(tf.Tensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of shape
<code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>) and 2 additional tensors of shape
<code>(batch_size, num_heads, encoder_sequence_length, embed_size_per_head)</code>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>decoder_input_ids</code> (those that
don&#x2019;t have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all
<code>decoder_input_ids</code> of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.decoder_inputs_embeds",description:`<strong>decoder_inputs_embeds</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>decoder_input_ids</code> you can choose to directly pass an embedded
representation. If <code>past_key_values</code> is used, optionally only the last <code>decoder_inputs_embeds</code> have to be
input (see <code>past_key_values</code>). This is useful if you want more control over how to convert
<code>decoder_input_ids</code> indices into associated vectors than the model&#x2019;s internal embedding lookup matrix.`,name:"decoder_inputs_embeds"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.TFWhisperForConditionalGeneration.call.labels",description:`<strong>labels</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code>
or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored (masked), the loss is
only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_tf_whisper.py#L1376",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_tf_outputs.TFSeq2SeqLMOutput"
>transformers.modeling_tf_outputs.TFSeq2SeqLMOutput</a> or a tuple of <code>tf.Tensor</code> (if
<code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various elements depending on the
configuration (<a
  href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig"
>WhisperConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>tf.Tensor</code> of shape <code>(n,)</code>, <em>optional</em>, where n is the number of non-masked labels, returned when <code>labels</code> is provided) — Language modeling loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>List[tf.Tensor]</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — List of <code>tf.Tensor</code> of length <code>config.n_layers</code>, with each tensor of shape <code>(2, batch_size, num_heads, sequence_length, embed_size_per_head)</code>).</p>
<p>Contains pre-computed hidden-states (key and values in the attention blocks) of the decoder that can be
used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>tf.Tensor</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>tf.Tensor</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_tf_outputs.TFSeq2SeqLMOutput"
>transformers.modeling_tf_outputs.TFSeq2SeqLMOutput</a> or <code>tuple(tf.Tensor)</code></p>
`}}),Le=new he({props:{$$slots:{default:[Ii]},$$scope:{ctx:v}}}),Ve=new ne({props:{anchor:"transformers.TFWhisperForConditionalGeneration.call.example",$$slots:{default:[Gi]},$$scope:{ctx:v}}}),so=new Z({props:{title:"FlaxWhisperModel",local:"flaxwhispermodel ][ transformers.FlaxWhisperModel",headingTag:"h2"}}),ao=new $({props:{name:"class transformers.FlaxWhisperModel",anchor:"transformers.FlaxWhisperModel",parameters:[{name:"config",val:": WhisperConfig"},{name:"input_shape",val:": typing.Optional[typing.Tuple[int]] = None"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"gradient_checkpointing",val:": bool = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxWhisperModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig">WhisperConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxWhisperModel.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code> (on GPUs) and
<code>jax.numpy.bfloat16</code> (on TPUs). This can be used to enable mixed-precision training or half-precision
inference on GPUs or TPUs. If specified all the computation will be performed with the given <code>dtype</code>.
<strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong> If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a>
and <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_flax_whisper.py#L1185"}}),ro=new $({props:{name:"__call__",anchor:"transformers.FlaxWhisperModel.__call__",parameters:[{name:"input_features",val:": Array"},{name:"decoder_input_ids",val:": Array"},{name:"attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"decoder_attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"position_ids",val:": typing.Optional[jax.Array] = None"},{name:"decoder_position_ids",val:": typing.Optional[jax.Array] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"train",val:": bool = False"},{name:"params",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"}],parametersDescription:[{anchor:"transformers.FlaxWhisperModel.__call__.input_features",description:`<strong>input_features</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, feature_size, sequence_length)</code>) &#x2014;
Float values mel features extracted from the raw speech waveform. Raw speech waveform can be obtained by
loading a <code>.flac</code> or <code>.wav</code> audio file into an array of type <code>List[float]</code> or a <code>numpy.ndarray</code>, <em>e.g.</em> via
the soundfile library (<code>pip install soundfile</code>). To prepare the array into <code>input_features</code>, the
<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor">WhisperFeatureExtractor</a> should be used for extracting the features, padding and conversion into a
tensor of type <code>numpy.ndarray</code>. See <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a>`,name:"input_features"},{anchor:"transformers.FlaxWhisperModel.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Whisper does not support masking of the <code>input_features</code>, this argument is preserved for compatibility, but
is not used. By default the silence in the input log mel spectrogram are ignored.`,name:"attention_mask"},{anchor:"transformers.FlaxWhisperModel.__call__.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary. Indices can be obtained using
<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperTokenizer">WhisperTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.
<a href="../glossary#decoder-input-ids">What are decoder input IDs?</a> Whisper uses the <code>decoder_start_token_id</code> as
the starting token for <code>decoder_input_ids</code> generation.`,name:"decoder_input_ids"},{anchor:"transformers.FlaxWhisperModel.__call__.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default. If you want to change padding behavior, you should modify to your needs. See diagram 1
in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.FlaxWhisperModel.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Whisper does not use <code>position_ids</code> in the encoder as <code>input_features</code> is always the same size and doesn&#x2019;t
use masking, but this argument is preserved for compatibility. By default the silence in the input log mel
spectrogram are ignored.`,name:"position_ids"},{anchor:"transformers.FlaxWhisperModel.__call__.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each decoder input sequence tokens in the position embeddings. Selected in the
range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"decoder_position_ids"},{anchor:"transformers.FlaxWhisperModel.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxWhisperModel.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxWhisperModel.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_flax_whisper.py#L1134",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSeq2SeqModelOutput"
>transformers.modeling_flax_outputs.FlaxSeq2SeqModelOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig"
>WhisperConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the decoder of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>tuple(tuple(jnp.ndarray))</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — Tuple of <code>tuple(jnp.ndarray)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of shape
<code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>) and 2 additional tensors of shape
<code>(batch_size, num_heads, encoder_sequence_length, embed_size_per_head)</code>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSeq2SeqModelOutput"
>transformers.modeling_flax_outputs.FlaxSeq2SeqModelOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Ee=new he({props:{$$slots:{default:[Ui]},$$scope:{ctx:v}}}),He=new ne({props:{anchor:"transformers.FlaxWhisperModel.__call__.example",$$slots:{default:[Ni]},$$scope:{ctx:v}}}),io=new Z({props:{title:"FlaxWhisperForConditionalGeneration",local:"flaxwhisperforconditionalgeneration ][ transformers.FlaxWhisperForConditionalGeneration",headingTag:"h2"}}),lo=new $({props:{name:"class transformers.FlaxWhisperForConditionalGeneration",anchor:"transformers.FlaxWhisperForConditionalGeneration",parameters:[{name:"config",val:": WhisperConfig"},{name:"input_shape",val:": typing.Optional[typing.Tuple[int]] = None"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"gradient_checkpointing",val:": bool = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxWhisperForConditionalGeneration.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig">WhisperConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code> (on GPUs) and
<code>jax.numpy.bfloat16</code> (on TPUs). This can be used to enable mixed-precision training or half-precision
inference on GPUs or TPUs. If specified all the computation will be performed with the given <code>dtype</code>.
<strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong> If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a>
and <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_flax_whisper.py#L1267"}}),co=new $({props:{name:"__call__",anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__",parameters:[{name:"input_features",val:": Array"},{name:"decoder_input_ids",val:": Array"},{name:"attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"decoder_attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"position_ids",val:": typing.Optional[jax.Array] = None"},{name:"decoder_position_ids",val:": typing.Optional[jax.Array] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"train",val:": bool = False"},{name:"params",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"}],parametersDescription:[{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.input_features",description:`<strong>input_features</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, feature_size, sequence_length)</code>) &#x2014;
Float values mel features extracted from the raw speech waveform. Raw speech waveform can be obtained by
loading a <code>.flac</code> or <code>.wav</code> audio file into an array of type <code>List[float]</code> or a <code>numpy.ndarray</code>, <em>e.g.</em> via
the soundfile library (<code>pip install soundfile</code>). To prepare the array into <code>input_features</code>, the
<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor">WhisperFeatureExtractor</a> should be used for extracting the features, padding and conversion into a
tensor of type <code>numpy.ndarray</code>. See <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a>`,name:"input_features"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Whisper does not support masking of the <code>input_features</code>, this argument is preserved for compatibility, but
is not used. By default the silence in the input log mel spectrogram are ignored.`,name:"attention_mask"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary. Indices can be obtained using
<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperTokenizer">WhisperTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.
<a href="../glossary#decoder-input-ids">What are decoder input IDs?</a> Whisper uses the <code>decoder_start_token_id</code> as
the starting token for <code>decoder_input_ids</code> generation.`,name:"decoder_input_ids"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default. If you want to change padding behavior, you should modify to your needs. See diagram 1
in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Whisper does not use <code>position_ids</code> in the encoder as <code>input_features</code> is always the same size and doesn&#x2019;t
use masking, but this argument is preserved for compatibility. By default the silence in the input log mel
spectrogram are ignored.`,name:"position_ids"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each decoder input sequence tokens in the position embeddings. Selected in the
range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"decoder_position_ids"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_flax_whisper.py#L1134",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSeq2SeqLMOutput"
>transformers.modeling_flax_outputs.FlaxSeq2SeqLMOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig"
>WhisperConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>logits</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>tuple(tuple(jnp.ndarray))</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — Tuple of <code>tuple(jnp.ndarray)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of shape
<code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>) and 2 additional tensors of shape
<code>(batch_size, num_heads, encoder_sequence_length, embed_size_per_head)</code>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSeq2SeqLMOutput"
>transformers.modeling_flax_outputs.FlaxSeq2SeqLMOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Pe=new he({props:{$$slots:{default:[Zi]},$$scope:{ctx:v}}}),Be=new ne({props:{anchor:"transformers.FlaxWhisperForConditionalGeneration.__call__.example",$$slots:{default:[Xi]},$$scope:{ctx:v}}}),po=new Z({props:{title:"FlaxWhisperForAudioClassification",local:"flaxwhisperforaudioclassification ][ transformers.FlaxWhisperForAudioClassification",headingTag:"h2"}}),ho=new $({props:{name:"class transformers.FlaxWhisperForAudioClassification",anchor:"transformers.FlaxWhisperForAudioClassification",parameters:[{name:"config",val:": WhisperConfig"},{name:"input_shape",val:": typing.Optional[typing.Tuple[int]] = None"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"gradient_checkpointing",val:": bool = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxWhisperForAudioClassification.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig">WhisperConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxWhisperForAudioClassification.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code> (on GPUs) and
<code>jax.numpy.bfloat16</code> (on TPUs). This can be used to enable mixed-precision training or half-precision
inference on GPUs or TPUs. If specified all the computation will be performed with the given <code>dtype</code>.
<strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong> If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a>
and <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_flax_whisper.py#L1597"}}),mo=new $({props:{name:"__call__",anchor:"transformers.FlaxWhisperForAudioClassification.__call__",parameters:[{name:"input_features",val:": Array"},{name:"attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"train",val:": bool = False"},{name:"params",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.input_features",description:`<strong>input_features</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, feature_size, sequence_length)</code>) &#x2014;
Float values mel features extracted from the raw speech waveform. Raw speech waveform can be obtained by
loading a <code>.flac</code> or <code>.wav</code> audio file into an array of type <code>List[float]</code> or a <code>numpy.ndarray</code>, <em>e.g.</em> via
the soundfile library (<code>pip install soundfile</code>). To prepare the array into <code>input_features</code>, the
<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor">WhisperFeatureExtractor</a> should be used for extracting the features, padding and conversion into a
tensor of type <code>numpy.ndarray</code>. See <a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperFeatureExtractor.__call__"><strong>call</strong>()</a>`,name:"input_features"},{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Whisper does not support masking of the <code>input_features</code>, this argument is preserved for compatibility, but
is not used. By default the silence in the input log mel spectrogram are ignored.`,name:"attention_mask"},{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary. Indices can be obtained using
<a href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperTokenizer">WhisperTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.
<a href="../glossary#decoder-input-ids">What are decoder input IDs?</a> Whisper uses the <code>decoder_start_token_id</code> as
the starting token for <code>decoder_input_ids</code> generation.`,name:"decoder_input_ids"},{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default. If you want to change padding behavior, you should modify to your needs. See diagram 1
in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Whisper does not use <code>position_ids</code> in the encoder as <code>input_features</code> is always the same size and doesn&#x2019;t
use masking, but this argument is preserved for compatibility. By default the silence in the input log mel
spectrogram are ignored.`,name:"position_ids"},{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each decoder input sequence tokens in the position embeddings. Selected in the
range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"decoder_position_ids"},{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/whisper/modeling_flax_whisper.py#L1625",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSequenceClassifierOutput"
>transformers.modeling_flax_outputs.FlaxSequenceClassifierOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/whisper#transformers.WhisperConfig"
>WhisperConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>logits</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, config.num_labels)</code>) — Classification (or regression if config.num_labels==1) scores (before SoftMax).</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSequenceClassifierOutput"
>transformers.modeling_flax_outputs.FlaxSequenceClassifierOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Se=new he({props:{$$slots:{default:[Ri]},$$scope:{ctx:v}}}),Ae=new ne({props:{anchor:"transformers.FlaxWhisperForAudioClassification.__call__.example",$$slots:{default:[Li]},$$scope:{ctx:v}}}),uo=new ki({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/whisper.md"}}),{c(){o=d("meta"),k=s(),c=d("p"),p=s(),m(T.$$.fragment),n=s(),m(w.$$.fragment),Cn=s(),dt=d("p"),dt.innerHTML=ir,jn=s(),lt=d("p"),lt.textContent=dr,qn=s(),ct=d("p"),ct.innerHTML=lr,Jn=s(),pt=d("p"),pt.textContent=cr,In=s(),ht=d("ul"),ht.innerHTML=pr,Gn=s(),m(mt.$$.fragment),Un=s(),ut=d("p"),ut.innerHTML=hr,Nn=s(),ft=d("p"),ft.innerHTML=mr,Zn=s(),m(gt.$$.fragment),Xn=s(),X=d("div"),m(_t.$$.fragment),us=s(),vo=d("p"),vo.innerHTML=ur,fs=s(),xo=d("p"),xo.innerHTML=fr,gs=s(),m(be.$$.fragment),Rn=s(),m(yt.$$.fragment),Ln=s(),W=d("div"),m(bt.$$.fragment),_s=s(),Mo=d("p"),Mo.textContent=gr,ys=s(),$o=d("p"),$o.innerHTML=_r,bs=s(),se=d("div"),m(kt.$$.fragment),ks=s(),Wo=d("p"),Wo.textContent=yr,Ts=s(),m(ke.$$.fragment),ws=s(),Te=d("div"),m(Tt.$$.fragment),vs=s(),Fo=d("p"),Fo.textContent=br,xs=s(),we=d("div"),m(wt.$$.fragment),Ms=s(),zo=d("p"),zo.innerHTML=kr,$s=s(),ae=d("div"),m(vt.$$.fragment),Ws=s(),Co=d("p"),Co.innerHTML=Tr,Fs=s(),jo=d("p"),jo.textContent=wr,zs=s(),qo=d("div"),m(xt.$$.fragment),Vn=s(),m(Mt.$$.fragment),En=s(),F=d("div"),m($t.$$.fragment),Cs=s(),Jo=d("p"),Jo.innerHTML=vr,js=s(),Io=d("p"),Io.innerHTML=xr,qs=s(),re=d("div"),m(Wt.$$.fragment),Js=s(),Go=d("p"),Go.textContent=Mr,Is=s(),m(ve.$$.fragment),Gs=s(),xe=d("div"),m(Ft.$$.fragment),Us=s(),Uo=d("p"),Uo.textContent=$r,Ns=s(),Me=d("div"),m(zt.$$.fragment),Zs=s(),No=d("p"),No.innerHTML=Wr,Xs=s(),ie=d("div"),m(Ct.$$.fragment),Rs=s(),Zo=d("p"),Zo.innerHTML=Fr,Ls=s(),Xo=d("p"),Xo.textContent=zr,Vs=s(),Ro=d("div"),m(jt.$$.fragment),Hn=s(),m(qt.$$.fragment),Pn=s(),G=d("div"),m(Jt.$$.fragment),Es=s(),Lo=d("p"),Lo.textContent=Cr,Hs=s(),Vo=d("p"),Vo.innerHTML=jr,Ps=s(),Eo=d("p"),Eo.innerHTML=qr,Bs=s(),$e=d("div"),m(It.$$.fragment),Ss=s(),Ho=d("p"),Ho.textContent=Jr,Bn=s(),m(Gt.$$.fragment),Sn=s(),z=d("div"),m(Ut.$$.fragment),As=s(),Po=d("p"),Po.textContent=Ir,Ys=s(),Bo=d("p"),Bo.innerHTML=Gr,Ds=s(),We=d("div"),m(Nt.$$.fragment),Os=s(),So=d("p"),So.innerHTML=Ur,Qs=s(),de=d("div"),m(Zt.$$.fragment),Ks=s(),Ao=d("p"),Ao.textContent=Nr,ea=s(),m(Fe.$$.fragment),ta=s(),le=d("div"),m(Xt.$$.fragment),oa=s(),Yo=d("p"),Yo.innerHTML=Zr,na=s(),m(ze.$$.fragment),sa=s(),Ce=d("div"),m(Rt.$$.fragment),aa=s(),Do=d("p"),Do.innerHTML=Xr,ra=s(),je=d("div"),m(Lt.$$.fragment),ia=s(),Oo=d("p"),Oo.innerHTML=Rr,An=s(),m(Vt.$$.fragment),Yn=s(),I=d("div"),m(Et.$$.fragment),da=s(),Qo=d("p"),Qo.textContent=Lr,la=s(),Ko=d("p"),Ko.innerHTML=Vr,ca=s(),en=d("p"),en.innerHTML=Er,pa=s(),B=d("div"),m(Ht.$$.fragment),ha=s(),tn=d("p"),tn.innerHTML=Hr,ma=s(),m(qe.$$.fragment),ua=s(),m(Je.$$.fragment),fa=s(),Ie=d("div"),m(Pt.$$.fragment),ga=s(),on=d("p"),on.innerHTML=Pr,Dn=s(),m(Bt.$$.fragment),On=s(),U=d("div"),m(St.$$.fragment),_a=s(),nn=d("p"),nn.textContent=Br,ya=s(),sn=d("p"),sn.innerHTML=Sr,ba=s(),an=d("p"),an.innerHTML=Ar,ka=s(),S=d("div"),m(At.$$.fragment),Ta=s(),rn=d("p"),rn.innerHTML=Yr,wa=s(),m(Ge.$$.fragment),va=s(),m(Ue.$$.fragment),Qn=s(),m(Yt.$$.fragment),Kn=s(),N=d("div"),m(Dt.$$.fragment),xa=s(),dn=d("p"),dn.textContent=Dr,Ma=s(),ln=d("p"),ln.innerHTML=Or,$a=s(),cn=d("p"),cn.innerHTML=Qr,Wa=s(),A=d("div"),m(Ot.$$.fragment),Fa=s(),pn=d("p"),pn.innerHTML=Kr,za=s(),m(Ne.$$.fragment),Ca=s(),m(Ze.$$.fragment),es=s(),m(Qt.$$.fragment),ts=s(),R=d("div"),m(Kt.$$.fragment),ja=s(),hn=d("p"),hn.innerHTML=ei,qa=s(),mn=d("p"),mn.innerHTML=ti,Ja=s(),Y=d("div"),m(eo.$$.fragment),Ia=s(),un=d("p"),un.innerHTML=oi,Ga=s(),m(Xe.$$.fragment),Ua=s(),m(Re.$$.fragment),os=s(),m(to.$$.fragment),ns=s(),L=d("div"),m(oo.$$.fragment),Na=s(),fn=d("p"),fn.innerHTML=ni,Za=s(),gn=d("p"),gn.innerHTML=si,Xa=s(),D=d("div"),m(no.$$.fragment),Ra=s(),_n=d("p"),_n.innerHTML=ai,La=s(),m(Le.$$.fragment),Va=s(),m(Ve.$$.fragment),ss=s(),m(so.$$.fragment),as=s(),V=d("div"),m(ao.$$.fragment),Ea=s(),yn=d("p"),yn.innerHTML=ri,Ha=s(),bn=d("ul"),bn.innerHTML=ii,Pa=s(),O=d("div"),m(ro.$$.fragment),Ba=s(),kn=d("p"),kn.innerHTML=di,Sa=s(),m(Ee.$$.fragment),Aa=s(),m(He.$$.fragment),rs=s(),m(io.$$.fragment),is=s(),E=d("div"),m(lo.$$.fragment),Ya=s(),Tn=d("p"),Tn.innerHTML=li,Da=s(),wn=d("ul"),wn.innerHTML=ci,Oa=s(),Q=d("div"),m(co.$$.fragment),Qa=s(),vn=d("p"),vn.innerHTML=pi,Ka=s(),m(Pe.$$.fragment),er=s(),m(Be.$$.fragment),ds=s(),m(po.$$.fragment),ls=s(),H=d("div"),m(ho.$$.fragment),tr=s(),xn=d("p"),xn.innerHTML=hi,or=s(),Mn=d("ul"),Mn.innerHTML=mi,nr=s(),K=d("div"),m(mo.$$.fragment),sr=s(),$n=d("p"),$n.innerHTML=ui,ar=s(),m(Se.$$.fragment),rr=s(),m(Ae.$$.fragment),cs=s(),m(uo.$$.fragment),ps=s(),Wn=d("p"),this.h()},l(e){const i=bi("svelte-u9bgzb",document.head);o=l(i,"META",{name:!0,content:!0}),i.forEach(r),k=a(e),c=l(e,"P",{}),x(c).forEach(r),p=a(e),u(T.$$.fragment,e),n=a(e),u(w.$$.fragment,e),Cn=a(e),dt=l(e,"P",{"data-svelte-h":!0}),b(dt)!=="svelte-jbylng"&&(dt.innerHTML=ir),jn=a(e),lt=l(e,"P",{"data-svelte-h":!0}),b(lt)!=="svelte-e5r8wp"&&(lt.textContent=dr),qn=a(e),ct=l(e,"P",{"data-svelte-h":!0}),b(ct)!=="svelte-miykgl"&&(ct.innerHTML=lr),Jn=a(e),pt=l(e,"P",{"data-svelte-h":!0}),b(pt)!=="svelte-k6v9m1"&&(pt.textContent=cr),In=a(e),ht=l(e,"UL",{"data-svelte-h":!0}),b(ht)!=="svelte-1uxmc8e"&&(ht.innerHTML=pr),Gn=a(e),u(mt.$$.fragment,e),Un=a(e),ut=l(e,"P",{"data-svelte-h":!0}),b(ut)!=="svelte-13fvt52"&&(ut.innerHTML=hr),Nn=a(e),ft=l(e,"P",{"data-svelte-h":!0}),b(ft)!=="svelte-x8w7b0"&&(ft.innerHTML=mr),Zn=a(e),u(gt.$$.fragment,e),Xn=a(e),X=l(e,"DIV",{class:!0});var oe=x(X);u(_t.$$.fragment,oe),us=a(oe),vo=l(oe,"P",{"data-svelte-h":!0}),b(vo)!=="svelte-1vvndk6"&&(vo.innerHTML=ur),fs=a(oe),xo=l(oe,"P",{"data-svelte-h":!0}),b(xo)!=="svelte-qr3t5r"&&(xo.innerHTML=fr),gs=a(oe),u(be.$$.fragment,oe),oe.forEach(r),Rn=a(e),u(yt.$$.fragment,e),Ln=a(e),W=l(e,"DIV",{class:!0});var j=x(W);u(bt.$$.fragment,j),_s=a(j),Mo=l(j,"P",{"data-svelte-h":!0}),b(Mo)!=="svelte-1996rkv"&&(Mo.textContent=gr),ys=a(j),$o=l(j,"P",{"data-svelte-h":!0}),b($o)!=="svelte-xbd6w0"&&($o.innerHTML=_r),bs=a(j),se=l(j,"DIV",{class:!0});var me=x(se);u(kt.$$.fragment,me),ks=a(me),Wo=l(me,"P",{"data-svelte-h":!0}),b(Wo)!=="svelte-8in46s"&&(Wo.textContent=yr),Ts=a(me),u(ke.$$.fragment,me),me.forEach(r),ws=a(j),Te=l(j,"DIV",{class:!0});var fo=x(Te);u(Tt.$$.fragment,fo),vs=a(fo),Fo=l(fo,"P",{"data-svelte-h":!0}),b(Fo)!=="svelte-wv4s2m"&&(Fo.textContent=br),fo.forEach(r),xs=a(j),we=l(j,"DIV",{class:!0});var go=x(we);u(wt.$$.fragment,go),Ms=a(go),zo=l(go,"P",{"data-svelte-h":!0}),b(zo)!=="svelte-1f4f5kp"&&(zo.innerHTML=kr),go.forEach(r),$s=a(j),ae=l(j,"DIV",{class:!0});var ue=x(ae);u(vt.$$.fragment,ue),Ws=a(ue),Co=l(ue,"P",{"data-svelte-h":!0}),b(Co)!=="svelte-zj1vf1"&&(Co.innerHTML=Tr),Fs=a(ue),jo=l(ue,"P",{"data-svelte-h":!0}),b(jo)!=="svelte-9vptpw"&&(jo.textContent=wr),ue.forEach(r),zs=a(j),qo=l(j,"DIV",{class:!0});var Fn=x(qo);u(xt.$$.fragment,Fn),Fn.forEach(r),j.forEach(r),Vn=a(e),u(Mt.$$.fragment,e),En=a(e),F=l(e,"DIV",{class:!0});var q=x(F);u($t.$$.fragment,q),Cs=a(q),Jo=l(q,"P",{"data-svelte-h":!0}),b(Jo)!=="svelte-14ct2lo"&&(Jo.innerHTML=vr),js=a(q),Io=l(q,"P",{"data-svelte-h":!0}),b(Io)!=="svelte-1ndfe3e"&&(Io.innerHTML=xr),qs=a(q),re=l(q,"DIV",{class:!0});var fe=x(re);u(Wt.$$.fragment,fe),Js=a(fe),Go=l(fe,"P",{"data-svelte-h":!0}),b(Go)!=="svelte-8in46s"&&(Go.textContent=Mr),Is=a(fe),u(ve.$$.fragment,fe),fe.forEach(r),Gs=a(q),xe=l(q,"DIV",{class:!0});var _o=x(xe);u(Ft.$$.fragment,_o),Us=a(_o),Uo=l(_o,"P",{"data-svelte-h":!0}),b(Uo)!=="svelte-wv4s2m"&&(Uo.textContent=$r),_o.forEach(r),Ns=a(q),Me=l(q,"DIV",{class:!0});var yo=x(Me);u(zt.$$.fragment,yo),Zs=a(yo),No=l(yo,"P",{"data-svelte-h":!0}),b(No)!=="svelte-1f4f5kp"&&(No.innerHTML=Wr),yo.forEach(r),Xs=a(q),ie=l(q,"DIV",{class:!0});var ge=x(ie);u(Ct.$$.fragment,ge),Rs=a(ge),Zo=l(ge,"P",{"data-svelte-h":!0}),b(Zo)!=="svelte-zj1vf1"&&(Zo.innerHTML=Fr),Ls=a(ge),Xo=l(ge,"P",{"data-svelte-h":!0}),b(Xo)!=="svelte-9vptpw"&&(Xo.textContent=zr),ge.forEach(r),Vs=a(q),Ro=l(q,"DIV",{class:!0});var zn=x(Ro);u(jt.$$.fragment,zn),zn.forEach(r),q.forEach(r),Hn=a(e),u(qt.$$.fragment,e),Pn=a(e),G=l(e,"DIV",{class:!0});var P=x(G);u(Jt.$$.fragment,P),Es=a(P),Lo=l(P,"P",{"data-svelte-h":!0}),b(Lo)!=="svelte-1xbhurt"&&(Lo.textContent=Cr),Hs=a(P),Vo=l(P,"P",{"data-svelte-h":!0}),b(Vo)!=="svelte-1oxm5u"&&(Vo.innerHTML=jr),Ps=a(P),Eo=l(P,"P",{"data-svelte-h":!0}),b(Eo)!=="svelte-1lv9ra7"&&(Eo.innerHTML=qr),Bs=a(P),$e=l(P,"DIV",{class:!0});var bo=x($e);u(It.$$.fragment,bo),Ss=a(bo),Ho=l(bo,"P",{"data-svelte-h":!0}),b(Ho)!=="svelte-1o1r06v"&&(Ho.textContent=Jr),bo.forEach(r),P.forEach(r),Bn=a(e),u(Gt.$$.fragment,e),Sn=a(e),z=l(e,"DIV",{class:!0});var J=x(z);u(Ut.$$.fragment,J),As=a(J),Po=l(J,"P",{"data-svelte-h":!0}),b(Po)!=="svelte-1g1myb6"&&(Po.textContent=Ir),Ys=a(J),Bo=l(J,"P",{"data-svelte-h":!0}),b(Bo)!=="svelte-tjn15i"&&(Bo.innerHTML=Gr),Ds=a(J),We=l(J,"DIV",{class:!0});var ko=x(We);u(Nt.$$.fragment,ko),Os=a(ko),So=l(ko,"P",{"data-svelte-h":!0}),b(So)!=="svelte-ghg8ys"&&(So.innerHTML=Ur),ko.forEach(r),Qs=a(J),de=l(J,"DIV",{class:!0});var _e=x(de);u(Zt.$$.fragment,_e),Ks=a(_e),Ao=l(_e,"P",{"data-svelte-h":!0}),b(Ao)!=="svelte-1cj8dcb"&&(Ao.textContent=Nr),ea=a(_e),u(Fe.$$.fragment,_e),_e.forEach(r),ta=a(J),le=l(J,"DIV",{class:!0});var ye=x(le);u(Xt.$$.fragment,ye),oa=a(ye),Yo=l(ye,"P",{"data-svelte-h":!0}),b(Yo)!=="svelte-fb31l0"&&(Yo.innerHTML=Zr),na=a(ye),u(ze.$$.fragment,ye),ye.forEach(r),sa=a(J),Ce=l(J,"DIV",{class:!0});var To=x(Ce);u(Rt.$$.fragment,To),aa=a(To),Do=l(To,"P",{"data-svelte-h":!0}),b(Do)!=="svelte-iix7ho"&&(Do.innerHTML=Xr),To.forEach(r),ra=a(J),je=l(J,"DIV",{class:!0});var wo=x(je);u(Lt.$$.fragment,wo),ia=a(wo),Oo=l(wo,"P",{"data-svelte-h":!0}),b(Oo)!=="svelte-o1gufi"&&(Oo.innerHTML=Rr),wo.forEach(r),J.forEach(r),An=a(e),u(Vt.$$.fragment,e),Yn=a(e),I=l(e,"DIV",{class:!0});var ee=x(I);u(Et.$$.fragment,ee),da=a(ee),Qo=l(ee,"P",{"data-svelte-h":!0}),b(Qo)!=="svelte-1spqpl8"&&(Qo.textContent=Lr),la=a(ee),Ko=l(ee,"P",{"data-svelte-h":!0}),b(Ko)!=="svelte-u3dlub"&&(Ko.innerHTML=Vr),ca=a(ee),en=l(ee,"P",{"data-svelte-h":!0}),b(en)!=="svelte-hswkmf"&&(en.innerHTML=Er),pa=a(ee),B=l(ee,"DIV",{class:!0});var Ye=x(B);u(Ht.$$.fragment,Ye),ha=a(Ye),tn=l(Ye,"P",{"data-svelte-h":!0}),b(tn)!=="svelte-1mwet9q"&&(tn.innerHTML=Hr),ma=a(Ye),u(qe.$$.fragment,Ye),ua=a(Ye),u(Je.$$.fragment,Ye),Ye.forEach(r),fa=a(ee),Ie=l(ee,"DIV",{class:!0});var ms=x(Ie);u(Pt.$$.fragment,ms),ga=a(ms),on=l(ms,"P",{"data-svelte-h":!0}),b(on)!=="svelte-i8aa35"&&(on.innerHTML=Pr),ms.forEach(r),ee.forEach(r),Dn=a(e),u(Bt.$$.fragment,e),On=a(e),U=l(e,"DIV",{class:!0});var ce=x(U);u(St.$$.fragment,ce),_a=a(ce),nn=l(ce,"P",{"data-svelte-h":!0}),b(nn)!=="svelte-lkrgsp"&&(nn.textContent=Br),ya=a(ce),sn=l(ce,"P",{"data-svelte-h":!0}),b(sn)!=="svelte-u3dlub"&&(sn.innerHTML=Sr),ba=a(ce),an=l(ce,"P",{"data-svelte-h":!0}),b(an)!=="svelte-hswkmf"&&(an.innerHTML=Ar),ka=a(ce),S=l(ce,"DIV",{class:!0});var De=x(S);u(At.$$.fragment,De),Ta=a(De),rn=l(De,"P",{"data-svelte-h":!0}),b(rn)!=="svelte-fjrdgw"&&(rn.innerHTML=Yr),wa=a(De),u(Ge.$$.fragment,De),va=a(De),u(Ue.$$.fragment,De),De.forEach(r),ce.forEach(r),Qn=a(e),u(Yt.$$.fragment,e),Kn=a(e),N=l(e,"DIV",{class:!0});var pe=x(N);u(Dt.$$.fragment,pe),xa=a(pe),dn=l(pe,"P",{"data-svelte-h":!0}),b(dn)!=="svelte-1y2nev0"&&(dn.textContent=Dr),Ma=a(pe),ln=l(pe,"P",{"data-svelte-h":!0}),b(ln)!=="svelte-u3dlub"&&(ln.innerHTML=Or),$a=a(pe),cn=l(pe,"P",{"data-svelte-h":!0}),b(cn)!=="svelte-hswkmf"&&(cn.innerHTML=Qr),Wa=a(pe),A=l(pe,"DIV",{class:!0});var Oe=x(A);u(Ot.$$.fragment,Oe),Fa=a(Oe),pn=l(Oe,"P",{"data-svelte-h":!0}),b(pn)!=="svelte-l6rpvo"&&(pn.innerHTML=Kr),za=a(Oe),u(Ne.$$.fragment,Oe),Ca=a(Oe),u(Ze.$$.fragment,Oe),Oe.forEach(r),pe.forEach(r),es=a(e),u(Qt.$$.fragment,e),ts=a(e),R=l(e,"DIV",{class:!0});var Qe=x(R);u(Kt.$$.fragment,Qe),ja=a(Qe),hn=l(Qe,"P",{"data-svelte-h":!0}),b(hn)!=="svelte-1e2u1ch"&&(hn.innerHTML=ei),qa=a(Qe),mn=l(Qe,"P",{"data-svelte-h":!0}),b(mn)!=="svelte-1be7e3c"&&(mn.innerHTML=ti),Ja=a(Qe),Y=l(Qe,"DIV",{class:!0});var Ke=x(Y);u(eo.$$.fragment,Ke),Ia=a(Ke),un=l(Ke,"P",{"data-svelte-h":!0}),b(un)!=="svelte-az9qey"&&(un.innerHTML=oi),Ga=a(Ke),u(Xe.$$.fragment,Ke),Ua=a(Ke),u(Re.$$.fragment,Ke),Ke.forEach(r),Qe.forEach(r),os=a(e),u(to.$$.fragment,e),ns=a(e),L=l(e,"DIV",{class:!0});var et=x(L);u(oo.$$.fragment,et),Na=a(et),fn=l(et,"P",{"data-svelte-h":!0}),b(fn)!=="svelte-uvh63i"&&(fn.innerHTML=ni),Za=a(et),gn=l(et,"P",{"data-svelte-h":!0}),b(gn)!=="svelte-1be7e3c"&&(gn.innerHTML=si),Xa=a(et),D=l(et,"DIV",{class:!0});var tt=x(D);u(no.$$.fragment,tt),Ra=a(tt),_n=l(tt,"P",{"data-svelte-h":!0}),b(_n)!=="svelte-sgyxxc"&&(_n.innerHTML=ai),La=a(tt),u(Le.$$.fragment,tt),Va=a(tt),u(Ve.$$.fragment,tt),tt.forEach(r),et.forEach(r),ss=a(e),u(so.$$.fragment,e),as=a(e),V=l(e,"DIV",{class:!0});var ot=x(V);u(ao.$$.fragment,ot),Ea=a(ot),yn=l(ot,"P",{"data-svelte-h":!0}),b(yn)!=="svelte-1kdhxuo"&&(yn.innerHTML=ri),Ha=a(ot),bn=l(ot,"UL",{"data-svelte-h":!0}),b(bn)!=="svelte-1w7z84m"&&(bn.innerHTML=ii),Pa=a(ot),O=l(ot,"DIV",{class:!0});var nt=x(O);u(ro.$$.fragment,nt),Ba=a(nt),kn=l(nt,"P",{"data-svelte-h":!0}),b(kn)!=="svelte-13ych8p"&&(kn.innerHTML=di),Sa=a(nt),u(Ee.$$.fragment,nt),Aa=a(nt),u(He.$$.fragment,nt),nt.forEach(r),ot.forEach(r),rs=a(e),u(io.$$.fragment,e),is=a(e),E=l(e,"DIV",{class:!0});var st=x(E);u(lo.$$.fragment,st),Ya=a(st),Tn=l(st,"P",{"data-svelte-h":!0}),b(Tn)!=="svelte-1yyb0v1"&&(Tn.innerHTML=li),Da=a(st),wn=l(st,"UL",{"data-svelte-h":!0}),b(wn)!=="svelte-1w7z84m"&&(wn.innerHTML=ci),Oa=a(st),Q=l(st,"DIV",{class:!0});var at=x(Q);u(co.$$.fragment,at),Qa=a(at),vn=l(at,"P",{"data-svelte-h":!0}),b(vn)!=="svelte-13ych8p"&&(vn.innerHTML=pi),Ka=a(at),u(Pe.$$.fragment,at),er=a(at),u(Be.$$.fragment,at),at.forEach(r),st.forEach(r),ds=a(e),u(po.$$.fragment,e),ls=a(e),H=l(e,"DIV",{class:!0});var rt=x(H);u(ho.$$.fragment,rt),tr=a(rt),xn=l(rt,"P",{"data-svelte-h":!0}),b(xn)!=="svelte-19jj3ii"&&(xn.innerHTML=hi),or=a(rt),Mn=l(rt,"UL",{"data-svelte-h":!0}),b(Mn)!=="svelte-1w7z84m"&&(Mn.innerHTML=mi),nr=a(rt),K=l(rt,"DIV",{class:!0});var it=x(K);u(mo.$$.fragment,it),sr=a(it),$n=l(it,"P",{"data-svelte-h":!0}),b($n)!=="svelte-1namxjo"&&($n.innerHTML=ui),ar=a(it),u(Se.$$.fragment,it),rr=a(it),u(Ae.$$.fragment,it),it.forEach(r),rt.forEach(r),cs=a(e),u(uo.$$.fragment,e),ps=a(e),Wn=l(e,"P",{}),x(Wn).forEach(r),this.h()},h(){M(o,"name","hf:doc:metadata"),M(o,"content",Ei),M(X,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(se,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(Te,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(we,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(ae,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(qo,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(W,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(re,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(xe,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(Me,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(ie,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(Ro,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(F,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M($e,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(G,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(We,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(de,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(le,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(Ce,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(je,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(z,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(B,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(Ie,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(I,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(S,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(U,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(A,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(N,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(Y,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(R,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(D,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(L,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(O,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(V,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(Q,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(E,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(K,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),M(H,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,i){t(document.head,o),h(e,k,i),h(e,c,i),h(e,p,i),f(T,e,i),h(e,n,i),f(w,e,i),h(e,Cn,i),h(e,dt,i),h(e,jn,i),h(e,lt,i),h(e,qn,i),h(e,ct,i),h(e,Jn,i),h(e,pt,i),h(e,In,i),h(e,ht,i),h(e,Gn,i),f(mt,e,i),h(e,Un,i),h(e,ut,i),h(e,Nn,i),h(e,ft,i),h(e,Zn,i),f(gt,e,i),h(e,Xn,i),h(e,X,i),f(_t,X,null),t(X,us),t(X,vo),t(X,fs),t(X,xo),t(X,gs),f(be,X,null),h(e,Rn,i),f(yt,e,i),h(e,Ln,i),h(e,W,i),f(bt,W,null),t(W,_s),t(W,Mo),t(W,ys),t(W,$o),t(W,bs),t(W,se),f(kt,se,null),t(se,ks),t(se,Wo),t(se,Ts),f(ke,se,null),t(W,ws),t(W,Te),f(Tt,Te,null),t(Te,vs),t(Te,Fo),t(W,xs),t(W,we),f(wt,we,null),t(we,Ms),t(we,zo),t(W,$s),t(W,ae),f(vt,ae,null),t(ae,Ws),t(ae,Co),t(ae,Fs),t(ae,jo),t(W,zs),t(W,qo),f(xt,qo,null),h(e,Vn,i),f(Mt,e,i),h(e,En,i),h(e,F,i),f($t,F,null),t(F,Cs),t(F,Jo),t(F,js),t(F,Io),t(F,qs),t(F,re),f(Wt,re,null),t(re,Js),t(re,Go),t(re,Is),f(ve,re,null),t(F,Gs),t(F,xe),f(Ft,xe,null),t(xe,Us),t(xe,Uo),t(F,Ns),t(F,Me),f(zt,Me,null),t(Me,Zs),t(Me,No),t(F,Xs),t(F,ie),f(Ct,ie,null),t(ie,Rs),t(ie,Zo),t(ie,Ls),t(ie,Xo),t(F,Vs),t(F,Ro),f(jt,Ro,null),h(e,Hn,i),f(qt,e,i),h(e,Pn,i),h(e,G,i),f(Jt,G,null),t(G,Es),t(G,Lo),t(G,Hs),t(G,Vo),t(G,Ps),t(G,Eo),t(G,Bs),t(G,$e),f(It,$e,null),t($e,Ss),t($e,Ho),h(e,Bn,i),f(Gt,e,i),h(e,Sn,i),h(e,z,i),f(Ut,z,null),t(z,As),t(z,Po),t(z,Ys),t(z,Bo),t(z,Ds),t(z,We),f(Nt,We,null),t(We,Os),t(We,So),t(z,Qs),t(z,de),f(Zt,de,null),t(de,Ks),t(de,Ao),t(de,ea),f(Fe,de,null),t(z,ta),t(z,le),f(Xt,le,null),t(le,oa),t(le,Yo),t(le,na),f(ze,le,null),t(z,sa),t(z,Ce),f(Rt,Ce,null),t(Ce,aa),t(Ce,Do),t(z,ra),t(z,je),f(Lt,je,null),t(je,ia),t(je,Oo),h(e,An,i),f(Vt,e,i),h(e,Yn,i),h(e,I,i),f(Et,I,null),t(I,da),t(I,Qo),t(I,la),t(I,Ko),t(I,ca),t(I,en),t(I,pa),t(I,B),f(Ht,B,null),t(B,ha),t(B,tn),t(B,ma),f(qe,B,null),t(B,ua),f(Je,B,null),t(I,fa),t(I,Ie),f(Pt,Ie,null),t(Ie,ga),t(Ie,on),h(e,Dn,i),f(Bt,e,i),h(e,On,i),h(e,U,i),f(St,U,null),t(U,_a),t(U,nn),t(U,ya),t(U,sn),t(U,ba),t(U,an),t(U,ka),t(U,S),f(At,S,null),t(S,Ta),t(S,rn),t(S,wa),f(Ge,S,null),t(S,va),f(Ue,S,null),h(e,Qn,i),f(Yt,e,i),h(e,Kn,i),h(e,N,i),f(Dt,N,null),t(N,xa),t(N,dn),t(N,Ma),t(N,ln),t(N,$a),t(N,cn),t(N,Wa),t(N,A),f(Ot,A,null),t(A,Fa),t(A,pn),t(A,za),f(Ne,A,null),t(A,Ca),f(Ze,A,null),h(e,es,i),f(Qt,e,i),h(e,ts,i),h(e,R,i),f(Kt,R,null),t(R,ja),t(R,hn),t(R,qa),t(R,mn),t(R,Ja),t(R,Y),f(eo,Y,null),t(Y,Ia),t(Y,un),t(Y,Ga),f(Xe,Y,null),t(Y,Ua),f(Re,Y,null),h(e,os,i),f(to,e,i),h(e,ns,i),h(e,L,i),f(oo,L,null),t(L,Na),t(L,fn),t(L,Za),t(L,gn),t(L,Xa),t(L,D),f(no,D,null),t(D,Ra),t(D,_n),t(D,La),f(Le,D,null),t(D,Va),f(Ve,D,null),h(e,ss,i),f(so,e,i),h(e,as,i),h(e,V,i),f(ao,V,null),t(V,Ea),t(V,yn),t(V,Ha),t(V,bn),t(V,Pa),t(V,O),f(ro,O,null),t(O,Ba),t(O,kn),t(O,Sa),f(Ee,O,null),t(O,Aa),f(He,O,null),h(e,rs,i),f(io,e,i),h(e,is,i),h(e,E,i),f(lo,E,null),t(E,Ya),t(E,Tn),t(E,Da),t(E,wn),t(E,Oa),t(E,Q),f(co,Q,null),t(Q,Qa),t(Q,vn),t(Q,Ka),f(Pe,Q,null),t(Q,er),f(Be,Q,null),h(e,ds,i),f(po,e,i),h(e,ls,i),h(e,H,i),f(ho,H,null),t(H,tr),t(H,xn),t(H,or),t(H,Mn),t(H,nr),t(H,K),f(mo,K,null),t(K,sr),t(K,$n),t(K,ar),f(Se,K,null),t(K,rr),f(Ae,K,null),h(e,cs,i),f(uo,e,i),h(e,ps,i),h(e,Wn,i),hs=!0},p(e,[i]){const oe={};i&2&&(oe.$$scope={dirty:i,ctx:e}),be.$set(oe);const j={};i&2&&(j.$$scope={dirty:i,ctx:e}),ke.$set(j);const me={};i&2&&(me.$$scope={dirty:i,ctx:e}),ve.$set(me);const fo={};i&2&&(fo.$$scope={dirty:i,ctx:e}),Fe.$set(fo);const go={};i&2&&(go.$$scope={dirty:i,ctx:e}),ze.$set(go);const ue={};i&2&&(ue.$$scope={dirty:i,ctx:e}),qe.$set(ue);const Fn={};i&2&&(Fn.$$scope={dirty:i,ctx:e}),Je.$set(Fn);const q={};i&2&&(q.$$scope={dirty:i,ctx:e}),Ge.$set(q);const fe={};i&2&&(fe.$$scope={dirty:i,ctx:e}),Ue.$set(fe);const _o={};i&2&&(_o.$$scope={dirty:i,ctx:e}),Ne.$set(_o);const yo={};i&2&&(yo.$$scope={dirty:i,ctx:e}),Ze.$set(yo);const ge={};i&2&&(ge.$$scope={dirty:i,ctx:e}),Xe.$set(ge);const zn={};i&2&&(zn.$$scope={dirty:i,ctx:e}),Re.$set(zn);const P={};i&2&&(P.$$scope={dirty:i,ctx:e}),Le.$set(P);const bo={};i&2&&(bo.$$scope={dirty:i,ctx:e}),Ve.$set(bo);const J={};i&2&&(J.$$scope={dirty:i,ctx:e}),Ee.$set(J);const ko={};i&2&&(ko.$$scope={dirty:i,ctx:e}),He.$set(ko);const _e={};i&2&&(_e.$$scope={dirty:i,ctx:e}),Pe.$set(_e);const ye={};i&2&&(ye.$$scope={dirty:i,ctx:e}),Be.$set(ye);const To={};i&2&&(To.$$scope={dirty:i,ctx:e}),Se.$set(To);const wo={};i&2&&(wo.$$scope={dirty:i,ctx:e}),Ae.$set(wo)},i(e){hs||(g(T.$$.fragment,e),g(w.$$.fragment,e),g(mt.$$.fragment,e),g(gt.$$.fragment,e),g(_t.$$.fragment,e),g(be.$$.fragment,e),g(yt.$$.fragment,e),g(bt.$$.fragment,e),g(kt.$$.fragment,e),g(ke.$$.fragment,e),g(Tt.$$.fragment,e),g(wt.$$.fragment,e),g(vt.$$.fragment,e),g(xt.$$.fragment,e),g(Mt.$$.fragment,e),g($t.$$.fragment,e),g(Wt.$$.fragment,e),g(ve.$$.fragment,e),g(Ft.$$.fragment,e),g(zt.$$.fragment,e),g(Ct.$$.fragment,e),g(jt.$$.fragment,e),g(qt.$$.fragment,e),g(Jt.$$.fragment,e),g(It.$$.fragment,e),g(Gt.$$.fragment,e),g(Ut.$$.fragment,e),g(Nt.$$.fragment,e),g(Zt.$$.fragment,e),g(Fe.$$.fragment,e),g(Xt.$$.fragment,e),g(ze.$$.fragment,e),g(Rt.$$.fragment,e),g(Lt.$$.fragment,e),g(Vt.$$.fragment,e),g(Et.$$.fragment,e),g(Ht.$$.fragment,e),g(qe.$$.fragment,e),g(Je.$$.fragment,e),g(Pt.$$.fragment,e),g(Bt.$$.fragment,e),g(St.$$.fragment,e),g(At.$$.fragment,e),g(Ge.$$.fragment,e),g(Ue.$$.fragment,e),g(Yt.$$.fragment,e),g(Dt.$$.fragment,e),g(Ot.$$.fragment,e),g(Ne.$$.fragment,e),g(Ze.$$.fragment,e),g(Qt.$$.fragment,e),g(Kt.$$.fragment,e),g(eo.$$.fragment,e),g(Xe.$$.fragment,e),g(Re.$$.fragment,e),g(to.$$.fragment,e),g(oo.$$.fragment,e),g(no.$$.fragment,e),g(Le.$$.fragment,e),g(Ve.$$.fragment,e),g(so.$$.fragment,e),g(ao.$$.fragment,e),g(ro.$$.fragment,e),g(Ee.$$.fragment,e),g(He.$$.fragment,e),g(io.$$.fragment,e),g(lo.$$.fragment,e),g(co.$$.fragment,e),g(Pe.$$.fragment,e),g(Be.$$.fragment,e),g(po.$$.fragment,e),g(ho.$$.fragment,e),g(mo.$$.fragment,e),g(Se.$$.fragment,e),g(Ae.$$.fragment,e),g(uo.$$.fragment,e),hs=!0)},o(e){_(T.$$.fragment,e),_(w.$$.fragment,e),_(mt.$$.fragment,e),_(gt.$$.fragment,e),_(_t.$$.fragment,e),_(be.$$.fragment,e),_(yt.$$.fragment,e),_(bt.$$.fragment,e),_(kt.$$.fragment,e),_(ke.$$.fragment,e),_(Tt.$$.fragment,e),_(wt.$$.fragment,e),_(vt.$$.fragment,e),_(xt.$$.fragment,e),_(Mt.$$.fragment,e),_($t.$$.fragment,e),_(Wt.$$.fragment,e),_(ve.$$.fragment,e),_(Ft.$$.fragment,e),_(zt.$$.fragment,e),_(Ct.$$.fragment,e),_(jt.$$.fragment,e),_(qt.$$.fragment,e),_(Jt.$$.fragment,e),_(It.$$.fragment,e),_(Gt.$$.fragment,e),_(Ut.$$.fragment,e),_(Nt.$$.fragment,e),_(Zt.$$.fragment,e),_(Fe.$$.fragment,e),_(Xt.$$.fragment,e),_(ze.$$.fragment,e),_(Rt.$$.fragment,e),_(Lt.$$.fragment,e),_(Vt.$$.fragment,e),_(Et.$$.fragment,e),_(Ht.$$.fragment,e),_(qe.$$.fragment,e),_(Je.$$.fragment,e),_(Pt.$$.fragment,e),_(Bt.$$.fragment,e),_(St.$$.fragment,e),_(At.$$.fragment,e),_(Ge.$$.fragment,e),_(Ue.$$.fragment,e),_(Yt.$$.fragment,e),_(Dt.$$.fragment,e),_(Ot.$$.fragment,e),_(Ne.$$.fragment,e),_(Ze.$$.fragment,e),_(Qt.$$.fragment,e),_(Kt.$$.fragment,e),_(eo.$$.fragment,e),_(Xe.$$.fragment,e),_(Re.$$.fragment,e),_(to.$$.fragment,e),_(oo.$$.fragment,e),_(no.$$.fragment,e),_(Le.$$.fragment,e),_(Ve.$$.fragment,e),_(so.$$.fragment,e),_(ao.$$.fragment,e),_(ro.$$.fragment,e),_(Ee.$$.fragment,e),_(He.$$.fragment,e),_(io.$$.fragment,e),_(lo.$$.fragment,e),_(co.$$.fragment,e),_(Pe.$$.fragment,e),_(Be.$$.fragment,e),_(po.$$.fragment,e),_(ho.$$.fragment,e),_(mo.$$.fragment,e),_(Se.$$.fragment,e),_(Ae.$$.fragment,e),_(uo.$$.fragment,e),hs=!1},d(e){e&&(r(k),r(c),r(p),r(n),r(Cn),r(dt),r(jn),r(lt),r(qn),r(ct),r(Jn),r(pt),r(In),r(ht),r(Gn),r(Un),r(ut),r(Nn),r(ft),r(Zn),r(Xn),r(X),r(Rn),r(Ln),r(W),r(Vn),r(En),r(F),r(Hn),r(Pn),r(G),r(Bn),r(Sn),r(z),r(An),r(Yn),r(I),r(Dn),r(On),r(U),r(Qn),r(Kn),r(N),r(es),r(ts),r(R),r(os),r(ns),r(L),r(ss),r(as),r(V),r(rs),r(is),r(E),r(ds),r(ls),r(H),r(cs),r(ps),r(Wn)),r(o),y(T,e),y(w,e),y(mt,e),y(gt,e),y(_t),y(be),y(yt,e),y(bt),y(kt),y(ke),y(Tt),y(wt),y(vt),y(xt),y(Mt,e),y($t),y(Wt),y(ve),y(Ft),y(zt),y(Ct),y(jt),y(qt,e),y(Jt),y(It),y(Gt,e),y(Ut),y(Nt),y(Zt),y(Fe),y(Xt),y(ze),y(Rt),y(Lt),y(Vt,e),y(Et),y(Ht),y(qe),y(Je),y(Pt),y(Bt,e),y(St),y(At),y(Ge),y(Ue),y(Yt,e),y(Dt),y(Ot),y(Ne),y(Ze),y(Qt,e),y(Kt),y(eo),y(Xe),y(Re),y(to,e),y(oo),y(no),y(Le),y(Ve),y(so,e),y(ao),y(ro),y(Ee),y(He),y(io,e),y(lo),y(co),y(Pe),y(Be),y(po,e),y(ho),y(mo),y(Se),y(Ae),y(uo,e)}}}const Ei='{"title":"Whisper","local":"whisper","sections":[{"title":"개요","local":"overview","sections":[],"depth":2},{"title":"WhisperConfig","local":"whisperconfig ][ transformers.WhisperConfig","sections":[],"depth":2},{"title":"WhisperTokenizer","local":"whispertokenizer ][ transformers.WhisperTokenizer","sections":[],"depth":2},{"title":"WhisperTokenizerFast","local":"whispertokenizerfast ][ transformers.WhisperTokenizerFast","sections":[],"depth":2},{"title":"WhisperFeatureExtractor","local":"whisperfeatureextractor ][ transformers.WhisperFeatureExtractor","sections":[],"depth":2},{"title":"WhisperProcessor","local":"whisperprocessor ][ transformers.WhisperProcessor","sections":[],"depth":2},{"title":"WhisperModel","local":"whispermodel ][ transformers.WhisperModel","sections":[],"depth":2},{"title":"WhisperForConditionalGeneration","local":"whisperforconditionalgeneration ][ transformers.WhisperForConditionalGeneration","sections":[],"depth":2},{"title":"WhisperForAudioClassification","local":"whisperforaudioclassification ][ transformers.WhisperForAudioClassification","sections":[],"depth":2},{"title":"TFWhisperModel","local":"tfwhispermodel ][ transformers.TFWhisperModel","sections":[],"depth":2},{"title":"TFWhisperForConditionalGeneration","local":"tfwhisperforconditionalgeneration ][ transformers.TFWhisperForConditionalGeneration","sections":[],"depth":2},{"title":"FlaxWhisperModel","local":"flaxwhispermodel ][ transformers.FlaxWhisperModel","sections":[],"depth":2},{"title":"FlaxWhisperForConditionalGeneration","local":"flaxwhisperforconditionalgeneration ][ transformers.FlaxWhisperForConditionalGeneration","sections":[],"depth":2},{"title":"FlaxWhisperForAudioClassification","local":"flaxwhisperforaudioclassification ][ transformers.FlaxWhisperForAudioClassification","sections":[],"depth":2}],"depth":1}';function Hi(v){return gi(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Qi extends _i{constructor(o){super(),yi(this,o,Hi,Vi,fi,{})}}export{Qi as component};
