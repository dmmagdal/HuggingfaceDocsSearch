import{s as ls,o as ds,n as W}from"../chunks/scheduler.bdbef820.js";import{S as cs,i as ms,g as d,s as o,r as h,A as ps,h as c,f as l,c as a,j as w,u as f,x as u,k as $,y as n,a as p,v as g,d as _,t as b,w as k}from"../chunks/index.33f81d56.js";import{T as Ue}from"../chunks/Tip.34194030.js";import{D as x}from"../chunks/Docstring.abcbe1ac.js";import{C as ie}from"../chunks/CodeBlock.3bad7fc9.js";import{E as re}from"../chunks/ExampleCodeBlock.16b3b633.js";import{H as ee,E as us}from"../chunks/getInferenceSnippets.64cd9466.js";function hs(v){let t,y;return t=new ie({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEdlbW1hTW9kZWwlMkMlMjBHZW1tYUNvbmZpZyUwQSUyMyUyMEluaXRpYWxpemluZyUyMGElMjBHZW1tYSUyMGdlbW1hLTdiJTIwc3R5bGUlMjBjb25maWd1cmF0aW9uJTBBY29uZmlndXJhdGlvbiUyMCUzRCUyMEdlbW1hQ29uZmlnKCklMEElMjMlMjBJbml0aWFsaXppbmclMjBhJTIwbW9kZWwlMjBmcm9tJTIwdGhlJTIwZ2VtbWEtN2IlMjBzdHlsZSUyMGNvbmZpZ3VyYXRpb24lMEFtb2RlbCUyMCUzRCUyMEdlbW1hTW9kZWwoY29uZmlndXJhdGlvbiklMEElMjMlMjBBY2Nlc3NpbmclMjB0aGUlMjBtb2RlbCUyMGNvbmZpZ3VyYXRpb24lMEFjb25maWd1cmF0aW9uJTIwJTNEJTIwbW9kZWwuY29uZmln",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> GemmaModel, GemmaConfig
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a Gemma gemma-7b style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = GemmaConfig()
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a model from the gemma-7b style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GemmaModel(configuration)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Accessing the model configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = model.config`,wrap:!1}}),{c(){h(t.$$.fragment)},l(r){f(t.$$.fragment,r)},m(r,m){g(t,r,m),y=!0},p:W,i(r){y||(_(t.$$.fragment,r),y=!0)},o(r){b(t.$$.fragment,r),y=!1},d(r){k(t,r)}}}function fs(v){let t,y="sequence pair mask has the following format:",r,m,T;return m=new ie({props:{code:"MCUyMDAlMjAwJTIwMCUyMDAlMjAwJTIwMCUyMDAlMjAwJTIwMCUyMDAlMjAxJTIwMSUyMDElMjAxJTIwMSUyMDElMjAxJTIwMSUyMDElMEElN0MlMjBmaXJzdCUyMHNlcXVlbmNlJTIwJTIwJTIwJTIwJTdDJTIwc2Vjb25kJTIwc2VxdWVuY2UlMjAlN0M=",highlighted:`0<span class="hljs-number"> 0 </span>0<span class="hljs-number"> 0 </span>0<span class="hljs-number"> 0 </span>0<span class="hljs-number"> 0 </span>0<span class="hljs-number"> 0 </span>0<span class="hljs-number"> 1 </span>1<span class="hljs-number"> 1 </span>1<span class="hljs-number"> 1 </span>1<span class="hljs-number"> 1 </span>1 1
| first sequence    | second sequence |`,wrap:!1}}),{c(){t=d("p"),t.textContent=y,r=o(),h(m.$$.fragment)},l(s){t=c(s,"P",{"data-svelte-h":!0}),u(t)!=="svelte-16klr56"&&(t.textContent=y),r=a(s),f(m.$$.fragment,s)},m(s,M){p(s,t,M),p(s,r,M),g(m,s,M),T=!0},p:W,i(s){T||(_(m.$$.fragment,s),T=!0)},o(s){b(m.$$.fragment,s),T=!1},d(s){s&&(l(t),l(r)),k(m,s)}}}function gs(v){let t,y;return t=new ie({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEdlbW1hVG9rZW5pemVyRmFzdCUwQSUwQXRva2VuaXplciUyMCUzRCUyMEdlbW1hVG9rZW5pemVyRmFzdC5mcm9tX3ByZXRyYWluZWQoJTIyaGYtaW50ZXJuYWwtdGVzdGluZyUyRmR1bW15LWdlbW1hJTIyKSUwQXRva2VuaXplci5lbmNvZGUoJTIySGVsbG8lMjB0aGlzJTIwaXMlMjBhJTIwdGVzdCUyMik=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> GemmaTokenizerFast

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = GemmaTokenizerFast.from_pretrained(<span class="hljs-string">&quot;hf-internal-testing/dummy-gemma&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.encode(<span class="hljs-string">&quot;Hello this is a test&quot;</span>)
[<span class="hljs-number">2</span>, <span class="hljs-number">4521</span>, <span class="hljs-number">736</span>, <span class="hljs-number">603</span>, <span class="hljs-number">476</span>, <span class="hljs-number">2121</span>]`,wrap:!1}}),{c(){h(t.$$.fragment)},l(r){f(t.$$.fragment,r)},m(r,m){g(t,r,m),y=!0},p:W,i(r){y||(_(t.$$.fragment,r),y=!0)},o(r){b(t.$$.fragment,r),y=!1},d(r){k(t,r)}}}function _s(v){let t,y=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){t=d("p"),t.innerHTML=y},l(r){t=c(r,"P",{"data-svelte-h":!0}),u(t)!=="svelte-fincs2"&&(t.innerHTML=y)},m(r,m){p(r,t,m)},p:W,d(r){r&&l(t)}}}function bs(v){let t,y=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){t=d("p"),t.innerHTML=y},l(r){t=c(r,"P",{"data-svelte-h":!0}),u(t)!=="svelte-fincs2"&&(t.innerHTML=y)},m(r,m){p(r,t,m)},p:W,d(r){r&&l(t)}}}function ks(v){let t,y="Example:",r,m,T;return m=new ie({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBHZW1tYUZvckNhdXNhbExNJTBBJTBBbW9kZWwlMjAlM0QlMjBHZW1tYUZvckNhdXNhbExNLmZyb21fcHJldHJhaW5lZCglMjJnb29nbGUlMkZnZW1tYS03YiUyMiklMEF0b2tlbml6ZXIlMjAlM0QlMjBBdXRvVG9rZW5pemVyLmZyb21fcHJldHJhaW5lZCglMjJnb29nbGUlMkZnZW1tYS03YiUyMiklMEElMEFwcm9tcHQlMjAlM0QlMjAlMjJXaGF0JTIwaXMlMjB5b3VyJTIwZmF2b3JpdGUlMjBjb25kaW1lbnQlM0YlMjIlMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIocHJvbXB0JTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMiklMEElMEElMjMlMjBHZW5lcmF0ZSUwQWdlbmVyYXRlX2lkcyUyMCUzRCUyMG1vZGVsLmdlbmVyYXRlKGlucHV0cy5pbnB1dF9pZHMlMkMlMjBtYXhfbGVuZ3RoJTNEMzApJTBBdG9rZW5pemVyLmJhdGNoX2RlY29kZShnZW5lcmF0ZV9pZHMlMkMlMjBza2lwX3NwZWNpYWxfdG9rZW5zJTNEVHJ1ZSUyQyUyMGNsZWFuX3VwX3Rva2VuaXphdGlvbl9zcGFjZXMlM0RGYWxzZSklNUIwJTVE",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, GemmaForCausalLM

<span class="hljs-meta">&gt;&gt;&gt; </span>model = GemmaForCausalLM.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>prompt = <span class="hljs-string">&quot;What is your favorite condiment?&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(prompt, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Generate</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>generate_ids = model.generate(inputs.input_ids, max_length=<span class="hljs-number">30</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.batch_decode(generate_ids, skip_special_tokens=<span class="hljs-literal">True</span>, clean_up_tokenization_spaces=<span class="hljs-literal">False</span>)[<span class="hljs-number">0</span>]
<span class="hljs-string">&quot;What is your favorite condiment?&quot;</span>`,wrap:!1}}),{c(){t=d("p"),t.textContent=y,r=o(),h(m.$$.fragment)},l(s){t=c(s,"P",{"data-svelte-h":!0}),u(t)!=="svelte-11lpom8"&&(t.textContent=y),r=a(s),f(m.$$.fragment,s)},m(s,M){p(s,t,M),p(s,r,M),g(m,s,M),T=!0},p:W,i(s){T||(_(m.$$.fragment,s),T=!0)},o(s){b(m.$$.fragment,s),T=!1},d(s){s&&(l(t),l(r)),k(m,s)}}}function ys(v){let t,y=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){t=d("p"),t.innerHTML=y},l(r){t=c(r,"P",{"data-svelte-h":!0}),u(t)!=="svelte-fincs2"&&(t.innerHTML=y)},m(r,m){p(r,t,m)},p:W,d(r){r&&l(t)}}}function Ts(v){let t,y="Example of single-label classification:",r,m,T;return m=new ie({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b1Rva2VuaXplciUyQyUyMEdlbW1hRm9yU2VxdWVuY2VDbGFzc2lmaWNhdGlvbiUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMmdvb2dsZSUyRmdlbW1hLTdiJTIyKSUwQW1vZGVsJTIwJTNEJTIwR2VtbWFGb3JTZXF1ZW5jZUNsYXNzaWZpY2F0aW9uLmZyb21fcHJldHJhaW5lZCglMjJnb29nbGUlMkZnZW1tYS03YiUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTIySGVsbG8lMkMlMjBteSUyMGRvZyUyMGlzJTIwY3V0ZSUyMiUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpJTBBJTBBd2l0aCUyMHRvcmNoLm5vX2dyYWQoKSUzQSUwQSUyMCUyMCUyMCUyMGxvZ2l0cyUyMCUzRCUyMG1vZGVsKCoqaW5wdXRzKS5sb2dpdHMlMEElMEFwcmVkaWN0ZWRfY2xhc3NfaWQlMjAlM0QlMjBsb2dpdHMuYXJnbWF4KCkuaXRlbSgpJTBBbW9kZWwuY29uZmlnLmlkMmxhYmVsJTVCcHJlZGljdGVkX2NsYXNzX2lkJTVEJTBBJTBBJTIzJTIwVG8lMjB0cmFpbiUyMGElMjBtb2RlbCUyMG9uJTIwJTYwbnVtX2xhYmVscyU2MCUyMGNsYXNzZXMlMkMlMjB5b3UlMjBjYW4lMjBwYXNzJTIwJTYwbnVtX2xhYmVscyUzRG51bV9sYWJlbHMlNjAlMjB0byUyMCU2MC5mcm9tX3ByZXRyYWluZWQoLi4uKSU2MCUwQW51bV9sYWJlbHMlMjAlM0QlMjBsZW4obW9kZWwuY29uZmlnLmlkMmxhYmVsKSUwQW1vZGVsJTIwJTNEJTIwR2VtbWFGb3JTZXF1ZW5jZUNsYXNzaWZpY2F0aW9uLmZyb21fcHJldHJhaW5lZCglMjJnb29nbGUlMkZnZW1tYS03YiUyMiUyQyUyMG51bV9sYWJlbHMlM0RudW1fbGFiZWxzKSUwQSUwQWxhYmVscyUyMCUzRCUyMHRvcmNoLnRlbnNvciglNUIxJTVEKSUwQWxvc3MlMjAlM0QlMjBtb2RlbCgqKmlucHV0cyUyQyUyMGxhYmVscyUzRGxhYmVscykubG9zcyUwQXJvdW5kKGxvc3MuaXRlbSgpJTJDJTIwMik=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, GemmaForSequenceClassification

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GemmaForSequenceClassification.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">with</span> torch.no_grad():
<span class="hljs-meta">... </span>    logits = model(**inputs).logits

<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_class_id = logits.argmax().item()
<span class="hljs-meta">&gt;&gt;&gt; </span>model.config.id2label[predicted_class_id]
...

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># To train a model on \`num_labels\` classes, you can pass \`num_labels=num_labels\` to \`.from_pretrained(...)\`</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>num_labels = <span class="hljs-built_in">len</span>(model.config.id2label)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GemmaForSequenceClassification.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>, num_labels=num_labels)

<span class="hljs-meta">&gt;&gt;&gt; </span>labels = torch.tensor([<span class="hljs-number">1</span>])
<span class="hljs-meta">&gt;&gt;&gt; </span>loss = model(**inputs, labels=labels).loss
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">round</span>(loss.item(), <span class="hljs-number">2</span>)
...`,wrap:!1}}),{c(){t=d("p"),t.textContent=y,r=o(),h(m.$$.fragment)},l(s){t=c(s,"P",{"data-svelte-h":!0}),u(t)!=="svelte-ykxpe4"&&(t.textContent=y),r=a(s),f(m.$$.fragment,s)},m(s,M){p(s,t,M),p(s,r,M),g(m,s,M),T=!0},p:W,i(s){T||(_(m.$$.fragment,s),T=!0)},o(s){b(m.$$.fragment,s),T=!1},d(s){s&&(l(t),l(r)),k(m,s)}}}function vs(v){let t,y="Example of multi-label classification:",r,m,T;return m=new ie({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b1Rva2VuaXplciUyQyUyMEdlbW1hRm9yU2VxdWVuY2VDbGFzc2lmaWNhdGlvbiUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMmdvb2dsZSUyRmdlbW1hLTdiJTIyKSUwQW1vZGVsJTIwJTNEJTIwR2VtbWFGb3JTZXF1ZW5jZUNsYXNzaWZpY2F0aW9uLmZyb21fcHJldHJhaW5lZCglMjJnb29nbGUlMkZnZW1tYS03YiUyMiUyQyUyMHByb2JsZW1fdHlwZSUzRCUyMm11bHRpX2xhYmVsX2NsYXNzaWZpY2F0aW9uJTIyKSUwQSUwQWlucHV0cyUyMCUzRCUyMHRva2VuaXplciglMjJIZWxsbyUyQyUyMG15JTIwZG9nJTIwaXMlMjBjdXRlJTIyJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMiklMEElMEF3aXRoJTIwdG9yY2gubm9fZ3JhZCgpJTNBJTBBJTIwJTIwJTIwJTIwbG9naXRzJTIwJTNEJTIwbW9kZWwoKippbnB1dHMpLmxvZ2l0cyUwQSUwQXByZWRpY3RlZF9jbGFzc19pZHMlMjAlM0QlMjB0b3JjaC5hcmFuZ2UoMCUyQyUyMGxvZ2l0cy5zaGFwZSU1Qi0xJTVEKSU1QnRvcmNoLnNpZ21vaWQobG9naXRzKS5zcXVlZXplKGRpbSUzRDApJTIwJTNFJTIwMC41JTVEJTBBJTBBJTIzJTIwVG8lMjB0cmFpbiUyMGElMjBtb2RlbCUyMG9uJTIwJTYwbnVtX2xhYmVscyU2MCUyMGNsYXNzZXMlMkMlMjB5b3UlMjBjYW4lMjBwYXNzJTIwJTYwbnVtX2xhYmVscyUzRG51bV9sYWJlbHMlNjAlMjB0byUyMCU2MC5mcm9tX3ByZXRyYWluZWQoLi4uKSU2MCUwQW51bV9sYWJlbHMlMjAlM0QlMjBsZW4obW9kZWwuY29uZmlnLmlkMmxhYmVsKSUwQW1vZGVsJTIwJTNEJTIwR2VtbWFGb3JTZXF1ZW5jZUNsYXNzaWZpY2F0aW9uLmZyb21fcHJldHJhaW5lZCglMEElMjAlMjAlMjAlMjAlMjJnb29nbGUlMkZnZW1tYS03YiUyMiUyQyUyMG51bV9sYWJlbHMlM0RudW1fbGFiZWxzJTJDJTIwcHJvYmxlbV90eXBlJTNEJTIybXVsdGlfbGFiZWxfY2xhc3NpZmljYXRpb24lMjIlMEEpJTBBJTBBbGFiZWxzJTIwJTNEJTIwdG9yY2guc3VtKCUwQSUyMCUyMCUyMCUyMHRvcmNoLm5uLmZ1bmN0aW9uYWwub25lX2hvdChwcmVkaWN0ZWRfY2xhc3NfaWRzJTVCTm9uZSUyQyUyMCUzQSU1RC5jbG9uZSgpJTJDJTIwbnVtX2NsYXNzZXMlM0RudW1fbGFiZWxzKSUyQyUyMGRpbSUzRDElMEEpLnRvKHRvcmNoLmZsb2F0KSUwQWxvc3MlMjAlM0QlMjBtb2RlbCgqKmlucHV0cyUyQyUyMGxhYmVscyUzRGxhYmVscykubG9zcw==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, GemmaForSequenceClassification

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GemmaForSequenceClassification.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>, problem_type=<span class="hljs-string">&quot;multi_label_classification&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">with</span> torch.no_grad():
<span class="hljs-meta">... </span>    logits = model(**inputs).logits

<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_class_ids = torch.arange(<span class="hljs-number">0</span>, logits.shape[-<span class="hljs-number">1</span>])[torch.sigmoid(logits).squeeze(dim=<span class="hljs-number">0</span>) &gt; <span class="hljs-number">0.5</span>]

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># To train a model on \`num_labels\` classes, you can pass \`num_labels=num_labels\` to \`.from_pretrained(...)\`</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>num_labels = <span class="hljs-built_in">len</span>(model.config.id2label)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GemmaForSequenceClassification.from_pretrained(
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;google/gemma-7b&quot;</span>, num_labels=num_labels, problem_type=<span class="hljs-string">&quot;multi_label_classification&quot;</span>
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>labels = torch.<span class="hljs-built_in">sum</span>(
<span class="hljs-meta">... </span>    torch.nn.functional.one_hot(predicted_class_ids[<span class="hljs-literal">None</span>, :].clone(), num_classes=num_labels), dim=<span class="hljs-number">1</span>
<span class="hljs-meta">... </span>).to(torch.<span class="hljs-built_in">float</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>loss = model(**inputs, labels=labels).loss`,wrap:!1}}),{c(){t=d("p"),t.textContent=y,r=o(),h(m.$$.fragment)},l(s){t=c(s,"P",{"data-svelte-h":!0}),u(t)!=="svelte-1l8e32d"&&(t.textContent=y),r=a(s),f(m.$$.fragment,s)},m(s,M){p(s,t,M),p(s,r,M),g(m,s,M),T=!0},p:W,i(s){T||(_(m.$$.fragment,s),T=!0)},o(s){b(m.$$.fragment,s),T=!1},d(s){s&&(l(t),l(r)),k(m,s)}}}function Ms(v){let t,y=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){t=d("p"),t.innerHTML=y},l(r){t=c(r,"P",{"data-svelte-h":!0}),u(t)!=="svelte-fincs2"&&(t.innerHTML=y)},m(r,m){p(r,t,m)},p:W,d(r){r&&l(t)}}}function ws(v){let t,y="Example:",r,m,T;return m=new ie({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBHZW1tYUZvclRva2VuQ2xhc3NpZmljYXRpb24lMEFpbXBvcnQlMjB0b3JjaCUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMmdvb2dsZSUyRmdlbW1hLTdiJTIyKSUwQW1vZGVsJTIwJTNEJTIwR2VtbWFGb3JUb2tlbkNsYXNzaWZpY2F0aW9uLmZyb21fcHJldHJhaW5lZCglMjJnb29nbGUlMkZnZW1tYS03YiUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTBBJTIwJTIwJTIwJTIwJTIySHVnZ2luZ0ZhY2UlMjBpcyUyMGElMjBjb21wYW55JTIwYmFzZWQlMjBpbiUyMFBhcmlzJTIwYW5kJTIwTmV3JTIwWW9yayUyMiUyQyUyMGFkZF9zcGVjaWFsX3Rva2VucyUzREZhbHNlJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJwdCUyMiUwQSklMEElMEF3aXRoJTIwdG9yY2gubm9fZ3JhZCgpJTNBJTBBJTIwJTIwJTIwJTIwbG9naXRzJTIwJTNEJTIwbW9kZWwoKippbnB1dHMpLmxvZ2l0cyUwQSUwQXByZWRpY3RlZF90b2tlbl9jbGFzc19pZHMlMjAlM0QlMjBsb2dpdHMuYXJnbWF4KC0xKSUwQSUwQSUyMyUyME5vdGUlMjB0aGF0JTIwdG9rZW5zJTIwYXJlJTIwY2xhc3NpZmllZCUyMHJhdGhlciUyMHRoZW4lMjBpbnB1dCUyMHdvcmRzJTIwd2hpY2glMjBtZWFucyUyMHRoYXQlMEElMjMlMjB0aGVyZSUyMG1pZ2h0JTIwYmUlMjBtb3JlJTIwcHJlZGljdGVkJTIwdG9rZW4lMjBjbGFzc2VzJTIwdGhhbiUyMHdvcmRzLiUwQSUyMyUyME11bHRpcGxlJTIwdG9rZW4lMjBjbGFzc2VzJTIwbWlnaHQlMjBhY2NvdW50JTIwZm9yJTIwdGhlJTIwc2FtZSUyMHdvcmQlMEFwcmVkaWN0ZWRfdG9rZW5zX2NsYXNzZXMlMjAlM0QlMjAlNUJtb2RlbC5jb25maWcuaWQybGFiZWwlNUJ0Lml0ZW0oKSU1RCUyMGZvciUyMHQlMjBpbiUyMHByZWRpY3RlZF90b2tlbl9jbGFzc19pZHMlNUIwJTVEJTVEJTBBcHJlZGljdGVkX3Rva2Vuc19jbGFzc2VzJTBBJTBBbGFiZWxzJTIwJTNEJTIwcHJlZGljdGVkX3Rva2VuX2NsYXNzX2lkcyUwQWxvc3MlMjAlM0QlMjBtb2RlbCgqKmlucHV0cyUyQyUyMGxhYmVscyUzRGxhYmVscykubG9zcyUwQXJvdW5kKGxvc3MuaXRlbSgpJTJDJTIwMik=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, GemmaForTokenClassification
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GemmaForTokenClassification.from_pretrained(<span class="hljs-string">&quot;google/gemma-7b&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;HuggingFace is a company based in Paris and New York&quot;</span>, add_special_tokens=<span class="hljs-literal">False</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">with</span> torch.no_grad():
<span class="hljs-meta">... </span>    logits = model(**inputs).logits

<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_token_class_ids = logits.argmax(-<span class="hljs-number">1</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Note that tokens are classified rather then input words which means that</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># there might be more predicted token classes than words.</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Multiple token classes might account for the same word</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_tokens_classes = [model.config.id2label[t.item()] <span class="hljs-keyword">for</span> t <span class="hljs-keyword">in</span> predicted_token_class_ids[<span class="hljs-number">0</span>]]
<span class="hljs-meta">&gt;&gt;&gt; </span>predicted_tokens_classes
...

<span class="hljs-meta">&gt;&gt;&gt; </span>labels = predicted_token_class_ids
<span class="hljs-meta">&gt;&gt;&gt; </span>loss = model(**inputs, labels=labels).loss
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">round</span>(loss.item(), <span class="hljs-number">2</span>)
...`,wrap:!1}}),{c(){t=d("p"),t.textContent=y,r=o(),h(m.$$.fragment)},l(s){t=c(s,"P",{"data-svelte-h":!0}),u(t)!=="svelte-11lpom8"&&(t.textContent=y),r=a(s),f(m.$$.fragment,s)},m(s,M){p(s,t,M),p(s,r,M),g(m,s,M),T=!0},p:W,i(s){T||(_(m.$$.fragment,s),T=!0)},o(s){b(m.$$.fragment,s),T=!1},d(s){s&&(l(t),l(r)),k(m,s)}}}function $s(v){let t,y=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){t=d("p"),t.innerHTML=y},l(r){t=c(r,"P",{"data-svelte-h":!0}),u(t)!=="svelte-fincs2"&&(t.innerHTML=y)},m(r,m){p(r,t,m)},p:W,d(r){r&&l(t)}}}function xs(v){let t,y=`This example uses a random model as the real ones are all very big. To get proper results, you should use
openlm-research/open_llama_3b_v2 instead of google/gemma-2b. If you get out-of-memory when loading that checkpoint, you can try
adding <code>device_map=&quot;auto&quot;</code> in the <code>from_pretrained</code> call.`;return{c(){t=d("p"),t.innerHTML=y},l(r){t=c(r,"P",{"data-svelte-h":!0}),u(t)!=="svelte-i4y11c"&&(t.innerHTML=y)},m(r,m){p(r,t,m)},p:W,d(r){r&&l(t)}}}function Gs(v){let t,y="Example:",r,m,T;return m=new ie({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBGbGF4R2VtbWFNb2RlbCUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMmdvb2dsZSUyRmdlbW1hLTJiJTIyKSUwQW1vZGVsJTIwJTNEJTIwRmxheEdlbW1hTW9kZWwuZnJvbV9wcmV0cmFpbmVkKCUyMmdvb2dsZSUyRmdlbW1hLTJiJTIyKSUwQSUwQWlucHV0cyUyMCUzRCUyMHRva2VuaXplciglMjJIZWxsbyUyQyUyMG15JTIwZG9nJTIwaXMlMjBjdXRlJTIyJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJqYXglMjIpJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKCoqaW5wdXRzKSUwQSUwQWxhc3RfaGlkZGVuX3N0YXRlcyUyMCUzRCUyMG91dHB1dHMubGFzdF9oaWRkZW5fc3RhdGU=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, FlaxGemmaModel

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;google/gemma-2b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxGemmaModel.from_pretrained(<span class="hljs-string">&quot;google/gemma-2b&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;jax&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_states = outputs.last_hidden_state`,wrap:!1}}),{c(){t=d("p"),t.textContent=y,r=o(),h(m.$$.fragment)},l(s){t=c(s,"P",{"data-svelte-h":!0}),u(t)!=="svelte-11lpom8"&&(t.textContent=y),r=a(s),f(m.$$.fragment,s)},m(s,M){p(s,t,M),p(s,r,M),g(m,s,M),T=!0},p:W,i(s){T||(_(m.$$.fragment,s),T=!0)},o(s){b(m.$$.fragment,s),T=!1},d(s){s&&(l(t),l(r)),k(m,s)}}}function Cs(v){let t,y=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){t=d("p"),t.innerHTML=y},l(r){t=c(r,"P",{"data-svelte-h":!0}),u(t)!=="svelte-fincs2"&&(t.innerHTML=y)},m(r,m){p(r,t,m)},p:W,d(r){r&&l(t)}}}function zs(v){let t,y=`This example uses a random model as the real ones are all very big. To get proper results, you should use
openlm-research/open_llama_3b_v2 instead of google/gemma-2b. If you get out-of-memory when loading that checkpoint, you can try
adding <code>device_map=&quot;auto&quot;</code> in the <code>from_pretrained</code> call.`;return{c(){t=d("p"),t.innerHTML=y},l(r){t=c(r,"P",{"data-svelte-h":!0}),u(t)!=="svelte-i4y11c"&&(t.innerHTML=y)},m(r,m){p(r,t,m)},p:W,d(r){r&&l(t)}}}function Fs(v){let t,y="Example:",r,m,T;return m=new ie({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBGbGF4R2VtbWFGb3JDYXVzYWxMTSUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMmdvb2dsZSUyRmdlbW1hLTJiJTIyKSUwQW1vZGVsJTIwJTNEJTIwRmxheEdlbW1hRm9yQ2F1c2FsTE0uZnJvbV9wcmV0cmFpbmVkKCUyMmdvb2dsZSUyRmdlbW1hLTJiJTIyKSUwQSUwQWlucHV0cyUyMCUzRCUyMHRva2VuaXplciglMjJIZWxsbyUyQyUyMG15JTIwZG9nJTIwaXMlMjBjdXRlJTIyJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJucCUyMiklMEFvdXRwdXRzJTIwJTNEJTIwbW9kZWwoKippbnB1dHMpJTBBJTBBJTIzJTIwcmV0cmlldmUlMjBsb2d0cyUyMGZvciUyMG5leHQlMjB0b2tlbiUwQW5leHRfdG9rZW5fbG9naXRzJTIwJTNEJTIwb3V0cHV0cy5sb2dpdHMlNUIlM0ElMkMlMjAtMSU1RA==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, FlaxGemmaForCausalLM

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;google/gemma-2b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxGemmaForCausalLM.from_pretrained(<span class="hljs-string">&quot;google/gemma-2b&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;np&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># retrieve logts for next token</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>next_token_logits = outputs.logits[:, -<span class="hljs-number">1</span>]`,wrap:!1}}),{c(){t=d("p"),t.textContent=y,r=o(),h(m.$$.fragment)},l(s){t=c(s,"P",{"data-svelte-h":!0}),u(t)!=="svelte-11lpom8"&&(t.textContent=y),r=a(s),f(m.$$.fragment,s)},m(s,M){p(s,t,M),p(s,r,M),g(m,s,M),T=!0},p:W,i(s){T||(_(m.$$.fragment,s),T=!0)},o(s){b(m.$$.fragment,s),T=!1},d(s){s&&(l(t),l(r)),k(m,s)}}}function js(v){let t,y,r,m,T,s,M,gn,Je,ma='Gemma 모델은 Google의 Gemma 팀이 작성한 <a href="https://blog.google/technology/developers/gemma-open-models/" rel="nofollow">Gemma: Open Models Based on Gemini Technology and Research</a>에서 제안되었습니다.',_n,Ie,pa="Gemma 모델은 6조 토큰으로 학습되었으며, 2b와 7b의 두 가지 버전으로 출시되었습니다.",bn,We,ua="논문의 초록은 다음과 같습니다:",kn,qe,ha="<em>이 연구는 언어 이해, 추론 및 안전성에 대한 학술 벤치마크에서 뛰어난 성능을 보이는 새로운 오픈 언어 모델 계열인 Gemma를 소개합니다. 우리는 두 가지 크기(20억 및 70억 매개변수)의 모델을 출시하며, 사전 학습된 체크포인트와 미세 조정된 체크포인트를 모두 제공합니다. Gemma는 18개의 텍스트 기반 작업 중 11개에서 유사한 크기의 오픈 모델을 능가하며, 우리는 모델 개발에 대한 상세한 설명과 함께 안전성과 책임 측면에 대한 종합적인 평가를 제공합니다. 우리는 LLM의 책임감 있는 공개가 최첨단 모델의 안전성을 향상시키고 다음 세대의 LLM 혁신을 가능하게 하는 데 중요하다고 믿습니다.</em>",yn,Le,fa="팁:",Tn,Ze,ga="<li>원본 체크포인트는 변환 스크립트 <code>src/transformers/models/gemma/convert_gemma_weights_to_hf.py</code>를 사용하여 변환할 수 있습니다.</li>",vn,Ve,_a='이 모델은 <a href="https://huggingface.co/ArthurZ" rel="nofollow">Arthur Zucker</a>, <a href="https://huggingface.co/ybelkada" rel="nofollow">Younes Belkada</a>, <a href="https://huggingface.co/sanchit-gandhi" rel="nofollow">Sanchit Gandhi</a>, <a href="https://huggingface.co/pcuenq" rel="nofollow">Pedro Cuenca</a>가 기여했습니다.',Mn,He,wn,D,Pe,Bn,wt,ba=`This is the configuration class to store the configuration of a <a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaModel">GemmaModel</a>. It is used to instantiate an Gemma
model according to the specified arguments, defining the model architecture. Instantiating a configuration with the
defaults will yield a similar configuration to that of the Gemma-7B.
e.g. <a href="https://huggingface.co/google/gemma-7b" rel="nofollow">google/gemma-7b</a>
Configuration objects inherit from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> and can be used to control the model outputs. Read the
documentation from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> for more information.`,Rn,le,$n,Ne,xn,G,Se,Xn,$t,ka=`Construct a Gemma tokenizer. Based on byte-level Byte-Pair-Encoding. The default padding token is unset as there is
no padding token in the original model.`,En,de,Be,Yn,xt,ya="Converts a sequence of tokens (string) in a single string.",Qn,Y,Re,An,Gt,Ta="Creates a mask from the two sequences passed to be used in a sequence-pair classification task. An ALBERT",Dn,ce,On,Ct,va="if token_ids_1 is None, only returns the first portion of the mask (0s).",Kn,me,Xe,eo,zt,Ma=`Retrieve sequence ids from a token list that has no special tokens added. This method is called when adding
special tokens using the tokenizer <code>prepare_for_model</code> method.`,to,pe,Ee,no,Ft,wa="Returns vocab as a dict",oo,ue,Ye,ao,jt,$a="Save the vocabulary and special tokens file to a directory.",so,he,Qe,ro,Ut,xa="Simply calls PreTrainedTokenizer’s method",Gn,Ae,Cn,C,De,io,Jt,Ga="Construct a Gemma tokenizer fast. Based on byte-level Byte-Pair-Encoding.",lo,It,Ca="This uses notably ByteFallback and no prefix space. Normalization is applied to replace  <code>&quot; &quot;</code> with <code>&quot;▁&quot;</code>",co,fe,mo,Wt,za=`If you want to change the <code>bos_token</code> or the <code>eos_token</code>, make sure to specify them when initializing the model, or
call <code>tokenizer.update_post_processor()</code> to make sure that the post-processing is correctly done (otherwise the
values of the first token and final token of an encoded sequence will not be correct). For more details, checkout
[post-processors] (<a href="https://huggingface.co/docs/tokenizers/api/post-processors" rel="nofollow">https://huggingface.co/docs/tokenizers/api/post-processors</a>) documentation.`,po,qt,Fa=`This tokenizer inherits from <code>PreTrainedTokenizerFast</code> which contains most of the main methods. Users should
refer to this superclass for more information regarding those methods.`,uo,ge,Oe,ho,Lt,ja="Updates the underlying post processor with the current <code>bos_token</code> and <code>eos_token</code>.",zn,Ke,Fn,q,et,fo,Zt,Ua="The bare Gemma Model outputting raw hidden-states without any specific head on top.",go,Vt,Ja=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,_o,Ht,Ia=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,bo,te,tt,ko,Pt,Wa='The <a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaModel">GemmaModel</a> forward method, overrides the <code>__call__</code> special method.',yo,_e,jn,nt,Un,L,ot,To,Nt,qa="The Gemma Model for causal language modeling.",vo,St,La=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Mo,Bt,Za=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,wo,Q,at,$o,Rt,Va='The <a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaForCausalLM">GemmaForCausalLM</a> forward method, overrides the <code>__call__</code> special method.',xo,be,Go,ke,Jn,st,In,z,rt,Co,Xt,Ha="The Gemma Model transformer with a sequence classification head on top (linear layer).",zo,Et,Pa=`<a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaForSequenceClassification">GemmaForSequenceClassification</a> uses the last token in order to do the classification, as other causal models
(e.g. GPT-2) do.`,Fo,Yt,Na=`Since it does classification on the last token, it requires to know the position of the last token. If a
<code>pad_token_id</code> is defined in the configuration, it finds the last token that is not a padding token in each row. If
no <code>pad_token_id</code> is defined, it simply takes the last value in each row of the batch. Since it cannot guess the
padding tokens when <code>inputs_embeds</code> are passed instead of <code>input_ids</code>, it does the same (take the last value in
each row of the batch).`,jo,Qt,Sa=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Uo,At,Ba=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,Jo,V,it,Io,Dt,Ra='The <a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaForSequenceClassification">GemmaForSequenceClassification</a> forward method, overrides the <code>__call__</code> special method.',Wo,ye,qo,Te,Lo,ve,Wn,lt,qn,Z,dt,Zo,Ot,Xa=`The Gemma transformer with a token classification head on top (a linear layer on top of the hidden-states
output) e.g. for Named-Entity-Recognition (NER) tasks.`,Vo,Kt,Ea=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Ho,en,Ya=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,Po,A,ct,No,tn,Qa='The <a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaForTokenClassification">GemmaForTokenClassification</a> forward method, overrides the <code>__call__</code> special method.',So,Me,Bo,we,Ln,mt,Zn,F,pt,Ro,nn,Aa="The bare Gemma Model transformer outputting raw hidden-states without any specific head on top.",Xo,on,Da=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,Eo,an,Oa=`This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.`,Yo,sn,Ka="Finally, this model supports inherent JAX features such as:",Qo,rn,es='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',Ao,H,ut,Do,ln,ts="The <code>FlaxGemmaPreTrainedModel</code> forward method, overrides the <code>__call__</code> special method.",Oo,$e,Ko,xe,ea,Ge,Vn,ht,Hn,j,ft,ta,dn,ns="The Gemma Model transformer with a language modeling head (linear layer) on top.",na,cn,os=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,oa,mn,as=`This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.`,aa,pn,ss="Finally, this model supports inherent JAX features such as:",sa,un,rs='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',ra,P,gt,ia,hn,is="The <code>FlaxGemmaPreTrainedModel</code> forward method, overrides the <code>__call__</code> special method.",la,Ce,da,ze,ca,Fe,Pn,_t,Nn,fn,Sn;return T=new ee({props:{title:"Gemma",local:"gemma",headingTag:"h1"}}),M=new ee({props:{title:"개요",local:"overview",headingTag:"h2"}}),He=new ee({props:{title:"GemmaConfig",local:"transformers.GemmaConfig ][ transformers.GemmaConfig",headingTag:"h2"}}),Pe=new x({props:{name:"class transformers.GemmaConfig",anchor:"transformers.GemmaConfig",parameters:[{name:"vocab_size",val:" = 256000"},{name:"hidden_size",val:" = 3072"},{name:"intermediate_size",val:" = 24576"},{name:"num_hidden_layers",val:" = 28"},{name:"num_attention_heads",val:" = 16"},{name:"num_key_value_heads",val:" = 16"},{name:"head_dim",val:" = 256"},{name:"hidden_act",val:" = 'gelu_pytorch_tanh'"},{name:"hidden_activation",val:" = None"},{name:"max_position_embeddings",val:" = 8192"},{name:"initializer_range",val:" = 0.02"},{name:"rms_norm_eps",val:" = 1e-06"},{name:"use_cache",val:" = True"},{name:"pad_token_id",val:" = 0"},{name:"eos_token_id",val:" = 1"},{name:"bos_token_id",val:" = 2"},{name:"tie_word_embeddings",val:" = True"},{name:"rope_theta",val:" = 10000.0"},{name:"attention_bias",val:" = False"},{name:"attention_dropout",val:" = 0.0"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.GemmaConfig.vocab_size",description:`<strong>vocab_size</strong> (<code>int</code>, <em>optional</em>, defaults to 256000) &#x2014;
Vocabulary size of the Gemma model. Defines the number of different tokens that can be represented by the
<code>inputs_ids</code> passed when calling <a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaModel">GemmaModel</a>`,name:"vocab_size"},{anchor:"transformers.GemmaConfig.hidden_size",description:`<strong>hidden_size</strong> (<code>int</code>, <em>optional</em>, defaults to 3072) &#x2014;
Dimension of the hidden representations.`,name:"hidden_size"},{anchor:"transformers.GemmaConfig.intermediate_size",description:`<strong>intermediate_size</strong> (<code>int</code>, <em>optional</em>, defaults to 24576) &#x2014;
Dimension of the MLP representations.`,name:"intermediate_size"},{anchor:"transformers.GemmaConfig.num_hidden_layers",description:`<strong>num_hidden_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 28) &#x2014;
Number of hidden layers in the Transformer decoder.`,name:"num_hidden_layers"},{anchor:"transformers.GemmaConfig.num_attention_heads",description:`<strong>num_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 16) &#x2014;
Number of attention heads for each attention layer in the Transformer decoder.`,name:"num_attention_heads"},{anchor:"transformers.GemmaConfig.num_key_value_heads",description:`<strong>num_key_value_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 16) &#x2014;
This is the number of key_value heads that should be used to implement Grouped Query Attention. If
<code>num_key_value_heads=num_attention_heads</code>, the model will use Multi Head Attention (MHA), if
<code>num_key_value_heads=1</code> the model will use Multi Query Attention (MQA) otherwise GQA is used. When
converting a multi-head checkpoint to a GQA checkpoint, each group key and value head should be constructed
by meanpooling all the original heads within that group. For more details, check out <a href="https://huggingface.co/papers/2305.13245" rel="nofollow">this
paper</a>. If it is not specified, will default to
<code>num_attention_heads</code>.`,name:"num_key_value_heads"},{anchor:"transformers.GemmaConfig.head_dim",description:`<strong>head_dim</strong> (<code>int</code>, <em>optional</em>, defaults to 256) &#x2014;
The attention head dimension.`,name:"head_dim"},{anchor:"transformers.GemmaConfig.hidden_act",description:`<strong>hidden_act</strong> (<code>str</code> or <code>function</code>, <em>optional</em>, defaults to <code>&quot;gelu_pytorch_tanh&quot;</code>) &#x2014;
The legacy activation function. It is overwritten by the <code>hidden_activation</code>.`,name:"hidden_act"},{anchor:"transformers.GemmaConfig.hidden_activation",description:`<strong>hidden_activation</strong> (<code>str</code> or <code>function</code>, <em>optional</em>) &#x2014;
The non-linear activation function (function or string) in the decoder. Will default to <code>&quot;gelu_pytorch_tanh&quot;</code>
if not specified. <code>&quot;gelu_pytorch_tanh&quot;</code> uses an approximation of the <code>&quot;gelu&quot;</code> activation function.`,name:"hidden_activation"},{anchor:"transformers.GemmaConfig.max_position_embeddings",description:`<strong>max_position_embeddings</strong> (<code>int</code>, <em>optional</em>, defaults to 8192) &#x2014;
The maximum sequence length that this model might ever be used with.`,name:"max_position_embeddings"},{anchor:"transformers.GemmaConfig.initializer_range",description:`<strong>initializer_range</strong> (<code>float</code>, <em>optional</em>, defaults to 0.02) &#x2014;
The standard deviation of the truncated_normal_initializer for initializing all weight matrices.`,name:"initializer_range"},{anchor:"transformers.GemmaConfig.rms_norm_eps",description:`<strong>rms_norm_eps</strong> (<code>float</code>, <em>optional</em>, defaults to 1e-06) &#x2014;
The epsilon used by the rms normalization layers.`,name:"rms_norm_eps"},{anchor:"transformers.GemmaConfig.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether or not the model should return the last key/values attentions (not used by all models). Only
relevant if <code>config.is_decoder=True</code>.`,name:"use_cache"},{anchor:"transformers.GemmaConfig.pad_token_id",description:`<strong>pad_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 0) &#x2014;
Padding token id.`,name:"pad_token_id"},{anchor:"transformers.GemmaConfig.eos_token_id",description:`<strong>eos_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 1) &#x2014;
End of stream token id.`,name:"eos_token_id"},{anchor:"transformers.GemmaConfig.bos_token_id",description:`<strong>bos_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 2) &#x2014;
Beginning of stream token id.`,name:"bos_token_id"},{anchor:"transformers.GemmaConfig.tie_word_embeddings",description:`<strong>tie_word_embeddings</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether to tie weight embeddings`,name:"tie_word_embeddings"},{anchor:"transformers.GemmaConfig.rope_theta",description:`<strong>rope_theta</strong> (<code>float</code>, <em>optional</em>, defaults to 10000.0) &#x2014;
The base period of the RoPE embeddings.`,name:"rope_theta"},{anchor:"transformers.GemmaConfig.attention_bias",description:`<strong>attention_bias</strong> (<code>bool</code>, defaults to <code>False</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether to use a bias in the query, key, value and output projection layers during self-attention.`,name:"attention_bias"},{anchor:"transformers.GemmaConfig.attention_dropout",description:`<strong>attention_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout ratio for the attention probabilities.`,name:"attention_dropout"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/configuration_gemma.py#L25"}}),le=new re({props:{anchor:"transformers.GemmaConfig.example",$$slots:{default:[hs]},$$scope:{ctx:v}}}),Ne=new ee({props:{title:"GemmaTokenizer",local:"transformers.GemmaTokenizer ][ transformers.GemmaTokenizer",headingTag:"h2"}}),Se=new x({props:{name:"class transformers.GemmaTokenizer",anchor:"transformers.GemmaTokenizer",parameters:[{name:"vocab_file",val:""},{name:"unk_token",val:" = '<unk>'"},{name:"bos_token",val:" = '<bos>'"},{name:"eos_token",val:" = '<eos>'"},{name:"pad_token",val:" = '<pad>'"},{name:"sp_model_kwargs",val:": typing.Optional[typing.Dict[str, typing.Any]] = None"},{name:"add_bos_token",val:" = True"},{name:"add_eos_token",val:" = False"},{name:"clean_up_tokenization_spaces",val:" = False"},{name:"use_default_system_prompt",val:" = False"},{name:"spaces_between_special_tokens",val:" = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.GemmaTokenizer.vocab_file",description:`<strong>vocab_file</strong> (<code>str</code>) &#x2014;
Path to the vocabulary file.`,name:"vocab_file"},{anchor:"transformers.GemmaTokenizer.unk_token",description:`<strong>unk_token</strong> (<code>str</code> or <code>tokenizers.AddedToken</code>, <em>optional</em>, defaults to <code>&quot;&lt;unk&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.GemmaTokenizer.bos_token",description:`<strong>bos_token</strong> (<code>str</code> or <code>tokenizers.AddedToken</code>, <em>optional</em>, defaults to <code>&quot;&lt;bos&gt;&quot;</code>) &#x2014;
The beginning of sequence token that was used during pretraining. Can be used a sequence classifier token.`,name:"bos_token"},{anchor:"transformers.GemmaTokenizer.eos_token",description:`<strong>eos_token</strong> (<code>str</code> or <code>tokenizers.AddedToken</code>, <em>optional</em>, defaults to <code>&quot;&lt;eos&gt;&quot;</code>) &#x2014;
The end of sequence token.`,name:"eos_token"},{anchor:"transformers.GemmaTokenizer.pad_token",description:`<strong>pad_token</strong> (<code>str</code> or <code>tokenizers.AddedToken</code>, <em>optional</em>, defaults to <code>&quot;&lt;pad&gt;&quot;</code>) &#x2014;
A special token used to make arrays of tokens the same size for batching purpose. Will then be ignored by
attention mechanisms or loss computation.`,name:"pad_token"},{anchor:"transformers.GemmaTokenizer.sp_model_kwargs",description:`<strong>sp_model_kwargs</strong> (<code>Dict[str, Any]</code>, <code>Optional</code>, <em>optional</em>) &#x2014;
Will be passed to the <code>SentencePieceProcessor.__init__()</code> method. The <a href="https://github.com/google/sentencepiece/tree/master/python" rel="nofollow">Python wrapper for
SentencePiece</a> can be used, among other things,
to set:</p>
<ul>
<li>
<p><code>enable_sampling</code>: Enable subword regularization.</p>
</li>
<li>
<p><code>nbest_size</code>: Sampling parameters for unigram. Invalid for BPE-Dropout.</p>
<ul>
<li><code>nbest_size = {0,1}</code>: No sampling is performed.</li>
<li><code>nbest_size &gt; 1</code>: samples from the nbest_size results.</li>
<li><code>nbest_size &lt; 0</code>: assuming that nbest_size is infinite and samples from the all hypothesis (lattice)
using forward-filtering-and-backward-sampling algorithm.</li>
</ul>
</li>
<li>
<p><code>alpha</code>: Smoothing parameter for unigram sampling, and dropout probability of merge operations for
BPE-dropout.</p>
</li>
</ul>`,name:"sp_model_kwargs"},{anchor:"transformers.GemmaTokenizer.add_bos_token",description:`<strong>add_bos_token</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether or not to add an <code>bos_token</code> at the start of sequences.`,name:"add_bos_token"},{anchor:"transformers.GemmaTokenizer.add_eos_token",description:`<strong>add_eos_token</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to add an <code>eos_token</code> at the end of sequences.`,name:"add_eos_token"},{anchor:"transformers.GemmaTokenizer.clean_up_tokenization_spaces",description:`<strong>clean_up_tokenization_spaces</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to cleanup spaces after decoding, cleanup consists in removing potential artifacts like
extra spaces.`,name:"clean_up_tokenization_spaces"},{anchor:"transformers.GemmaTokenizer.use_default_system_prompt",description:`<strong>use_default_system_prompt</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not the default system prompt for Gemma should be used.`,name:"use_default_system_prompt"},{anchor:"transformers.GemmaTokenizer.spaces_between_special_tokens",description:`<strong>spaces_between_special_tokens</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to add spaces between special tokens.`,name:"spaces_between_special_tokens"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma.py#L43"}}),Be=new x({props:{name:"convert_tokens_to_string",anchor:"transformers.GemmaTokenizer.convert_tokens_to_string",parameters:[{name:"tokens",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma.py#L183"}}),Re=new x({props:{name:"create_token_type_ids_from_sequences",anchor:"transformers.GemmaTokenizer.create_token_type_ids_from_sequences",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.GemmaTokenizer.create_token_type_ids_from_sequences.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of ids.`,name:"token_ids_0"},{anchor:"transformers.GemmaTokenizer.create_token_type_ids_from_sequences.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma.py#L272",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>List of <a href="../glossary#token-type-ids">token type IDs</a> according to the given sequence(s).</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),ce=new re({props:{anchor:"transformers.GemmaTokenizer.create_token_type_ids_from_sequences.example",$$slots:{default:[fs]},$$scope:{ctx:v}}}),Xe=new x({props:{name:"get_special_tokens_mask",anchor:"transformers.GemmaTokenizer.get_special_tokens_mask",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"},{name:"already_has_special_tokens",val:": bool = False"}],parametersDescription:[{anchor:"transformers.GemmaTokenizer.get_special_tokens_mask.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs.`,name:"token_ids_0"},{anchor:"transformers.GemmaTokenizer.get_special_tokens_mask.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"},{anchor:"transformers.GemmaTokenizer.get_special_tokens_mask.already_has_special_tokens",description:`<strong>already_has_special_tokens</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not the token list is already formatted with special tokens for the model.`,name:"already_has_special_tokens"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma.py#L235",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A list of integers in the range [0, 1]: 1 for a special token, 0 for a sequence token.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),Ee=new x({props:{name:"get_vocab",anchor:"transformers.GemmaTokenizer.get_vocab",parameters:[],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma.py#L152"}}),Ye=new x({props:{name:"save_vocabulary",anchor:"transformers.GemmaTokenizer.save_vocabulary",parameters:[{name:"save_directory",val:""},{name:"filename_prefix",val:": typing.Optional[str] = None"}],parametersDescription:[{anchor:"transformers.GemmaTokenizer.save_vocabulary.save_directory",description:`<strong>save_directory</strong> (<code>str</code>) &#x2014;
The directory in which to save the vocabulary.`,name:"save_directory"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma.py#L197",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>Paths to the files saved.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>Tuple(str)</code></p>
`}}),Qe=new x({props:{name:"tokenize",anchor:"transformers.GemmaTokenizer.tokenize",parameters:[{name:"text",val:": TextInput"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.GemmaTokenizer.tokenize.text",description:"<strong>text</strong> &#x2014; TextInput",name:"text"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma.py#L158"}}),Ae=new ee({props:{title:"GemmaTokenizerFast",local:"transformers.GemmaTokenizerFast ][ transformers.GemmaTokenizerFast",headingTag:"h2"}}),De=new x({props:{name:"class transformers.GemmaTokenizerFast",anchor:"transformers.GemmaTokenizerFast",parameters:[{name:"vocab_file",val:" = None"},{name:"tokenizer_file",val:" = None"},{name:"clean_up_tokenization_spaces",val:" = False"},{name:"unk_token",val:" = '<unk>'"},{name:"bos_token",val:" = '<bos>'"},{name:"eos_token",val:" = '<eos>'"},{name:"pad_token",val:" = '<pad>'"},{name:"add_bos_token",val:" = True"},{name:"add_eos_token",val:" = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.GemmaTokenizerFast.vocab_file",description:`<strong>vocab_file</strong> (<code>str</code>, <em>optional</em>) &#x2014;
<a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a> file (generally has a .model extension) that
contains the vocabulary necessary to instantiate a tokenizer.`,name:"vocab_file"},{anchor:"transformers.GemmaTokenizerFast.tokenizer_file",description:`<strong>tokenizer_file</strong> (<code>str</code>, <em>optional</em>) &#x2014;
<a href="https://github.com/huggingface/tokenizers" rel="nofollow">tokenizers</a> file (generally has a .json extension) that
contains everything needed to load the tokenizer.`,name:"tokenizer_file"},{anchor:"transformers.GemmaTokenizerFast.clean_up_tokenization_spaces",description:`<strong>clean_up_tokenization_spaces</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to cleanup spaces after decoding, cleanup consists in removing potential artifacts like
extra spaces.`,name:"clean_up_tokenization_spaces"},{anchor:"transformers.GemmaTokenizerFast.unk_token",description:`<strong>unk_token</strong> (<code>str</code> or <code>tokenizers.AddedToken</code>, <em>optional</em>, defaults to <code>&quot;&lt;unk&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.GemmaTokenizerFast.bos_token",description:`<strong>bos_token</strong> (<code>str</code> or <code>tokenizers.AddedToken</code>, <em>optional</em>, defaults to <code>&quot;&lt;bos&gt;&quot;</code>) &#x2014;
The beginning of sequence token that was used during pretraining. Can be used a sequence classifier token.`,name:"bos_token"},{anchor:"transformers.GemmaTokenizerFast.eos_token",description:`<strong>eos_token</strong> (<code>str</code> or <code>tokenizers.AddedToken</code>, <em>optional</em>, defaults to <code>&quot;&lt;eos&gt;&quot;</code>) &#x2014;
The end of sequence token.`,name:"eos_token"},{anchor:"transformers.GemmaTokenizerFast.pad_token",description:`<strong>pad_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;pad&gt;&quot;</code>) &#x2014;
The padding token`,name:"pad_token"},{anchor:"transformers.GemmaTokenizerFast.add_bos_token",description:`<strong>add_bos_token</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether or not to add an <code>bos_token</code> at the start of sequences.`,name:"add_bos_token"},{anchor:"transformers.GemmaTokenizerFast.add_eos_token",description:`<strong>add_eos_token</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to add an <code>eos_token</code> at the end of sequences.`,name:"add_eos_token"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma_fast.py#L34"}}),fe=new re({props:{anchor:"transformers.GemmaTokenizerFast.example",$$slots:{default:[gs]},$$scope:{ctx:v}}}),Oe=new x({props:{name:"update_post_processor",anchor:"transformers.GemmaTokenizerFast.update_post_processor",parameters:[],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/tokenization_gemma_fast.py#L118"}}),Ke=new ee({props:{title:"GemmaModel",local:"transformers.GemmaModel ][ transformers.GemmaModel",headingTag:"h2"}}),et=new x({props:{name:"class transformers.GemmaModel",anchor:"transformers.GemmaModel",parameters:[{name:"config",val:": GemmaConfig"}],parametersDescription:[{anchor:"transformers.GemmaModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig">GemmaConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L343"}}),tt=new x({props:{name:"forward",anchor:"transformers.GemmaModel.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"},{name:"**kwargs",val:": typing_extensions.Unpack[transformers.modeling_flash_attention_utils.FlashAttentionKwargs]"}],parametersDescription:[{anchor:"transformers.GemmaModel.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.GemmaModel.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.GemmaModel.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.GemmaModel.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.GemmaModel.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.GemmaModel.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.GemmaModel.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.GemmaModel.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.GemmaModel.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L367",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.BaseModelOutputWithPast"
>transformers.modeling_outputs.BaseModelOutputWithPast</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig"
>GemmaConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if
<code>config.is_encoder_decoder=True</code> in the cross-attention blocks) that can be used (see <code>past_key_values</code>
input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.BaseModelOutputWithPast"
>transformers.modeling_outputs.BaseModelOutputWithPast</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),_e=new Ue({props:{$$slots:{default:[_s]},$$scope:{ctx:v}}}),nt=new ee({props:{title:"GemmaForCausalLM",local:"transformers.GemmaForCausalLM ][ transformers.GemmaForCausalLM",headingTag:"h2"}}),ot=new x({props:{name:"class transformers.GemmaForCausalLM",anchor:"transformers.GemmaForCausalLM",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.GemmaForCausalLM.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaForCausalLM">GemmaForCausalLM</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L474"}}),at=new x({props:{name:"forward",anchor:"transformers.GemmaForCausalLM.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"},{name:"logits_to_keep",val:": typing.Union[int, torch.Tensor] = 0"},{name:"**kwargs",val:": typing_extensions.Unpack[transformers.models.gemma.modeling_gemma.KwargsForCausalLM]"}],parametersDescription:[{anchor:"transformers.GemmaForCausalLM.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.GemmaForCausalLM.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.GemmaForCausalLM.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.GemmaForCausalLM.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.GemmaForCausalLM.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.GemmaForCausalLM.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the masked language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code> or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored
(masked), the loss is only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"},{anchor:"transformers.GemmaForCausalLM.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.GemmaForCausalLM.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.GemmaForCausalLM.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.GemmaForCausalLM.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"},{anchor:"transformers.GemmaForCausalLM.forward.logits_to_keep",description:`<strong>logits_to_keep</strong> (<code>Union[int, torch.Tensor]</code>, defaults to <code>0</code>) &#x2014;
If an <code>int</code>, compute logits for the last <code>logits_to_keep</code> tokens. If <code>0</code>, calculate logits for all
<code>input_ids</code> (special case). Only last token logits are needed for generation, and calculating them only for that
token can save memory, which becomes pretty significant for long sequences or large vocabulary size.
If a <code>torch.Tensor</code>, must be 1D corresponding to the indices to keep in the sequence length dimension.
This is useful when using packed tensor format (single dimension for batch and sequence length).`,name:"logits_to_keep"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L507",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.CausalLMOutputWithPast"
>transformers.modeling_outputs.CausalLMOutputWithPast</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig"
>GemmaConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Language modeling loss (for next-token prediction).</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks) that can be used (see
<code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.CausalLMOutputWithPast"
>transformers.modeling_outputs.CausalLMOutputWithPast</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),be=new Ue({props:{$$slots:{default:[bs]},$$scope:{ctx:v}}}),ke=new re({props:{anchor:"transformers.GemmaForCausalLM.forward.example",$$slots:{default:[ks]},$$scope:{ctx:v}}}),st=new ee({props:{title:"GemmaForSequenceClassification",local:"transformers.GemmaForSequenceClassification ][ transformers.GemmaForSequenceClassification",headingTag:"h2"}}),rt=new x({props:{name:"class transformers.GemmaForSequenceClassification",anchor:"transformers.GemmaForSequenceClassification",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.GemmaForSequenceClassification.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaForSequenceClassification">GemmaForSequenceClassification</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L583"}}),it=new x({props:{name:"forward",anchor:"transformers.GemmaForSequenceClassification.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.GemmaForSequenceClassification.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.GemmaForSequenceClassification.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.GemmaForSequenceClassification.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.GemmaForSequenceClassification.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.GemmaForSequenceClassification.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.GemmaForSequenceClassification.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size,)</code>, <em>optional</em>) &#x2014;
Labels for computing the sequence classification/regression loss. Indices should be in <code>[0, ..., config.num_labels - 1]</code>. If <code>config.num_labels == 1</code> a regression loss is computed (Mean-Square loss), If
<code>config.num_labels &gt; 1</code> a classification loss is computed (Cross-Entropy).`,name:"labels"},{anchor:"transformers.GemmaForSequenceClassification.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.GemmaForSequenceClassification.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.GemmaForSequenceClassification.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L613",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>transformers.modeling_outputs.SequenceClassifierOutputWithPast</code> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig"
>GemmaConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Classification (or regression if config.num_labels==1) loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, config.num_labels)</code>) — Classification (or regression if config.num_labels==1) scores (before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks) that can be used (see
<code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>transformers.modeling_outputs.SequenceClassifierOutputWithPast</code> or <code>tuple(torch.FloatTensor)</code></p>
`}}),ye=new Ue({props:{$$slots:{default:[ys]},$$scope:{ctx:v}}}),Te=new re({props:{anchor:"transformers.GemmaForSequenceClassification.forward.example",$$slots:{default:[Ts]},$$scope:{ctx:v}}}),ve=new re({props:{anchor:"transformers.GemmaForSequenceClassification.forward.example-2",$$slots:{default:[vs]},$$scope:{ctx:v}}}),lt=new ee({props:{title:"GemmaForTokenClassification",local:"transformers.GemmaForTokenClassification ][ transformers.GemmaForTokenClassification",headingTag:"h2"}}),dt=new x({props:{name:"class transformers.GemmaForTokenClassification",anchor:"transformers.GemmaForTokenClassification",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.GemmaForTokenClassification.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaForTokenClassification">GemmaForTokenClassification</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L683"}}),ct=new x({props:{name:"forward",anchor:"transformers.GemmaForTokenClassification.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"past_key_values",val:": typing.Optional[transformers.cache_utils.Cache] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.GemmaForTokenClassification.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.GemmaForTokenClassification.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.GemmaForTokenClassification.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.GemmaForTokenClassification.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>~cache_utils.Cache</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.GemmaForTokenClassification.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.GemmaForTokenClassification.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size,)</code>, <em>optional</em>) &#x2014;
Labels for computing the sequence classification/regression loss. Indices should be in <code>[0, ..., config.num_labels - 1]</code>. If <code>config.num_labels == 1</code> a regression loss is computed (Mean-Square loss), If
<code>config.num_labels &gt; 1</code> a classification loss is computed (Cross-Entropy).`,name:"labels"},{anchor:"transformers.GemmaForTokenClassification.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.GemmaForTokenClassification.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.GemmaForTokenClassification.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_gemma.py#L707",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.TokenClassifierOutput"
>transformers.modeling_outputs.TokenClassifierOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig"
>GemmaConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided)  — Classification loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.num_labels)</code>) — Classification scores (before SoftMax).</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.TokenClassifierOutput"
>transformers.modeling_outputs.TokenClassifierOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Me=new Ue({props:{$$slots:{default:[Ms]},$$scope:{ctx:v}}}),we=new re({props:{anchor:"transformers.GemmaForTokenClassification.forward.example",$$slots:{default:[ws]},$$scope:{ctx:v}}}),mt=new ee({props:{title:"FlaxGemmaModel",local:"transformers.FlaxGemmaModel ][ transformers.FlaxGemmaModel",headingTag:"h2"}}),pt=new x({props:{name:"class transformers.FlaxGemmaModel",anchor:"transformers.FlaxGemmaModel",parameters:[{name:"config",val:": GemmaConfig"},{name:"input_shape",val:": typing.Tuple = (1, 1)"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxGemmaModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig">GemmaConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxGemmaModel.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code>, or
<code>jax.numpy.bfloat16</code>.</p>
<p>This can be used to enable mixed-precision training or half-precision inference on GPUs or TPUs. If
specified all the computation will be performed with the given <code>dtype</code>.</p>
<p><strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong></p>
<p>If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a> and
<a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_flax_gemma.py#L663"}}),ut=new x({props:{name:"__call__",anchor:"transformers.FlaxGemmaModel.__call__",parameters:[{name:"input_ids",val:""},{name:"attention_mask",val:" = None"},{name:"position_ids",val:" = None"},{name:"params",val:": typing.Optional[dict] = None"},{name:"past_key_values",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"},{name:"train",val:": bool = False"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.FlaxGemmaModel.__call__.input_ids",description:`<strong>input_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, input_ids_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.FlaxGemmaModel.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a></p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p>If <code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).</p>
<p>If you want to change padding behavior, you should read <code>modeling_opt._prepare_decoder_attention_mask</code>
and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more
information on the default strategy.</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"attention_mask"},{anchor:"transformers.FlaxGemmaModel.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, input_ids_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.FlaxGemmaModel.__call__.past_key_values",description:`<strong>past_key_values</strong> (<code>Dict[str, np.ndarray]</code>, <em>optional</em>, returned by <code>init_cache</code> or when passing previous <code>past_key_values</code>) &#x2014;
Dictionary of pre-computed hidden-states (key and values in the attention blocks) that can be used for fast
auto-regressive decoding. Pre-computed key and value hidden-states are of shape <em>[batch_size, max_length]</em>.`,name:"past_key_values"},{anchor:"transformers.FlaxGemmaModel.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxGemmaModel.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxGemmaModel.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_flax_gemma.py#L482",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxBaseModelOutput"
>transformers.modeling_flax_outputs.FlaxBaseModelOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig"
>GemmaConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the model.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxBaseModelOutput"
>transformers.modeling_flax_outputs.FlaxBaseModelOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),$e=new Ue({props:{$$slots:{default:[$s]},$$scope:{ctx:v}}}),xe=new Ue({props:{warning:!0,$$slots:{default:[xs]},$$scope:{ctx:v}}}),Ge=new re({props:{anchor:"transformers.FlaxGemmaModel.__call__.example",$$slots:{default:[Gs]},$$scope:{ctx:v}}}),ht=new ee({props:{title:"FlaxGemmaForCausalLM",local:"transformers.FlaxGemmaForCausalLM ][ transformers.FlaxGemmaForCausalLM",headingTag:"h2"}}),ft=new x({props:{name:"class transformers.FlaxGemmaForCausalLM",anchor:"transformers.FlaxGemmaForCausalLM",parameters:[{name:"config",val:": GemmaConfig"},{name:"input_shape",val:": typing.Tuple = (1, 1)"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxGemmaForCausalLM.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig">GemmaConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxGemmaForCausalLM.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code>, or
<code>jax.numpy.bfloat16</code>.</p>
<p>This can be used to enable mixed-precision training or half-precision inference on GPUs or TPUs. If
specified all the computation will be performed with the given <code>dtype</code>.</p>
<p><strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong></p>
<p>If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a> and
<a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_flax_gemma.py#L731"}}),gt=new x({props:{name:"__call__",anchor:"transformers.FlaxGemmaForCausalLM.__call__",parameters:[{name:"input_ids",val:""},{name:"attention_mask",val:" = None"},{name:"position_ids",val:" = None"},{name:"params",val:": typing.Optional[dict] = None"},{name:"past_key_values",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"},{name:"train",val:": bool = False"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"transformers.FlaxGemmaForCausalLM.__call__.input_ids",description:`<strong>input_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, input_ids_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.FlaxGemmaForCausalLM.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a></p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p>If <code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).</p>
<p>If you want to change padding behavior, you should read <code>modeling_opt._prepare_decoder_attention_mask</code>
and modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the paper</a> for more
information on the default strategy.</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"attention_mask"},{anchor:"transformers.FlaxGemmaForCausalLM.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, input_ids_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.FlaxGemmaForCausalLM.__call__.past_key_values",description:`<strong>past_key_values</strong> (<code>Dict[str, np.ndarray]</code>, <em>optional</em>, returned by <code>init_cache</code> or when passing previous <code>past_key_values</code>) &#x2014;
Dictionary of pre-computed hidden-states (key and values in the attention blocks) that can be used for fast
auto-regressive decoding. Pre-computed key and value hidden-states are of shape <em>[batch_size, max_length]</em>.`,name:"past_key_values"},{anchor:"transformers.FlaxGemmaForCausalLM.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxGemmaForCausalLM.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxGemmaForCausalLM.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gemma/modeling_flax_gemma.py#L482",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxMaskedLMOutput"
>transformers.modeling_flax_outputs.FlaxMaskedLMOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/gemma#transformers.GemmaConfig"
>GemmaConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>logits</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxMaskedLMOutput"
>transformers.modeling_flax_outputs.FlaxMaskedLMOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Ce=new Ue({props:{$$slots:{default:[Cs]},$$scope:{ctx:v}}}),ze=new Ue({props:{warning:!0,$$slots:{default:[zs]},$$scope:{ctx:v}}}),Fe=new re({props:{anchor:"transformers.FlaxGemmaForCausalLM.__call__.example",$$slots:{default:[Fs]},$$scope:{ctx:v}}}),_t=new us({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/gemma.md"}}),{c(){t=d("meta"),y=o(),r=d("p"),m=o(),h(T.$$.fragment),s=o(),h(M.$$.fragment),gn=o(),Je=d("p"),Je.innerHTML=ma,_n=o(),Ie=d("p"),Ie.textContent=pa,bn=o(),We=d("p"),We.textContent=ua,kn=o(),qe=d("p"),qe.innerHTML=ha,yn=o(),Le=d("p"),Le.textContent=fa,Tn=o(),Ze=d("ul"),Ze.innerHTML=ga,vn=o(),Ve=d("p"),Ve.innerHTML=_a,Mn=o(),h(He.$$.fragment),wn=o(),D=d("div"),h(Pe.$$.fragment),Bn=o(),wt=d("p"),wt.innerHTML=ba,Rn=o(),h(le.$$.fragment),$n=o(),h(Ne.$$.fragment),xn=o(),G=d("div"),h(Se.$$.fragment),Xn=o(),$t=d("p"),$t.textContent=ka,En=o(),de=d("div"),h(Be.$$.fragment),Yn=o(),xt=d("p"),xt.textContent=ya,Qn=o(),Y=d("div"),h(Re.$$.fragment),An=o(),Gt=d("p"),Gt.textContent=Ta,Dn=o(),h(ce.$$.fragment),On=o(),Ct=d("p"),Ct.textContent=va,Kn=o(),me=d("div"),h(Xe.$$.fragment),eo=o(),zt=d("p"),zt.innerHTML=Ma,to=o(),pe=d("div"),h(Ee.$$.fragment),no=o(),Ft=d("p"),Ft.textContent=wa,oo=o(),ue=d("div"),h(Ye.$$.fragment),ao=o(),jt=d("p"),jt.textContent=$a,so=o(),he=d("div"),h(Qe.$$.fragment),ro=o(),Ut=d("p"),Ut.textContent=xa,Gn=o(),h(Ae.$$.fragment),Cn=o(),C=d("div"),h(De.$$.fragment),io=o(),Jt=d("p"),Jt.textContent=Ga,lo=o(),It=d("p"),It.innerHTML=Ca,co=o(),h(fe.$$.fragment),mo=o(),Wt=d("p"),Wt.innerHTML=za,po=o(),qt=d("p"),qt.innerHTML=Fa,uo=o(),ge=d("div"),h(Oe.$$.fragment),ho=o(),Lt=d("p"),Lt.innerHTML=ja,zn=o(),h(Ke.$$.fragment),Fn=o(),q=d("div"),h(et.$$.fragment),fo=o(),Zt=d("p"),Zt.textContent=Ua,go=o(),Vt=d("p"),Vt.innerHTML=Ja,_o=o(),Ht=d("p"),Ht.innerHTML=Ia,bo=o(),te=d("div"),h(tt.$$.fragment),ko=o(),Pt=d("p"),Pt.innerHTML=Wa,yo=o(),h(_e.$$.fragment),jn=o(),h(nt.$$.fragment),Un=o(),L=d("div"),h(ot.$$.fragment),To=o(),Nt=d("p"),Nt.textContent=qa,vo=o(),St=d("p"),St.innerHTML=La,Mo=o(),Bt=d("p"),Bt.innerHTML=Za,wo=o(),Q=d("div"),h(at.$$.fragment),$o=o(),Rt=d("p"),Rt.innerHTML=Va,xo=o(),h(be.$$.fragment),Go=o(),h(ke.$$.fragment),Jn=o(),h(st.$$.fragment),In=o(),z=d("div"),h(rt.$$.fragment),Co=o(),Xt=d("p"),Xt.textContent=Ha,zo=o(),Et=d("p"),Et.innerHTML=Pa,Fo=o(),Yt=d("p"),Yt.innerHTML=Na,jo=o(),Qt=d("p"),Qt.innerHTML=Sa,Uo=o(),At=d("p"),At.innerHTML=Ba,Jo=o(),V=d("div"),h(it.$$.fragment),Io=o(),Dt=d("p"),Dt.innerHTML=Ra,Wo=o(),h(ye.$$.fragment),qo=o(),h(Te.$$.fragment),Lo=o(),h(ve.$$.fragment),Wn=o(),h(lt.$$.fragment),qn=o(),Z=d("div"),h(dt.$$.fragment),Zo=o(),Ot=d("p"),Ot.textContent=Xa,Vo=o(),Kt=d("p"),Kt.innerHTML=Ea,Ho=o(),en=d("p"),en.innerHTML=Ya,Po=o(),A=d("div"),h(ct.$$.fragment),No=o(),tn=d("p"),tn.innerHTML=Qa,So=o(),h(Me.$$.fragment),Bo=o(),h(we.$$.fragment),Ln=o(),h(mt.$$.fragment),Zn=o(),F=d("div"),h(pt.$$.fragment),Ro=o(),nn=d("p"),nn.textContent=Aa,Xo=o(),on=d("p"),on.innerHTML=Da,Eo=o(),an=d("p"),an.innerHTML=Oa,Yo=o(),sn=d("p"),sn.textContent=Ka,Qo=o(),rn=d("ul"),rn.innerHTML=es,Ao=o(),H=d("div"),h(ut.$$.fragment),Do=o(),ln=d("p"),ln.innerHTML=ts,Oo=o(),h($e.$$.fragment),Ko=o(),h(xe.$$.fragment),ea=o(),h(Ge.$$.fragment),Vn=o(),h(ht.$$.fragment),Hn=o(),j=d("div"),h(ft.$$.fragment),ta=o(),dn=d("p"),dn.textContent=ns,na=o(),cn=d("p"),cn.innerHTML=os,oa=o(),mn=d("p"),mn.innerHTML=as,aa=o(),pn=d("p"),pn.textContent=ss,sa=o(),un=d("ul"),un.innerHTML=rs,ra=o(),P=d("div"),h(gt.$$.fragment),ia=o(),hn=d("p"),hn.innerHTML=is,la=o(),h(Ce.$$.fragment),da=o(),h(ze.$$.fragment),ca=o(),h(Fe.$$.fragment),Pn=o(),h(_t.$$.fragment),Nn=o(),fn=d("p"),this.h()},l(e){const i=ps("svelte-u9bgzb",document.head);t=c(i,"META",{name:!0,content:!0}),i.forEach(l),y=a(e),r=c(e,"P",{}),w(r).forEach(l),m=a(e),f(T.$$.fragment,e),s=a(e),f(M.$$.fragment,e),gn=a(e),Je=c(e,"P",{"data-svelte-h":!0}),u(Je)!=="svelte-1ieup5f"&&(Je.innerHTML=ma),_n=a(e),Ie=c(e,"P",{"data-svelte-h":!0}),u(Ie)!=="svelte-99cpdj"&&(Ie.textContent=pa),bn=a(e),We=c(e,"P",{"data-svelte-h":!0}),u(We)!=="svelte-e5r8wp"&&(We.textContent=ua),kn=a(e),qe=c(e,"P",{"data-svelte-h":!0}),u(qe)!=="svelte-1eyopk6"&&(qe.innerHTML=ha),yn=a(e),Le=c(e,"P",{"data-svelte-h":!0}),u(Le)!=="svelte-k6v9m1"&&(Le.textContent=fa),Tn=a(e),Ze=c(e,"UL",{"data-svelte-h":!0}),u(Ze)!=="svelte-1vk3ps1"&&(Ze.innerHTML=ga),vn=a(e),Ve=c(e,"P",{"data-svelte-h":!0}),u(Ve)!=="svelte-jx67hz"&&(Ve.innerHTML=_a),Mn=a(e),f(He.$$.fragment,e),wn=a(e),D=c(e,"DIV",{class:!0});var ae=w(D);f(Pe.$$.fragment,ae),Bn=a(ae),wt=c(ae,"P",{"data-svelte-h":!0}),u(wt)!=="svelte-bnymbt"&&(wt.innerHTML=ba),Rn=a(ae),f(le.$$.fragment,ae),ae.forEach(l),$n=a(e),f(Ne.$$.fragment,e),xn=a(e),G=c(e,"DIV",{class:!0});var U=w(G);f(Se.$$.fragment,U),Xn=a(U),$t=c(U,"P",{"data-svelte-h":!0}),u($t)!=="svelte-33lcdu"&&($t.textContent=ka),En=a(U),de=c(U,"DIV",{class:!0});var bt=w(de);f(Be.$$.fragment,bt),Yn=a(bt),xt=c(bt,"P",{"data-svelte-h":!0}),u(xt)!=="svelte-b3k2yi"&&(xt.textContent=ya),bt.forEach(l),Qn=a(U),Y=c(U,"DIV",{class:!0});var O=w(Y);f(Re.$$.fragment,O),An=a(O),Gt=c(O,"P",{"data-svelte-h":!0}),u(Gt)!=="svelte-13bfd60"&&(Gt.textContent=Ta),Dn=a(O),f(ce.$$.fragment,O),On=a(O),Ct=c(O,"P",{"data-svelte-h":!0}),u(Ct)!=="svelte-wtrslu"&&(Ct.textContent=va),O.forEach(l),Kn=a(U),me=c(U,"DIV",{class:!0});var kt=w(me);f(Xe.$$.fragment,kt),eo=a(kt),zt=c(kt,"P",{"data-svelte-h":!0}),u(zt)!=="svelte-1f4f5kp"&&(zt.innerHTML=Ma),kt.forEach(l),to=a(U),pe=c(U,"DIV",{class:!0});var yt=w(pe);f(Ee.$$.fragment,yt),no=a(yt),Ft=c(yt,"P",{"data-svelte-h":!0}),u(Ft)!=="svelte-iwelht"&&(Ft.textContent=wa),yt.forEach(l),oo=a(U),ue=c(U,"DIV",{class:!0});var Tt=w(ue);f(Ye.$$.fragment,Tt),ao=a(Tt),jt=c(Tt,"P",{"data-svelte-h":!0}),u(jt)!=="svelte-1slb66l"&&(jt.textContent=$a),Tt.forEach(l),so=a(U),he=c(U,"DIV",{class:!0});var vt=w(he);f(Qe.$$.fragment,vt),ro=a(vt),Ut=c(vt,"P",{"data-svelte-h":!0}),u(Ut)!=="svelte-15czuwn"&&(Ut.textContent=xa),vt.forEach(l),U.forEach(l),Gn=a(e),f(Ae.$$.fragment,e),Cn=a(e),C=c(e,"DIV",{class:!0});var J=w(C);f(De.$$.fragment,J),io=a(J),Jt=c(J,"P",{"data-svelte-h":!0}),u(Jt)!=="svelte-m9hkz6"&&(Jt.textContent=Ga),lo=a(J),It=c(J,"P",{"data-svelte-h":!0}),u(It)!=="svelte-1l3z03t"&&(It.innerHTML=Ca),co=a(J),f(fe.$$.fragment,J),mo=a(J),Wt=c(J,"P",{"data-svelte-h":!0}),u(Wt)!=="svelte-cnb6q1"&&(Wt.innerHTML=za),po=a(J),qt=c(J,"P",{"data-svelte-h":!0}),u(qt)!=="svelte-1ndfe3e"&&(qt.innerHTML=Fa),uo=a(J),ge=c(J,"DIV",{class:!0});var Mt=w(ge);f(Oe.$$.fragment,Mt),ho=a(Mt),Lt=c(Mt,"P",{"data-svelte-h":!0}),u(Lt)!=="svelte-nfci2w"&&(Lt.innerHTML=ja),Mt.forEach(l),J.forEach(l),zn=a(e),f(Ke.$$.fragment,e),Fn=a(e),q=c(e,"DIV",{class:!0});var B=w(q);f(et.$$.fragment,B),fo=a(B),Zt=c(B,"P",{"data-svelte-h":!0}),u(Zt)!=="svelte-1a0hztx"&&(Zt.textContent=Ua),go=a(B),Vt=c(B,"P",{"data-svelte-h":!0}),u(Vt)!=="svelte-u3dlub"&&(Vt.innerHTML=Ja),_o=a(B),Ht=c(B,"P",{"data-svelte-h":!0}),u(Ht)!=="svelte-hswkmf"&&(Ht.innerHTML=Ia),bo=a(B),te=c(B,"DIV",{class:!0});var se=w(te);f(tt.$$.fragment,se),ko=a(se),Pt=c(se,"P",{"data-svelte-h":!0}),u(Pt)!=="svelte-4dce9v"&&(Pt.innerHTML=Wa),yo=a(se),f(_e.$$.fragment,se),se.forEach(l),B.forEach(l),jn=a(e),f(nt.$$.fragment,e),Un=a(e),L=c(e,"DIV",{class:!0});var R=w(L);f(ot.$$.fragment,R),To=a(R),Nt=c(R,"P",{"data-svelte-h":!0}),u(Nt)!=="svelte-71v2ou"&&(Nt.textContent=qa),vo=a(R),St=c(R,"P",{"data-svelte-h":!0}),u(St)!=="svelte-u3dlub"&&(St.innerHTML=La),Mo=a(R),Bt=c(R,"P",{"data-svelte-h":!0}),u(Bt)!=="svelte-hswkmf"&&(Bt.innerHTML=Za),wo=a(R),Q=c(R,"DIV",{class:!0});var K=w(Q);f(at.$$.fragment,K),$o=a(K),Rt=c(K,"P",{"data-svelte-h":!0}),u(Rt)!=="svelte-y3x8az"&&(Rt.innerHTML=Va),xo=a(K),f(be.$$.fragment,K),Go=a(K),f(ke.$$.fragment,K),K.forEach(l),R.forEach(l),Jn=a(e),f(st.$$.fragment,e),In=a(e),z=c(e,"DIV",{class:!0});var I=w(z);f(rt.$$.fragment,I),Co=a(I),Xt=c(I,"P",{"data-svelte-h":!0}),u(Xt)!=="svelte-1140lml"&&(Xt.textContent=Ha),zo=a(I),Et=c(I,"P",{"data-svelte-h":!0}),u(Et)!=="svelte-1wkmn6c"&&(Et.innerHTML=Pa),Fo=a(I),Yt=c(I,"P",{"data-svelte-h":!0}),u(Yt)!=="svelte-10ugs3m"&&(Yt.innerHTML=Na),jo=a(I),Qt=c(I,"P",{"data-svelte-h":!0}),u(Qt)!=="svelte-u3dlub"&&(Qt.innerHTML=Sa),Uo=a(I),At=c(I,"P",{"data-svelte-h":!0}),u(At)!=="svelte-hswkmf"&&(At.innerHTML=Ba),Jo=a(I),V=c(I,"DIV",{class:!0});var X=w(V);f(it.$$.fragment,X),Io=a(X),Dt=c(X,"P",{"data-svelte-h":!0}),u(Dt)!=="svelte-1vd4o7x"&&(Dt.innerHTML=Ra),Wo=a(X),f(ye.$$.fragment,X),qo=a(X),f(Te.$$.fragment,X),Lo=a(X),f(ve.$$.fragment,X),X.forEach(l),I.forEach(l),Wn=a(e),f(lt.$$.fragment,e),qn=a(e),Z=c(e,"DIV",{class:!0});var E=w(Z);f(dt.$$.fragment,E),Zo=a(E),Ot=c(E,"P",{"data-svelte-h":!0}),u(Ot)!=="svelte-cm3k2r"&&(Ot.textContent=Xa),Vo=a(E),Kt=c(E,"P",{"data-svelte-h":!0}),u(Kt)!=="svelte-u3dlub"&&(Kt.innerHTML=Ea),Ho=a(E),en=c(E,"P",{"data-svelte-h":!0}),u(en)!=="svelte-hswkmf"&&(en.innerHTML=Ya),Po=a(E),A=c(E,"DIV",{class:!0});var je=w(A);f(ct.$$.fragment,je),No=a(je),tn=c(je,"P",{"data-svelte-h":!0}),u(tn)!=="svelte-sr9tsr"&&(tn.innerHTML=Qa),So=a(je),f(Me.$$.fragment,je),Bo=a(je),f(we.$$.fragment,je),je.forEach(l),E.forEach(l),Ln=a(e),f(mt.$$.fragment,e),Zn=a(e),F=c(e,"DIV",{class:!0});var N=w(F);f(pt.$$.fragment,N),Ro=a(N),nn=c(N,"P",{"data-svelte-h":!0}),u(nn)!=="svelte-toiqik"&&(nn.textContent=Aa),Xo=a(N),on=c(N,"P",{"data-svelte-h":!0}),u(on)!=="svelte-11z45y7"&&(on.innerHTML=Da),Eo=a(N),an=c(N,"P",{"data-svelte-h":!0}),u(an)!=="svelte-idybz1"&&(an.innerHTML=Oa),Yo=a(N),sn=c(N,"P",{"data-svelte-h":!0}),u(sn)!=="svelte-1pplc4a"&&(sn.textContent=Ka),Qo=a(N),rn=c(N,"UL",{"data-svelte-h":!0}),u(rn)!=="svelte-1w7z84m"&&(rn.innerHTML=es),Ao=a(N),H=c(N,"DIV",{class:!0});var ne=w(H);f(ut.$$.fragment,ne),Do=a(ne),ln=c(ne,"P",{"data-svelte-h":!0}),u(ln)!=="svelte-1y60y2q"&&(ln.innerHTML=ts),Oo=a(ne),f($e.$$.fragment,ne),Ko=a(ne),f(xe.$$.fragment,ne),ea=a(ne),f(Ge.$$.fragment,ne),ne.forEach(l),N.forEach(l),Vn=a(e),f(ht.$$.fragment,e),Hn=a(e),j=c(e,"DIV",{class:!0});var S=w(j);f(ft.$$.fragment,S),ta=a(S),dn=c(S,"P",{"data-svelte-h":!0}),u(dn)!=="svelte-3xz13p"&&(dn.textContent=ns),na=a(S),cn=c(S,"P",{"data-svelte-h":!0}),u(cn)!=="svelte-11z45y7"&&(cn.innerHTML=os),oa=a(S),mn=c(S,"P",{"data-svelte-h":!0}),u(mn)!=="svelte-idybz1"&&(mn.innerHTML=as),aa=a(S),pn=c(S,"P",{"data-svelte-h":!0}),u(pn)!=="svelte-1pplc4a"&&(pn.textContent=ss),sa=a(S),un=c(S,"UL",{"data-svelte-h":!0}),u(un)!=="svelte-1w7z84m"&&(un.innerHTML=rs),ra=a(S),P=c(S,"DIV",{class:!0});var oe=w(P);f(gt.$$.fragment,oe),ia=a(oe),hn=c(oe,"P",{"data-svelte-h":!0}),u(hn)!=="svelte-1y60y2q"&&(hn.innerHTML=is),la=a(oe),f(Ce.$$.fragment,oe),da=a(oe),f(ze.$$.fragment,oe),ca=a(oe),f(Fe.$$.fragment,oe),oe.forEach(l),S.forEach(l),Pn=a(e),f(_t.$$.fragment,e),Nn=a(e),fn=c(e,"P",{}),w(fn).forEach(l),this.h()},h(){$(t,"name","hf:doc:metadata"),$(t,"content",Us),$(D,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(de,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(Y,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(me,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(pe,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(ue,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(he,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(G,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(ge,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(C,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(te,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(q,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(Q,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(L,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(V,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(z,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(A,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(Z,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(H,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(F,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(P,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),$(j,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,i){n(document.head,t),p(e,y,i),p(e,r,i),p(e,m,i),g(T,e,i),p(e,s,i),g(M,e,i),p(e,gn,i),p(e,Je,i),p(e,_n,i),p(e,Ie,i),p(e,bn,i),p(e,We,i),p(e,kn,i),p(e,qe,i),p(e,yn,i),p(e,Le,i),p(e,Tn,i),p(e,Ze,i),p(e,vn,i),p(e,Ve,i),p(e,Mn,i),g(He,e,i),p(e,wn,i),p(e,D,i),g(Pe,D,null),n(D,Bn),n(D,wt),n(D,Rn),g(le,D,null),p(e,$n,i),g(Ne,e,i),p(e,xn,i),p(e,G,i),g(Se,G,null),n(G,Xn),n(G,$t),n(G,En),n(G,de),g(Be,de,null),n(de,Yn),n(de,xt),n(G,Qn),n(G,Y),g(Re,Y,null),n(Y,An),n(Y,Gt),n(Y,Dn),g(ce,Y,null),n(Y,On),n(Y,Ct),n(G,Kn),n(G,me),g(Xe,me,null),n(me,eo),n(me,zt),n(G,to),n(G,pe),g(Ee,pe,null),n(pe,no),n(pe,Ft),n(G,oo),n(G,ue),g(Ye,ue,null),n(ue,ao),n(ue,jt),n(G,so),n(G,he),g(Qe,he,null),n(he,ro),n(he,Ut),p(e,Gn,i),g(Ae,e,i),p(e,Cn,i),p(e,C,i),g(De,C,null),n(C,io),n(C,Jt),n(C,lo),n(C,It),n(C,co),g(fe,C,null),n(C,mo),n(C,Wt),n(C,po),n(C,qt),n(C,uo),n(C,ge),g(Oe,ge,null),n(ge,ho),n(ge,Lt),p(e,zn,i),g(Ke,e,i),p(e,Fn,i),p(e,q,i),g(et,q,null),n(q,fo),n(q,Zt),n(q,go),n(q,Vt),n(q,_o),n(q,Ht),n(q,bo),n(q,te),g(tt,te,null),n(te,ko),n(te,Pt),n(te,yo),g(_e,te,null),p(e,jn,i),g(nt,e,i),p(e,Un,i),p(e,L,i),g(ot,L,null),n(L,To),n(L,Nt),n(L,vo),n(L,St),n(L,Mo),n(L,Bt),n(L,wo),n(L,Q),g(at,Q,null),n(Q,$o),n(Q,Rt),n(Q,xo),g(be,Q,null),n(Q,Go),g(ke,Q,null),p(e,Jn,i),g(st,e,i),p(e,In,i),p(e,z,i),g(rt,z,null),n(z,Co),n(z,Xt),n(z,zo),n(z,Et),n(z,Fo),n(z,Yt),n(z,jo),n(z,Qt),n(z,Uo),n(z,At),n(z,Jo),n(z,V),g(it,V,null),n(V,Io),n(V,Dt),n(V,Wo),g(ye,V,null),n(V,qo),g(Te,V,null),n(V,Lo),g(ve,V,null),p(e,Wn,i),g(lt,e,i),p(e,qn,i),p(e,Z,i),g(dt,Z,null),n(Z,Zo),n(Z,Ot),n(Z,Vo),n(Z,Kt),n(Z,Ho),n(Z,en),n(Z,Po),n(Z,A),g(ct,A,null),n(A,No),n(A,tn),n(A,So),g(Me,A,null),n(A,Bo),g(we,A,null),p(e,Ln,i),g(mt,e,i),p(e,Zn,i),p(e,F,i),g(pt,F,null),n(F,Ro),n(F,nn),n(F,Xo),n(F,on),n(F,Eo),n(F,an),n(F,Yo),n(F,sn),n(F,Qo),n(F,rn),n(F,Ao),n(F,H),g(ut,H,null),n(H,Do),n(H,ln),n(H,Oo),g($e,H,null),n(H,Ko),g(xe,H,null),n(H,ea),g(Ge,H,null),p(e,Vn,i),g(ht,e,i),p(e,Hn,i),p(e,j,i),g(ft,j,null),n(j,ta),n(j,dn),n(j,na),n(j,cn),n(j,oa),n(j,mn),n(j,aa),n(j,pn),n(j,sa),n(j,un),n(j,ra),n(j,P),g(gt,P,null),n(P,ia),n(P,hn),n(P,la),g(Ce,P,null),n(P,da),g(ze,P,null),n(P,ca),g(Fe,P,null),p(e,Pn,i),g(_t,e,i),p(e,Nn,i),p(e,fn,i),Sn=!0},p(e,[i]){const ae={};i&2&&(ae.$$scope={dirty:i,ctx:e}),le.$set(ae);const U={};i&2&&(U.$$scope={dirty:i,ctx:e}),ce.$set(U);const bt={};i&2&&(bt.$$scope={dirty:i,ctx:e}),fe.$set(bt);const O={};i&2&&(O.$$scope={dirty:i,ctx:e}),_e.$set(O);const kt={};i&2&&(kt.$$scope={dirty:i,ctx:e}),be.$set(kt);const yt={};i&2&&(yt.$$scope={dirty:i,ctx:e}),ke.$set(yt);const Tt={};i&2&&(Tt.$$scope={dirty:i,ctx:e}),ye.$set(Tt);const vt={};i&2&&(vt.$$scope={dirty:i,ctx:e}),Te.$set(vt);const J={};i&2&&(J.$$scope={dirty:i,ctx:e}),ve.$set(J);const Mt={};i&2&&(Mt.$$scope={dirty:i,ctx:e}),Me.$set(Mt);const B={};i&2&&(B.$$scope={dirty:i,ctx:e}),we.$set(B);const se={};i&2&&(se.$$scope={dirty:i,ctx:e}),$e.$set(se);const R={};i&2&&(R.$$scope={dirty:i,ctx:e}),xe.$set(R);const K={};i&2&&(K.$$scope={dirty:i,ctx:e}),Ge.$set(K);const I={};i&2&&(I.$$scope={dirty:i,ctx:e}),Ce.$set(I);const X={};i&2&&(X.$$scope={dirty:i,ctx:e}),ze.$set(X);const E={};i&2&&(E.$$scope={dirty:i,ctx:e}),Fe.$set(E)},i(e){Sn||(_(T.$$.fragment,e),_(M.$$.fragment,e),_(He.$$.fragment,e),_(Pe.$$.fragment,e),_(le.$$.fragment,e),_(Ne.$$.fragment,e),_(Se.$$.fragment,e),_(Be.$$.fragment,e),_(Re.$$.fragment,e),_(ce.$$.fragment,e),_(Xe.$$.fragment,e),_(Ee.$$.fragment,e),_(Ye.$$.fragment,e),_(Qe.$$.fragment,e),_(Ae.$$.fragment,e),_(De.$$.fragment,e),_(fe.$$.fragment,e),_(Oe.$$.fragment,e),_(Ke.$$.fragment,e),_(et.$$.fragment,e),_(tt.$$.fragment,e),_(_e.$$.fragment,e),_(nt.$$.fragment,e),_(ot.$$.fragment,e),_(at.$$.fragment,e),_(be.$$.fragment,e),_(ke.$$.fragment,e),_(st.$$.fragment,e),_(rt.$$.fragment,e),_(it.$$.fragment,e),_(ye.$$.fragment,e),_(Te.$$.fragment,e),_(ve.$$.fragment,e),_(lt.$$.fragment,e),_(dt.$$.fragment,e),_(ct.$$.fragment,e),_(Me.$$.fragment,e),_(we.$$.fragment,e),_(mt.$$.fragment,e),_(pt.$$.fragment,e),_(ut.$$.fragment,e),_($e.$$.fragment,e),_(xe.$$.fragment,e),_(Ge.$$.fragment,e),_(ht.$$.fragment,e),_(ft.$$.fragment,e),_(gt.$$.fragment,e),_(Ce.$$.fragment,e),_(ze.$$.fragment,e),_(Fe.$$.fragment,e),_(_t.$$.fragment,e),Sn=!0)},o(e){b(T.$$.fragment,e),b(M.$$.fragment,e),b(He.$$.fragment,e),b(Pe.$$.fragment,e),b(le.$$.fragment,e),b(Ne.$$.fragment,e),b(Se.$$.fragment,e),b(Be.$$.fragment,e),b(Re.$$.fragment,e),b(ce.$$.fragment,e),b(Xe.$$.fragment,e),b(Ee.$$.fragment,e),b(Ye.$$.fragment,e),b(Qe.$$.fragment,e),b(Ae.$$.fragment,e),b(De.$$.fragment,e),b(fe.$$.fragment,e),b(Oe.$$.fragment,e),b(Ke.$$.fragment,e),b(et.$$.fragment,e),b(tt.$$.fragment,e),b(_e.$$.fragment,e),b(nt.$$.fragment,e),b(ot.$$.fragment,e),b(at.$$.fragment,e),b(be.$$.fragment,e),b(ke.$$.fragment,e),b(st.$$.fragment,e),b(rt.$$.fragment,e),b(it.$$.fragment,e),b(ye.$$.fragment,e),b(Te.$$.fragment,e),b(ve.$$.fragment,e),b(lt.$$.fragment,e),b(dt.$$.fragment,e),b(ct.$$.fragment,e),b(Me.$$.fragment,e),b(we.$$.fragment,e),b(mt.$$.fragment,e),b(pt.$$.fragment,e),b(ut.$$.fragment,e),b($e.$$.fragment,e),b(xe.$$.fragment,e),b(Ge.$$.fragment,e),b(ht.$$.fragment,e),b(ft.$$.fragment,e),b(gt.$$.fragment,e),b(Ce.$$.fragment,e),b(ze.$$.fragment,e),b(Fe.$$.fragment,e),b(_t.$$.fragment,e),Sn=!1},d(e){e&&(l(y),l(r),l(m),l(s),l(gn),l(Je),l(_n),l(Ie),l(bn),l(We),l(kn),l(qe),l(yn),l(Le),l(Tn),l(Ze),l(vn),l(Ve),l(Mn),l(wn),l(D),l($n),l(xn),l(G),l(Gn),l(Cn),l(C),l(zn),l(Fn),l(q),l(jn),l(Un),l(L),l(Jn),l(In),l(z),l(Wn),l(qn),l(Z),l(Ln),l(Zn),l(F),l(Vn),l(Hn),l(j),l(Pn),l(Nn),l(fn)),l(t),k(T,e),k(M,e),k(He,e),k(Pe),k(le),k(Ne,e),k(Se),k(Be),k(Re),k(ce),k(Xe),k(Ee),k(Ye),k(Qe),k(Ae,e),k(De),k(fe),k(Oe),k(Ke,e),k(et),k(tt),k(_e),k(nt,e),k(ot),k(at),k(be),k(ke),k(st,e),k(rt),k(it),k(ye),k(Te),k(ve),k(lt,e),k(dt),k(ct),k(Me),k(we),k(mt,e),k(pt),k(ut),k($e),k(xe),k(Ge),k(ht,e),k(ft),k(gt),k(Ce),k(ze),k(Fe),k(_t,e)}}}const Us='{"title":"Gemma","local":"gemma","sections":[{"title":"개요","local":"overview","sections":[],"depth":2},{"title":"GemmaConfig","local":"transformers.GemmaConfig ][ transformers.GemmaConfig","sections":[],"depth":2},{"title":"GemmaTokenizer","local":"transformers.GemmaTokenizer ][ transformers.GemmaTokenizer","sections":[],"depth":2},{"title":"GemmaTokenizerFast","local":"transformers.GemmaTokenizerFast ][ transformers.GemmaTokenizerFast","sections":[],"depth":2},{"title":"GemmaModel","local":"transformers.GemmaModel ][ transformers.GemmaModel","sections":[],"depth":2},{"title":"GemmaForCausalLM","local":"transformers.GemmaForCausalLM ][ transformers.GemmaForCausalLM","sections":[],"depth":2},{"title":"GemmaForSequenceClassification","local":"transformers.GemmaForSequenceClassification ][ transformers.GemmaForSequenceClassification","sections":[],"depth":2},{"title":"GemmaForTokenClassification","local":"transformers.GemmaForTokenClassification ][ transformers.GemmaForTokenClassification","sections":[],"depth":2},{"title":"FlaxGemmaModel","local":"transformers.FlaxGemmaModel ][ transformers.FlaxGemmaModel","sections":[],"depth":2},{"title":"FlaxGemmaForCausalLM","local":"transformers.FlaxGemmaForCausalLM ][ transformers.FlaxGemmaForCausalLM","sections":[],"depth":2}],"depth":1}';function Js(v){return ds(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Ps extends cs{constructor(t){super(),ms(this,t,Js,js,ls,{})}}export{Ps as component};
