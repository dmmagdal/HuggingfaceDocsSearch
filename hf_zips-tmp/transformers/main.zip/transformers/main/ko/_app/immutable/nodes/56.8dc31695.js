import{s as De,n as Ne,o as Oe}from"../chunks/scheduler.bdbef820.js";import{S as Ye,i as Ke,g as i,s,r as d,A as et,h as l,f as n,c as o,j as E,u as m,x as g,k as Z,y as r,a,v as h,d as u,t as f,w as _}from"../chunks/index.33f81d56.js";import{D as ee}from"../chunks/Docstring.abcbe1ac.js";import{C as Pe}from"../chunks/CodeBlock.3bad7fc9.js";import{H as te,E as tt}from"../chunks/getInferenceSnippets.64cd9466.js";function nt(Ce){let b,ne,Y,se,v,oe,w,ae,U,Qe='BARTpho 모델은 Nguyen Luong Tran, Duong Minh Le, Dat Quoc Nguyen에 의해 <a href="https://huggingface.co/papers/2109.09701" rel="nofollow">BARTpho: Pre-trained Sequence-to-Sequence Models for Vietnamese</a>에서 제안되었습니다.',re,B,Le="이 논문의 초록은 다음과 같습니다:",ie,$,Ie=`<em>우리는 BARTpho_word와 BARTpho_syllable의 두 가지 버전으로 BARTpho를 제시합니다.
이는 베트남어를 위해 사전훈련된 최초의 대규모 단일 언어 시퀀스-투-시퀀스 모델입니다.
우리의 BARTpho는 시퀀스-투-시퀀스 디노이징 모델인 BART의 “large” 아키텍처와 사전훈련 방식을 사용하여, 생성형 NLP 작업에 특히 적합합니다.
베트남어 텍스트 요약의 다운스트림 작업 실험에서,
자동 및 인간 평가 모두에서 BARTpho가 강력한 기준인 mBART를 능가하고 최신 성능을 개선했음을 보여줍니다.
우리는 향후 연구 및 베트남어 생성형 NLP 작업의 응용을 촉진하기 위해 BARTpho를 공개합니다.</em>`,le,R,Ae='이 모델은 <a href="https://huggingface.co/dqnguyen" rel="nofollow">dqnguyen</a>이 기여했습니다. 원본 코드는 <a href="https://github.com/VinAIResearch/BARTpho" rel="nofollow">여기</a>에서 찾을 수 있습니다.',pe,z,ce,j,de,J,me,x,We=`<li>mBART를 따르며, BARTpho는 BART의 “large” 아키텍처에 인코더와 디코더의 상단에 추가적인 레이어 정규화 레이어를 사용합니다.
따라서 <a href="bart">BART 문서</a>에 있는 사용 예시를 BARTpho에 맞게 적용하려면
BART 전용 클래스를 mBART 전용 클래스로 대체하여 조정해야 합니다.
예를 들어:</li>`,ge,q,he,C,He=`<li>이 구현은 토큰화만을 위한 것입니다: “monolingual_vocab_file”은 다국어
XLM-RoBERTa에서 제공되는 사전훈련된 SentencePiece 모델
“vocab_file”에서 추출된 베트남어 전용 유형으로 구성됩니다.
다른 언어들도 이 사전훈련된 다국어 SentencePiece 모델 “vocab_file”을 하위 단어 분할에 사용하면, 자신의 언어 전용 “monolingual_vocab_file”과 함께 BartphoTokenizer를 재사용할 수 있습니다.</li>`,ue,Q,fe,p,L,ve,V,Xe='Adapted from <code>XLMRobertaTokenizer</code>. Based on <a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a>.',we,G,Ee=`This tokenizer inherits from <code>PreTrainedTokenizer</code> which contains most of the main methods. Users should refer to
this superclass for more information regarding those methods.`,Ue,k,I,Be,S,Ze=`Build model inputs from a sequence or a pair of sequence for sequence classification tasks by concatenating and
adding special tokens. An BARTPho sequence has the following format:`,$e,F,Ve="<li>single sequence: <code>&lt;s&gt; X &lt;/s&gt;</code></li> <li>pair of sequences: <code>&lt;s&gt; A &lt;/s&gt;&lt;/s&gt; B &lt;/s&gt;</code></li>",Re,y,A,ze,P,Ge="Converts a sequence of tokens (strings for sub-words) in a single string.",je,M,W,Je,D,Se=`Create a mask from the two sequences passed to be used in a sequence-pair classification task. BARTPho does not
make use of token type ids, therefore a list of zeros is returned.`,xe,T,H,qe,N,Fe=`Retrieve sequence ids from a token list that has no special tokens added. This method is called when adding
special tokens using the tokenizer <code>prepare_for_model</code> method.`,_e,X,ke,K,be;return v=new te({props:{title:"BARTpho",local:"bartpho",headingTag:"h1"}}),w=new te({props:{title:"개요",local:"overview",headingTag:"h2"}}),z=new te({props:{title:"사용 예시",local:"usage-example",headingTag:"h2"}}),j=new Pe({props:{code:"aW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHJhbnNmb3JtZXJzJTIwaW1wb3J0JTIwQXV0b01vZGVsJTJDJTIwQXV0b1Rva2VuaXplciUwQSUwQWJhcnRwaG8lMjAlM0QlMjBBdXRvTW9kZWwuZnJvbV9wcmV0cmFpbmVkKCUyMnZpbmFpJTJGYmFydHBoby1zeWxsYWJsZSUyMiklMEElMEF0b2tlbml6ZXIlMjAlM0QlMjBBdXRvVG9rZW5pemVyLmZyb21fcHJldHJhaW5lZCglMjJ2aW5haSUyRmJhcnRwaG8tc3lsbGFibGUlMjIpJTBBJTBBbGluZSUyMCUzRCUyMCUyMkNoJUMzJUJBbmclMjB0JUMzJUI0aSUyMGwlQzMlQTAlMjBuaCVFMSVCQiVBRm5nJTIwbmdoaSVDMyVBQW4lMjBjJUUxJUJCJUE5dSUyMHZpJUMzJUFBbi4lMjIlMEElMEFpbnB1dF9pZHMlMjAlM0QlMjB0b2tlbml6ZXIobGluZSUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpJTBBJTBBd2l0aCUyMHRvcmNoLm5vX2dyYWQoKSUzQSUwQSUyMCUyMCUyMCUyMGZlYXR1cmVzJTIwJTNEJTIwYmFydHBobygqKmlucHV0X2lkcyklMjAlMjAlMjMlMjAlRUMlOUQlQjQlRUMlQTAlOUMlMjAlRUIlQUElQTglRUIlOEQlQjglMjAlRUMlQjYlOUMlRUIlQTAlQTUlRUMlOUQlODAlMjAlRUQlOEElOUMlRUQlOTQlOEMlRUMlOUUlODUlRUIlOEIlODglRUIlOEIlQTQlMEElMEElMjMlMjBXaXRoJTIwVGVuc29yRmxvdyUyMDIuMCUyQiUzQSUwQWZyb20lMjB0cmFuc2Zvcm1lcnMlMjBpbXBvcnQlMjBURkF1dG9Nb2RlbCUwQSUwQWJhcnRwaG8lMjAlM0QlMjBURkF1dG9Nb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIydmluYWklMkZiYXJ0cGhvLXN5bGxhYmxlJTIyKSUwQWlucHV0X2lkcyUyMCUzRCUyMHRva2VuaXplcihsaW5lJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJ0ZiUyMiklMEFmZWF0dXJlcyUyMCUzRCUyMGJhcnRwaG8oKippbnB1dF9pZHMp",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoModel, AutoTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>bartpho = AutoModel.from_pretrained(<span class="hljs-string">&quot;vinai/bartpho-syllable&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;vinai/bartpho-syllable&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>line = <span class="hljs-string">&quot;Chúng tôi là những nghiên cứu viên.&quot;</span>

<span class="hljs-meta">&gt;&gt;&gt; </span>input_ids = tokenizer(line, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">with</span> torch.no_grad():
<span class="hljs-meta">... </span>    features = bartpho(**input_ids)  <span class="hljs-comment"># 이제 모델 출력은 튜플입니다</span>

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># With TensorFlow 2.0+:</span>
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> TFAutoModel

<span class="hljs-meta">&gt;&gt;&gt; </span>bartpho = TFAutoModel.from_pretrained(<span class="hljs-string">&quot;vinai/bartpho-syllable&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>input_ids = tokenizer(line, return_tensors=<span class="hljs-string">&quot;tf&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>features = bartpho(**input_ids)`,wrap:!1}}),J=new te({props:{title:"사용 팁",local:"usage-tips",headingTag:"h2"}}),q=new Pe({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyME1CYXJ0Rm9yQ29uZGl0aW9uYWxHZW5lcmF0aW9uJTBBJTBBYmFydHBobyUyMCUzRCUyME1CYXJ0Rm9yQ29uZGl0aW9uYWxHZW5lcmF0aW9uLmZyb21fcHJldHJhaW5lZCglMjJ2aW5haSUyRmJhcnRwaG8tc3lsbGFibGUlMjIpJTBBVFhUJTIwJTNEJTIwJTIyQ2glQzMlQkFuZyUyMHQlQzMlQjRpJTIwbCVDMyVBMCUyMCUzQ21hc2slM0UlMjBuZ2hpJUMzJUFBbiUyMGMlRTElQkIlQTl1JTIwdmklQzMlQUFuLiUyMiUwQWlucHV0X2lkcyUyMCUzRCUyMHRva2VuaXplciglNUJUWFQlNUQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyKSU1QiUyMmlucHV0X2lkcyUyMiU1RCUwQWxvZ2l0cyUyMCUzRCUyMGJhcnRwaG8oaW5wdXRfaWRzKS5sb2dpdHMlMEFtYXNrZWRfaW5kZXglMjAlM0QlMjAoaW5wdXRfaWRzJTVCMCU1RCUyMCUzRCUzRCUyMHRva2VuaXplci5tYXNrX3Rva2VuX2lkKS5ub256ZXJvKCkuaXRlbSgpJTBBcHJvYnMlMjAlM0QlMjBsb2dpdHMlNUIwJTJDJTIwbWFza2VkX2luZGV4JTVELnNvZnRtYXgoZGltJTNEMCklMEF2YWx1ZXMlMkMlMjBwcmVkaWN0aW9ucyUyMCUzRCUyMHByb2JzLnRvcGsoNSklMEFwcmludCh0b2tlbml6ZXIuZGVjb2RlKHByZWRpY3Rpb25zKS5zcGxpdCgpKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> MBartForConditionalGeneration

<span class="hljs-meta">&gt;&gt;&gt; </span>bartpho = MBartForConditionalGeneration.from_pretrained(<span class="hljs-string">&quot;vinai/bartpho-syllable&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>TXT = <span class="hljs-string">&quot;Chúng tôi là &lt;mask&gt; nghiên cứu viên.&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>input_ids = tokenizer([TXT], return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)[<span class="hljs-string">&quot;input_ids&quot;</span>]
<span class="hljs-meta">&gt;&gt;&gt; </span>logits = bartpho(input_ids).logits
<span class="hljs-meta">&gt;&gt;&gt; </span>masked_index = (input_ids[<span class="hljs-number">0</span>] == tokenizer.mask_token_id).nonzero().item()
<span class="hljs-meta">&gt;&gt;&gt; </span>probs = logits[<span class="hljs-number">0</span>, masked_index].softmax(dim=<span class="hljs-number">0</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>values, predictions = probs.topk(<span class="hljs-number">5</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(tokenizer.decode(predictions).split())`,wrap:!1}}),Q=new te({props:{title:"BartphoTokenizer",local:"bartphotokenizer ][ transformers.BartphoTokenizer",headingTag:"h2"}}),L=new ee({props:{name:"class transformers.BartphoTokenizer",anchor:"transformers.BartphoTokenizer",parameters:[{name:"vocab_file",val:""},{name:"monolingual_vocab_file",val:""},{name:"bos_token",val:" = '<s>'"},{name:"eos_token",val:" = '</s>'"},{name:"sep_token",val:" = '</s>'"},{name:"cls_token",val:" = '<s>'"},{name:"unk_token",val:" = '<unk>'"},{name:"pad_token",val:" = '<pad>'"},{name:"mask_token",val:" = '<mask>'"},{name:"sp_model_kwargs",val:": typing.Optional[typing.Dict[str, typing.Any]] = None"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.BartphoTokenizer.vocab_file",description:`<strong>vocab_file</strong> (<code>str</code>) &#x2014;
Path to the vocabulary file. This vocabulary is the pre-trained SentencePiece model available from the
multilingual XLM-RoBERTa, also used in mBART, consisting of 250K types.`,name:"vocab_file"},{anchor:"transformers.BartphoTokenizer.monolingual_vocab_file",description:`<strong>monolingual_vocab_file</strong> (<code>str</code>) &#x2014;
Path to the monolingual vocabulary file. This monolingual vocabulary consists of Vietnamese-specialized
types extracted from the multilingual vocabulary vocab_file of 250K types.`,name:"monolingual_vocab_file"},{anchor:"transformers.BartphoTokenizer.bos_token",description:`<strong>bos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;s&gt;&quot;</code>) &#x2014;
The beginning of sequence token that was used during pretraining. Can be used a sequence classifier token.</p>
<div class="course-tip  bg-gradient-to-br dark:bg-gradient-to-r before:border-green-500 dark:before:border-green-800 from-green-50 dark:from-gray-900 to-white dark:to-gray-950 border border-green-50 text-green-700 dark:text-gray-400">
						
<p>When building a sequence using special tokens, this is not the token that is used for the beginning of
sequence. The token used is the <code>cls_token</code>.</p>

					</div>`,name:"bos_token"},{anchor:"transformers.BartphoTokenizer.eos_token",description:`<strong>eos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;/s&gt;&quot;</code>) &#x2014;
The end of sequence token.</p>
<div class="course-tip  bg-gradient-to-br dark:bg-gradient-to-r before:border-green-500 dark:before:border-green-800 from-green-50 dark:from-gray-900 to-white dark:to-gray-950 border border-green-50 text-green-700 dark:text-gray-400">
						
<p>When building a sequence using special tokens, this is not the token that is used for the end of sequence.
The token used is the <code>sep_token</code>.</p>

					</div>`,name:"eos_token"},{anchor:"transformers.BartphoTokenizer.sep_token",description:`<strong>sep_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;/s&gt;&quot;</code>) &#x2014;
The separator token, which is used when building a sequence from multiple sequences, e.g. two sequences for
sequence classification or for a text and a question for question answering. It is also used as the last
token of a sequence built with special tokens.`,name:"sep_token"},{anchor:"transformers.BartphoTokenizer.cls_token",description:`<strong>cls_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;s&gt;&quot;</code>) &#x2014;
The classifier token which is used when doing sequence classification (classification of the whole sequence
instead of per-token classification). It is the first token of the sequence when built with special tokens.`,name:"cls_token"},{anchor:"transformers.BartphoTokenizer.unk_token",description:`<strong>unk_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;unk&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.BartphoTokenizer.pad_token",description:`<strong>pad_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;pad&gt;&quot;</code>) &#x2014;
The token used for padding, for example when batching sequences of different lengths.`,name:"pad_token"},{anchor:"transformers.BartphoTokenizer.mask_token",description:`<strong>mask_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;mask&gt;&quot;</code>) &#x2014;
The token used for masking values. This is the token used when training this model with masked language
modeling. This is the token which the model will try to predict.`,name:"mask_token"},{anchor:"transformers.BartphoTokenizer.sp_model_kwargs",description:`<strong>sp_model_kwargs</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Will be passed to the <code>SentencePieceProcessor.__init__()</code> method. The <a href="https://github.com/google/sentencepiece/tree/master/python" rel="nofollow">Python wrapper for
SentencePiece</a> can be used, among other things,
to set:</p>
<ul>
<li>
<p><code>enable_sampling</code>: Enable subword regularization.</p>
</li>
<li>
<p><code>nbest_size</code>: Sampling parameters for unigram. Invalid for BPE-Dropout.</p>
<ul>
<li><code>nbest_size = {0,1}</code>: No sampling is performed.</li>
<li><code>nbest_size &gt; 1</code>: samples from the nbest_size results.</li>
<li><code>nbest_size &lt; 0</code>: assuming that nbest_size is infinite and samples from the all hypothesis (lattice)
using forward-filtering-and-backward-sampling algorithm.</li>
</ul>
</li>
<li>
<p><code>alpha</code>: Smoothing parameter for unigram sampling, and dropout probability of merge operations for
BPE-dropout.</p>
</li>
</ul>`,name:"sp_model_kwargs"},{anchor:"transformers.BartphoTokenizer.sp_model",description:`<strong>sp_model</strong> (<code>SentencePieceProcessor</code>) &#x2014;
The <em>SentencePiece</em> processor that is used for every conversion (string, tokens and IDs).`,name:"sp_model"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/bartpho/tokenization_bartpho.py#L35"}}),I=new ee({props:{name:"build_inputs_with_special_tokens",anchor:"transformers.BartphoTokenizer.build_inputs_with_special_tokens",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.BartphoTokenizer.build_inputs_with_special_tokens.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs to which the special tokens will be added.`,name:"token_ids_0"},{anchor:"transformers.BartphoTokenizer.build_inputs_with_special_tokens.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/bartpho/tokenization_bartpho.py#L179",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>List of <a href="../glossary#input-ids">input IDs</a> with the appropriate special tokens.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),A=new ee({props:{name:"convert_tokens_to_string",anchor:"transformers.BartphoTokenizer.convert_tokens_to_string",parameters:[{name:"tokens",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/bartpho/tokenization_bartpho.py#L281"}}),W=new ee({props:{name:"create_token_type_ids_from_sequences",anchor:"transformers.BartphoTokenizer.create_token_type_ids_from_sequences",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.BartphoTokenizer.create_token_type_ids_from_sequences.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs.`,name:"token_ids_0"},{anchor:"transformers.BartphoTokenizer.create_token_type_ids_from_sequences.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/bartpho/tokenization_bartpho.py#L233",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>List of zeros.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),H=new ee({props:{name:"get_special_tokens_mask",anchor:"transformers.BartphoTokenizer.get_special_tokens_mask",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"},{name:"already_has_special_tokens",val:": bool = False"}],parametersDescription:[{anchor:"transformers.BartphoTokenizer.get_special_tokens_mask.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs.`,name:"token_ids_0"},{anchor:"transformers.BartphoTokenizer.get_special_tokens_mask.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"},{anchor:"transformers.BartphoTokenizer.get_special_tokens_mask.already_has_special_tokens",description:`<strong>already_has_special_tokens</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not the token list is already formatted with special tokens for the model.`,name:"already_has_special_tokens"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/bartpho/tokenization_bartpho.py#L205",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A list of integers in the range [0, 1]: 1 for a special token, 0 for a sequence token.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),X=new tt({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/bartpho.md"}}),{c(){b=i("meta"),ne=s(),Y=i("p"),se=s(),d(v.$$.fragment),oe=s(),d(w.$$.fragment),ae=s(),U=i("p"),U.innerHTML=Qe,re=s(),B=i("p"),B.textContent=Le,ie=s(),$=i("p"),$.innerHTML=Ie,le=s(),R=i("p"),R.innerHTML=Ae,pe=s(),d(z.$$.fragment),ce=s(),d(j.$$.fragment),de=s(),d(J.$$.fragment),me=s(),x=i("ul"),x.innerHTML=We,ge=s(),d(q.$$.fragment),he=s(),C=i("ul"),C.innerHTML=He,ue=s(),d(Q.$$.fragment),fe=s(),p=i("div"),d(L.$$.fragment),ve=s(),V=i("p"),V.innerHTML=Xe,we=s(),G=i("p"),G.innerHTML=Ee,Ue=s(),k=i("div"),d(I.$$.fragment),Be=s(),S=i("p"),S.textContent=Ze,$e=s(),F=i("ul"),F.innerHTML=Ve,Re=s(),y=i("div"),d(A.$$.fragment),ze=s(),P=i("p"),P.textContent=Ge,je=s(),M=i("div"),d(W.$$.fragment),Je=s(),D=i("p"),D.textContent=Se,xe=s(),T=i("div"),d(H.$$.fragment),qe=s(),N=i("p"),N.innerHTML=Fe,_e=s(),d(X.$$.fragment),ke=s(),K=i("p"),this.h()},l(e){const t=et("svelte-u9bgzb",document.head);b=l(t,"META",{name:!0,content:!0}),t.forEach(n),ne=o(e),Y=l(e,"P",{}),E(Y).forEach(n),se=o(e),m(v.$$.fragment,e),oe=o(e),m(w.$$.fragment,e),ae=o(e),U=l(e,"P",{"data-svelte-h":!0}),g(U)!=="svelte-kjdirq"&&(U.innerHTML=Qe),re=o(e),B=l(e,"P",{"data-svelte-h":!0}),g(B)!=="svelte-1t4tqml"&&(B.textContent=Le),ie=o(e),$=l(e,"P",{"data-svelte-h":!0}),g($)!=="svelte-o3f2xn"&&($.innerHTML=Ie),le=o(e),R=l(e,"P",{"data-svelte-h":!0}),g(R)!=="svelte-1205wq5"&&(R.innerHTML=Ae),pe=o(e),m(z.$$.fragment,e),ce=o(e),m(j.$$.fragment,e),de=o(e),m(J.$$.fragment,e),me=o(e),x=l(e,"UL",{"data-svelte-h":!0}),g(x)!=="svelte-kg3pt5"&&(x.innerHTML=We),ge=o(e),m(q.$$.fragment,e),he=o(e),C=l(e,"UL",{"data-svelte-h":!0}),g(C)!=="svelte-vacbbs"&&(C.innerHTML=He),ue=o(e),m(Q.$$.fragment,e),fe=o(e),p=l(e,"DIV",{class:!0});var c=E(p);m(L.$$.fragment,c),ve=o(c),V=l(c,"P",{"data-svelte-h":!0}),g(V)!=="svelte-11w33w6"&&(V.innerHTML=Xe),we=o(c),G=l(c,"P",{"data-svelte-h":!0}),g(G)!=="svelte-1urdkfw"&&(G.innerHTML=Ee),Ue=o(c),k=l(c,"DIV",{class:!0});var O=E(k);m(I.$$.fragment,O),Be=o(O),S=l(O,"P",{"data-svelte-h":!0}),g(S)!=="svelte-hazsjn"&&(S.textContent=Ze),$e=o(O),F=l(O,"UL",{"data-svelte-h":!0}),g(F)!=="svelte-rq8uot"&&(F.innerHTML=Ve),O.forEach(n),Re=o(c),y=l(c,"DIV",{class:!0});var ye=E(y);m(A.$$.fragment,ye),ze=o(ye),P=l(ye,"P",{"data-svelte-h":!0}),g(P)!=="svelte-1ne8awa"&&(P.textContent=Ge),ye.forEach(n),je=o(c),M=l(c,"DIV",{class:!0});var Me=E(M);m(W.$$.fragment,Me),Je=o(Me),D=l(Me,"P",{"data-svelte-h":!0}),g(D)!=="svelte-1t18cnp"&&(D.textContent=Se),Me.forEach(n),xe=o(c),T=l(c,"DIV",{class:!0});var Te=E(T);m(H.$$.fragment,Te),qe=o(Te),N=l(Te,"P",{"data-svelte-h":!0}),g(N)!=="svelte-1f4f5kp"&&(N.innerHTML=Fe),Te.forEach(n),c.forEach(n),_e=o(e),m(X.$$.fragment,e),ke=o(e),K=l(e,"P",{}),E(K).forEach(n),this.h()},h(){Z(b,"name","hf:doc:metadata"),Z(b,"content",st),Z(k,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Z(y,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Z(M,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Z(T,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Z(p,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,t){r(document.head,b),a(e,ne,t),a(e,Y,t),a(e,se,t),h(v,e,t),a(e,oe,t),h(w,e,t),a(e,ae,t),a(e,U,t),a(e,re,t),a(e,B,t),a(e,ie,t),a(e,$,t),a(e,le,t),a(e,R,t),a(e,pe,t),h(z,e,t),a(e,ce,t),h(j,e,t),a(e,de,t),h(J,e,t),a(e,me,t),a(e,x,t),a(e,ge,t),h(q,e,t),a(e,he,t),a(e,C,t),a(e,ue,t),h(Q,e,t),a(e,fe,t),a(e,p,t),h(L,p,null),r(p,ve),r(p,V),r(p,we),r(p,G),r(p,Ue),r(p,k),h(I,k,null),r(k,Be),r(k,S),r(k,$e),r(k,F),r(p,Re),r(p,y),h(A,y,null),r(y,ze),r(y,P),r(p,je),r(p,M),h(W,M,null),r(M,Je),r(M,D),r(p,xe),r(p,T),h(H,T,null),r(T,qe),r(T,N),a(e,_e,t),h(X,e,t),a(e,ke,t),a(e,K,t),be=!0},p:Ne,i(e){be||(u(v.$$.fragment,e),u(w.$$.fragment,e),u(z.$$.fragment,e),u(j.$$.fragment,e),u(J.$$.fragment,e),u(q.$$.fragment,e),u(Q.$$.fragment,e),u(L.$$.fragment,e),u(I.$$.fragment,e),u(A.$$.fragment,e),u(W.$$.fragment,e),u(H.$$.fragment,e),u(X.$$.fragment,e),be=!0)},o(e){f(v.$$.fragment,e),f(w.$$.fragment,e),f(z.$$.fragment,e),f(j.$$.fragment,e),f(J.$$.fragment,e),f(q.$$.fragment,e),f(Q.$$.fragment,e),f(L.$$.fragment,e),f(I.$$.fragment,e),f(A.$$.fragment,e),f(W.$$.fragment,e),f(H.$$.fragment,e),f(X.$$.fragment,e),be=!1},d(e){e&&(n(ne),n(Y),n(se),n(oe),n(ae),n(U),n(re),n(B),n(ie),n($),n(le),n(R),n(pe),n(ce),n(de),n(me),n(x),n(ge),n(he),n(C),n(ue),n(fe),n(p),n(_e),n(ke),n(K)),n(b),_(v,e),_(w,e),_(z,e),_(j,e),_(J,e),_(q,e),_(Q,e),_(L),_(I),_(A),_(W),_(H),_(X,e)}}}const st='{"title":"BARTpho","local":"bartpho","sections":[{"title":"개요","local":"overview","sections":[],"depth":2},{"title":"사용 예시","local":"usage-example","sections":[],"depth":2},{"title":"사용 팁","local":"usage-tips","sections":[],"depth":2},{"title":"BartphoTokenizer","local":"bartphotokenizer ][ transformers.BartphoTokenizer","sections":[],"depth":2}],"depth":1}';function ot(Ce){return Oe(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class ct extends Ye{constructor(b){super(),Ke(this,b,ot,nt,De,{})}}export{ct as component};
