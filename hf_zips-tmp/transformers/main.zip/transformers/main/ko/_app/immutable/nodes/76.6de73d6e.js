import{s as Ft,o as Zt,n as xe}from"../chunks/scheduler.bdbef820.js";import{S as It,i as Wt,g as p,s,r as h,A as Et,h as m,f as o,c as r,j as z,u,x as y,k as V,y as d,a as l,v as g,d as f,t as _,w as T}from"../chunks/index.33f81d56.js";import{T as Vt}from"../chunks/Tip.34194030.js";import{D as he}from"../chunks/Docstring.abcbe1ac.js";import{C as Ne}from"../chunks/CodeBlock.3bad7fc9.js";import{E as Oe}from"../chunks/ExampleCodeBlock.16b3b633.js";import{H as q,E as Bt}from"../chunks/getInferenceSnippets.64cd9466.js";function Lt(w){let n,b;return n=new Ne({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEdQVE5lb1hKYXBhbmVzZUNvbmZpZyUyQyUyMEdQVE5lb1hKYXBhbmVzZU1vZGVsJTBBJTBBJTIzJTIwSW5pdGlhbGl6aW5nJTIwYSUyMEdQVE5lb1hKYXBhbmVzZSUyMGdwdC1uZW94LWphcGFuZXNlLTIuN2IlMjBzdHlsZSUyMGNvbmZpZ3VyYXRpb24lMEFjb25maWd1cmF0aW9uJTIwJTNEJTIwR1BUTmVvWEphcGFuZXNlQ29uZmlnKCklMEElMEElMjMlMjBJbml0aWFsaXppbmclMjBhJTIwbW9kZWwlMjAod2l0aCUyMHJhbmRvbSUyMHdlaWdodHMpJTIwZnJvbSUyMHRoZSUyMGdwdC1uZW94LWphcGFuZXNlLTIuN2IlMjBzdHlsZSUyMGNvbmZpZ3VyYXRpb24lMEFtb2RlbCUyMCUzRCUyMEdQVE5lb1hKYXBhbmVzZU1vZGVsKGNvbmZpZ3VyYXRpb24pJTBBJTBBJTIzJTIwQWNjZXNzaW5nJTIwdGhlJTIwbW9kZWwlMjBjb25maWd1cmF0aW9uJTBBY29uZmlndXJhdGlvbiUyMCUzRCUyMG1vZGVsLmNvbmZpZw==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> GPTNeoXJapaneseConfig, GPTNeoXJapaneseModel

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a GPTNeoXJapanese gpt-neox-japanese-2.7b style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = GPTNeoXJapaneseConfig()

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a model (with random weights) from the gpt-neox-japanese-2.7b style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GPTNeoXJapaneseModel(configuration)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Accessing the model configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = model.config`,wrap:!1}}),{c(){h(n.$$.fragment)},l(i){u(n.$$.fragment,i)},m(i,c){g(n,i,c),b=!0},p:xe,i(i){b||(f(n.$$.fragment,i),b=!0)},o(i){_(n.$$.fragment,i),b=!1},d(i){T(n,i)}}}function Rt(w){let n,b="Example:",i,c,J;return c=new Ne({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEdQVE5lb1hKYXBhbmVzZVRva2VuaXplciUwQSUwQXRva2VuaXplciUyMCUzRCUyMEdQVE5lb1hKYXBhbmVzZVRva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIyYWJlamElMkZncHQtbmVveC1qYXBhbmVzZS0yLjdiJTIyKSUwQSUyMyUyMFlvdSUyMGNhbiUyMGNvbmZpcm0lMjBib3RoJTIwJUU2JTg1JUI2JUU1JUJGJTlDJTIwYW5kJTIwJUU2JTg1JUI2JUU2JTg3JTg5JTIwYXJlJTIwZW5jb2RlZCUyMHRvJTIwMTc3NDklMEF0b2tlbml6ZXIoJTIyJUU1JTkwJUJFJUU4JUJDJUE5JUUzJTgxJUFGJUU3JThDJUFCJUUzJTgxJUE3JUUzJTgxJTgyJUUzJTgyJThCJUYwJTlGJTkwJUFGJUUzJTgwJTgyJUU1JUFFJTlGJUUzJTgxJUFGJUU2JTg1JUI2JUU1JUJGJTlDKCVFNiU4NSVCNiVFNiU4NyU4OSklRTUlQTQlQTclRTUlQUQlQTYlRTUlODclQkElRTglQkElQUIlMjIpJTVCJTIyaW5wdXRfaWRzJTIyJTVEJTBBJTBBJTIzJTIwQm90aCUyMCVFNiU4NSVCNiVFNSVCRiU5QyUyMGFuZCUyMCVFNiU4NSVCNiVFNiU4NyU4OSUyMGFyZSUyMGRlY29kZWQlMjB0byUyMCVFNiU4NSVCNiVFNSVCRiU5QyUwQXRva2VuaXplci5kZWNvZGUodG9rZW5pemVyKCUyMiVFNSU5MCVCRSVFOCVCQyVBOSVFMyU4MSVBRiVFNyU4QyVBQiVFMyU4MSVBNyVFMyU4MSU4MiVFMyU4MiU4QiVGMCU5RiU5MCVBRiVFMyU4MCU4MiVFNSVBRSU5RiVFMyU4MSVBRiVFNiU4NSVCNiVFNSVCRiU5QyglRTYlODUlQjYlRTYlODclODkpJUU1JUE0JUE3JUU1JUFEJUE2JUU1JTg3JUJBJUU4JUJBJUFCJTIyKSU1QiUyMmlucHV0X2lkcyUyMiU1RCk=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> GPTNeoXJapaneseTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = GPTNeoXJapaneseTokenizer.from_pretrained(<span class="hljs-string">&quot;abeja/gpt-neox-japanese-2.7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># You can confirm both 慶応 and 慶應 are encoded to 17749</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer(<span class="hljs-string">&quot;吾輩は猫である🐯。実は慶応(慶應)大学出身&quot;</span>)[<span class="hljs-string">&quot;input_ids&quot;</span>]
[<span class="hljs-number">30014</span>, <span class="hljs-number">26883</span>, <span class="hljs-number">26638</span>, <span class="hljs-number">27228</span>, <span class="hljs-number">25</span>, <span class="hljs-number">26650</span>, <span class="hljs-number">31732</span>, <span class="hljs-number">31679</span>, <span class="hljs-number">27809</span>, <span class="hljs-number">26638</span>, <span class="hljs-number">17749</span>, <span class="hljs-number">31592</span>, <span class="hljs-number">17749</span>, <span class="hljs-number">31593</span>, <span class="hljs-number">321</span>, <span class="hljs-number">1281</span>]

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Both 慶応 and 慶應 are decoded to 慶応</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.decode(tokenizer(<span class="hljs-string">&quot;吾輩は猫である🐯。実は慶応(慶應)大学出身&quot;</span>)[<span class="hljs-string">&quot;input_ids&quot;</span>])
<span class="hljs-string">&#x27;吾輩は猫である🐯。実は慶応(慶応)大学出身&#x27;</span>`,wrap:!1}}),{c(){n=p("p"),n.textContent=b,i=s(),h(c.$$.fragment)},l(a){n=m(a,"P",{"data-svelte-h":!0}),y(n)!=="svelte-11lpom8"&&(n.textContent=b),i=r(a),u(c.$$.fragment,a)},m(a,M){l(a,n,M),l(a,i,M),g(c,a,M),J=!0},p:xe,i(a){J||(f(c.$$.fragment,a),J=!0)},o(a){_(c.$$.fragment,a),J=!1},d(a){a&&(o(n),o(i)),T(c,a)}}}function qt(w){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=p("p"),n.innerHTML=b},l(i){n=m(i,"P",{"data-svelte-h":!0}),y(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(i,c){l(i,n,c)},p:xe,d(i){i&&o(n)}}}function St(w){let n,b="Example:",i,c,J;return c=new Ne({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBHUFROZW9YSmFwYW5lc2VNb2RlbCUwQWltcG9ydCUyMHRvcmNoJTBBJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIyYWJlamElMkZncHQtbmVveC1qYXBhbmVzZS0yLjdiJTIyKSUwQW1vZGVsJTIwJTNEJTIwR1BUTmVvWEphcGFuZXNlTW9kZWwuZnJvbV9wcmV0cmFpbmVkKCUyMmFiZWphJTJGZ3B0LW5lb3gtamFwYW5lc2UtMi43YiUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTIyJUU2JTk3JUE1JUU2JTlDJUFDJUU4JUFBJTlFJUUzJTgxJUFFR1BULW5lb3glRTMlODElOENIdWdnaW5nJTIwRmFjZSVFMyU4MSVBNyVFNCVCRCVCRiVFMyU4MSU4OCVFMyU4MSVCRSVFMyU4MSU5OSVGMCU5RiU5OCU4MCUyMiUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKCoqaW5wdXRzKSUwQSUwQWxhc3RfaGlkZGVuX3N0YXRlcyUyMCUzRCUyMG91dHB1dHMubGFzdF9oaWRkZW5fc3RhdGU=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, GPTNeoXJapaneseModel
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;abeja/gpt-neox-japanese-2.7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GPTNeoXJapaneseModel.from_pretrained(<span class="hljs-string">&quot;abeja/gpt-neox-japanese-2.7b&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;日本語のGPT-neoxがHugging Faceで使えます😀&quot;</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_states = outputs.last_hidden_state`,wrap:!1}}),{c(){n=p("p"),n.textContent=b,i=s(),h(c.$$.fragment)},l(a){n=m(a,"P",{"data-svelte-h":!0}),y(n)!=="svelte-11lpom8"&&(n.textContent=b),i=r(a),u(c.$$.fragment,a)},m(a,M){l(a,n,M),l(a,i,M),g(c,a,M),J=!0},p:xe,i(a){J||(f(c.$$.fragment,a),J=!0)},o(a){_(c.$$.fragment,a),J=!1},d(a){a&&(o(n),o(i)),T(c,a)}}}function Ht(w){let n,b=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){n=p("p"),n.innerHTML=b},l(i){n=m(i,"P",{"data-svelte-h":!0}),y(n)!=="svelte-fincs2"&&(n.innerHTML=b)},m(i,c){l(i,n,c)},p:xe,d(i){i&&o(n)}}}function Qt(w){let n,b="Example:",i,c,J;return c=new Ne({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBHUFROZW9YSmFwYW5lc2VGb3JDYXVzYWxMTSUyQyUyMEdQVE5lb1hKYXBhbmVzZUNvbmZpZyUwQWltcG9ydCUyMHRvcmNoJTBBJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIyYWJlamElMkZncHQtbmVveC1qYXBhbmVzZS0yLjdiJTIyKSUwQWNvbmZpZyUyMCUzRCUyMEdQVE5lb1hKYXBhbmVzZUNvbmZpZy5mcm9tX3ByZXRyYWluZWQoJTIyYWJlamElMkZncHQtbmVveC1qYXBhbmVzZS0yLjdiJTIyKSUwQWNvbmZpZy5pc19kZWNvZGVyJTIwJTNEJTIwVHJ1ZSUwQW1vZGVsJTIwJTNEJTIwR1BUTmVvWEphcGFuZXNlRm9yQ2F1c2FsTE0uZnJvbV9wcmV0cmFpbmVkKCUyMmFiZWphJTJGZ3B0LW5lb3gtamFwYW5lc2UtMi43YiUyMiUyQyUyMGNvbmZpZyUzRGNvbmZpZyklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTIyJUU2JTk3JUE1JUU2JTlDJUFDJUU4JUFBJTlFJUUzJTgxJUFFR1BULW5lb3glRTMlODElOENIdWdnaW5nJTIwRmFjZSVFMyU4MSVBNyVFNCVCRCVCRiVFMyU4MSU4OCVFMyU4MSVCRSVFMyU4MSU5OSVGMCU5RiU5OCU4MCUyMiUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKCoqaW5wdXRzKSUwQSUwQXByZWRpY3Rpb25fbG9naXRzJTIwJTNEJTIwb3V0cHV0cy5sb2dpdHM=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, GPTNeoXJapaneseForCausalLM, GPTNeoXJapaneseConfig
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> torch

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;abeja/gpt-neox-japanese-2.7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>config = GPTNeoXJapaneseConfig.from_pretrained(<span class="hljs-string">&quot;abeja/gpt-neox-japanese-2.7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>config.is_decoder = <span class="hljs-literal">True</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = GPTNeoXJapaneseForCausalLM.from_pretrained(<span class="hljs-string">&quot;abeja/gpt-neox-japanese-2.7b&quot;</span>, config=config)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;日本語のGPT-neoxがHugging Faceで使えます😀&quot;</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span>prediction_logits = outputs.logits`,wrap:!1}}),{c(){n=p("p"),n.textContent=b,i=s(),h(c.$$.fragment)},l(a){n=m(a,"P",{"data-svelte-h":!0}),y(n)!=="svelte-11lpom8"&&(n.textContent=b),i=r(a),u(c.$$.fragment,a)},m(a,M){l(a,n,M),l(a,i,M),g(c,a,M),J=!0},p:xe,i(a){J||(f(c.$$.fragment,a),J=!0)},o(a){_(c.$$.fragment,a),J=!1},d(a){a&&(o(n),o(i)),T(c,a)}}}function Ot(w){let n,b,i,c,J,a,M,Ce,S,Tt='일본어를 위한 자동회귀 언어 모델인 GPT-NeoX-Japanese를 소개합니다. 이 모델은 <a href="https://github.com/EleutherAI/gpt-neox" rel="nofollow">https://github.com/EleutherAI/gpt-neox</a>에서 학습되었습니다. 일본어는 많은 어휘와 히라가나, 가타카나, 한자의 조합으로 이루어진 독특한 언어입니다. 이러한 일본어의 독특한 구조를 해결하기 위해 <a href="https://github.com/tanreinama/Japanese-BPEEncoder_V2" rel="nofollow">특수 서브워드 토크나이저</a>를 사용했습니다. 이 유용한 토크나이저를 오픈소스로 제공해 준 <em>tanreinama</em>에게 매우 감사드립니다.',Ge,H,bt='이 모델은 Google의 <a href="https://ai.googleblog.com/2022/04/pathways-language-model-palm-scaling-to.html" rel="nofollow">PaLM</a> 연구 권장 사항을 따르며, 트랜스포머 블록에서 편향 파라미터를 제거하여 모델 성능을 향상시켰습니다. 자세한 내용은 <a href="https://medium.com/ml-abeja/training-a-better-gpt-2-93b157662ae4" rel="nofollow">이 기사</a>를 참조하세요.',je,Q,yt='모델 개발은 <a href="https://www.abejainc.com/" rel="nofollow">ABEJA, Inc.</a>의 <a href="https://github.com/SO0529" rel="nofollow">신야 오타니</a>, <a href="https://github.com/spider-man-tm" rel="nofollow">타카요시 마카베</a>, <a href="https://github.com/Anuj040" rel="nofollow">안주 아로라</a>, <a href="https://github.com/go5paopao" rel="nofollow">쿄 하토리</a>에 의해 주도되었습니다. 이 모델 개발 활동에 대한 자세한 내용은 <a href="https://tech-blog.abeja.asia/entry/abeja-gpt-project-202207" rel="nofollow">여기</a>를 참조하세요.',Pe,O,Xe,Y,Jt="<code>generate()</code> 메서드를 사용하면 GPT NeoX Japanese 모델을 통해 텍스트를 생성할 수 있습니다.",ze,D,Ve,A,Fe,K,Mt='<li><a href="../tasks/language_modeling">일상 언어 모델링 작업 가이드</a></li>',Ze,ee,Ie,x,te,Ye,ue,kt=`This is the configuration class to store the configuration of a <code>GPTNeoXModelJapanese</code>. It is used to instantiate
a GPTNeoX model according to the specified arguments, defining the model architecture. Instantiating a
configuration with the defaults will yield a similar configuration to that of the GPTNeoXJapanese
<a href="https://huggingface.co/abeja/gpt-neox-japanese-2.7b" rel="nofollow">abeja/gpt-neox-japanese-2.7b</a> architecture.`,De,ge,Ut=`Configuration objects inherit from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> and can be used to control the model outputs. Read the
documentation from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> for more information. Default configs is set as 2.7B model`,Ae,F,We,ne,Ee,k,oe,Ke,fe,vt=`This tokenizer inherits from <code>PreTrainedTokenizer</code> and is based on Japanese special Sub-Word-Encoding that is
used in this repository (<a href="https://github.com/tanreinama/Japanese-BPEEncoder_V2" rel="nofollow">https://github.com/tanreinama/Japanese-BPEEncoder_V2</a>). Check the repository for details.
Japanese has a relatively large vocabulary and there is no separation between words. Furthermore, the language is a
combination of hiragana, katakana, and kanji, and variants such as “1” and “①” are often used. In order to cope
with these, this tokenizer has the following features`,et,_e,wt=`<li>Subword-by-subword segmentation, which is intermediate between byte strings and morphological analysis.</li> <li>BPEs are created for each Kanji, Hiragana, and Katakana character, and there are no BPEs that cross character
types, such as Kanji + Hiragana or Hiragana + Katakana.</li> <li>All-byte encoding that does not require &lt;unk&gt;.</li> <li>Independent of UTF codes such as 2-byte and 3-byte characters</li> <li>Conversion of heterographs to the same token_id</li> <li>Emoji and Emoticon are grouped into 12 types as special tags.</li>`,tt,Z,nt,I,ae,ot,Te,xt="Converts a sequence of tokens (string) in a single string.",Be,se,Le,U,re,at,be,$t="The bare Gpt Neox Japanese Model outputting raw hidden-states without any specific head on top.",st,ye,Nt=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,rt,Je,Ct=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,it,G,ie,lt,Me,Gt='The <a href="/docs/transformers/main/ko/model_doc/gpt_neox_japanese#transformers.GPTNeoXJapaneseModel">GPTNeoXJapaneseModel</a> forward method, overrides the <code>__call__</code> special method.',dt,W,ct,E,Re,le,qe,v,de,pt,ke,jt="GPTNeoXJapanese Model with a <code>language modeling</code> head on top for Classifier Model fine-tuning.",mt,Ue,Pt=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,ht,ve,Xt=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,ut,j,ce,gt,we,zt='The <a href="/docs/transformers/main/ko/model_doc/gpt_neox_japanese#transformers.GPTNeoXJapaneseForCausalLM">GPTNeoXJapaneseForCausalLM</a> forward method, overrides the <code>__call__</code> special method.',ft,B,_t,L,Se,pe,He,$e,Qe;return J=new q({props:{title:"GPT-NeoX-Japanese",local:"gpt-neox-japanese",headingTag:"h1"}}),M=new q({props:{title:"개요",local:"overview",headingTag:"h2"}}),O=new q({props:{title:"사용 예시",local:"usage-example",headingTag:"h3"}}),D=new Ne({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEdQVE5lb1hKYXBhbmVzZUZvckNhdXNhbExNJTJDJTIwR1BUTmVvWEphcGFuZXNlVG9rZW5pemVyJTBBJTBBbW9kZWwlMjAlM0QlMjBHUFROZW9YSmFwYW5lc2VGb3JDYXVzYWxMTS5mcm9tX3ByZXRyYWluZWQoJTIyYWJlamElMkZncHQtbmVveC1qYXBhbmVzZS0yLjdiJTIyKSUwQXRva2VuaXplciUyMCUzRCUyMEdQVE5lb1hKYXBhbmVzZVRva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIyYWJlamElMkZncHQtbmVveC1qYXBhbmVzZS0yLjdiJTIyKSUwQSUwQXByb21wdCUyMCUzRCUyMCUyMiVFNCVCQSVCQSVFMyU4MSVBOEFJJUUzJTgxJThDJUU1JThEJTk0JUU4JUFBJUJGJUUzJTgxJTk5JUUzJTgyJThCJUUzJTgxJTlGJUUzJTgyJTgxJUUzJTgxJUFCJUUzJTgxJUFGJUUzJTgwJTgxJTIyJTBBJTBBaW5wdXRfaWRzJTIwJTNEJTIwdG9rZW5pemVyKHByb21wdCUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpLmlucHV0X2lkcyUwQSUwQWdlbl90b2tlbnMlMjAlM0QlMjBtb2RlbC5nZW5lcmF0ZSglMEElMjAlMjAlMjAlMjBpbnB1dF9pZHMlMkMlMEElMjAlMjAlMjAlMjBkb19zYW1wbGUlM0RUcnVlJTJDJTBBJTIwJTIwJTIwJTIwdGVtcGVyYXR1cmUlM0QwLjklMkMlMEElMjAlMjAlMjAlMjBtYXhfbGVuZ3RoJTNEMTAwJTJDJTBBKSUwQWdlbl90ZXh0JTIwJTNEJTIwdG9rZW5pemVyLmJhdGNoX2RlY29kZShnZW5fdG9rZW5zJTJDJTIwc2tpcF9zcGVjaWFsX3Rva2VucyUzRFRydWUpJTVCMCU1RCUwQSUwQXByaW50KGdlbl90ZXh0KQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> GPTNeoXJapaneseForCausalLM, GPTNeoXJapaneseTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>model = GPTNeoXJapaneseForCausalLM.from_pretrained(<span class="hljs-string">&quot;abeja/gpt-neox-japanese-2.7b&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = GPTNeoXJapaneseTokenizer.from_pretrained(<span class="hljs-string">&quot;abeja/gpt-neox-japanese-2.7b&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>prompt = <span class="hljs-string">&quot;人とAIが協調するためには、&quot;</span>

<span class="hljs-meta">&gt;&gt;&gt; </span>input_ids = tokenizer(prompt, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).input_ids

<span class="hljs-meta">&gt;&gt;&gt; </span>gen_tokens = model.generate(
<span class="hljs-meta">... </span>    input_ids,
<span class="hljs-meta">... </span>    do_sample=<span class="hljs-literal">True</span>,
<span class="hljs-meta">... </span>    temperature=<span class="hljs-number">0.9</span>,
<span class="hljs-meta">... </span>    max_length=<span class="hljs-number">100</span>,
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>gen_text = tokenizer.batch_decode(gen_tokens, skip_special_tokens=<span class="hljs-literal">True</span>)[<span class="hljs-number">0</span>]

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(gen_text)
人とAIが協調するためには、AIと人が共存し、AIを正しく理解する必要があります。`,wrap:!1}}),A=new q({props:{title:"자료",local:"resources",headingTag:"h2"}}),ee=new q({props:{title:"GPTNeoXJapanese 설정 (GPTNeoXJapaneseConfig)",local:"transformers.GPTNeoXJapaneseConfig ][ transformers.GPTNeoXJapaneseConfig",headingTag:"h2"}}),te=new he({props:{name:"class transformers.GPTNeoXJapaneseConfig",anchor:"transformers.GPTNeoXJapaneseConfig",parameters:[{name:"vocab_size",val:" = 32000"},{name:"hidden_size",val:" = 2560"},{name:"num_hidden_layers",val:" = 32"},{name:"num_attention_heads",val:" = 32"},{name:"intermediate_multiple_size",val:" = 4"},{name:"hidden_act",val:" = 'gelu'"},{name:"rotary_pct",val:" = 1.0"},{name:"rotary_emb_base",val:" = 10000"},{name:"max_position_embeddings",val:" = 2048"},{name:"initializer_range",val:" = 0.02"},{name:"layer_norm_eps",val:" = 1e-05"},{name:"use_cache",val:" = True"},{name:"bos_token_id",val:" = 31996"},{name:"eos_token_id",val:" = 31999"},{name:"rope_scaling",val:" = None"},{name:"attention_dropout",val:" = 0.1"},{name:"hidden_dropout",val:" = 0.0"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.GPTNeoXJapaneseConfig.vocab_size",description:`<strong>vocab_size</strong> (<code>int</code>, <em>optional</em>, defaults to 32000) &#x2014;
Vocabulary size of the GPTNeoXJapanese model. Defines the number of different tokens that can be
represented by the <code>inputs_ids</code> passed when calling <code>GPTNeoXJapanese</code>.`,name:"vocab_size"},{anchor:"transformers.GPTNeoXJapaneseConfig.hidden_size",description:`<strong>hidden_size</strong> (<code>int</code>, <em>optional</em>, defaults to 2560) &#x2014;
Dimension of the encoder layers and the pooler layer.`,name:"hidden_size"},{anchor:"transformers.GPTNeoXJapaneseConfig.num_hidden_layers",description:`<strong>num_hidden_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 32) &#x2014;
Number of hidden layers in the Transformer encoder.`,name:"num_hidden_layers"},{anchor:"transformers.GPTNeoXJapaneseConfig.num_attention_heads",description:`<strong>num_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 32) &#x2014;
Number of attention heads for each attention layer in the Transformer encoder.`,name:"num_attention_heads"},{anchor:"transformers.GPTNeoXJapaneseConfig.intermediate_multiple_size",description:`<strong>intermediate_multiple_size</strong> (<code>int</code>, <em>optional</em>, defaults to 4) &#x2014;
Dimension of the &#x201C;intermediate&#x201D; layer in the Transformer encoder is calculated by hidden_size *
intermediate_multiple_size.`,name:"intermediate_multiple_size"},{anchor:"transformers.GPTNeoXJapaneseConfig.hidden_act",description:`<strong>hidden_act</strong> (<code>str</code> or <code>function</code>, <em>optional</em>, defaults to <code>&quot;gelu&quot;</code>) &#x2014;
The non-linear activation function (function or string) in the encoder and pooler.`,name:"hidden_act"},{anchor:"transformers.GPTNeoXJapaneseConfig.rotary_pct",description:`<strong>rotary_pct</strong> (<code>float</code>, <em>optional</em>, defaults to 1.00) &#x2014;
percentage of hidden dimensions to allocate to rotary embeddings`,name:"rotary_pct"},{anchor:"transformers.GPTNeoXJapaneseConfig.rotary_emb_base",description:`<strong>rotary_emb_base</strong> (<code>int</code>, <em>optional</em>, defaults to 10000) &#x2014;
base for computing rotary embeddings frequency`,name:"rotary_emb_base"},{anchor:"transformers.GPTNeoXJapaneseConfig.max_position_embeddings",description:`<strong>max_position_embeddings</strong> (<code>int</code>, <em>optional</em>, defaults to 2048) &#x2014;
The maximum sequence length that this model might ever be used with.`,name:"max_position_embeddings"},{anchor:"transformers.GPTNeoXJapaneseConfig.initializer_range",description:`<strong>initializer_range</strong> (<code>float</code>, <em>optional</em>, defaults to 0.02) &#x2014;
The standard deviation of the truncated_normal_initializer for initializing all weight matrices.`,name:"initializer_range"},{anchor:"transformers.GPTNeoXJapaneseConfig.layer_norm_eps",description:`<strong>layer_norm_eps</strong> (<code>float</code>, <em>optional</em>, defaults to 1e-5) &#x2014;
The epsilon used by the layer normalization layers.`,name:"layer_norm_eps"},{anchor:"transformers.GPTNeoXJapaneseConfig.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether or not the model should return the last key/values attentions (not used by all models). Only
relevant if <code>config.is_decoder=True</code>.`,name:"use_cache"},{anchor:"transformers.GPTNeoXJapaneseConfig.rope_scaling",description:`<strong>rope_scaling</strong> (<code>Dict</code>, <em>optional</em>) &#x2014;
Dictionary containing the scaling configuration for the RoPE embeddings. NOTE: if you apply new rope type
and you expect the model to work on longer <code>max_position_embeddings</code>, we recommend you to update this value
accordingly.
Expected contents:
<code>rope_type</code> (<code>str</code>):
The sub-variant of RoPE to use. Can be one of [&#x2018;default&#x2019;, &#x2018;linear&#x2019;, &#x2018;dynamic&#x2019;, &#x2018;yarn&#x2019;, &#x2018;longrope&#x2019;,
&#x2018;llama3&#x2019;], with &#x2018;default&#x2019; being the original RoPE implementation.
<code>factor</code> (<code>float</code>, <em>optional</em>):
Used with all rope types except &#x2018;default&#x2019;. The scaling factor to apply to the RoPE embeddings. In
most scaling types, a <code>factor</code> of x will enable the model to handle sequences of length x <em>
original maximum pre-trained length.
<code>original_max_position_embeddings</code> (<code>int</code>, </em>optional<em>):
Used with &#x2018;dynamic&#x2019;, &#x2018;longrope&#x2019; and &#x2018;llama3&#x2019;. The original max position embeddings used during
pretraining.
<code>attention_factor</code> (<code>float</code>, </em>optional<em>):
Used with &#x2018;yarn&#x2019; and &#x2018;longrope&#x2019;. The scaling factor to be applied on the attention
computation. If unspecified, it defaults to value recommended by the implementation, using the
<code>factor</code> field to infer the suggested value.
<code>beta_fast</code> (<code>float</code>, </em>optional<em>):
Only used with &#x2018;yarn&#x2019;. Parameter to set the boundary for extrapolation (only) in the linear
ramp function. If unspecified, it defaults to 32.
<code>beta_slow</code> (<code>float</code>, </em>optional<em>):
Only used with &#x2018;yarn&#x2019;. Parameter to set the boundary for interpolation (only) in the linear
ramp function. If unspecified, it defaults to 1.
<code>short_factor</code> (<code>List[float]</code>, </em>optional<em>):
Only used with &#x2018;longrope&#x2019;. The scaling factor to be applied to short contexts (&lt;
<code>original_max_position_embeddings</code>). Must be a list of numbers with the same length as the hidden
size divided by the number of attention heads divided by 2
<code>long_factor</code> (<code>List[float]</code>, </em>optional<em>):
Only used with &#x2018;longrope&#x2019;. The scaling factor to be applied to long contexts (&lt;
<code>original_max_position_embeddings</code>). Must be a list of numbers with the same length as the hidden
size divided by the number of attention heads divided by 2
<code>low_freq_factor</code> (<code>float</code>, </em>optional<em>):
Only used with &#x2018;llama3&#x2019;. Scaling factor applied to low frequency components of the RoPE
<code>high_freq_factor</code> (<code>float</code>, </em>optional*):
Only used with &#x2018;llama3&#x2019;. Scaling factor applied to high frequency components of the RoPE`,name:"rope_scaling"},{anchor:"transformers.GPTNeoXJapaneseConfig.attention_dropout",description:`<strong>attention_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.1) &#x2014;
The dropout ratio for the attention.`,name:"attention_dropout"},{anchor:"transformers.GPTNeoXJapaneseConfig.hidden_dropout",description:`<strong>hidden_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout ratio for the hidden layer.`,name:"hidden_dropout"},{anchor:"transformers.GPTNeoXJapaneseConfig.Example",description:"<strong>Example</strong> &#x2014;",name:"Example"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt_neox_japanese/configuration_gpt_neox_japanese.py#L25"}}),F=new Oe({props:{anchor:"transformers.GPTNeoXJapaneseConfig.example",$$slots:{default:[Lt]},$$scope:{ctx:w}}}),ne=new q({props:{title:"GPTNeoXJapanese토큰화 (GPTNeoXJapaneseTokenizer)",local:"transformers.GPTNeoXJapaneseTokenizer ][ transformers.GPTNeoXJapaneseTokenizer",headingTag:"h2"}}),oe=new he({props:{name:"class transformers.GPTNeoXJapaneseTokenizer",anchor:"transformers.GPTNeoXJapaneseTokenizer",parameters:[{name:"vocab_file",val:""},{name:"emoji_file",val:""},{name:"unk_token",val:" = '<|endoftext|>'"},{name:"pad_token",val:" = '<|endoftext|>'"},{name:"bos_token",val:" = '<|startoftext|>'"},{name:"eos_token",val:" = '<|endoftext|>'"},{name:"do_clean_text",val:" = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.GPTNeoXJapaneseTokenizer.vocab_file",description:`<strong>vocab_file</strong> (<code>str</code>) &#x2014;
File containing the vocabulary.`,name:"vocab_file"},{anchor:"transformers.GPTNeoXJapaneseTokenizer.emoji_file",description:`<strong>emoji_file</strong> (<code>str</code>) &#x2014;
File containing the emoji.`,name:"emoji_file"},{anchor:"transformers.GPTNeoXJapaneseTokenizer.unk_token",description:`<strong>unk_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.GPTNeoXJapaneseTokenizer.pad_token",description:`<strong>pad_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The token used for padding`,name:"pad_token"},{anchor:"transformers.GPTNeoXJapaneseTokenizer.bos_token",description:`<strong>bos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|startoftext|&gt;&quot;</code>) &#x2014;
The beginning of sequence token.`,name:"bos_token"},{anchor:"transformers.GPTNeoXJapaneseTokenizer.eos_token",description:`<strong>eos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;|endoftext|&gt;&quot;</code>) &#x2014;
The end of sequence token.`,name:"eos_token"},{anchor:"transformers.GPTNeoXJapaneseTokenizer.do_clean_text",description:`<strong>do_clean_text</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to clean text for URL, EMAIL, TEL, Japanese DATE and Japanese PRICE.`,name:"do_clean_text"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt_neox_japanese/tokenization_gpt_neox_japanese.py#L55"}}),Z=new Oe({props:{anchor:"transformers.GPTNeoXJapaneseTokenizer.example",$$slots:{default:[Rt]},$$scope:{ctx:w}}}),ae=new he({props:{name:"convert_tokens_to_string",anchor:"transformers.GPTNeoXJapaneseTokenizer.convert_tokens_to_string",parameters:[{name:"tokens",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt_neox_japanese/tokenization_gpt_neox_japanese.py#L160"}}),se=new q({props:{title:"GPTNeoXJapaneseModel",local:"transformers.GPTNeoXJapaneseModel ][ transformers.GPTNeoXJapaneseModel",headingTag:"h2"}}),re=new he({props:{name:"class transformers.GPTNeoXJapaneseModel",anchor:"transformers.GPTNeoXJapaneseModel",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.GPTNeoXJapaneseModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/gpt_neox_japanese#transformers.GPTNeoXJapaneseModel">GPTNeoXJapaneseModel</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt_neox_japanese/modeling_gpt_neox_japanese.py#L397"}}),ie=new he({props:{name:"forward",anchor:"transformers.GPTNeoXJapaneseModel.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.FloatTensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"head_mask",val:": typing.Optional[torch.FloatTensor] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"past_key_values",val:": typing.Union[transformers.cache_utils.Cache, typing.Tuple[typing.Tuple[torch.FloatTensor]], NoneType] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"}],parametersDescription:[{anchor:"transformers.GPTNeoXJapaneseModel.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.FloatTensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>Union[~cache_utils.Cache, Tuple[Tuple[torch.FloatTensor]], NoneType]</code>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.GPTNeoXJapaneseModel.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt_neox_japanese/modeling_gpt_neox_japanese.py#L419",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.BaseModelOutputWithPast"
>transformers.modeling_outputs.BaseModelOutputWithPast</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/gpt_neox_japanese#transformers.GPTNeoXJapaneseConfig"
>GPTNeoXJapaneseConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if
<code>config.is_encoder_decoder=True</code> in the cross-attention blocks) that can be used (see <code>past_key_values</code>
input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.BaseModelOutputWithPast"
>transformers.modeling_outputs.BaseModelOutputWithPast</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),W=new Vt({props:{$$slots:{default:[qt]},$$scope:{ctx:w}}}),E=new Oe({props:{anchor:"transformers.GPTNeoXJapaneseModel.forward.example",$$slots:{default:[St]},$$scope:{ctx:w}}}),le=new q({props:{title:"일상 LLM 을 위한 GPTNeoXJapanese(GPTNeoXJapaneseForCausalLM)",local:"transformers.GPTNeoXJapaneseForCausalLM ][ transformers.GPTNeoXJapaneseForCausalLM",headingTag:"h2"}}),de=new he({props:{name:"class transformers.GPTNeoXJapaneseForCausalLM",anchor:"transformers.GPTNeoXJapaneseForCausalLM",parameters:[{name:"config",val:""}],parametersDescription:[{anchor:"transformers.GPTNeoXJapaneseForCausalLM.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/gpt_neox_japanese#transformers.GPTNeoXJapaneseForCausalLM">GPTNeoXJapaneseForCausalLM</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt_neox_japanese/modeling_gpt_neox_japanese.py#L669"}}),ce=new he({props:{name:"forward",anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.FloatTensor] = None"},{name:"position_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"head_mask",val:": typing.Optional[torch.FloatTensor] = None"},{name:"past_key_values",val:": typing.Union[transformers.cache_utils.Cache, typing.Tuple[typing.Tuple[torch.FloatTensor]], NoneType] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.position_ids",description:`<strong>position_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.n_positions - 1]</code>.</p>
<p><a href="../glossary#position-ids">What are position IDs?</a>`,name:"position_ids"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.FloatTensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>Union[~cache_utils.Cache, Tuple[Tuple[torch.FloatTensor]], NoneType]</code>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the left-to-right language modeling loss (next word prediction). Indices should be in
<code>[-100, 0, ..., config.vocab_size]</code> (see <code>input_ids</code> docstring) Tokens with indices set to <code>-100</code> are
ignored (masked), the loss is only computed for the tokens with labels n <code>[0, ..., config.vocab_size]</code>.`,name:"labels"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt_neox_japanese/modeling_gpt_neox_japanese.py#L693",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.CausalLMOutputWithPast"
>transformers.modeling_outputs.CausalLMOutputWithPast</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/gpt_neox_japanese#transformers.GPTNeoXJapaneseConfig"
>GPTNeoXJapaneseConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Language modeling loss (for next-token prediction).</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks) that can be used (see
<code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.CausalLMOutputWithPast"
>transformers.modeling_outputs.CausalLMOutputWithPast</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),B=new Vt({props:{$$slots:{default:[Ht]},$$scope:{ctx:w}}}),L=new Oe({props:{anchor:"transformers.GPTNeoXJapaneseForCausalLM.forward.example",$$slots:{default:[Qt]},$$scope:{ctx:w}}}),pe=new Bt({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/gpt_neox_japanese.md"}}),{c(){n=p("meta"),b=s(),i=p("p"),c=s(),h(J.$$.fragment),a=s(),h(M.$$.fragment),Ce=s(),S=p("p"),S.innerHTML=Tt,Ge=s(),H=p("p"),H.innerHTML=bt,je=s(),Q=p("p"),Q.innerHTML=yt,Pe=s(),h(O.$$.fragment),Xe=s(),Y=p("p"),Y.innerHTML=Jt,ze=s(),h(D.$$.fragment),Ve=s(),h(A.$$.fragment),Fe=s(),K=p("ul"),K.innerHTML=Mt,Ze=s(),h(ee.$$.fragment),Ie=s(),x=p("div"),h(te.$$.fragment),Ye=s(),ue=p("p"),ue.innerHTML=kt,De=s(),ge=p("p"),ge.innerHTML=Ut,Ae=s(),h(F.$$.fragment),We=s(),h(ne.$$.fragment),Ee=s(),k=p("div"),h(oe.$$.fragment),Ke=s(),fe=p("p"),fe.innerHTML=vt,et=s(),_e=p("ul"),_e.innerHTML=wt,tt=s(),h(Z.$$.fragment),nt=s(),I=p("div"),h(ae.$$.fragment),ot=s(),Te=p("p"),Te.textContent=xt,Be=s(),h(se.$$.fragment),Le=s(),U=p("div"),h(re.$$.fragment),at=s(),be=p("p"),be.textContent=$t,st=s(),ye=p("p"),ye.innerHTML=Nt,rt=s(),Je=p("p"),Je.innerHTML=Ct,it=s(),G=p("div"),h(ie.$$.fragment),lt=s(),Me=p("p"),Me.innerHTML=Gt,dt=s(),h(W.$$.fragment),ct=s(),h(E.$$.fragment),Re=s(),h(le.$$.fragment),qe=s(),v=p("div"),h(de.$$.fragment),pt=s(),ke=p("p"),ke.innerHTML=jt,mt=s(),Ue=p("p"),Ue.innerHTML=Pt,ht=s(),ve=p("p"),ve.innerHTML=Xt,ut=s(),j=p("div"),h(ce.$$.fragment),gt=s(),we=p("p"),we.innerHTML=zt,ft=s(),h(B.$$.fragment),_t=s(),h(L.$$.fragment),Se=s(),h(pe.$$.fragment),He=s(),$e=p("p"),this.h()},l(e){const t=Et("svelte-u9bgzb",document.head);n=m(t,"META",{name:!0,content:!0}),t.forEach(o),b=r(e),i=m(e,"P",{}),z(i).forEach(o),c=r(e),u(J.$$.fragment,e),a=r(e),u(M.$$.fragment,e),Ce=r(e),S=m(e,"P",{"data-svelte-h":!0}),y(S)!=="svelte-nlt5vz"&&(S.innerHTML=Tt),Ge=r(e),H=m(e,"P",{"data-svelte-h":!0}),y(H)!=="svelte-1f85avp"&&(H.innerHTML=bt),je=r(e),Q=m(e,"P",{"data-svelte-h":!0}),y(Q)!=="svelte-12bg6m"&&(Q.innerHTML=yt),Pe=r(e),u(O.$$.fragment,e),Xe=r(e),Y=m(e,"P",{"data-svelte-h":!0}),y(Y)!=="svelte-1x0whr1"&&(Y.innerHTML=Jt),ze=r(e),u(D.$$.fragment,e),Ve=r(e),u(A.$$.fragment,e),Fe=r(e),K=m(e,"UL",{"data-svelte-h":!0}),y(K)!=="svelte-tjy0uo"&&(K.innerHTML=Mt),Ze=r(e),u(ee.$$.fragment,e),Ie=r(e),x=m(e,"DIV",{class:!0});var P=z(x);u(te.$$.fragment,P),Ye=r(P),ue=m(P,"P",{"data-svelte-h":!0}),y(ue)!=="svelte-6p1ri7"&&(ue.innerHTML=kt),De=r(P),ge=m(P,"P",{"data-svelte-h":!0}),y(ge)!=="svelte-wfbb4h"&&(ge.innerHTML=Ut),Ae=r(P),u(F.$$.fragment,P),P.forEach(o),We=r(e),u(ne.$$.fragment,e),Ee=r(e),k=m(e,"DIV",{class:!0});var $=z(k);u(oe.$$.fragment,$),Ke=r($),fe=m($,"P",{"data-svelte-h":!0}),y(fe)!=="svelte-vjvdvo"&&(fe.innerHTML=vt),et=r($),_e=m($,"UL",{"data-svelte-h":!0}),y(_e)!=="svelte-9px4ih"&&(_e.innerHTML=wt),tt=r($),u(Z.$$.fragment,$),nt=r($),I=m($,"DIV",{class:!0});var me=z(I);u(ae.$$.fragment,me),ot=r(me),Te=m(me,"P",{"data-svelte-h":!0}),y(Te)!=="svelte-b3k2yi"&&(Te.textContent=xt),me.forEach(o),$.forEach(o),Be=r(e),u(se.$$.fragment,e),Le=r(e),U=m(e,"DIV",{class:!0});var N=z(U);u(re.$$.fragment,N),at=r(N),be=m(N,"P",{"data-svelte-h":!0}),y(be)!=="svelte-1cum3sy"&&(be.textContent=$t),st=r(N),ye=m(N,"P",{"data-svelte-h":!0}),y(ye)!=="svelte-u3dlub"&&(ye.innerHTML=Nt),rt=r(N),Je=m(N,"P",{"data-svelte-h":!0}),y(Je)!=="svelte-hswkmf"&&(Je.innerHTML=Ct),it=r(N),G=m(N,"DIV",{class:!0});var X=z(G);u(ie.$$.fragment,X),lt=r(X),Me=m(X,"P",{"data-svelte-h":!0}),y(Me)!=="svelte-1ruc88y"&&(Me.innerHTML=Gt),dt=r(X),u(W.$$.fragment,X),ct=r(X),u(E.$$.fragment,X),X.forEach(o),N.forEach(o),Re=r(e),u(le.$$.fragment,e),qe=r(e),v=m(e,"DIV",{class:!0});var C=z(v);u(de.$$.fragment,C),pt=r(C),ke=m(C,"P",{"data-svelte-h":!0}),y(ke)!=="svelte-lpe5g3"&&(ke.innerHTML=jt),mt=r(C),Ue=m(C,"P",{"data-svelte-h":!0}),y(Ue)!=="svelte-u3dlub"&&(Ue.innerHTML=Pt),ht=r(C),ve=m(C,"P",{"data-svelte-h":!0}),y(ve)!=="svelte-hswkmf"&&(ve.innerHTML=Xt),ut=r(C),j=m(C,"DIV",{class:!0});var R=z(j);u(ce.$$.fragment,R),gt=r(R),we=m(R,"P",{"data-svelte-h":!0}),y(we)!=="svelte-10tikgm"&&(we.innerHTML=zt),ft=r(R),u(B.$$.fragment,R),_t=r(R),u(L.$$.fragment,R),R.forEach(o),C.forEach(o),Se=r(e),u(pe.$$.fragment,e),He=r(e),$e=m(e,"P",{}),z($e).forEach(o),this.h()},h(){V(n,"name","hf:doc:metadata"),V(n,"content",Yt),V(x,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),V(I,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),V(k,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),V(G,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),V(U,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),V(j,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),V(v,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,t){d(document.head,n),l(e,b,t),l(e,i,t),l(e,c,t),g(J,e,t),l(e,a,t),g(M,e,t),l(e,Ce,t),l(e,S,t),l(e,Ge,t),l(e,H,t),l(e,je,t),l(e,Q,t),l(e,Pe,t),g(O,e,t),l(e,Xe,t),l(e,Y,t),l(e,ze,t),g(D,e,t),l(e,Ve,t),g(A,e,t),l(e,Fe,t),l(e,K,t),l(e,Ze,t),g(ee,e,t),l(e,Ie,t),l(e,x,t),g(te,x,null),d(x,Ye),d(x,ue),d(x,De),d(x,ge),d(x,Ae),g(F,x,null),l(e,We,t),g(ne,e,t),l(e,Ee,t),l(e,k,t),g(oe,k,null),d(k,Ke),d(k,fe),d(k,et),d(k,_e),d(k,tt),g(Z,k,null),d(k,nt),d(k,I),g(ae,I,null),d(I,ot),d(I,Te),l(e,Be,t),g(se,e,t),l(e,Le,t),l(e,U,t),g(re,U,null),d(U,at),d(U,be),d(U,st),d(U,ye),d(U,rt),d(U,Je),d(U,it),d(U,G),g(ie,G,null),d(G,lt),d(G,Me),d(G,dt),g(W,G,null),d(G,ct),g(E,G,null),l(e,Re,t),g(le,e,t),l(e,qe,t),l(e,v,t),g(de,v,null),d(v,pt),d(v,ke),d(v,mt),d(v,Ue),d(v,ht),d(v,ve),d(v,ut),d(v,j),g(ce,j,null),d(j,gt),d(j,we),d(j,ft),g(B,j,null),d(j,_t),g(L,j,null),l(e,Se,t),g(pe,e,t),l(e,He,t),l(e,$e,t),Qe=!0},p(e,[t]){const P={};t&2&&(P.$$scope={dirty:t,ctx:e}),F.$set(P);const $={};t&2&&($.$$scope={dirty:t,ctx:e}),Z.$set($);const me={};t&2&&(me.$$scope={dirty:t,ctx:e}),W.$set(me);const N={};t&2&&(N.$$scope={dirty:t,ctx:e}),E.$set(N);const X={};t&2&&(X.$$scope={dirty:t,ctx:e}),B.$set(X);const C={};t&2&&(C.$$scope={dirty:t,ctx:e}),L.$set(C)},i(e){Qe||(f(J.$$.fragment,e),f(M.$$.fragment,e),f(O.$$.fragment,e),f(D.$$.fragment,e),f(A.$$.fragment,e),f(ee.$$.fragment,e),f(te.$$.fragment,e),f(F.$$.fragment,e),f(ne.$$.fragment,e),f(oe.$$.fragment,e),f(Z.$$.fragment,e),f(ae.$$.fragment,e),f(se.$$.fragment,e),f(re.$$.fragment,e),f(ie.$$.fragment,e),f(W.$$.fragment,e),f(E.$$.fragment,e),f(le.$$.fragment,e),f(de.$$.fragment,e),f(ce.$$.fragment,e),f(B.$$.fragment,e),f(L.$$.fragment,e),f(pe.$$.fragment,e),Qe=!0)},o(e){_(J.$$.fragment,e),_(M.$$.fragment,e),_(O.$$.fragment,e),_(D.$$.fragment,e),_(A.$$.fragment,e),_(ee.$$.fragment,e),_(te.$$.fragment,e),_(F.$$.fragment,e),_(ne.$$.fragment,e),_(oe.$$.fragment,e),_(Z.$$.fragment,e),_(ae.$$.fragment,e),_(se.$$.fragment,e),_(re.$$.fragment,e),_(ie.$$.fragment,e),_(W.$$.fragment,e),_(E.$$.fragment,e),_(le.$$.fragment,e),_(de.$$.fragment,e),_(ce.$$.fragment,e),_(B.$$.fragment,e),_(L.$$.fragment,e),_(pe.$$.fragment,e),Qe=!1},d(e){e&&(o(b),o(i),o(c),o(a),o(Ce),o(S),o(Ge),o(H),o(je),o(Q),o(Pe),o(Xe),o(Y),o(ze),o(Ve),o(Fe),o(K),o(Ze),o(Ie),o(x),o(We),o(Ee),o(k),o(Be),o(Le),o(U),o(Re),o(qe),o(v),o(Se),o(He),o($e)),o(n),T(J,e),T(M,e),T(O,e),T(D,e),T(A,e),T(ee,e),T(te),T(F),T(ne,e),T(oe),T(Z),T(ae),T(se,e),T(re),T(ie),T(W),T(E),T(le,e),T(de),T(ce),T(B),T(L),T(pe,e)}}}const Yt='{"title":"GPT-NeoX-Japanese","local":"gpt-neox-japanese","sections":[{"title":"개요","local":"overview","sections":[{"title":"사용 예시","local":"usage-example","sections":[],"depth":3}],"depth":2},{"title":"자료","local":"resources","sections":[],"depth":2},{"title":"GPTNeoXJapanese 설정 (GPTNeoXJapaneseConfig)","local":"transformers.GPTNeoXJapaneseConfig ][ transformers.GPTNeoXJapaneseConfig","sections":[],"depth":2},{"title":"GPTNeoXJapanese토큰화 (GPTNeoXJapaneseTokenizer)","local":"transformers.GPTNeoXJapaneseTokenizer ][ transformers.GPTNeoXJapaneseTokenizer","sections":[],"depth":2},{"title":"GPTNeoXJapaneseModel","local":"transformers.GPTNeoXJapaneseModel ][ transformers.GPTNeoXJapaneseModel","sections":[],"depth":2},{"title":"일상 LLM 을 위한 GPTNeoXJapanese(GPTNeoXJapaneseForCausalLM)","local":"transformers.GPTNeoXJapaneseForCausalLM ][ transformers.GPTNeoXJapaneseForCausalLM","sections":[],"depth":2}],"depth":1}';function Dt(w){return Zt(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class sn extends It{constructor(n){super(),Wt(this,n,Dt,Ot,Ft,{})}}export{sn as component};
