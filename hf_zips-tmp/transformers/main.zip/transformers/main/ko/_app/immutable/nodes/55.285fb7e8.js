import{s as gt,o as kt,n as _t}from"../chunks/scheduler.bdbef820.js";import{S as bt,i as zt,g as a,s,r as f,A as Tt,h as i,f as n,c as r,j as x,u,x as c,k as q,y as o,a as d,v as g,d as k,t as _,w as b}from"../chunks/index.33f81d56.js";import{T as vt}from"../chunks/Tip.34194030.js";import{D}from"../chunks/Docstring.abcbe1ac.js";import{H as fe,E as $t}from"../chunks/getInferenceSnippets.64cd9466.js";function xt(ue){let m,A=`BARThez 구현은 🤗 BART와 동일하나, 토큰화에서 차이가 있습니다. 구성 클래스와 그 매개변수에 대한 정보는 <a href="bart">BART 문서</a>를 참조하십시오.
BARThez 전용 토크나이저는 아래에 문서화되어 있습니다.`;return{c(){m=a("p"),m.innerHTML=A},l(z){m=i(z,"P",{"data-svelte-h":!0}),c(m)!=="svelte-9z55yg"&&(m.innerHTML=A)},m(z,Y){d(z,m,Y)},p:_t,d(z){z&&n(m)}}}function qt(ue){let m,A,z,Y,P,ge,R,ke,M,Ze='BARThez 모델은 2020년 10월 23일, Moussa Kamal Eddine, Antoine J.-P. Tixier, Michalis Vazirgiannis에 의해 <a href="https://huggingface.co/papers/2010.12321" rel="nofollow">BARThez: a Skilled Pretrained French Sequence-to-Sequence Model</a>에서 제안되었습니다.',_e,E,et="이 논문의 초록:",be,F,tt=`<em>자기지도 학습에 의해 가능해진 귀납적 전이 학습은 자연어 처리(NLP) 분야 전반에 걸쳐 큰 반향을 일으켰으며,
BERT와 BART와 같은 모델들은 수많은 자연어 이해 작업에서 새로운 최첨단 성과를 기록했습니다. 일부 주목할 만한 예외가 있지만,
대부분의 사용 가능한 모델과 연구는 영어에 집중되어 있었습니다. 본 연구에서는 BARThez를 소개합니다.
이는 (우리가 아는 한) 프랑스어를 위한 첫 번째 BART 모델입니다.
BARThez는 과거 연구에서 얻은 매우 큰 프랑스어 단일 언어 말뭉치로 사전훈련되었으며,
BART의 변형 방식에 맞게 조정되었습니다.
CamemBERT 및 FlauBERT와 같은 기존의 BERT 기반 프랑스어 모델과 달리, BARThez는 생성 작업에 특히 적합합니다.
이는 인코더뿐만 아니라 디코더도 사전훈련되었기 때문입니다.
우리는 FLUE 벤치마크에서의 판별 작업 외에도 이 논문과 함께 공개하는 새로운 요약 데이터셋인 OrangeSum에서 BARThez를 평가했습니다.
또한 이미 사전훈련된 다국어 BART의 사전훈련을 BARThez의 말뭉치로 계속 진행하였으며,
결과적으로 얻어진 모델인 mBARTHez가 기본 BARThez보다 유의미한 성능 향상을 보였고,
CamemBERT 및 FlauBERT와 동등하거나 이를 능가함을 보였습니다.</em>`,ze,I,nt='이 모델은 <a href="https://huggingface.co/moussakam" rel="nofollow">moussakam</a>이 기여했습니다. 저자의 코드는 <a href="https://github.com/moussaKam/BARThez" rel="nofollow">여기</a>에서 찾을 수 있습니다.',Te,w,ve,H,$e,S,ot=`<li>BARThez는 🤗 BART와 유사한 방식으로 시퀀스-투-시퀀스 작업에 맞춰 미세 조정될 수 있습니다. 다음을 확인하세요:
<a href="https://github.com/huggingface/transformers/tree/main/examples/pytorch/summarization/README.md" rel="nofollow">examples/pytorch/summarization/</a>.</li>`,xe,O,qe,l,N,Me,Z,st=`Adapted from <code>CamembertTokenizer</code> and <a href="/docs/transformers/main/ko/model_doc/bart#transformers.BartTokenizer">BartTokenizer</a>. Construct a BARThez tokenizer. Based on
<a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a>.`,Ee,ee,rt=`This tokenizer inherits from <code>PreTrainedTokenizer</code> which contains most of the main methods. Users should refer to
this superclass for more information regarding those methods.`,Fe,T,U,Ie,te,at=`Build model inputs from a sequence or a pair of sequence for sequence classification tasks by concatenating and
adding special tokens. A BARThez sequence has the following format:`,He,ne,it="<li>single sequence: <code>&lt;s&gt; X &lt;/s&gt;</code></li> <li>pair of sequences: <code>&lt;s&gt; A &lt;/s&gt;&lt;/s&gt; B &lt;/s&gt;</code></li>",Se,y,V,Oe,oe,dt="Converts a sequence of tokens (string) in a single string.",Ne,B,W,Ue,se,lt="Create a mask from the two sequences passed to be used in a sequence-pair classification task.",Ve,L,j,We,re,ct=`Retrieve sequence ids from a token list that has no special tokens added. This method is called when adding
special tokens using the tokenizer <code>prepare_for_model</code> method.`,we,K,ye,h,X,je,ae,mt=`Adapted from <code>CamembertTokenizer</code> and <a href="/docs/transformers/main/ko/model_doc/bart#transformers.BartTokenizer">BartTokenizer</a>. Construct a “fast” BARThez tokenizer. Based on
<a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a>.`,Ke,ie,pt=`This tokenizer inherits from <code>PreTrainedTokenizerFast</code> which contains most of the main methods. Users should
refer to this superclass for more information regarding those methods.`,Xe,v,G,Ge,de,ht=`Build model inputs from a sequence or a pair of sequence for sequence classification tasks by concatenating and
adding special tokens. A BARThez sequence has the following format:`,Je,le,ft="<li>single sequence: <code>&lt;s&gt; X &lt;/s&gt;</code></li> <li>pair of sequences: <code>&lt;s&gt; A &lt;/s&gt;&lt;/s&gt; B &lt;/s&gt;</code></li>",Qe,C,J,Ye,ce,ut="Create a mask from the two sequences passed to be used in a sequence-pair classification task.",Be,Q,Le,he,Ce;return P=new fe({props:{title:"BARThez",local:"barthez",headingTag:"h1"}}),R=new fe({props:{title:"개요",local:"overview",headingTag:"h2"}}),w=new vt({props:{$$slots:{default:[xt]},$$scope:{ctx:ue}}}),H=new fe({props:{title:"리소스",local:"resources",headingTag:"h2"}}),O=new fe({props:{title:"BarthezTokenizer",local:"bartheztokenizer ][ transformers.BarthezTokenizer",headingTag:"h2"}}),N=new D({props:{name:"class transformers.BarthezTokenizer",anchor:"transformers.BarthezTokenizer",parameters:[{name:"vocab_file",val:""},{name:"bos_token",val:" = '<s>'"},{name:"eos_token",val:" = '</s>'"},{name:"sep_token",val:" = '</s>'"},{name:"cls_token",val:" = '<s>'"},{name:"unk_token",val:" = '<unk>'"},{name:"pad_token",val:" = '<pad>'"},{name:"mask_token",val:" = '<mask>'"},{name:"sp_model_kwargs",val:": typing.Optional[typing.Dict[str, typing.Any]] = None"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.BarthezTokenizer.vocab_file",description:`<strong>vocab_file</strong> (<code>str</code>) &#x2014;
<a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a> file (generally has a <em>.spm</em> extension) that
contains the vocabulary necessary to instantiate a tokenizer.`,name:"vocab_file"},{anchor:"transformers.BarthezTokenizer.bos_token",description:`<strong>bos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;s&gt;&quot;</code>) &#x2014;
The beginning of sequence token that was used during pretraining. Can be used a sequence classifier token.</p>
<div class="course-tip  bg-gradient-to-br dark:bg-gradient-to-r before:border-green-500 dark:before:border-green-800 from-green-50 dark:from-gray-900 to-white dark:to-gray-950 border border-green-50 text-green-700 dark:text-gray-400">
						
<p>When building a sequence using special tokens, this is not the token that is used for the beginning of
sequence. The token used is the <code>cls_token</code>.</p>

					</div>`,name:"bos_token"},{anchor:"transformers.BarthezTokenizer.eos_token",description:`<strong>eos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;/s&gt;&quot;</code>) &#x2014;
The end of sequence token.</p>
<div class="course-tip  bg-gradient-to-br dark:bg-gradient-to-r before:border-green-500 dark:before:border-green-800 from-green-50 dark:from-gray-900 to-white dark:to-gray-950 border border-green-50 text-green-700 dark:text-gray-400">
						
<p>When building a sequence using special tokens, this is not the token that is used for the end of sequence.
The token used is the <code>sep_token</code>.</p>

					</div>`,name:"eos_token"},{anchor:"transformers.BarthezTokenizer.sep_token",description:`<strong>sep_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;/s&gt;&quot;</code>) &#x2014;
The separator token, which is used when building a sequence from multiple sequences, e.g. two sequences for
sequence classification or for a text and a question for question answering. It is also used as the last
token of a sequence built with special tokens.`,name:"sep_token"},{anchor:"transformers.BarthezTokenizer.cls_token",description:`<strong>cls_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;s&gt;&quot;</code>) &#x2014;
The classifier token which is used when doing sequence classification (classification of the whole sequence
instead of per-token classification). It is the first token of the sequence when built with special tokens.`,name:"cls_token"},{anchor:"transformers.BarthezTokenizer.unk_token",description:`<strong>unk_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;unk&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.BarthezTokenizer.pad_token",description:`<strong>pad_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;pad&gt;&quot;</code>) &#x2014;
The token used for padding, for example when batching sequences of different lengths.`,name:"pad_token"},{anchor:"transformers.BarthezTokenizer.mask_token",description:`<strong>mask_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;mask&gt;&quot;</code>) &#x2014;
The token used for masking values. This is the token used when training this model with masked language
modeling. This is the token which the model will try to predict.`,name:"mask_token"},{anchor:"transformers.BarthezTokenizer.sp_model_kwargs",description:`<strong>sp_model_kwargs</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Will be passed to the <code>SentencePieceProcessor.__init__()</code> method. The <a href="https://github.com/google/sentencepiece/tree/master/python" rel="nofollow">Python wrapper for
SentencePiece</a> can be used, among other things,
to set:</p>
<ul>
<li>
<p><code>enable_sampling</code>: Enable subword regularization.</p>
</li>
<li>
<p><code>nbest_size</code>: Sampling parameters for unigram. Invalid for BPE-Dropout.</p>
<ul>
<li><code>nbest_size = {0,1}</code>: No sampling is performed.</li>
<li><code>nbest_size &gt; 1</code>: samples from the nbest_size results.</li>
<li><code>nbest_size &lt; 0</code>: assuming that nbest_size is infinite and samples from the all hypothesis (lattice)
using forward-filtering-and-backward-sampling algorithm.</li>
</ul>
</li>
<li>
<p><code>alpha</code>: Smoothing parameter for unigram sampling, and dropout probability of merge operations for
BPE-dropout.</p>
</li>
</ul>`,name:"sp_model_kwargs"},{anchor:"transformers.BarthezTokenizer.sp_model",description:`<strong>sp_model</strong> (<code>SentencePieceProcessor</code>) &#x2014;
The <em>SentencePiece</em> processor that is used for every conversion (string, tokens and IDs).`,name:"sp_model"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/barthez/tokenization_barthez.py#L38"}}),U=new D({props:{name:"build_inputs_with_special_tokens",anchor:"transformers.BarthezTokenizer.build_inputs_with_special_tokens",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.BarthezTokenizer.build_inputs_with_special_tokens.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs to which the special tokens will be added.`,name:"token_ids_0"},{anchor:"transformers.BarthezTokenizer.build_inputs_with_special_tokens.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/barthez/tokenization_barthez.py#L143",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>List of <a href="../glossary#input-ids">input IDs</a> with the appropriate special tokens.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),V=new D({props:{name:"convert_tokens_to_string",anchor:"transformers.BarthezTokenizer.convert_tokens_to_string",parameters:[{name:"tokens",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/barthez/tokenization_barthez.py#L239"}}),W=new D({props:{name:"create_token_type_ids_from_sequences",anchor:"transformers.BarthezTokenizer.create_token_type_ids_from_sequences",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.BarthezTokenizer.create_token_type_ids_from_sequences.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs.`,name:"token_ids_0"},{anchor:"transformers.BarthezTokenizer.create_token_type_ids_from_sequences.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/barthez/tokenization_barthez.py#L196",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>List of zeros.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),j=new D({props:{name:"get_special_tokens_mask",anchor:"transformers.BarthezTokenizer.get_special_tokens_mask",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"},{name:"already_has_special_tokens",val:": bool = False"}],parametersDescription:[{anchor:"transformers.BarthezTokenizer.get_special_tokens_mask.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs.`,name:"token_ids_0"},{anchor:"transformers.BarthezTokenizer.get_special_tokens_mask.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"},{anchor:"transformers.BarthezTokenizer.get_special_tokens_mask.already_has_special_tokens",description:`<strong>already_has_special_tokens</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not the token list is already formatted with special tokens for the model.`,name:"already_has_special_tokens"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/barthez/tokenization_barthez.py#L169",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A list of integers in the range [0, 1]: 1 for a special token, 0 for a sequence token.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),K=new fe({props:{title:"BarthezTokenizerFast",local:"bartheztokenizerfast ][ transformers.BarthezTokenizerFast",headingTag:"h2"}}),X=new D({props:{name:"class transformers.BarthezTokenizerFast",anchor:"transformers.BarthezTokenizerFast",parameters:[{name:"vocab_file",val:" = None"},{name:"tokenizer_file",val:" = None"},{name:"bos_token",val:" = '<s>'"},{name:"eos_token",val:" = '</s>'"},{name:"sep_token",val:" = '</s>'"},{name:"cls_token",val:" = '<s>'"},{name:"unk_token",val:" = '<unk>'"},{name:"pad_token",val:" = '<pad>'"},{name:"mask_token",val:" = '<mask>'"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.BarthezTokenizerFast.vocab_file",description:`<strong>vocab_file</strong> (<code>str</code>) &#x2014;
<a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a> file (generally has a <em>.spm</em> extension) that
contains the vocabulary necessary to instantiate a tokenizer.`,name:"vocab_file"},{anchor:"transformers.BarthezTokenizerFast.bos_token",description:`<strong>bos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;s&gt;&quot;</code>) &#x2014;
The beginning of sequence token that was used during pretraining. Can be used a sequence classifier token.</p>
<div class="course-tip  bg-gradient-to-br dark:bg-gradient-to-r before:border-green-500 dark:before:border-green-800 from-green-50 dark:from-gray-900 to-white dark:to-gray-950 border border-green-50 text-green-700 dark:text-gray-400">
						
<p>When building a sequence using special tokens, this is not the token that is used for the beginning of
sequence. The token used is the <code>cls_token</code>.</p>

					</div>`,name:"bos_token"},{anchor:"transformers.BarthezTokenizerFast.eos_token",description:`<strong>eos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;/s&gt;&quot;</code>) &#x2014;
The end of sequence token.</p>
<div class="course-tip  bg-gradient-to-br dark:bg-gradient-to-r before:border-green-500 dark:before:border-green-800 from-green-50 dark:from-gray-900 to-white dark:to-gray-950 border border-green-50 text-green-700 dark:text-gray-400">
						
<p>When building a sequence using special tokens, this is not the token that is used for the end of sequence.
The token used is the <code>sep_token</code>.</p>

					</div>`,name:"eos_token"},{anchor:"transformers.BarthezTokenizerFast.sep_token",description:`<strong>sep_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;/s&gt;&quot;</code>) &#x2014;
The separator token, which is used when building a sequence from multiple sequences, e.g. two sequences for
sequence classification or for a text and a question for question answering. It is also used as the last
token of a sequence built with special tokens.`,name:"sep_token"},{anchor:"transformers.BarthezTokenizerFast.cls_token",description:`<strong>cls_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;s&gt;&quot;</code>) &#x2014;
The classifier token which is used when doing sequence classification (classification of the whole sequence
instead of per-token classification). It is the first token of the sequence when built with special tokens.`,name:"cls_token"},{anchor:"transformers.BarthezTokenizerFast.unk_token",description:`<strong>unk_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;unk&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.BarthezTokenizerFast.pad_token",description:`<strong>pad_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;pad&gt;&quot;</code>) &#x2014;
The token used for padding, for example when batching sequences of different lengths.`,name:"pad_token"},{anchor:"transformers.BarthezTokenizerFast.mask_token",description:`<strong>mask_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;mask&gt;&quot;</code>) &#x2014;
The token used for masking values. This is the token used when training this model with masked language
modeling. This is the token which the model will try to predict.`,name:"mask_token"},{anchor:"transformers.BarthezTokenizerFast.additional_special_tokens",description:`<strong>additional_special_tokens</strong> (<code>List[str]</code>, <em>optional</em>, defaults to <code>[&quot;&lt;s&gt;NOTUSED&quot;, &quot;&lt;/s&gt;NOTUSED&quot;]</code>) &#x2014;
Additional special tokens used by the tokenizer.`,name:"additional_special_tokens"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/barthez/tokenization_barthez_fast.py#L39"}}),G=new D({props:{name:"build_inputs_with_special_tokens",anchor:"transformers.BarthezTokenizerFast.build_inputs_with_special_tokens",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.BarthezTokenizerFast.build_inputs_with_special_tokens.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs to which the special tokens will be added.`,name:"token_ids_0"},{anchor:"transformers.BarthezTokenizerFast.build_inputs_with_special_tokens.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/barthez/tokenization_barthez_fast.py#L125",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>List of <a href="../glossary#input-ids">input IDs</a> with the appropriate special tokens.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),J=new D({props:{name:"create_token_type_ids_from_sequences",anchor:"transformers.BarthezTokenizerFast.create_token_type_ids_from_sequences",parameters:[{name:"token_ids_0",val:": typing.List[int]"},{name:"token_ids_1",val:": typing.Optional[typing.List[int]] = None"}],parametersDescription:[{anchor:"transformers.BarthezTokenizerFast.create_token_type_ids_from_sequences.token_ids_0",description:`<strong>token_ids_0</strong> (<code>List[int]</code>) &#x2014;
List of IDs.`,name:"token_ids_0"},{anchor:"transformers.BarthezTokenizerFast.create_token_type_ids_from_sequences.token_ids_1",description:`<strong>token_ids_1</strong> (<code>List[int]</code>, <em>optional</em>) &#x2014;
Optional second list of IDs for sequence pairs.`,name:"token_ids_1"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/barthez/tokenization_barthez_fast.py#L151",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>List of zeros.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`}}),Q=new $t({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/barthez.md"}}),{c(){m=a("meta"),A=s(),z=a("p"),Y=s(),f(P.$$.fragment),ge=s(),f(R.$$.fragment),ke=s(),M=a("p"),M.innerHTML=Ze,_e=s(),E=a("p"),E.textContent=et,be=s(),F=a("p"),F.innerHTML=tt,ze=s(),I=a("p"),I.innerHTML=nt,Te=s(),f(w.$$.fragment),ve=s(),f(H.$$.fragment),$e=s(),S=a("ul"),S.innerHTML=ot,xe=s(),f(O.$$.fragment),qe=s(),l=a("div"),f(N.$$.fragment),Me=s(),Z=a("p"),Z.innerHTML=st,Ee=s(),ee=a("p"),ee.innerHTML=rt,Fe=s(),T=a("div"),f(U.$$.fragment),Ie=s(),te=a("p"),te.textContent=at,He=s(),ne=a("ul"),ne.innerHTML=it,Se=s(),y=a("div"),f(V.$$.fragment),Oe=s(),oe=a("p"),oe.textContent=dt,Ne=s(),B=a("div"),f(W.$$.fragment),Ue=s(),se=a("p"),se.textContent=lt,Ve=s(),L=a("div"),f(j.$$.fragment),We=s(),re=a("p"),re.innerHTML=ct,we=s(),f(K.$$.fragment),ye=s(),h=a("div"),f(X.$$.fragment),je=s(),ae=a("p"),ae.innerHTML=mt,Ke=s(),ie=a("p"),ie.innerHTML=pt,Xe=s(),v=a("div"),f(G.$$.fragment),Ge=s(),de=a("p"),de.textContent=ht,Je=s(),le=a("ul"),le.innerHTML=ft,Qe=s(),C=a("div"),f(J.$$.fragment),Ye=s(),ce=a("p"),ce.textContent=ut,Be=s(),f(Q.$$.fragment),Le=s(),he=a("p"),this.h()},l(e){const t=Tt("svelte-u9bgzb",document.head);m=i(t,"META",{name:!0,content:!0}),t.forEach(n),A=r(e),z=i(e,"P",{}),x(z).forEach(n),Y=r(e),u(P.$$.fragment,e),ge=r(e),u(R.$$.fragment,e),ke=r(e),M=i(e,"P",{"data-svelte-h":!0}),c(M)!=="svelte-1upbu9r"&&(M.innerHTML=Ze),_e=r(e),E=i(e,"P",{"data-svelte-h":!0}),c(E)!=="svelte-2fdm8b"&&(E.textContent=et),be=r(e),F=i(e,"P",{"data-svelte-h":!0}),c(F)!=="svelte-1f8xp20"&&(F.innerHTML=tt),ze=r(e),I=i(e,"P",{"data-svelte-h":!0}),c(I)!=="svelte-1mozgsw"&&(I.innerHTML=nt),Te=r(e),u(w.$$.fragment,e),ve=r(e),u(H.$$.fragment,e),$e=r(e),S=i(e,"UL",{"data-svelte-h":!0}),c(S)!=="svelte-1p96yp5"&&(S.innerHTML=ot),xe=r(e),u(O.$$.fragment,e),qe=r(e),l=i(e,"DIV",{class:!0});var p=x(l);u(N.$$.fragment,p),Me=r(p),Z=i(p,"P",{"data-svelte-h":!0}),c(Z)!=="svelte-1h3npu3"&&(Z.innerHTML=st),Ee=r(p),ee=i(p,"P",{"data-svelte-h":!0}),c(ee)!=="svelte-1urdkfw"&&(ee.innerHTML=rt),Fe=r(p),T=i(p,"DIV",{class:!0});var me=x(T);u(U.$$.fragment,me),Ie=r(me),te=i(me,"P",{"data-svelte-h":!0}),c(te)!=="svelte-js8h2n"&&(te.textContent=at),He=r(me),ne=i(me,"UL",{"data-svelte-h":!0}),c(ne)!=="svelte-rq8uot"&&(ne.innerHTML=it),me.forEach(n),Se=r(p),y=i(p,"DIV",{class:!0});var De=x(y);u(V.$$.fragment,De),Oe=r(De),oe=i(De,"P",{"data-svelte-h":!0}),c(oe)!=="svelte-b3k2yi"&&(oe.textContent=dt),De.forEach(n),Ne=r(p),B=i(p,"DIV",{class:!0});var Ae=x(B);u(W.$$.fragment,Ae),Ue=r(Ae),se=i(Ae,"P",{"data-svelte-h":!0}),c(se)!=="svelte-sqjw56"&&(se.textContent=lt),Ae.forEach(n),Ve=r(p),L=i(p,"DIV",{class:!0});var Pe=x(L);u(j.$$.fragment,Pe),We=r(Pe),re=i(Pe,"P",{"data-svelte-h":!0}),c(re)!=="svelte-1f4f5kp"&&(re.innerHTML=ct),Pe.forEach(n),p.forEach(n),we=r(e),u(K.$$.fragment,e),ye=r(e),h=i(e,"DIV",{class:!0});var $=x(h);u(X.$$.fragment,$),je=r($),ae=i($,"P",{"data-svelte-h":!0}),c(ae)!=="svelte-1ifo2qo"&&(ae.innerHTML=mt),Ke=r($),ie=i($,"P",{"data-svelte-h":!0}),c(ie)!=="svelte-1ndfe3e"&&(ie.innerHTML=pt),Xe=r($),v=i($,"DIV",{class:!0});var pe=x(v);u(G.$$.fragment,pe),Ge=r(pe),de=i(pe,"P",{"data-svelte-h":!0}),c(de)!=="svelte-js8h2n"&&(de.textContent=ht),Je=r(pe),le=i(pe,"UL",{"data-svelte-h":!0}),c(le)!=="svelte-rq8uot"&&(le.innerHTML=ft),pe.forEach(n),Qe=r($),C=i($,"DIV",{class:!0});var Re=x(C);u(J.$$.fragment,Re),Ye=r(Re),ce=i(Re,"P",{"data-svelte-h":!0}),c(ce)!=="svelte-sqjw56"&&(ce.textContent=ut),Re.forEach(n),$.forEach(n),Be=r(e),u(Q.$$.fragment,e),Le=r(e),he=i(e,"P",{}),x(he).forEach(n),this.h()},h(){q(m,"name","hf:doc:metadata"),q(m,"content",wt),q(T,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),q(y,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),q(B,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),q(L,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),q(l,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),q(v,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),q(C,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),q(h,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,t){o(document.head,m),d(e,A,t),d(e,z,t),d(e,Y,t),g(P,e,t),d(e,ge,t),g(R,e,t),d(e,ke,t),d(e,M,t),d(e,_e,t),d(e,E,t),d(e,be,t),d(e,F,t),d(e,ze,t),d(e,I,t),d(e,Te,t),g(w,e,t),d(e,ve,t),g(H,e,t),d(e,$e,t),d(e,S,t),d(e,xe,t),g(O,e,t),d(e,qe,t),d(e,l,t),g(N,l,null),o(l,Me),o(l,Z),o(l,Ee),o(l,ee),o(l,Fe),o(l,T),g(U,T,null),o(T,Ie),o(T,te),o(T,He),o(T,ne),o(l,Se),o(l,y),g(V,y,null),o(y,Oe),o(y,oe),o(l,Ne),o(l,B),g(W,B,null),o(B,Ue),o(B,se),o(l,Ve),o(l,L),g(j,L,null),o(L,We),o(L,re),d(e,we,t),g(K,e,t),d(e,ye,t),d(e,h,t),g(X,h,null),o(h,je),o(h,ae),o(h,Ke),o(h,ie),o(h,Xe),o(h,v),g(G,v,null),o(v,Ge),o(v,de),o(v,Je),o(v,le),o(h,Qe),o(h,C),g(J,C,null),o(C,Ye),o(C,ce),d(e,Be,t),g(Q,e,t),d(e,Le,t),d(e,he,t),Ce=!0},p(e,[t]){const p={};t&2&&(p.$$scope={dirty:t,ctx:e}),w.$set(p)},i(e){Ce||(k(P.$$.fragment,e),k(R.$$.fragment,e),k(w.$$.fragment,e),k(H.$$.fragment,e),k(O.$$.fragment,e),k(N.$$.fragment,e),k(U.$$.fragment,e),k(V.$$.fragment,e),k(W.$$.fragment,e),k(j.$$.fragment,e),k(K.$$.fragment,e),k(X.$$.fragment,e),k(G.$$.fragment,e),k(J.$$.fragment,e),k(Q.$$.fragment,e),Ce=!0)},o(e){_(P.$$.fragment,e),_(R.$$.fragment,e),_(w.$$.fragment,e),_(H.$$.fragment,e),_(O.$$.fragment,e),_(N.$$.fragment,e),_(U.$$.fragment,e),_(V.$$.fragment,e),_(W.$$.fragment,e),_(j.$$.fragment,e),_(K.$$.fragment,e),_(X.$$.fragment,e),_(G.$$.fragment,e),_(J.$$.fragment,e),_(Q.$$.fragment,e),Ce=!1},d(e){e&&(n(A),n(z),n(Y),n(ge),n(ke),n(M),n(_e),n(E),n(be),n(F),n(ze),n(I),n(Te),n(ve),n($e),n(S),n(xe),n(qe),n(l),n(we),n(ye),n(h),n(Be),n(Le),n(he)),n(m),b(P,e),b(R,e),b(w,e),b(H,e),b(O,e),b(N),b(U),b(V),b(W),b(j),b(K,e),b(X),b(G),b(J),b(Q,e)}}}const wt='{"title":"BARThez","local":"barthez","sections":[{"title":"개요","local":"overview","sections":[],"depth":2},{"title":"리소스","local":"resources","sections":[],"depth":2},{"title":"BarthezTokenizer","local":"bartheztokenizer ][ transformers.BarthezTokenizer","sections":[],"depth":2},{"title":"BarthezTokenizerFast","local":"bartheztokenizerfast ][ transformers.BarthezTokenizerFast","sections":[],"depth":2}],"depth":1}';function yt(ue){return kt(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Pt extends bt{constructor(m){super(),zt(this,m,yt,qt,gt,{})}}export{Pt as component};
