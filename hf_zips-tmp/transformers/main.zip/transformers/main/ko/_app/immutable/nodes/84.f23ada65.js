import{s as yt,o as bt,n as ve}from"../chunks/scheduler.bdbef820.js";import{S as kt,i as wt,g as p,s as r,r as _,A as xt,h,f as a,c as i,j as we,u as M,x as v,k as Me,y as d,a as l,v as T,d as y,t as b,w as k}from"../chunks/index.33f81d56.js";import{T as Ve}from"../chunks/Tip.34194030.js";import{D as $e}from"../chunks/Docstring.abcbe1ac.js";import{C as We}from"../chunks/CodeBlock.3bad7fc9.js";import{F as vt,M as gt}from"../chunks/Markdown.03194dea.js";import{E as Se}from"../chunks/ExampleCodeBlock.16b3b633.js";import{H as je,E as jt}from"../chunks/getInferenceSnippets.64cd9466.js";function $t(J){let e,c="Examples:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyME1hcmlhbk1vZGVsJTJDJTIwTWFyaWFuQ29uZmlnJTBBJTBBJTIzJTIwSW5pdGlhbGl6aW5nJTIwYSUyME1hcmlhbiUyMEhlbHNpbmtpLU5MUCUyRm9wdXMtbXQtZW4tZGUlMjBzdHlsZSUyMGNvbmZpZ3VyYXRpb24lMEFjb25maWd1cmF0aW9uJTIwJTNEJTIwTWFyaWFuQ29uZmlnKCklMEElMEElMjMlMjBJbml0aWFsaXppbmclMjBhJTIwbW9kZWwlMjBmcm9tJTIwdGhlJTIwSGVsc2lua2ktTkxQJTJGb3B1cy1tdC1lbi1kZSUyMHN0eWxlJTIwY29uZmlndXJhdGlvbiUwQW1vZGVsJTIwJTNEJTIwTWFyaWFuTW9kZWwoY29uZmlndXJhdGlvbiklMEElMEElMjMlMjBBY2Nlc3NpbmclMjB0aGUlMjBtb2RlbCUyMGNvbmZpZ3VyYXRpb24lMEFjb25maWd1cmF0aW9uJTIwJTNEJTIwbW9kZWwuY29uZmln",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> MarianModel, MarianConfig

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a Marian Helsinki-NLP/opus-mt-en-de style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = MarianConfig()

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Initializing a model from the Helsinki-NLP/opus-mt-en-de style configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MarianModel(configuration)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Accessing the model configuration</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>configuration = model.config`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-kvfsh7"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function Jt(J){let e,c="Examples:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyME1hcmlhbkZvckNhdXNhbExNJTJDJTIwTWFyaWFuVG9rZW5pemVyJTBBJTBBbW9kZWwlMjAlM0QlMjBNYXJpYW5Gb3JDYXVzYWxMTS5mcm9tX3ByZXRyYWluZWQoJTIySGVsc2lua2ktTkxQJTJGb3B1cy1tdC1lbi1kZSUyMiklMEF0b2tlbml6ZXIlMjAlM0QlMjBNYXJpYW5Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMkhlbHNpbmtpLU5MUCUyRm9wdXMtbXQtZW4tZGUlMjIpJTBBc3JjX3RleHRzJTIwJTNEJTIwJTVCJTIySSUyMGFtJTIwYSUyMHNtYWxsJTIwZnJvZy4lMjIlMkMlMjAlMjJUb20lMjBhc2tlZCUyMGhpcyUyMHRlYWNoZXIlMjBmb3IlMjBhZHZpY2UuJTIyJTVEJTBBdGd0X3RleHRzJTIwJTNEJTIwJTVCJTIySWNoJTIwYmluJTIwZWluJTIwa2xlaW5lciUyMEZyb3NjaC4lMjIlMkMlMjAlMjJUb20lMjBiYXQlMjBzZWluZW4lMjBMZWhyZXIlMjB1bSUyMFJhdC4lMjIlNUQlMjAlMjAlMjMlMjBvcHRpb25hbCUwQWlucHV0cyUyMCUzRCUyMHRva2VuaXplcihzcmNfdGV4dHMlMkMlMjB0ZXh0X3RhcmdldCUzRHRndF90ZXh0cyUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIlMkMlMjBwYWRkaW5nJTNEVHJ1ZSklMEElMEFvdXRwdXRzJTIwJTNEJTIwbW9kZWwoKippbnB1dHMpJTIwJTIwJTIzJTIwc2hvdWxkJTIwd29yaw==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> MarianForCausalLM, MarianTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>model = MarianForCausalLM.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = MarianTokenizer.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>src_texts = [<span class="hljs-string">&quot;I am a small frog.&quot;</span>, <span class="hljs-string">&quot;Tom asked his teacher for advice.&quot;</span>]
<span class="hljs-meta">&gt;&gt;&gt; </span>tgt_texts = [<span class="hljs-string">&quot;Ich bin ein kleiner Frosch.&quot;</span>, <span class="hljs-string">&quot;Tom bat seinen Lehrer um Rat.&quot;</span>]  <span class="hljs-comment"># optional</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(src_texts, text_target=tgt_texts, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>, padding=<span class="hljs-literal">True</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)  <span class="hljs-comment"># should work</span>`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-kvfsh7"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function Ut(J){let e,c=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){e=p("p"),e.innerHTML=c},l(n){e=h(n,"P",{"data-svelte-h":!0}),v(e)!=="svelte-fincs2"&&(e.innerHTML=c)},m(n,s){l(n,e,s)},p:ve,d(n){n&&a(e)}}}function zt(J){let e,c="Example:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBNYXJpYW5Nb2RlbCUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMkhlbHNpbmtpLU5MUCUyRm9wdXMtbXQtZW4tZGUlMjIpJTBBbW9kZWwlMjAlM0QlMjBNYXJpYW5Nb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIySGVsc2lua2ktTkxQJTJGb3B1cy1tdC1lbi1kZSUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTIyU3R1ZGllcyUyMGhhdmUlMjBiZWVuJTIwc2hvd24lMjB0aGF0JTIwb3duaW5nJTIwYSUyMGRvZyUyMGlzJTIwZ29vZCUyMGZvciUyMHlvdSUyMiUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIpJTBBZGVjb2Rlcl9pbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTBBJTIwJTIwJTIwJTIwJTIyJTNDcGFkJTNFJTIwU3R1ZGllbiUyMGhhYmVuJTIwZ2V6ZWlndCUyMGRhc3MlMjBlcyUyMGhpbGZyZWljaCUyMGlzdCUyMGVpbmVuJTIwSHVuZCUyMHp1JTIwYmVzaXR6ZW4lMjIlMkMlMEElMjAlMjAlMjAlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyJTJDJTBBJTIwJTIwJTIwJTIwYWRkX3NwZWNpYWxfdG9rZW5zJTNERmFsc2UlMkMlMEEpJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKGlucHV0X2lkcyUzRGlucHV0cy5pbnB1dF9pZHMlMkMlMjBkZWNvZGVyX2lucHV0X2lkcyUzRGRlY29kZXJfaW5wdXRzLmlucHV0X2lkcyklMEElMEFsYXN0X2hpZGRlbl9zdGF0ZXMlMjAlM0QlMjBvdXRwdXRzLmxhc3RfaGlkZGVuX3N0YXRlJTBBbGlzdChsYXN0X2hpZGRlbl9zdGF0ZXMuc2hhcGUp",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, MarianModel

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MarianModel.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Studies have been shown that owning a dog is good for you&quot;</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>decoder_inputs = tokenizer(
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;&lt;pad&gt; Studien haben gezeigt dass es hilfreich ist einen Hund zu besitzen&quot;</span>,
<span class="hljs-meta">... </span>    return_tensors=<span class="hljs-string">&quot;pt&quot;</span>,
<span class="hljs-meta">... </span>    add_special_tokens=<span class="hljs-literal">False</span>,
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(input_ids=inputs.input_ids, decoder_input_ids=decoder_inputs.input_ids)

<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_states = outputs.last_hidden_state
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">list</span>(last_hidden_states.shape)
[<span class="hljs-number">1</span>, <span class="hljs-number">26</span>, <span class="hljs-number">512</span>]`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-11lpom8"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function Ct(J){let e,c=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){e=p("p"),e.innerHTML=c},l(n){e=h(n,"P",{"data-svelte-h":!0}),v(e)!=="svelte-fincs2"&&(e.innerHTML=c)},m(n,s){l(n,e,s)},p:ve,d(n){n&&a(e)}}}function It(J){let e,c="Example:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBNYXJpYW5NVE1vZGVsJTBBJTBBc3JjJTIwJTNEJTIwJTIyZnIlMjIlMjAlMjAlMjMlMjBzb3VyY2UlMjBsYW5ndWFnZSUwQXRyZyUyMCUzRCUyMCUyMmVuJTIyJTIwJTIwJTIzJTIwdGFyZ2V0JTIwbGFuZ3VhZ2UlMEElMEFtb2RlbF9uYW1lJTIwJTNEJTIwZiUyMkhlbHNpbmtpLU5MUCUyRm9wdXMtbXQtJTdCc3JjJTdELSU3QnRyZyU3RCUyMiUwQW1vZGVsJTIwJTNEJTIwTWFyaWFuTVRNb2RlbC5mcm9tX3ByZXRyYWluZWQobW9kZWxfbmFtZSklMEF0b2tlbml6ZXIlMjAlM0QlMjBBdXRvVG9rZW5pemVyLmZyb21fcHJldHJhaW5lZChtb2RlbF9uYW1lKSUwQSUwQXNhbXBsZV90ZXh0JTIwJTNEJTIwJTIybyVDMyVCOSUyMGVzdCUyMGwnYXJyJUMzJUFBdCUyMGRlJTIwYnVzJTIwJTNGJTIyJTBBYmF0Y2glMjAlM0QlMjB0b2tlbml6ZXIoJTVCc2FtcGxlX3RleHQlNUQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyKSUwQSUwQWdlbmVyYXRlZF9pZHMlMjAlM0QlMjBtb2RlbC5nZW5lcmF0ZSgqKmJhdGNoKSUwQXRva2VuaXplci5iYXRjaF9kZWNvZGUoZ2VuZXJhdGVkX2lkcyUyQyUyMHNraXBfc3BlY2lhbF90b2tlbnMlM0RUcnVlKSU1QjAlNUQ=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, MarianMTModel

<span class="hljs-meta">&gt;&gt;&gt; </span>src = <span class="hljs-string">&quot;fr&quot;</span>  <span class="hljs-comment"># source language</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>trg = <span class="hljs-string">&quot;en&quot;</span>  <span class="hljs-comment"># target language</span>

<span class="hljs-meta">&gt;&gt;&gt; </span>model_name = <span class="hljs-string">f&quot;Helsinki-NLP/opus-mt-<span class="hljs-subst">{src}</span>-<span class="hljs-subst">{trg}</span>&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MarianMTModel.from_pretrained(model_name)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(model_name)

<span class="hljs-meta">&gt;&gt;&gt; </span>sample_text = <span class="hljs-string">&quot;où est l&#x27;arrêt de bus ?&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>batch = tokenizer([sample_text], return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>generated_ids = model.generate(**batch)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.batch_decode(generated_ids, skip_special_tokens=<span class="hljs-literal">True</span>)[<span class="hljs-number">0</span>]
<span class="hljs-string">&quot;Where&#x27;s the bus stop?&quot;</span>`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-11lpom8"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function Ft(J){let e,c=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){e=p("p"),e.innerHTML=c},l(n){e=h(n,"P",{"data-svelte-h":!0}),v(e)!=="svelte-fincs2"&&(e.innerHTML=c)},m(n,s){l(n,e,s)},p:ve,d(n){n&&a(e)}}}function Nt(J){let e,c="Example:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBNYXJpYW5Gb3JDYXVzYWxMTSUwQSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKCUyMkhlbHNpbmtpLU5MUCUyRm9wdXMtbXQtZnItZW4lMjIpJTBBbW9kZWwlMjAlM0QlMjBNYXJpYW5Gb3JDYXVzYWxMTS5mcm9tX3ByZXRyYWluZWQoJTIySGVsc2lua2ktTkxQJTJGb3B1cy1tdC1mci1lbiUyMiUyQyUyMGFkZF9jcm9zc19hdHRlbnRpb24lM0RGYWxzZSklMEFhc3NlcnQlMjBtb2RlbC5jb25maWcuaXNfZGVjb2RlciUyQyUyMGYlMjIlN0Jtb2RlbC5fX2NsYXNzX18lN0QlMjBoYXMlMjB0byUyMGJlJTIwY29uZmlndXJlZCUyMGFzJTIwYSUyMGRlY29kZXIuJTIyJTBBaW5wdXRzJTIwJTNEJTIwdG9rZW5pemVyKCUyMkhlbGxvJTJDJTIwbXklMjBkb2clMjBpcyUyMGN1dGUlMjIlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyKSUwQW91dHB1dHMlMjAlM0QlMjBtb2RlbCgqKmlucHV0cyklMEElMEFsb2dpdHMlMjAlM0QlMjBvdXRwdXRzLmxvZ2l0cyUwQWV4cGVjdGVkX3NoYXBlJTIwJTNEJTIwJTVCMSUyQyUyMGlucHV0cy5pbnB1dF9pZHMuc2hhcGUlNUItMSU1RCUyQyUyMG1vZGVsLmNvbmZpZy52b2NhYl9zaXplJTVEJTBBbGlzdChsb2dpdHMuc2hhcGUpJTIwJTNEJTNEJTIwZXhwZWN0ZWRfc2hhcGU=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, MarianForCausalLM

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-fr-en&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = MarianForCausalLM.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-fr-en&quot;</span>, add_cross_attention=<span class="hljs-literal">False</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">assert</span> model.config.is_decoder, <span class="hljs-string">f&quot;<span class="hljs-subst">{model.__class__}</span> has to be configured as a decoder.&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span>logits = outputs.logits
<span class="hljs-meta">&gt;&gt;&gt; </span>expected_shape = [<span class="hljs-number">1</span>, inputs.input_ids.shape[-<span class="hljs-number">1</span>], model.config.vocab_size]
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">list</span>(logits.shape) == expected_shape
<span class="hljs-literal">True</span>`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-11lpom8"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function qt(J){let e,c,n,s,u,o,w="The bare Marian Model outputting raw hidden-states without any specific head on top.",he,Z,H=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,re,C,G=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,B,f,I,ie,A,Te='The <a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianModel">MarianModel</a> forward method, overrides the <code>__call__</code> special method.',O,Y,te,me,P,D,L,F,le,ue,W,ye="The Marian Model with a language modeling head. Can be used for summarization.",de,be,Ie=`This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel">PreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,K,fe,E=`This model is also a PyTorch <a href="https://pytorch.org/docs/stable/nn.html#torch.nn.Module" rel="nofollow">torch.nn.Module</a> subclass.
Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage
and behavior.`,ne,X,Q,qe,ce,pe='The <a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianMTModel">MarianMTModel</a> forward method, overrides the <code>__call__</code> special method.',Je,N,ke,ee,oe,ge,x,$,V,S,q,j,z,R,se='The <a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianForCausalLM">MarianForCausalLM</a> forward method, overrides the <code>__call__</code> special method.',ae,Fe,Re,Ue,Be;return e=new je({props:{title:"MarianModel",local:"transformers.MarianModel",headingTag:"h2"}}),s=new $e({props:{name:"class transformers.MarianModel",anchor:"transformers.MarianModel",parameters:[{name:"config",val:": MarianConfig"}],parametersDescription:[{anchor:"transformers.MarianModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig">MarianConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_marian.py#L1153"}}),I=new $e({props:{name:"forward",anchor:"transformers.MarianModel.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"decoder_attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"cross_attn_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"encoder_outputs",val:": typing.Union[typing.Tuple[torch.Tensor], transformers.modeling_outputs.BaseModelOutput, NoneType] = None"},{name:"past_key_values",val:": typing.Optional[typing.Tuple[typing.Tuple[torch.FloatTensor]]] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"decoder_inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.Tensor] = None"}],parametersDescription:[{anchor:"transformers.MarianModel.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.MarianModel.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.MarianModel.forward.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>Marian uses the <code>pad_token_id</code> as the starting token for <code>decoder_input_ids</code> generation. If
<code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).`,name:"decoder_input_ids"},{anchor:"transformers.MarianModel.forward.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default.`,name:"decoder_attention_mask"},{anchor:"transformers.MarianModel.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.Tensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.MarianModel.forward.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.MarianModel.forward.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.MarianModel.forward.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>Union[Tuple[torch.Tensor], ~modeling_outputs.BaseModelOutput, NoneType]</code>) &#x2014;
Tuple consists of (<code>last_hidden_state</code>, <em>optional</em>: <code>hidden_states</code>, <em>optional</em>: <code>attentions</code>)
<code>last_hidden_state</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) is a sequence of
hidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.`,name:"encoder_outputs"},{anchor:"transformers.MarianModel.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>Tuple[Tuple[torch.FloatTensor]]</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.MarianModel.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.MarianModel.forward.decoder_inputs_embeds",description:`<strong>decoder_inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, target_sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>decoder_input_ids</code> you can choose to directly pass an embedded
representation. If <code>past_key_values</code> is used, optionally only the last <code>decoder_inputs_embeds</code> have to be
input (see <code>past_key_values</code>). This is useful if you want more control over how to convert
<code>decoder_input_ids</code> indices into associated vectors than the model&#x2019;s internal embedding lookup matrix.</p>
<p>If <code>decoder_input_ids</code> and <code>decoder_inputs_embeds</code> are both unset, <code>decoder_inputs_embeds</code> takes the value
of <code>inputs_embeds</code>.`,name:"decoder_inputs_embeds"},{anchor:"transformers.MarianModel.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.MarianModel.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.MarianModel.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.MarianModel.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.MarianModel.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.Tensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_marian.py#L1238",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqModelOutput"
>transformers.modeling_outputs.Seq2SeqModelOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig"
>MarianConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the decoder of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>EncoderDecoderCache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.EncoderDecoderCache"
>EncoderDecoderCache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqModelOutput"
>transformers.modeling_outputs.Seq2SeqModelOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Y=new Ve({props:{$$slots:{default:[Ut]},$$scope:{ctx:J}}}),me=new Se({props:{anchor:"transformers.MarianModel.forward.example",$$slots:{default:[zt]},$$scope:{ctx:J}}}),D=new je({props:{title:"MarianMTModel",local:"transformers.MarianMTModel",headingTag:"h2"}}),le=new $e({props:{name:"class transformers.MarianMTModel",anchor:"transformers.MarianMTModel",parameters:[{name:"config",val:": MarianConfig"}],parametersDescription:[{anchor:"transformers.MarianMTModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig">MarianConfig</a>) &#x2014;
Model configuration class with all the parameters of the model. Initializing with a config file does not
load the weights associated with the model, only the configuration. Check out the
<a href="/docs/transformers/main/ko/main_classes/model#transformers.PreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_marian.py#L1357"}}),Q=new $e({props:{name:"forward",anchor:"transformers.MarianMTModel.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"decoder_attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"decoder_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"cross_attn_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"encoder_outputs",val:": typing.Union[typing.Tuple[torch.Tensor], transformers.modeling_outputs.BaseModelOutput, NoneType] = None"},{name:"past_key_values",val:": typing.Optional[typing.Tuple[typing.Tuple[torch.FloatTensor]]] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"decoder_inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.Tensor] = None"}],parametersDescription:[{anchor:"transformers.MarianMTModel.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.MarianMTModel.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.MarianMTModel.forward.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>Marian uses the <code>pad_token_id</code> as the starting token for <code>decoder_input_ids</code> generation. If
<code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).`,name:"decoder_input_ids"},{anchor:"transformers.MarianMTModel.forward.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default.`,name:"decoder_attention_mask"},{anchor:"transformers.MarianMTModel.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.Tensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.MarianMTModel.forward.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.MarianMTModel.forward.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.MarianMTModel.forward.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>Union[Tuple[torch.Tensor], ~modeling_outputs.BaseModelOutput, NoneType]</code>) &#x2014;
Tuple consists of (<code>last_hidden_state</code>, <em>optional</em>: <code>hidden_states</code>, <em>optional</em>: <code>attentions</code>)
<code>last_hidden_state</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) is a sequence of
hidden-states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.`,name:"encoder_outputs"},{anchor:"transformers.MarianMTModel.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>Tuple[Tuple[torch.FloatTensor]]</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.MarianMTModel.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.MarianMTModel.forward.decoder_inputs_embeds",description:`<strong>decoder_inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, target_sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>decoder_input_ids</code> you can choose to directly pass an embedded
representation. If <code>past_key_values</code> is used, optionally only the last <code>decoder_inputs_embeds</code> have to be
input (see <code>past_key_values</code>). This is useful if you want more control over how to convert
<code>decoder_input_ids</code> indices into associated vectors than the model&#x2019;s internal embedding lookup matrix.</p>
<p>If <code>decoder_input_ids</code> and <code>decoder_inputs_embeds</code> are both unset, <code>decoder_inputs_embeds</code> takes the value
of <code>inputs_embeds</code>.`,name:"decoder_inputs_embeds"},{anchor:"transformers.MarianMTModel.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the masked language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code> or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored
(masked), the loss is only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"},{anchor:"transformers.MarianMTModel.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.MarianMTModel.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.MarianMTModel.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.MarianMTModel.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.MarianMTModel.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.Tensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_marian.py#L1495",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqLMOutput"
>transformers.modeling_outputs.Seq2SeqLMOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig"
>MarianConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Language modeling loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>EncoderDecoderCache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.EncoderDecoderCache"
>EncoderDecoderCache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.Seq2SeqLMOutput"
>transformers.modeling_outputs.Seq2SeqLMOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),N=new Ve({props:{$$slots:{default:[Ct]},$$scope:{ctx:J}}}),ee=new Se({props:{anchor:"transformers.MarianMTModel.forward.example",$$slots:{default:[It]},$$scope:{ctx:J}}}),ge=new je({props:{title:"MarianForCausalLM",local:"transformers.MarianForCausalLM",headingTag:"h2"}}),V=new $e({props:{name:"class transformers.MarianForCausalLM",anchor:"transformers.MarianForCausalLM",parameters:[{name:"config",val:""}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_marian.py#L1645"}}),j=new $e({props:{name:"forward",anchor:"transformers.MarianForCausalLM.forward",parameters:[{name:"input_ids",val:": typing.Optional[torch.LongTensor] = None"},{name:"attention_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"encoder_hidden_states",val:": typing.Optional[torch.FloatTensor] = None"},{name:"encoder_attention_mask",val:": typing.Optional[torch.FloatTensor] = None"},{name:"head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"cross_attn_head_mask",val:": typing.Optional[torch.Tensor] = None"},{name:"past_key_values",val:": typing.Optional[typing.List[torch.FloatTensor]] = None"},{name:"inputs_embeds",val:": typing.Optional[torch.FloatTensor] = None"},{name:"labels",val:": typing.Optional[torch.LongTensor] = None"},{name:"use_cache",val:": typing.Optional[bool] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"cache_position",val:": typing.Optional[torch.LongTensor] = None"}],parametersDescription:[{anchor:"transformers.MarianForCausalLM.forward.input_ids",description:`<strong>input_ids</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.MarianForCausalLM.forward.attention_mask",description:`<strong>attention_mask</strong> (<code>torch.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.MarianForCausalLM.forward.encoder_hidden_states",description:`<strong>encoder_hidden_states</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Sequence of hidden-states at the output of the last layer of the encoder. Used in the cross-attention
if the model is configured as a decoder.`,name:"encoder_hidden_states"},{anchor:"transformers.MarianForCausalLM.forward.encoder_attention_mask",description:`<strong>encoder_attention_mask</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on the padding token indices of the encoder input. This mask is used in
the cross-attention if the model is configured as a decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>`,name:"encoder_attention_mask"},{anchor:"transformers.MarianForCausalLM.forward.head_mask",description:`<strong>head_mask</strong> (<code>torch.Tensor</code> of shape <code>(num_heads,)</code> or <code>(num_layers, num_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the self-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.MarianForCausalLM.forward.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>torch.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.MarianForCausalLM.forward.past_key_values",description:`<strong>past_key_values</strong> (<code>List[torch.FloatTensor]</code>, <em>optional</em>) &#x2014;
Pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used to speed up sequential decoding. This typically consists in the <code>past_key_values</code>
returned by the model at a previous stage of decoding, when <code>use_cache=True</code> or <code>config.use_cache=True</code>.</p>
<p>Two formats are allowed:</p>
<ul>
<li>a <a href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache">Cache</a> instance, see our <a href="https://huggingface.co/docs/transformers/en/kv_cache" rel="nofollow">kv cache guide</a>;</li>
<li>Tuple of <code>tuple(torch.FloatTensor)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of
shape <code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>). This is also known as the legacy
cache format.</li>
</ul>
<p>The model will output the same cache format that is fed as input. If no <code>past_key_values</code> are passed, the
legacy cache format will be returned.</p>
<p>If <code>past_key_values</code> are used, the user can optionally input only the last <code>input_ids</code> (those that don&#x2019;t
have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all <code>input_ids</code>
of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.MarianForCausalLM.forward.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation. This
is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors than the
model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.MarianForCausalLM.forward.labels",description:`<strong>labels</strong> (<code>torch.LongTensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the masked language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code> or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored
(masked), the loss is only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"},{anchor:"transformers.MarianForCausalLM.forward.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>).`,name:"use_cache"},{anchor:"transformers.MarianForCausalLM.forward.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.MarianForCausalLM.forward.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.MarianForCausalLM.forward.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"},{anchor:"transformers.MarianForCausalLM.forward.cache_position",description:`<strong>cache_position</strong> (<code>torch.LongTensor</code> of shape <code>(sequence_length)</code>, <em>optional</em>) &#x2014;
Indices depicting the position of the input sequence tokens in the sequence. Contrarily to <code>position_ids</code>,
this tensor is not affected by padding. It is used to update the cache in the correct position and to infer
the complete sequence length.`,name:"cache_position"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_marian.py#L1678",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.CausalLMOutputWithCrossAttentions"
>transformers.modeling_outputs.CausalLMOutputWithCrossAttentions</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig"
>MarianConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>torch.FloatTensor</code> of shape <code>(1,)</code>, <em>optional</em>, returned when <code>labels</code> is provided) — Language modeling loss (for next-token prediction).</p>
</li>
<li>
<p><strong>logits</strong> (<code>torch.FloatTensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>hidden_states</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for the output of the embeddings, if the model has an embedding layer, +
one for the output of each layer) of shape <code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.</p>
</li>
<li>
<p><strong>attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(torch.FloatTensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>torch.FloatTensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Cross attentions weights after the attention softmax, used to compute the weighted average in the
cross-attention heads.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>Cache</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — It is a <a
  href="/docs/transformers/main/ko/internal/generation_utils#transformers.Cache"
>Cache</a> instance. For more details, see our <a
  href="https://huggingface.co/docs/transformers/en/kv_cache"
  rel="nofollow"
>kv cache guide</a>.</p>
<p>Contains pre-computed hidden-states (key and values in the attention blocks) that can be used (see
<code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_outputs.CausalLMOutputWithCrossAttentions"
>transformers.modeling_outputs.CausalLMOutputWithCrossAttentions</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),Fe=new Ve({props:{$$slots:{default:[Ft]},$$scope:{ctx:J}}}),Ue=new Se({props:{anchor:"transformers.MarianForCausalLM.forward.example",$$slots:{default:[Nt]},$$scope:{ctx:J}}}),{c(){_(e.$$.fragment),c=r(),n=p("div"),_(s.$$.fragment),u=r(),o=p("p"),o.textContent=w,he=r(),Z=p("p"),Z.innerHTML=H,re=r(),C=p("p"),C.innerHTML=G,B=r(),f=p("div"),_(I.$$.fragment),ie=r(),A=p("p"),A.innerHTML=Te,O=r(),_(Y.$$.fragment),te=r(),_(me.$$.fragment),P=r(),_(D.$$.fragment),L=r(),F=p("div"),_(le.$$.fragment),ue=r(),W=p("p"),W.textContent=ye,de=r(),be=p("p"),be.innerHTML=Ie,K=r(),fe=p("p"),fe.innerHTML=E,ne=r(),X=p("div"),_(Q.$$.fragment),qe=r(),ce=p("p"),ce.innerHTML=pe,Je=r(),_(N.$$.fragment),ke=r(),_(ee.$$.fragment),oe=r(),_(ge.$$.fragment),x=r(),$=p("div"),_(V.$$.fragment),S=r(),q=p("div"),_(j.$$.fragment),z=r(),R=p("p"),R.innerHTML=se,ae=r(),_(Fe.$$.fragment),Re=r(),_(Ue.$$.fragment),this.h()},l(m){M(e.$$.fragment,m),c=i(m),n=h(m,"DIV",{class:!0});var U=we(n);M(s.$$.fragment,U),u=i(U),o=h(U,"P",{"data-svelte-h":!0}),v(o)!=="svelte-183di38"&&(o.textContent=w),he=i(U),Z=h(U,"P",{"data-svelte-h":!0}),v(Z)!=="svelte-u3dlub"&&(Z.innerHTML=H),re=i(U),C=h(U,"P",{"data-svelte-h":!0}),v(C)!=="svelte-hswkmf"&&(C.innerHTML=G),B=i(U),f=h(U,"DIV",{class:!0});var ze=we(f);M(I.$$.fragment,ze),ie=i(ze),A=h(ze,"P",{"data-svelte-h":!0}),v(A)!=="svelte-14zduaa"&&(A.innerHTML=Te),O=i(ze),M(Y.$$.fragment,ze),te=i(ze),M(me.$$.fragment,ze),ze.forEach(a),U.forEach(a),P=i(m),M(D.$$.fragment,m),L=i(m),F=h(m,"DIV",{class:!0});var _e=we(F);M(le.$$.fragment,_e),ue=i(_e),W=h(_e,"P",{"data-svelte-h":!0}),v(W)!=="svelte-1k5jxq4"&&(W.textContent=ye),de=i(_e),be=h(_e,"P",{"data-svelte-h":!0}),v(be)!=="svelte-u3dlub"&&(be.innerHTML=Ie),K=i(_e),fe=h(_e,"P",{"data-svelte-h":!0}),v(fe)!=="svelte-hswkmf"&&(fe.innerHTML=E),ne=i(_e),X=h(_e,"DIV",{class:!0});var Ne=we(X);M(Q.$$.fragment,Ne),qe=i(Ne),ce=h(Ne,"P",{"data-svelte-h":!0}),v(ce)!=="svelte-1av9f6a"&&(ce.innerHTML=pe),Je=i(Ne),M(N.$$.fragment,Ne),ke=i(Ne),M(ee.$$.fragment,Ne),Ne.forEach(a),_e.forEach(a),oe=i(m),M(ge.$$.fragment,m),x=i(m),$=h(m,"DIV",{class:!0});var Le=we($);M(V.$$.fragment,Le),S=i(Le),q=h(Le,"DIV",{class:!0});var xe=we(q);M(j.$$.fragment,xe),z=i(xe),R=h(xe,"P",{"data-svelte-h":!0}),v(R)!=="svelte-1mt9q5a"&&(R.innerHTML=se),ae=i(xe),M(Fe.$$.fragment,xe),Re=i(xe),M(Ue.$$.fragment,xe),xe.forEach(a),Le.forEach(a),this.h()},h(){Me(f,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(n,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(X,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(F,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(q,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me($,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(m,U){T(e,m,U),l(m,c,U),l(m,n,U),T(s,n,null),d(n,u),d(n,o),d(n,he),d(n,Z),d(n,re),d(n,C),d(n,B),d(n,f),T(I,f,null),d(f,ie),d(f,A),d(f,O),T(Y,f,null),d(f,te),T(me,f,null),l(m,P,U),T(D,m,U),l(m,L,U),l(m,F,U),T(le,F,null),d(F,ue),d(F,W),d(F,de),d(F,be),d(F,K),d(F,fe),d(F,ne),d(F,X),T(Q,X,null),d(X,qe),d(X,ce),d(X,Je),T(N,X,null),d(X,ke),T(ee,X,null),l(m,oe,U),T(ge,m,U),l(m,x,U),l(m,$,U),T(V,$,null),d($,S),d($,q),T(j,q,null),d(q,z),d(q,R),d(q,ae),T(Fe,q,null),d(q,Re),T(Ue,q,null),Be=!0},p(m,U){const ze={};U&2&&(ze.$$scope={dirty:U,ctx:m}),Y.$set(ze);const _e={};U&2&&(_e.$$scope={dirty:U,ctx:m}),me.$set(_e);const Ne={};U&2&&(Ne.$$scope={dirty:U,ctx:m}),N.$set(Ne);const Le={};U&2&&(Le.$$scope={dirty:U,ctx:m}),ee.$set(Le);const xe={};U&2&&(xe.$$scope={dirty:U,ctx:m}),Fe.$set(xe);const nt={};U&2&&(nt.$$scope={dirty:U,ctx:m}),Ue.$set(nt)},i(m){Be||(y(e.$$.fragment,m),y(s.$$.fragment,m),y(I.$$.fragment,m),y(Y.$$.fragment,m),y(me.$$.fragment,m),y(D.$$.fragment,m),y(le.$$.fragment,m),y(Q.$$.fragment,m),y(N.$$.fragment,m),y(ee.$$.fragment,m),y(ge.$$.fragment,m),y(V.$$.fragment,m),y(j.$$.fragment,m),y(Fe.$$.fragment,m),y(Ue.$$.fragment,m),Be=!0)},o(m){b(e.$$.fragment,m),b(s.$$.fragment,m),b(I.$$.fragment,m),b(Y.$$.fragment,m),b(me.$$.fragment,m),b(D.$$.fragment,m),b(le.$$.fragment,m),b(Q.$$.fragment,m),b(N.$$.fragment,m),b(ee.$$.fragment,m),b(ge.$$.fragment,m),b(V.$$.fragment,m),b(j.$$.fragment,m),b(Fe.$$.fragment,m),b(Ue.$$.fragment,m),Be=!1},d(m){m&&(a(c),a(n),a(P),a(L),a(F),a(oe),a(x),a($)),k(e,m),k(s),k(I),k(Y),k(me),k(D,m),k(le),k(Q),k(N),k(ee),k(ge,m),k(V),k(j),k(Fe),k(Ue)}}}function Zt(J){let e,c;return e=new gt({props:{$$slots:{default:[qt]},$$scope:{ctx:J}}}),{c(){_(e.$$.fragment)},l(n){M(e.$$.fragment,n)},m(n,s){T(e,n,s),c=!0},p(n,s){const u={};s&2&&(u.$$scope={dirty:s,ctx:n}),e.$set(u)},i(n){c||(y(e.$$.fragment,n),c=!0)},o(n){b(e.$$.fragment,n),c=!1},d(n){k(e,n)}}}function Wt(J){let e,c="TensorFlow models and layers in <code>transformers</code> accept two formats as input:",n,s,u="<li>having all inputs as keyword arguments (like PyTorch models), or</li> <li>having all inputs as a list, tuple or dict in the first positional argument.</li>",o,w,he=`The reason the second format is supported is that Keras methods prefer this format when passing inputs to models
and layers. Because of this support, when using methods like <code>model.fit()</code> things should “just work” for you - just
pass your inputs and labels in any format that <code>model.fit()</code> supports! If, however, you want to use the second
format outside of Keras methods like <code>fit()</code> and <code>predict()</code>, such as when creating your own layers or models with
the Keras <code>Functional</code> API, there are three possibilities you can use to gather all the input Tensors in the first
positional argument:`,Z,H,re=`<li>a single Tensor with <code>input_ids</code> only and nothing else: <code>model(input_ids)</code></li> <li>a list of varying length with one or several input Tensors IN THE ORDER given in the docstring:
<code>model([input_ids, attention_mask])</code> or <code>model([input_ids, attention_mask, token_type_ids])</code></li> <li>a dictionary with one or several input Tensors associated to the input names given in the docstring:
<code>model({&quot;input_ids&quot;: input_ids, &quot;token_type_ids&quot;: token_type_ids})</code></li>`,C,G,B=`Note that when creating models and layers with
<a href="https://keras.io/guides/making_new_layers_and_models_via_subclassing/" rel="nofollow">subclassing</a> then you don’t need to worry
about any of this, as you can just pass inputs like you would to any other Python function!`;return{c(){e=p("p"),e.innerHTML=c,n=r(),s=p("ul"),s.innerHTML=u,o=r(),w=p("p"),w.innerHTML=he,Z=r(),H=p("ul"),H.innerHTML=re,C=r(),G=p("p"),G.innerHTML=B},l(f){e=h(f,"P",{"data-svelte-h":!0}),v(e)!=="svelte-1ajbfxg"&&(e.innerHTML=c),n=i(f),s=h(f,"UL",{"data-svelte-h":!0}),v(s)!=="svelte-qm1t26"&&(s.innerHTML=u),o=i(f),w=h(f,"P",{"data-svelte-h":!0}),v(w)!=="svelte-1v9qsc5"&&(w.innerHTML=he),Z=i(f),H=h(f,"UL",{"data-svelte-h":!0}),v(H)!=="svelte-15scerc"&&(H.innerHTML=re),C=i(f),G=h(f,"P",{"data-svelte-h":!0}),v(G)!=="svelte-1an3odd"&&(G.innerHTML=B)},m(f,I){l(f,e,I),l(f,n,I),l(f,s,I),l(f,o,I),l(f,w,I),l(f,Z,I),l(f,H,I),l(f,C,I),l(f,G,I)},p:ve,d(f){f&&(a(e),a(n),a(s),a(o),a(w),a(Z),a(H),a(C),a(G))}}}function Lt(J){let e,c=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){e=p("p"),e.innerHTML=c},l(n){e=h(n,"P",{"data-svelte-h":!0}),v(e)!=="svelte-fincs2"&&(e.innerHTML=c)},m(n,s){l(n,e,s)},p:ve,d(n){n&&a(e)}}}function Ht(J){let e,c="Example:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBURk1hcmlhbk1vZGVsJTBBaW1wb3J0JTIwdGVuc29yZmxvdyUyMGFzJTIwdGYlMEElMEF0b2tlbml6ZXIlMjAlM0QlMjBBdXRvVG9rZW5pemVyLmZyb21fcHJldHJhaW5lZCglMjJIZWxzaW5raS1OTFAlMkZvcHVzLW10LWVuLWRlJTIyKSUwQW1vZGVsJTIwJTNEJTIwVEZNYXJpYW5Nb2RlbC5mcm9tX3ByZXRyYWluZWQoJTIySGVsc2lua2ktTkxQJTJGb3B1cy1tdC1lbi1kZSUyMiklMEElMEFpbnB1dHMlMjAlM0QlMjB0b2tlbml6ZXIoJTIySGVsbG8lMkMlMjBteSUyMGRvZyUyMGlzJTIwY3V0ZSUyMiUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIydGYlMjIpJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKGlucHV0cyklMEElMEFsYXN0X2hpZGRlbl9zdGF0ZXMlMjAlM0QlMjBvdXRwdXRzLmxhc3RfaGlkZGVuX3N0YXRl",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, TFMarianModel
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">import</span> tensorflow <span class="hljs-keyword">as</span> tf

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = TFMarianModel.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;tf&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_states = outputs.last_hidden_state`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-11lpom8"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function Bt(J){let e,c="TensorFlow models and layers in <code>transformers</code> accept two formats as input:",n,s,u="<li>having all inputs as keyword arguments (like PyTorch models), or</li> <li>having all inputs as a list, tuple or dict in the first positional argument.</li>",o,w,he=`The reason the second format is supported is that Keras methods prefer this format when passing inputs to models
and layers. Because of this support, when using methods like <code>model.fit()</code> things should “just work” for you - just
pass your inputs and labels in any format that <code>model.fit()</code> supports! If, however, you want to use the second
format outside of Keras methods like <code>fit()</code> and <code>predict()</code>, such as when creating your own layers or models with
the Keras <code>Functional</code> API, there are three possibilities you can use to gather all the input Tensors in the first
positional argument:`,Z,H,re=`<li>a single Tensor with <code>input_ids</code> only and nothing else: <code>model(input_ids)</code></li> <li>a list of varying length with one or several input Tensors IN THE ORDER given in the docstring:
<code>model([input_ids, attention_mask])</code> or <code>model([input_ids, attention_mask, token_type_ids])</code></li> <li>a dictionary with one or several input Tensors associated to the input names given in the docstring:
<code>model({&quot;input_ids&quot;: input_ids, &quot;token_type_ids&quot;: token_type_ids})</code></li>`,C,G,B=`Note that when creating models and layers with
<a href="https://keras.io/guides/making_new_layers_and_models_via_subclassing/" rel="nofollow">subclassing</a> then you don’t need to worry
about any of this, as you can just pass inputs like you would to any other Python function!`;return{c(){e=p("p"),e.innerHTML=c,n=r(),s=p("ul"),s.innerHTML=u,o=r(),w=p("p"),w.innerHTML=he,Z=r(),H=p("ul"),H.innerHTML=re,C=r(),G=p("p"),G.innerHTML=B},l(f){e=h(f,"P",{"data-svelte-h":!0}),v(e)!=="svelte-1ajbfxg"&&(e.innerHTML=c),n=i(f),s=h(f,"UL",{"data-svelte-h":!0}),v(s)!=="svelte-qm1t26"&&(s.innerHTML=u),o=i(f),w=h(f,"P",{"data-svelte-h":!0}),v(w)!=="svelte-1v9qsc5"&&(w.innerHTML=he),Z=i(f),H=h(f,"UL",{"data-svelte-h":!0}),v(H)!=="svelte-15scerc"&&(H.innerHTML=re),C=i(f),G=h(f,"P",{"data-svelte-h":!0}),v(G)!=="svelte-1an3odd"&&(G.innerHTML=B)},m(f,I){l(f,e,I),l(f,n,I),l(f,s,I),l(f,o,I),l(f,w,I),l(f,Z,I),l(f,H,I),l(f,C,I),l(f,G,I)},p:ve,d(f){f&&(a(e),a(n),a(s),a(o),a(w),a(Z),a(H),a(C),a(G))}}}function Vt(J){let e,c=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){e=p("p"),e.innerHTML=c},l(n){e=h(n,"P",{"data-svelte-h":!0}),v(e)!=="svelte-fincs2"&&(e.innerHTML=c)},m(n,s){l(n,e,s)},p:ve,d(n){n&&a(e)}}}function St(J){let e,c="Examples:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBURk1hcmlhbk1UTW9kZWwlMEFmcm9tJTIwdHlwaW5nJTIwaW1wb3J0JTIwTGlzdCUwQSUwQXNyYyUyMCUzRCUyMCUyMmZyJTIyJTIwJTIwJTIzJTIwc291cmNlJTIwbGFuZ3VhZ2UlMEF0cmclMjAlM0QlMjAlMjJlbiUyMiUyMCUyMCUyMyUyMHRhcmdldCUyMGxhbmd1YWdlJTBBc2FtcGxlX3RleHQlMjAlM0QlMjAlMjJvJUMzJUI5JTIwZXN0JTIwbCdhcnIlQzMlQUF0JTIwZGUlMjBidXMlMjAlM0YlMjIlMEFtb2RlbF9uYW1lJTIwJTNEJTIwZiUyMkhlbHNpbmtpLU5MUCUyRm9wdXMtbXQtJTdCc3JjJTdELSU3QnRyZyU3RCUyMiUwQSUwQW1vZGVsJTIwJTNEJTIwVEZNYXJpYW5NVE1vZGVsLmZyb21fcHJldHJhaW5lZChtb2RlbF9uYW1lKSUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKG1vZGVsX25hbWUpJTBBYmF0Y2glMjAlM0QlMjB0b2tlbml6ZXIoJTVCc2FtcGxlX3RleHQlNUQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnRmJTIyKSUwQWdlbiUyMCUzRCUyMG1vZGVsLmdlbmVyYXRlKCoqYmF0Y2gpJTBBdG9rZW5pemVyLmJhdGNoX2RlY29kZShnZW4lMkMlMjBza2lwX3NwZWNpYWxfdG9rZW5zJTNEVHJ1ZSk=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, TFMarianMTModel
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> typing <span class="hljs-keyword">import</span> <span class="hljs-type">List</span>

<span class="hljs-meta">&gt;&gt;&gt; </span>src = <span class="hljs-string">&quot;fr&quot;</span>  <span class="hljs-comment"># source language</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>trg = <span class="hljs-string">&quot;en&quot;</span>  <span class="hljs-comment"># target language</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>sample_text = <span class="hljs-string">&quot;où est l&#x27;arrêt de bus ?&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>model_name = <span class="hljs-string">f&quot;Helsinki-NLP/opus-mt-<span class="hljs-subst">{src}</span>-<span class="hljs-subst">{trg}</span>&quot;</span>

<span class="hljs-meta">&gt;&gt;&gt; </span>model = TFMarianMTModel.from_pretrained(model_name)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(model_name)
<span class="hljs-meta">&gt;&gt;&gt; </span>batch = tokenizer([sample_text], return_tensors=<span class="hljs-string">&quot;tf&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>gen = model.generate(**batch)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer.batch_decode(gen, skip_special_tokens=<span class="hljs-literal">True</span>)
<span class="hljs-string">&quot;Where is the bus stop ?&quot;</span>`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-kvfsh7"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function Rt(J){let e,c,n,s,u,o,w=`The bare MARIAN Model outputting raw hidden-states without any specific head on top.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel">TFPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,he,Z,H=`This model is also a <a href="https://www.tensorflow.org/api_docs/python/tf/keras/Model" rel="nofollow">keras.Model</a> subclass. Use it
as a regular TF 2.0 Keras Model and refer to the TF 2.0 documentation for all matter related to general usage and
behavior.`,re,C,G,B,f,I,ie,A='The <a href="/docs/transformers/main/ko/model_doc/marian#transformers.TFMarianModel">TFMarianModel</a> forward method, overrides the <code>__call__</code> special method.',Te,O,Y,te,me,P,D,L,F,le,ue,W=`The MARIAN Model with a language modeling head. Can be used for summarization.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel">TFPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,ye,de,be=`This model is also a <a href="https://www.tensorflow.org/api_docs/python/tf/keras/Model" rel="nofollow">keras.Model</a> subclass. Use it
as a regular TF 2.0 Keras Model and refer to the TF 2.0 documentation for all matter related to general usage and
behavior.`,Ie,K,fe,E,ne,X,Q,qe='The <a href="/docs/transformers/main/ko/model_doc/marian#transformers.TFMarianMTModel">TFMarianMTModel</a> forward method, overrides the <code>__call__</code> special method.',ce,pe,Je,N,ke=`TF version of marian-nmt’s transformer.h (c++). Designed for the OPUS-NMT translation checkpoints. Available
models are listed <a href="https://huggingface.co/models?search=Helsinki-NLP" rel="nofollow">here</a>.`,ee,oe,ge;return e=new je({props:{title:"TFMarianModel",local:"transformers.TFMarianModel",headingTag:"h2"}}),s=new $e({props:{name:"class transformers.TFMarianModel",anchor:"transformers.TFMarianModel",parameters:[{name:"config",val:": MarianConfig"},{name:"*inputs",val:""},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.TFMarianModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig">MarianConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_tf_marian.py#L1245"}}),C=new Ve({props:{$$slots:{default:[Wt]},$$scope:{ctx:J}}}),f=new $e({props:{name:"call",anchor:"transformers.TFMarianModel.call",parameters:[{name:"input_ids",val:": tf.Tensor | None = None"},{name:"attention_mask",val:": tf.Tensor | None = None"},{name:"decoder_input_ids",val:": tf.Tensor | None = None"},{name:"decoder_attention_mask",val:": tf.Tensor | None = None"},{name:"decoder_position_ids",val:": tf.Tensor | None = None"},{name:"head_mask",val:": tf.Tensor | None = None"},{name:"decoder_head_mask",val:": tf.Tensor | None = None"},{name:"cross_attn_head_mask",val:": tf.Tensor | None = None"},{name:"encoder_outputs",val:": tf.Tensor | None = None"},{name:"past_key_values",val:": Tuple[Tuple[tf.Tensor]] | None = None"},{name:"inputs_embeds",val:": tf.Tensor | None = None"},{name:"decoder_inputs_embeds",val:": tf.Tensor | None = None"},{name:"use_cache",val:": bool | None = None"},{name:"output_attentions",val:": bool | None = None"},{name:"output_hidden_states",val:": bool | None = None"},{name:"return_dict",val:": bool | None = None"},{name:"training",val:": bool = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.TFMarianModel.call.input_ids",description:`<strong>input_ids</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.TFMarianModel.call.attention_mask",description:`<strong>attention_mask</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.TFMarianModel.call.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>Marian uses the <code>pad_token_id</code> as the starting token for <code>decoder_input_ids</code> generation. If
<code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).`,name:"decoder_input_ids"},{anchor:"transformers.TFMarianModel.call.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
will be made by default and ignore pad tokens. It is not recommended to set this for most use cases.`,name:"decoder_attention_mask"},{anchor:"transformers.TFMarianModel.call.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each decoder input sequence tokens in the position embeddings. Selected in the
range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"decoder_position_ids"},{anchor:"transformers.TFMarianModel.call.head_mask",description:`<strong>head_mask</strong> (<code>tf.Tensor</code> of shape <code>(encoder_layers, encoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the encoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.TFMarianModel.call.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>tf.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.TFMarianModel.call.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>tf.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.TFMarianModel.call.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>tf.FloatTensor</code>, <em>optional</em>) &#x2014;
hidden states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.
of shape <code>(batch_size, sequence_length, hidden_size)</code> is a sequence of`,name:"encoder_outputs"},{anchor:"transformers.TFMarianModel.call.past_key_values",description:`<strong>past_key_values</strong> (<code>Tuple[Tuple[tf.Tensor]]</code> of length <code>config.n_layers</code>) &#x2014;
contains precomputed key and value hidden states of the attention blocks. Can be used to speed up decoding.
If <code>past_key_values</code> are used, the user can optionally input only the last <code>decoder_input_ids</code> (those that
don&#x2019;t have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all
<code>decoder_input_ids</code> of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.TFMarianModel.call.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation.
This is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors
than the model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.TFMarianModel.call.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>). Set to <code>False</code> during training, <code>True</code> during generation`,name:"use_cache"},{anchor:"transformers.TFMarianModel.call.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail. This argument can be used only in eager mode, in graph mode the value in the
config will be used instead.`,name:"output_attentions"},{anchor:"transformers.TFMarianModel.call.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail. This argument can be used only in eager mode, in graph mode the value in the config will be
used instead.`,name:"output_hidden_states"},{anchor:"transformers.TFMarianModel.call.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple. This argument can be used in
eager mode, in graph mode the value will always be set to True.`,name:"return_dict"},{anchor:"transformers.TFMarianModel.call.training",description:`<strong>training</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to use the model in training mode (some modules like dropout modules have different
behaviors between training and evaluation).`,name:"training"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_tf_marian.py#L1261",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_tf_outputs.TFSeq2SeqModelOutput"
>transformers.modeling_tf_outputs.TFSeq2SeqModelOutput</a> or a tuple of <code>tf.Tensor</code> (if
<code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various elements depending on the
configuration (<a
  href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig"
>MarianConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the decoder of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>List[tf.Tensor]</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — List of <code>tf.Tensor</code> of length <code>config.n_layers</code>, with each tensor of shape <code>(2, batch_size, num_heads, sequence_length, embed_size_per_head)</code>).</p>
<p>Contains pre-computed hidden-states (key and values in the attention blocks) of the decoder that can be
used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>tf.Tensor</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>tf.Tensor</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_tf_outputs.TFSeq2SeqModelOutput"
>transformers.modeling_tf_outputs.TFSeq2SeqModelOutput</a> or <code>tuple(tf.Tensor)</code></p>
`}}),O=new Ve({props:{$$slots:{default:[Lt]},$$scope:{ctx:J}}}),te=new Se({props:{anchor:"transformers.TFMarianModel.call.example",$$slots:{default:[Ht]},$$scope:{ctx:J}}}),P=new je({props:{title:"TFMarianMTModel",local:"transformers.TFMarianMTModel",headingTag:"h2"}}),F=new $e({props:{name:"class transformers.TFMarianMTModel",anchor:"transformers.TFMarianMTModel",parameters:[{name:"config",val:""},{name:"*inputs",val:""},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.TFMarianMTModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig">MarianConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.TFPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_tf_marian.py#L1358"}}),K=new Ve({props:{$$slots:{default:[Bt]},$$scope:{ctx:J}}}),ne=new $e({props:{name:"call",anchor:"transformers.TFMarianMTModel.call",parameters:[{name:"input_ids",val:": tf.Tensor | None = None"},{name:"attention_mask",val:": tf.Tensor | None = None"},{name:"decoder_input_ids",val:": tf.Tensor | None = None"},{name:"decoder_attention_mask",val:": tf.Tensor | None = None"},{name:"decoder_position_ids",val:": tf.Tensor | None = None"},{name:"head_mask",val:": tf.Tensor | None = None"},{name:"decoder_head_mask",val:": tf.Tensor | None = None"},{name:"cross_attn_head_mask",val:": tf.Tensor | None = None"},{name:"encoder_outputs",val:": TFBaseModelOutput | None = None"},{name:"past_key_values",val:": Tuple[Tuple[tf.Tensor]] | None = None"},{name:"inputs_embeds",val:": tf.Tensor | None = None"},{name:"decoder_inputs_embeds",val:": tf.Tensor | None = None"},{name:"use_cache",val:": bool | None = None"},{name:"output_attentions",val:": bool | None = None"},{name:"output_hidden_states",val:": bool | None = None"},{name:"return_dict",val:": bool | None = None"},{name:"labels",val:": tf.Tensor | None = None"},{name:"training",val:": bool = False"}],parametersDescription:[{anchor:"transformers.TFMarianMTModel.call.input_ids",description:`<strong>input_ids</strong> (<code>tf.Tensor</code> of shape <code>({0})</code>) &#x2014;
Indices of input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.TFMarianMTModel.call.attention_mask",description:`<strong>attention_mask</strong> (<code>tf.Tensor</code> of shape <code>({0})</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.TFMarianMTModel.call.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>Marian uses the <code>pad_token_id</code> as the starting token for <code>decoder_input_ids</code> generation. If
<code>past_key_values</code> is used, optionally only the last <code>decoder_input_ids</code> have to be input (see
<code>past_key_values</code>).`,name:"decoder_input_ids"},{anchor:"transformers.TFMarianMTModel.call.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
will be made by default and ignore pad tokens. It is not recommended to set this for most use cases.`,name:"decoder_attention_mask"},{anchor:"transformers.TFMarianMTModel.call.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each decoder input sequence tokens in the position embeddings. Selected in the
range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"decoder_position_ids"},{anchor:"transformers.TFMarianMTModel.call.head_mask",description:`<strong>head_mask</strong> (<code>tf.Tensor</code> of shape <code>(encoder_layers, encoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the encoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"head_mask"},{anchor:"transformers.TFMarianMTModel.call.decoder_head_mask",description:`<strong>decoder_head_mask</strong> (<code>tf.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the attention modules in the decoder. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"decoder_head_mask"},{anchor:"transformers.TFMarianMTModel.call.cross_attn_head_mask",description:`<strong>cross_attn_head_mask</strong> (<code>tf.Tensor</code> of shape <code>(decoder_layers, decoder_attention_heads)</code>, <em>optional</em>) &#x2014;
Mask to nullify selected heads of the cross-attention modules. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 indicates the head is <strong>not masked</strong>,</li>
<li>0 indicates the head is <strong>masked</strong>.</li>
</ul>`,name:"cross_attn_head_mask"},{anchor:"transformers.TFMarianMTModel.call.encoder_outputs",description:`<strong>encoder_outputs</strong> (<code>tf.FloatTensor</code>, <em>optional</em>) &#x2014;
hidden states at the output of the last layer of the encoder. Used in the cross-attention of the decoder.
of shape <code>(batch_size, sequence_length, hidden_size)</code> is a sequence of`,name:"encoder_outputs"},{anchor:"transformers.TFMarianMTModel.call.past_key_values",description:`<strong>past_key_values</strong> (<code>Tuple[Tuple[tf.Tensor]]</code> of length <code>config.n_layers</code>) &#x2014;
contains precomputed key and value hidden states of the attention blocks. Can be used to speed up decoding.
If <code>past_key_values</code> are used, the user can optionally input only the last <code>decoder_input_ids</code> (those that
don&#x2019;t have their past key value states given to this model) of shape <code>(batch_size, 1)</code> instead of all
<code>decoder_input_ids</code> of shape <code>(batch_size, sequence_length)</code>.`,name:"past_key_values"},{anchor:"transformers.TFMarianMTModel.call.inputs_embeds",description:`<strong>inputs_embeds</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) &#x2014;
Optionally, instead of passing <code>input_ids</code> you can choose to directly pass an embedded representation.
This is useful if you want more control over how to convert <code>input_ids</code> indices into associated vectors
than the model&#x2019;s internal embedding lookup matrix.`,name:"inputs_embeds"},{anchor:"transformers.TFMarianMTModel.call.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
If set to <code>True</code>, <code>past_key_values</code> key value states are returned and can be used to speed up decoding (see
<code>past_key_values</code>). Set to <code>False</code> during training, <code>True</code> during generation`,name:"use_cache"},{anchor:"transformers.TFMarianMTModel.call.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail. This argument can be used only in eager mode, in graph mode the value in the
config will be used instead.`,name:"output_attentions"},{anchor:"transformers.TFMarianMTModel.call.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail. This argument can be used only in eager mode, in graph mode the value in the config will be
used instead.`,name:"output_hidden_states"},{anchor:"transformers.TFMarianMTModel.call.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple. This argument can be used in
eager mode, in graph mode the value will always be set to True.`,name:"return_dict"},{anchor:"transformers.TFMarianMTModel.call.training",description:`<strong>training</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether or not to use the model in training mode (some modules like dropout modules have different
behaviors between training and evaluation).`,name:"training"},{anchor:"transformers.TFMarianMTModel.call.labels",description:`<strong>labels</strong> (<code>tf.tensor</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Labels for computing the masked language modeling loss. Indices should either be in <code>[0, ..., config.vocab_size]</code> or -100 (see <code>input_ids</code> docstring). Tokens with indices set to <code>-100</code> are ignored
(masked), the loss is only computed for the tokens with labels in <code>[0, ..., config.vocab_size]</code>.`,name:"labels"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_tf_marian.py#L1400",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_tf_outputs.TFSeq2SeqLMOutput"
>transformers.modeling_tf_outputs.TFSeq2SeqLMOutput</a> or a tuple of <code>tf.Tensor</code> (if
<code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various elements depending on the
configuration (<a
  href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig"
>MarianConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>loss</strong> (<code>tf.Tensor</code> of shape <code>(n,)</code>, <em>optional</em>, where n is the number of non-masked labels, returned when <code>labels</code> is provided) — Language modeling loss.</p>
</li>
<li>
<p><strong>logits</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>List[tf.Tensor]</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — List of <code>tf.Tensor</code> of length <code>config.n_layers</code>, with each tensor of shape <code>(2, batch_size, num_heads, sequence_length, embed_size_per_head)</code>).</p>
<p>Contains pre-computed hidden-states (key and values in the attention blocks) of the decoder that can be
used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>tf.Tensor</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>tf.Tensor</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>tf.Tensor</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(tf.Tensor)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>tf.Tensor</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_tf_outputs.TFSeq2SeqLMOutput"
>transformers.modeling_tf_outputs.TFSeq2SeqLMOutput</a> or <code>tuple(tf.Tensor)</code></p>
`}}),pe=new Ve({props:{$$slots:{default:[Vt]},$$scope:{ctx:J}}}),oe=new Se({props:{anchor:"transformers.TFMarianMTModel.call.example",$$slots:{default:[St]},$$scope:{ctx:J}}}),{c(){_(e.$$.fragment),c=r(),n=p("div"),_(s.$$.fragment),u=r(),o=p("p"),o.innerHTML=w,he=r(),Z=p("p"),Z.innerHTML=H,re=r(),_(C.$$.fragment),G=r(),B=p("div"),_(f.$$.fragment),I=r(),ie=p("p"),ie.innerHTML=A,Te=r(),_(O.$$.fragment),Y=r(),_(te.$$.fragment),me=r(),_(P.$$.fragment),D=r(),L=p("div"),_(F.$$.fragment),le=r(),ue=p("p"),ue.innerHTML=W,ye=r(),de=p("p"),de.innerHTML=be,Ie=r(),_(K.$$.fragment),fe=r(),E=p("div"),_(ne.$$.fragment),X=r(),Q=p("p"),Q.innerHTML=qe,ce=r(),_(pe.$$.fragment),Je=r(),N=p("p"),N.innerHTML=ke,ee=r(),_(oe.$$.fragment),this.h()},l(x){M(e.$$.fragment,x),c=i(x),n=h(x,"DIV",{class:!0});var $=we(n);M(s.$$.fragment,$),u=i($),o=h($,"P",{"data-svelte-h":!0}),v(o)!=="svelte-nh843b"&&(o.innerHTML=w),he=i($),Z=h($,"P",{"data-svelte-h":!0}),v(Z)!=="svelte-1be7e3c"&&(Z.innerHTML=H),re=i($),M(C.$$.fragment,$),G=i($),B=h($,"DIV",{class:!0});var V=we(B);M(f.$$.fragment,V),I=i(V),ie=h(V,"P",{"data-svelte-h":!0}),v(ie)!=="svelte-s2sx2"&&(ie.innerHTML=A),Te=i(V),M(O.$$.fragment,V),Y=i(V),M(te.$$.fragment,V),V.forEach(a),$.forEach(a),me=i(x),M(P.$$.fragment,x),D=i(x),L=h(x,"DIV",{class:!0});var S=we(L);M(F.$$.fragment,S),le=i(S),ue=h(S,"P",{"data-svelte-h":!0}),v(ue)!=="svelte-s42l1v"&&(ue.innerHTML=W),ye=i(S),de=h(S,"P",{"data-svelte-h":!0}),v(de)!=="svelte-1be7e3c"&&(de.innerHTML=be),Ie=i(S),M(K.$$.fragment,S),fe=i(S),E=h(S,"DIV",{class:!0});var q=we(E);M(ne.$$.fragment,q),X=i(q),Q=h(q,"P",{"data-svelte-h":!0}),v(Q)!=="svelte-1ke83y2"&&(Q.innerHTML=qe),ce=i(q),M(pe.$$.fragment,q),Je=i(q),N=h(q,"P",{"data-svelte-h":!0}),v(N)!=="svelte-11jr0s7"&&(N.innerHTML=ke),ee=i(q),M(oe.$$.fragment,q),q.forEach(a),S.forEach(a),this.h()},h(){Me(B,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(n,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(E,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(L,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(x,$){T(e,x,$),l(x,c,$),l(x,n,$),T(s,n,null),d(n,u),d(n,o),d(n,he),d(n,Z),d(n,re),T(C,n,null),d(n,G),d(n,B),T(f,B,null),d(B,I),d(B,ie),d(B,Te),T(O,B,null),d(B,Y),T(te,B,null),l(x,me,$),T(P,x,$),l(x,D,$),l(x,L,$),T(F,L,null),d(L,le),d(L,ue),d(L,ye),d(L,de),d(L,Ie),T(K,L,null),d(L,fe),d(L,E),T(ne,E,null),d(E,X),d(E,Q),d(E,ce),T(pe,E,null),d(E,Je),d(E,N),d(E,ee),T(oe,E,null),ge=!0},p(x,$){const V={};$&2&&(V.$$scope={dirty:$,ctx:x}),C.$set(V);const S={};$&2&&(S.$$scope={dirty:$,ctx:x}),O.$set(S);const q={};$&2&&(q.$$scope={dirty:$,ctx:x}),te.$set(q);const j={};$&2&&(j.$$scope={dirty:$,ctx:x}),K.$set(j);const z={};$&2&&(z.$$scope={dirty:$,ctx:x}),pe.$set(z);const R={};$&2&&(R.$$scope={dirty:$,ctx:x}),oe.$set(R)},i(x){ge||(y(e.$$.fragment,x),y(s.$$.fragment,x),y(C.$$.fragment,x),y(f.$$.fragment,x),y(O.$$.fragment,x),y(te.$$.fragment,x),y(P.$$.fragment,x),y(F.$$.fragment,x),y(K.$$.fragment,x),y(ne.$$.fragment,x),y(pe.$$.fragment,x),y(oe.$$.fragment,x),ge=!0)},o(x){b(e.$$.fragment,x),b(s.$$.fragment,x),b(C.$$.fragment,x),b(f.$$.fragment,x),b(O.$$.fragment,x),b(te.$$.fragment,x),b(P.$$.fragment,x),b(F.$$.fragment,x),b(K.$$.fragment,x),b(ne.$$.fragment,x),b(pe.$$.fragment,x),b(oe.$$.fragment,x),ge=!1},d(x){x&&(a(c),a(n),a(me),a(D),a(L)),k(e,x),k(s),k(C),k(f),k(O),k(te),k(P,x),k(F),k(K),k(ne),k(pe),k(oe)}}}function Gt(J){let e,c;return e=new gt({props:{$$slots:{default:[Rt]},$$scope:{ctx:J}}}),{c(){_(e.$$.fragment)},l(n){M(e.$$.fragment,n)},m(n,s){T(e,n,s),c=!0},p(n,s){const u={};s&2&&(u.$$scope={dirty:s,ctx:n}),e.$set(u)},i(n){c||(y(e.$$.fragment,n),c=!0)},o(n){b(e.$$.fragment,n),c=!1},d(n){k(e,n)}}}function Xt(J){let e,c=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){e=p("p"),e.innerHTML=c},l(n){e=h(n,"P",{"data-svelte-h":!0}),v(e)!=="svelte-fincs2"&&(e.innerHTML=c)},m(n,s){l(n,e,s)},p:ve,d(n){n&&a(e)}}}function Pt(J){let e,c="Example:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBGbGF4TWFyaWFuTW9kZWwlMEElMEF0b2tlbml6ZXIlMjAlM0QlMjBBdXRvVG9rZW5pemVyLmZyb21fcHJldHJhaW5lZCglMjJIZWxzaW5raS1OTFAlMkZvcHVzLW10LWVuLWRlJTIyKSUwQW1vZGVsJTIwJTNEJTIwRmxheE1hcmlhbk1vZGVsLmZyb21fcHJldHJhaW5lZCglMjJIZWxzaW5raS1OTFAlMkZvcHVzLW10LWVuLWRlJTIyKSUwQSUwQWlucHV0cyUyMCUzRCUyMHRva2VuaXplciglMjJIZWxsbyUyQyUyMG15JTIwZG9nJTIwaXMlMjBjdXRlJTIyJTJDJTIwcmV0dXJuX3RlbnNvcnMlM0QlMjJqYXglMjIpJTBBb3V0cHV0cyUyMCUzRCUyMG1vZGVsKCoqaW5wdXRzKSUwQSUwQWxhc3RfaGlkZGVuX3N0YXRlcyUyMCUzRCUyMG91dHB1dHMubGFzdF9oaWRkZW5fc3RhdGU=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, FlaxMarianModel

<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxMarianModel.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>inputs = tokenizer(<span class="hljs-string">&quot;Hello, my dog is cute&quot;</span>, return_tensors=<span class="hljs-string">&quot;jax&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = model(**inputs)

<span class="hljs-meta">&gt;&gt;&gt; </span>last_hidden_states = outputs.last_hidden_state`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-11lpom8"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function At(J){let e,c=`Although the recipe for forward pass needs to be defined within this function, one should call the <code>Module</code>
instance afterwards instead of this since the former takes care of running the pre and post processing steps while
the latter silently ignores them.`;return{c(){e=p("p"),e.innerHTML=c},l(n){e=h(n,"P",{"data-svelte-h":!0}),v(e)!=="svelte-fincs2"&&(e.innerHTML=c)},m(n,s){l(n,e,s)},p:ve,d(n){n&&a(e)}}}function Et(J){let e,c="Example:",n,s,u;return s=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMEF1dG9Ub2tlbml6ZXIlMkMlMjBGbGF4TWFyaWFuTVRNb2RlbCUwQSUwQW1vZGVsJTIwJTNEJTIwRmxheE1hcmlhbk1UTW9kZWwuZnJvbV9wcmV0cmFpbmVkKCUyMkhlbHNpbmtpLU5MUCUyRm9wdXMtbXQtZW4tZGUlMjIpJTBBdG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoJTIySGVsc2lua2ktTkxQJTJGb3B1cy1tdC1lbi1kZSUyMiklMEElMEF0ZXh0JTIwJTNEJTIwJTIyTXklMjBmcmllbmRzJTIwYXJlJTIwY29vbCUyMGJ1dCUyMHRoZXklMjBlYXQlMjB0b28lMjBtYW55JTIwY2FyYnMuJTIyJTBBaW5wdXRfaWRzJTIwJTNEJTIwdG9rZW5pemVyKHRleHQlMkMlMjBtYXhfbGVuZ3RoJTNENjQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMmpheCUyMikuaW5wdXRfaWRzJTBBJTBBc2VxdWVuY2VzJTIwJTNEJTIwbW9kZWwuZ2VuZXJhdGUoaW5wdXRfaWRzJTJDJTIwbWF4X2xlbmd0aCUzRDY0JTJDJTIwbnVtX2JlYW1zJTNEMikuc2VxdWVuY2VzJTBBJTBBb3V0cHV0cyUyMCUzRCUyMHRva2VuaXplci5iYXRjaF9kZWNvZGUoc2VxdWVuY2VzJTJDJTIwc2tpcF9zcGVjaWFsX3Rva2VucyUzRFRydWUpJTBBJTIzJTIwc2hvdWxkJTIwZ2l2ZSUyMCpNZWluZSUyMEZyZXVuZGUlMjBzaW5kJTIwY29vbCUyQyUyMGFiZXIlMjBzaWUlMjBlc3NlbiUyMHp1JTIwdmllbGUlMjBLb2hsZW5oeWRyYXRlLio=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> AutoTokenizer, FlaxMarianMTModel

<span class="hljs-meta">&gt;&gt;&gt; </span>model = FlaxMarianMTModel.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(<span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-de&quot;</span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>text = <span class="hljs-string">&quot;My friends are cool but they eat too many carbs.&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>input_ids = tokenizer(text, max_length=<span class="hljs-number">64</span>, return_tensors=<span class="hljs-string">&quot;jax&quot;</span>).input_ids

<span class="hljs-meta">&gt;&gt;&gt; </span>sequences = model.generate(input_ids, max_length=<span class="hljs-number">64</span>, num_beams=<span class="hljs-number">2</span>).sequences

<span class="hljs-meta">&gt;&gt;&gt; </span>outputs = tokenizer.batch_decode(sequences, skip_special_tokens=<span class="hljs-literal">True</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># should give *Meine Freunde sind cool, aber sie essen zu viele Kohlenhydrate.*</span>`,wrap:!1}}),{c(){e=p("p"),e.textContent=c,n=r(),_(s.$$.fragment)},l(o){e=h(o,"P",{"data-svelte-h":!0}),v(e)!=="svelte-11lpom8"&&(e.textContent=c),n=i(o),M(s.$$.fragment,o)},m(o,w){l(o,e,w),l(o,n,w),T(s,o,w),u=!0},p:ve,i(o){u||(y(s.$$.fragment,o),u=!0)},o(o){b(s.$$.fragment,o),u=!1},d(o){o&&(a(e),a(n)),k(s,o)}}}function Qt(J){let e,c,n,s,u,o,w=`The bare Marian Model transformer outputting raw hidden-states without any specific head on top.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,he,Z,H=`This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.`,re,C,G="Finally, this model supports inherent JAX features such as:",B,f,I='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',ie,A,Te,O,Y,te="The <code>FlaxMarianPreTrainedModel</code> forward method, overrides the <code>__call__</code> special method.",me,P,D,L,F,le,ue,W,ye,de,be,Ie=`The MARIAN Model with a language modeling head. Can be used for translation.
This model inherits from <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel">FlaxPreTrainedModel</a>. Check the superclass documentation for the generic methods the
library implements for all its model (such as downloading or saving, resizing the input embeddings, pruning heads
etc.)`,K,fe,E=`This model is also a Flax Linen
<a href="https://flax.readthedocs.io/en/latest/_autosummary/flax.nn.module.html" rel="nofollow">flax.nn.Module</a> subclass. Use it as a
regular Flax Module and refer to the Flax documentation for all matter related to general usage and behavior.`,ne,X,Q="Finally, this model supports inherent JAX features such as:",qe,ce,pe='<li><a href="https://jax.readthedocs.io/en/latest/jax.html#just-in-time-compilation-jit" rel="nofollow">Just-In-Time (JIT) compilation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#automatic-differentiation" rel="nofollow">Automatic Differentiation</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#vectorization-vmap" rel="nofollow">Vectorization</a></li> <li><a href="https://jax.readthedocs.io/en/latest/jax.html#parallelization-pmap" rel="nofollow">Parallelization</a></li>',Je,N,ke,ee,oe,ge="The <code>FlaxMarianPreTrainedModel</code> forward method, overrides the <code>__call__</code> special method.",x,$,V,S,q;return e=new je({props:{title:"FlaxMarianModel",local:"transformers.FlaxMarianModel",headingTag:"h2"}}),s=new $e({props:{name:"class transformers.FlaxMarianModel",anchor:"transformers.FlaxMarianModel",parameters:[{name:"config",val:": MarianConfig"},{name:"input_shape",val:": typing.Tuple[int] = (1, 1)"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxMarianModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig">MarianConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxMarianModel.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code> (on GPUs) and
<code>jax.numpy.bfloat16</code> (on TPUs).</p>
<p>This can be used to enable mixed-precision training or half-precision inference on GPUs or TPUs. If
specified all the computation will be performed with the given <code>dtype</code>.</p>
<p><strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong></p>
<p>If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a> and
<a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_flax_marian.py#L1201"}}),Te=new $e({props:{name:"__call__",anchor:"transformers.FlaxMarianModel.__call__",parameters:[{name:"input_ids",val:": Array"},{name:"attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"decoder_input_ids",val:": typing.Optional[jax.Array] = None"},{name:"decoder_attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"position_ids",val:": typing.Optional[jax.Array] = None"},{name:"decoder_position_ids",val:": typing.Optional[jax.Array] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"train",val:": bool = False"},{name:"params",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"}],parametersDescription:[{anchor:"transformers.FlaxMarianModel.__call__.input_ids",description:`<strong>input_ids</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.FlaxMarianModel.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.FlaxMarianModel.__call__.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>For translation and summarization training, <code>decoder_input_ids</code> should be provided. If no
<code>decoder_input_ids</code> is provided, the model will create this tensor by shifting the <code>input_ids</code> to the right
for denoising pre-training following the paper.`,name:"decoder_input_ids"},{anchor:"transformers.FlaxMarianModel.__call__.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default.</p>
<p>If you want to change padding behavior, you should modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the
paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.FlaxMarianModel.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"position_ids"},{anchor:"transformers.FlaxMarianModel.__call__.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each decoder input sequence tokens in the position embeddings. Selected in the
range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"decoder_position_ids"},{anchor:"transformers.FlaxMarianModel.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxMarianModel.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxMarianModel.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_flax_marian.py#L1140",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSeq2SeqModelOutput"
>transformers.modeling_flax_outputs.FlaxSeq2SeqModelOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig"
>MarianConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>last_hidden_state</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>) — Sequence of hidden-states at the output of the last layer of the decoder of the model.</p>
<p>If <code>past_key_values</code> is used only the last hidden-state of the sequences of shape <code>(batch_size, 1, hidden_size)</code> is output.</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>tuple(tuple(jnp.ndarray))</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — Tuple of <code>tuple(jnp.ndarray)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of shape
<code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>) and 2 additional tensors of shape
<code>(batch_size, num_heads, encoder_sequence_length, embed_size_per_head)</code>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSeq2SeqModelOutput"
>transformers.modeling_flax_outputs.FlaxSeq2SeqModelOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),P=new Ve({props:{$$slots:{default:[Xt]},$$scope:{ctx:J}}}),L=new Se({props:{anchor:"transformers.FlaxMarianModel.__call__.example",$$slots:{default:[Pt]},$$scope:{ctx:J}}}),le=new je({props:{title:"FlaxMarianMTModel",local:"transformers.FlaxMarianMTModel",headingTag:"h2"}}),ye=new $e({props:{name:"class transformers.FlaxMarianMTModel",anchor:"transformers.FlaxMarianMTModel",parameters:[{name:"config",val:": MarianConfig"},{name:"input_shape",val:": typing.Tuple[int] = (1, 1)"},{name:"seed",val:": int = 0"},{name:"dtype",val:": dtype = <class 'jax.numpy.float32'>"},{name:"_do_init",val:": bool = True"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.FlaxMarianMTModel.config",description:`<strong>config</strong> (<a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig">MarianConfig</a>) &#x2014; Model configuration class with all the parameters of the model.
Initializing with a config file does not load the weights associated with the model, only the
configuration. Check out the <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.from_pretrained">from_pretrained()</a> method to load the model weights.`,name:"config"},{anchor:"transformers.FlaxMarianMTModel.dtype",description:`<strong>dtype</strong> (<code>jax.numpy.dtype</code>, <em>optional</em>, defaults to <code>jax.numpy.float32</code>) &#x2014;
The data type of the computation. Can be one of <code>jax.numpy.float32</code>, <code>jax.numpy.float16</code> (on GPUs) and
<code>jax.numpy.bfloat16</code> (on TPUs).</p>
<p>This can be used to enable mixed-precision training or half-precision inference on GPUs or TPUs. If
specified all the computation will be performed with the given <code>dtype</code>.</p>
<p><strong>Note that this only specifies the dtype of the computation and does not influence the dtype of model
parameters.</strong></p>
<p>If you wish to change the dtype of the model parameters, see <a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_fp16">to_fp16()</a> and
<a href="/docs/transformers/main/ko/main_classes/model#transformers.FlaxPreTrainedModel.to_bf16">to_bf16()</a>.`,name:"dtype"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_flax_marian.py#L1286"}}),ke=new $e({props:{name:"__call__",anchor:"transformers.FlaxMarianMTModel.__call__",parameters:[{name:"input_ids",val:": Array"},{name:"attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"decoder_input_ids",val:": typing.Optional[jax.Array] = None"},{name:"decoder_attention_mask",val:": typing.Optional[jax.Array] = None"},{name:"position_ids",val:": typing.Optional[jax.Array] = None"},{name:"decoder_position_ids",val:": typing.Optional[jax.Array] = None"},{name:"output_attentions",val:": typing.Optional[bool] = None"},{name:"output_hidden_states",val:": typing.Optional[bool] = None"},{name:"return_dict",val:": typing.Optional[bool] = None"},{name:"train",val:": bool = False"},{name:"params",val:": typing.Optional[dict] = None"},{name:"dropout_rng",val:": <function PRNGKey at 0x7f468777b370> = None"}],parametersDescription:[{anchor:"transformers.FlaxMarianMTModel.__call__.input_ids",description:`<strong>input_ids</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length)</code>) &#x2014;
Indices of input sequence tokens in the vocabulary. Padding will be ignored by default should you provide
it.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#input-ids">What are input IDs?</a>`,name:"input_ids"},{anchor:"transformers.FlaxMarianMTModel.__call__.attention_mask",description:`<strong>attention_mask</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Mask to avoid performing attention on padding token indices. Mask values selected in <code>[0, 1]</code>:</p>
<ul>
<li>1 for tokens that are <strong>not masked</strong>,</li>
<li>0 for tokens that are <strong>masked</strong>.</li>
</ul>
<p><a href="../glossary#attention-mask">What are attention masks?</a>`,name:"attention_mask"},{anchor:"transformers.FlaxMarianMTModel.__call__.decoder_input_ids",description:`<strong>decoder_input_ids</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of decoder input sequence tokens in the vocabulary.</p>
<p>Indices can be obtained using <a href="/docs/transformers/main/ko/model_doc/auto#transformers.AutoTokenizer">AutoTokenizer</a>. See <a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.encode">PreTrainedTokenizer.encode()</a> and
<a href="/docs/transformers/main/ko/internal/tokenization_utils#transformers.PreTrainedTokenizerBase.__call__">PreTrainedTokenizer.<strong>call</strong>()</a> for details.</p>
<p><a href="../glossary#decoder-input-ids">What are decoder input IDs?</a></p>
<p>For translation and summarization training, <code>decoder_input_ids</code> should be provided. If no
<code>decoder_input_ids</code> is provided, the model will create this tensor by shifting the <code>input_ids</code> to the right
for denoising pre-training following the paper.`,name:"decoder_input_ids"},{anchor:"transformers.FlaxMarianMTModel.__call__.decoder_attention_mask",description:`<strong>decoder_attention_mask</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, target_sequence_length)</code>, <em>optional</em>) &#x2014;
Default behavior: generate a tensor that ignores pad tokens in <code>decoder_input_ids</code>. Causal mask will also
be used by default.</p>
<p>If you want to change padding behavior, you should modify to your needs. See diagram 1 in <a href="https://huggingface.co/papers/1910.13461" rel="nofollow">the
paper</a> for more information on the default strategy.`,name:"decoder_attention_mask"},{anchor:"transformers.FlaxMarianMTModel.__call__.position_ids",description:`<strong>position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each input sequence tokens in the position embeddings. Selected in the range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"position_ids"},{anchor:"transformers.FlaxMarianMTModel.__call__.decoder_position_ids",description:`<strong>decoder_position_ids</strong> (<code>numpy.ndarray</code> of shape <code>(batch_size, sequence_length)</code>, <em>optional</em>) &#x2014;
Indices of positions of each decoder input sequence tokens in the position embeddings. Selected in the
range <code>[0, config.max_position_embeddings - 1]</code>.`,name:"decoder_position_ids"},{anchor:"transformers.FlaxMarianMTModel.__call__.output_attentions",description:`<strong>output_attentions</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the attentions tensors of all attention layers. See <code>attentions</code> under returned
tensors for more detail.`,name:"output_attentions"},{anchor:"transformers.FlaxMarianMTModel.__call__.output_hidden_states",description:`<strong>output_hidden_states</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return the hidden states of all layers. See <code>hidden_states</code> under returned tensors for
more detail.`,name:"output_hidden_states"},{anchor:"transformers.FlaxMarianMTModel.__call__.return_dict",description:`<strong>return_dict</strong> (<code>bool</code>, <em>optional</em>) &#x2014;
Whether or not to return a <a href="/docs/transformers/main/ko/main_classes/output#transformers.utils.ModelOutput">ModelOutput</a> instead of a plain tuple.`,name:"return_dict"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/modeling_flax_marian.py#L1140",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSeq2SeqLMOutput"
>transformers.modeling_flax_outputs.FlaxSeq2SeqLMOutput</a> or a tuple of
<code>torch.FloatTensor</code> (if <code>return_dict=False</code> is passed or when <code>config.return_dict=False</code>) comprising various
elements depending on the configuration (<a
  href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianConfig"
>MarianConfig</a>) and inputs.</p>
<ul>
<li>
<p><strong>logits</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, config.vocab_size)</code>) — Prediction scores of the language modeling head (scores for each vocabulary token before SoftMax).</p>
</li>
<li>
<p><strong>past_key_values</strong> (<code>tuple(tuple(jnp.ndarray))</code>, <em>optional</em>, returned when <code>use_cache=True</code> is passed or when <code>config.use_cache=True</code>) — Tuple of <code>tuple(jnp.ndarray)</code> of length <code>config.n_layers</code>, with each tuple having 2 tensors of shape
<code>(batch_size, num_heads, sequence_length, embed_size_per_head)</code>) and 2 additional tensors of shape
<code>(batch_size, num_heads, encoder_sequence_length, embed_size_per_head)</code>.</p>
<p>Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention
blocks) that can be used (see <code>past_key_values</code> input) to speed up sequential decoding.</p>
</li>
<li>
<p><strong>decoder_hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>decoder_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
<li>
<p><strong>cross_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the
weighted average in the cross-attention heads.</p>
</li>
<li>
<p><strong>encoder_last_hidden_state</strong> (<code>jnp.ndarray</code> of shape <code>(batch_size, sequence_length, hidden_size)</code>, <em>optional</em>) — Sequence of hidden-states at the output of the last layer of the encoder of the model.</p>
</li>
<li>
<p><strong>encoder_hidden_states</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_hidden_states=True</code> is passed or when <code>config.output_hidden_states=True</code>) — Tuple of <code>jnp.ndarray</code> (one for the output of the embeddings + one for the output of each layer) of shape
<code>(batch_size, sequence_length, hidden_size)</code>.</p>
<p>Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.</p>
</li>
<li>
<p><strong>encoder_attentions</strong> (<code>tuple(jnp.ndarray)</code>, <em>optional</em>, returned when <code>output_attentions=True</code> is passed or when <code>config.output_attentions=True</code>) — Tuple of <code>jnp.ndarray</code> (one for each layer) of shape <code>(batch_size, num_heads, sequence_length, sequence_length)</code>.</p>
<p>Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the
self-attention heads.</p>
</li>
</ul>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/transformers/main/ko/main_classes/output#transformers.modeling_flax_outputs.FlaxSeq2SeqLMOutput"
>transformers.modeling_flax_outputs.FlaxSeq2SeqLMOutput</a> or <code>tuple(torch.FloatTensor)</code></p>
`}}),$=new Ve({props:{$$slots:{default:[At]},$$scope:{ctx:J}}}),S=new Se({props:{anchor:"transformers.FlaxMarianMTModel.__call__.example",$$slots:{default:[Et]},$$scope:{ctx:J}}}),{c(){_(e.$$.fragment),c=r(),n=p("div"),_(s.$$.fragment),u=r(),o=p("p"),o.innerHTML=w,he=r(),Z=p("p"),Z.innerHTML=H,re=r(),C=p("p"),C.textContent=G,B=r(),f=p("ul"),f.innerHTML=I,ie=r(),A=p("div"),_(Te.$$.fragment),O=r(),Y=p("p"),Y.innerHTML=te,me=r(),_(P.$$.fragment),D=r(),_(L.$$.fragment),F=r(),_(le.$$.fragment),ue=r(),W=p("div"),_(ye.$$.fragment),de=r(),be=p("p"),be.innerHTML=Ie,K=r(),fe=p("p"),fe.innerHTML=E,ne=r(),X=p("p"),X.textContent=Q,qe=r(),ce=p("ul"),ce.innerHTML=pe,Je=r(),N=p("div"),_(ke.$$.fragment),ee=r(),oe=p("p"),oe.innerHTML=ge,x=r(),_($.$$.fragment),V=r(),_(S.$$.fragment),this.h()},l(j){M(e.$$.fragment,j),c=i(j),n=h(j,"DIV",{class:!0});var z=we(n);M(s.$$.fragment,z),u=i(z),o=h(z,"P",{"data-svelte-h":!0}),v(o)!=="svelte-19ii6pw"&&(o.innerHTML=w),he=i(z),Z=h(z,"P",{"data-svelte-h":!0}),v(Z)!=="svelte-idybz1"&&(Z.innerHTML=H),re=i(z),C=h(z,"P",{"data-svelte-h":!0}),v(C)!=="svelte-1pplc4a"&&(C.textContent=G),B=i(z),f=h(z,"UL",{"data-svelte-h":!0}),v(f)!=="svelte-1w7z84m"&&(f.innerHTML=I),ie=i(z),A=h(z,"DIV",{class:!0});var R=we(A);M(Te.$$.fragment,R),O=i(R),Y=h(R,"P",{"data-svelte-h":!0}),v(Y)!=="svelte-1pl959f"&&(Y.innerHTML=te),me=i(R),M(P.$$.fragment,R),D=i(R),M(L.$$.fragment,R),R.forEach(a),z.forEach(a),F=i(j),M(le.$$.fragment,j),ue=i(j),W=h(j,"DIV",{class:!0});var se=we(W);M(ye.$$.fragment,se),de=i(se),be=h(se,"P",{"data-svelte-h":!0}),v(be)!=="svelte-ih66hv"&&(be.innerHTML=Ie),K=i(se),fe=h(se,"P",{"data-svelte-h":!0}),v(fe)!=="svelte-idybz1"&&(fe.innerHTML=E),ne=i(se),X=h(se,"P",{"data-svelte-h":!0}),v(X)!=="svelte-1pplc4a"&&(X.textContent=Q),qe=i(se),ce=h(se,"UL",{"data-svelte-h":!0}),v(ce)!=="svelte-1w7z84m"&&(ce.innerHTML=pe),Je=i(se),N=h(se,"DIV",{class:!0});var ae=we(N);M(ke.$$.fragment,ae),ee=i(ae),oe=h(ae,"P",{"data-svelte-h":!0}),v(oe)!=="svelte-1pl959f"&&(oe.innerHTML=ge),x=i(ae),M($.$$.fragment,ae),V=i(ae),M(S.$$.fragment,ae),ae.forEach(a),se.forEach(a),this.h()},h(){Me(A,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(n,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(N,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(W,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(j,z){T(e,j,z),l(j,c,z),l(j,n,z),T(s,n,null),d(n,u),d(n,o),d(n,he),d(n,Z),d(n,re),d(n,C),d(n,B),d(n,f),d(n,ie),d(n,A),T(Te,A,null),d(A,O),d(A,Y),d(A,me),T(P,A,null),d(A,D),T(L,A,null),l(j,F,z),T(le,j,z),l(j,ue,z),l(j,W,z),T(ye,W,null),d(W,de),d(W,be),d(W,K),d(W,fe),d(W,ne),d(W,X),d(W,qe),d(W,ce),d(W,Je),d(W,N),T(ke,N,null),d(N,ee),d(N,oe),d(N,x),T($,N,null),d(N,V),T(S,N,null),q=!0},p(j,z){const R={};z&2&&(R.$$scope={dirty:z,ctx:j}),P.$set(R);const se={};z&2&&(se.$$scope={dirty:z,ctx:j}),L.$set(se);const ae={};z&2&&(ae.$$scope={dirty:z,ctx:j}),$.$set(ae);const Fe={};z&2&&(Fe.$$scope={dirty:z,ctx:j}),S.$set(Fe)},i(j){q||(y(e.$$.fragment,j),y(s.$$.fragment,j),y(Te.$$.fragment,j),y(P.$$.fragment,j),y(L.$$.fragment,j),y(le.$$.fragment,j),y(ye.$$.fragment,j),y(ke.$$.fragment,j),y($.$$.fragment,j),y(S.$$.fragment,j),q=!0)},o(j){b(e.$$.fragment,j),b(s.$$.fragment,j),b(Te.$$.fragment,j),b(P.$$.fragment,j),b(L.$$.fragment,j),b(le.$$.fragment,j),b(ye.$$.fragment,j),b(ke.$$.fragment,j),b($.$$.fragment,j),b(S.$$.fragment,j),q=!1},d(j){j&&(a(c),a(n),a(F),a(ue),a(W)),k(e,j),k(s),k(Te),k(P),k(L),k(le,j),k(ye),k(ke),k($),k(S)}}}function Ot(J){let e,c;return e=new gt({props:{$$slots:{default:[Qt]},$$scope:{ctx:J}}}),{c(){_(e.$$.fragment)},l(n){M(e.$$.fragment,n)},m(n,s){T(e,n,s),c=!0},p(n,s){const u={};s&2&&(u.$$scope={dirty:s,ctx:n}),e.$set(u)},i(n){c||(y(e.$$.fragment,n),c=!0)},o(n){b(e.$$.fragment,n),c=!1},d(n){k(e,n)}}}function Yt(J){let e,c,n,s,u,o,w,he='<a href="https://huggingface.co/models?filter=marian"><img alt="Models" src="https://img.shields.io/badge/All_model_pages-marian-blueviolet"/></a> <a href="https://huggingface.co/spaces/docs-demos/opus-mt-zh-en"><img alt="Spaces" src="https://img.shields.io/badge/%F0%9F%A4%97%20Hugging%20Face-Spaces-blue"/></a>',Z,H,re,C,G='BART와 동일한 모델을 사용하는 번역 모델 프레임워크입니다. 번역 결과는 각 모델 카드의 테스트 세트와 유사하지만, 정확히 일치하지는 않을 수 있습니다. 이 모델은 <a href="https://huggingface.co/sshleifer" rel="nofollow">sshleifer</a>가 제공했습니다.',B,f,I,ie,A=`<li><p>각 모델은 약 298 MB를 차지하며, 1,000개 이상의 모델이 제공됩니다.</p></li> <li><p>지원되는 언어 쌍 목록은 <a href="https://huggingface.co/Helsinki-NLP" rel="nofollow">여기</a>에서 확인할 수 있습니다.</p></li> <li><p>모델들은 <a href="https://researchportal.helsinki.fi/en/persons/j%C3%B6rg-tiedemann" rel="nofollow">Jörg Tiedemann</a>에 의해 <a href="https://marian-nmt.github.io/" rel="nofollow">Marian</a> C++ 라이브러리를 이용하여 학습되었습니다. 이 라이브러리는 빠른 학습과 번역을 지원합니다.</p></li> <li><p>모든 모델은 6개 레이어로 이루어진 Transformer 기반의 인코더-디코더 구조입니다. 각 모델의 성능은 모델 카드에 기입되어 있습니다.</p></li> <li><p>BPE 전처리가 필요한 80개의 OPUS 모델은 지원되지 않습니다.</p></li> <li><p>모델링 코드는 <a href="/docs/transformers/main/ko/model_doc/bart#transformers.BartForConditionalGeneration">BartForConditionalGeneration</a>을 기반으로 하며, 일부 수정사항이 반영되어 있습니다:</p> <ul><li>정적 (사인 함수 기반) 위치 임베딩 사용 (<code>MarianConfig.static_position_embeddings=True</code>)</li> <li>임베딩 레이어 정규화 생략 (<code>MarianConfig.normalize_embedding=False</code>)</li> <li>모델은 생성 시 프리픽스로 <code>pad_token_id</code> (해당 토큰 임베딩 값은 0)를 사용하여 시작합니다 (Bart는
<code>&lt;s/&gt;</code>를 사용),</li></ul></li> <li><p>Marian 모델을 PyTorch로 대량 변환하는 코드는 <code>convert_marian_to_pytorch.py</code>에서 찾을 수 있습니다.</p></li>`,Te,O,Y,te,me='<li>모든 모델 이름은 <code>Helsinki-NLP/opus-mt-{src}-{tgt}</code> 형식을 따릅니다.</li> <li>모델의 언어 코드 표기는 일관되지 않습니다. 두 자리 코드는 일반적으로 <a href="https://developers.google.com/admin-sdk/directory/v1/languages" rel="nofollow">여기</a>에서 찾을 수 있으며, 세 자리 코드는 “언어 코드 {code}“로 구글 검색을 통해 찾습니다.</li> <li><code>es_AR</code>과 같은 형태의 코드는 <code>code_{region}</code> 형식을 의미합니다. 여기서의 예시는 아르헨티나의 스페인어를 의미합니다.</li> <li>모델 변환은 두 단계로 이루어졌습니다. 처음 1,000개 모델은 ISO-639-2 코드를 사용하고, 두 번째 그룹은 ISO-639-5와 ISO-639-2 코드를 조합하여 언어를 식별합니다.</li>',P,D,L,F,le='<li>Marian 모델은 라이브러리의 다른 번역 모델들보다 크기가 작아 파인튜닝 실험과 통합 테스트에 유용합니다.</li> <li><a href="https://github.com/huggingface/transformers/blob/master/examples/legacy/seq2seq/train_distil_marian_enro.sh" rel="nofollow">GPU에서 파인튜닝하기</a></li>',ue,W,ye,de,be='<li>모든 모델 이름은<code>Helsinki-NLP/opus-mt-{src}-{tgt}</code> 형식을 따릅니다.</li> <li>다중 언어 출력을 지원하는 모델의 경우, 출력을 원하는 언어의 언어 코드를 <code>src_text</code>의 시작 부분에 추가하여 지정해야 합니다.</li> <li>모델 카드에서 지원되는 언어 코드의 목록을 확인할 수 있습니다! 예를 들어 <a href="https://huggingface.co/Helsinki-NLP/opus-mt-en-roa" rel="nofollow">opus-mt-en-roa</a>에서 확인할 수 있습니다.</li> <li><code>Helsinki-NLP/opus-mt-roa-en</code>처럼 소스 측에서만 다국어를 지원하는 모델의 경우, 별도의 언어 코드 지정이 필요하지 않습니다.</li>',Ie,K,fe='<a href="https://github.com/Helsinki-NLP/Tatoeba-Challenge" rel="nofollow">Tatoeba-Challenge 리포지토리</a>의 새로운 다국적 모델은 3자리 언어 코드를 사용합니다:',E,ne,X,Q,qe="허브에 있는 모든 사전 학습된 모델을 확인하는 코드입니다:",ce,pe,Je,N,ke,ee,oe="이 모델들은 OPUS-MT-Train 리포지토리의 구형 다국어 모델들입니다. 각 언어 그룹에 포함된 언어들은 다음과 같습니다:",ge,x,$,V,S="영어를 여러 로망스 언어로 번역하는 예제입니다. 여기서는 구형 2자리 언어 코드를 사용합니다:",q,j,z,R,se,ae,Fe='<li><a href="../tasks/translation">번역 작업 가이드</a></li> <li><a href="../tasks/summarization">요약 작업 가이드</a></li> <li><a href="../tasks/language_modeling">언어 모델링 작업 가이드</a></li>',Re,Ue,Be,m,U,ze,_e,Ne=`This is the configuration class to store the configuration of a <a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianModel">MarianModel</a>. It is used to instantiate an
Marian model according to the specified arguments, defining the model architecture. Instantiating a configuration
with the defaults will yield a similar configuration to that of the Marian
<a href="https://huggingface.co/Helsinki-NLP/opus-mt-en-de" rel="nofollow">Helsinki-NLP/opus-mt-en-de</a> architecture.`,Le,xe,nt=`Configuration objects inherit from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> and can be used to control the model outputs. Read the
documentation from <a href="/docs/transformers/main/ko/main_classes/configuration#transformers.PretrainedConfig">PretrainedConfig</a> for more information.`,ct,Ge,st,Ee,at,Ce,Qe,pt,Ke,_t='Construct a Marian tokenizer. Based on <a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a>.',ht,et,Mt=`This tokenizer inherits from <code>PreTrainedTokenizer</code> which contains most of the main methods. Users should refer to
this superclass for more information regarding those methods.`,mt,Xe,ut,Pe,Oe,ft,tt,Tt="Build model inputs from a sequence by appending eos_token_id.",rt,Ae,it,Ye,lt,ot,dt;return u=new je({props:{title:"MarianMT",local:"MarianMT",headingTag:"h1"}}),H=new je({props:{title:"개요",local:"Overview",headingTag:"h2"}}),f=new je({props:{title:"구현 노트",local:"Implementation Notes",headingTag:"h2"}}),O=new je({props:{title:"모델 이름 규칙",local:"Naming",headingTag:"h2"}}),D=new je({props:{title:"예시",local:"Examples",headingTag:"h2"}}),W=new je({props:{title:"다국어 모델 사용법",local:"Multilingual Models",headingTag:"h2"}}),ne=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyME1hcmlhbk1UTW9kZWwlMkMlMjBNYXJpYW5Ub2tlbml6ZXIlMEElMEFzcmNfdGV4dCUyMCUzRCUyMCU1QiUwQSUyMCUyMCUyMCUyMCUyMiUzRSUzRWZyYSUzQyUzQyUyMHRoaXMlMjBpcyUyMGElMjBzZW50ZW5jZSUyMGluJTIwZW5nbGlzaCUyMHRoYXQlMjB3ZSUyMHdhbnQlMjB0byUyMHRyYW5zbGF0ZSUyMHRvJTIwZnJlbmNoJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIyJTNFJTNFcG9yJTNDJTNDJTIwVGhpcyUyMHNob3VsZCUyMGdvJTIwdG8lMjBwb3J0dWd1ZXNlJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIyJTNFJTNFZXNwJTNDJTNDJTIwQW5kJTIwdGhpcyUyMHRvJTIwU3BhbmlzaCUyMiUyQyUwQSU1RCUwQSUwQW1vZGVsX25hbWUlMjAlM0QlMjAlMjJIZWxzaW5raS1OTFAlMkZvcHVzLW10LWVuLXJvYSUyMiUwQXRva2VuaXplciUyMCUzRCUyME1hcmlhblRva2VuaXplci5mcm9tX3ByZXRyYWluZWQobW9kZWxfbmFtZSklMEFwcmludCh0b2tlbml6ZXIuc3VwcG9ydGVkX2xhbmd1YWdlX2NvZGVzKSUwQSUwQW1vZGVsJTIwJTNEJTIwTWFyaWFuTVRNb2RlbC5mcm9tX3ByZXRyYWluZWQobW9kZWxfbmFtZSklMEF0cmFuc2xhdGVkJTIwJTNEJTIwbW9kZWwuZ2VuZXJhdGUoKip0b2tlbml6ZXIoc3JjX3RleHQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyJTJDJTIwcGFkZGluZyUzRFRydWUpKSUwQSU1QnRva2VuaXplci5kZWNvZGUodCUyQyUyMHNraXBfc3BlY2lhbF90b2tlbnMlM0RUcnVlKSUyMGZvciUyMHQlMjBpbiUyMHRyYW5zbGF0ZWQlNUQ=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> MarianMTModel, MarianTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>src_text = [
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;&gt;&gt;fra&lt;&lt; this is a sentence in english that we want to translate to french&quot;</span>,
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;&gt;&gt;por&lt;&lt; This should go to portuguese&quot;</span>,
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;&gt;&gt;esp&lt;&lt; And this to Spanish&quot;</span>,
<span class="hljs-meta">... </span>]

<span class="hljs-meta">&gt;&gt;&gt; </span>model_name = <span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-roa&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = MarianTokenizer.from_pretrained(model_name)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(tokenizer.supported_language_codes)
[<span class="hljs-string">&#x27;&gt;&gt;zlm_Latn&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;mfe&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;hat&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;pap&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;ast&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;cat&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;ind&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;glg&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;wln&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;spa&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;fra&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;ron&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;por&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;ita&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;oci&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;arg&lt;&lt;&#x27;</span>, <span class="hljs-string">&#x27;&gt;&gt;min&lt;&lt;&#x27;</span>]

<span class="hljs-meta">&gt;&gt;&gt; </span>model = MarianMTModel.from_pretrained(model_name)
<span class="hljs-meta">&gt;&gt;&gt; </span>translated = model.generate(**tokenizer(src_text, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>, padding=<span class="hljs-literal">True</span>))
<span class="hljs-meta">&gt;&gt;&gt; </span>[tokenizer.decode(t, skip_special_tokens=<span class="hljs-literal">True</span>) <span class="hljs-keyword">for</span> t <span class="hljs-keyword">in</span> translated]
[<span class="hljs-string">&quot;c&#x27;est une phrase en anglais que nous voulons traduire en français&quot;</span>,
 <span class="hljs-string">&#x27;Isto deve ir para o português.&#x27;</span>,
 <span class="hljs-string">&#x27;Y esto al español&#x27;</span>]`,wrap:!1}}),pe=new We({props:{code:"ZnJvbSUyMGh1Z2dpbmdmYWNlX2h1YiUyMGltcG9ydCUyMGxpc3RfbW9kZWxzJTBBJTBBbW9kZWxfbGlzdCUyMCUzRCUyMGxpc3RfbW9kZWxzKCklMEFvcmclMjAlM0QlMjAlMjJIZWxzaW5raS1OTFAlMjIlMEFtb2RlbF9pZHMlMjAlM0QlMjAlNUJ4LmlkJTIwZm9yJTIweCUyMGluJTIwbW9kZWxfbGlzdCUyMGlmJTIweC5pZC5zdGFydHN3aXRoKG9yZyklNUQlMEFzdWZmaXglMjAlM0QlMjAlNUJ4LnNwbGl0KCUyMiUyRiUyMiklNUIxJTVEJTIwZm9yJTIweCUyMGluJTIwbW9kZWxfaWRzJTVEJTBBb2xkX3N0eWxlX211bHRpX21vZGVscyUyMCUzRCUyMCU1QmYlMjIlN0JvcmclN0QlMkYlN0JzJTdEJTIyJTIwZm9yJTIwcyUyMGluJTIwc3VmZml4JTIwaWYlMjBzJTIwISUzRCUyMHMubG93ZXIoKSU1RA==",highlighted:`<span class="hljs-keyword">from</span> huggingface_hub <span class="hljs-keyword">import</span> list_models

model_list = list_models()
org = <span class="hljs-string">&quot;Helsinki-NLP&quot;</span>
model_ids = [x.<span class="hljs-built_in">id</span> <span class="hljs-keyword">for</span> x <span class="hljs-keyword">in</span> model_list <span class="hljs-keyword">if</span> x.<span class="hljs-built_in">id</span>.startswith(org)]
suffix = [x.split(<span class="hljs-string">&quot;/&quot;</span>)[<span class="hljs-number">1</span>] <span class="hljs-keyword">for</span> x <span class="hljs-keyword">in</span> model_ids]
old_style_multi_models = [<span class="hljs-string">f&quot;<span class="hljs-subst">{org}</span>/<span class="hljs-subst">{s}</span>&quot;</span> <span class="hljs-keyword">for</span> s <span class="hljs-keyword">in</span> suffix <span class="hljs-keyword">if</span> s != s.lower()]`,wrap:!1}}),N=new je({props:{title:"구형 다국어 모델",local:"Old Style Multi-Lingual Models",headingTag:"h2"}}),x=new We({props:{code:"JTVCJ0hlbHNpbmtpLU5MUCUyRm9wdXMtbXQtTk9SVEhfRVUtTk9SVEhfRVUnJTJDJTBBJTIwJ0hlbHNpbmtpLU5MUCUyRm9wdXMtbXQtUk9NQU5DRS1lbiclMkMlMEElMjAnSGVsc2lua2ktTkxQJTJGb3B1cy1tdC1TQ0FORElOQVZJQS1TQ0FORElOQVZJQSclMkMlMEElMjAnSGVsc2lua2ktTkxQJTJGb3B1cy1tdC1kZS1aSCclMkMlMEElMjAnSGVsc2lua2ktTkxQJTJGb3B1cy1tdC1lbi1DRUxUSUMnJTJDJTBBJTIwJ0hlbHNpbmtpLU5MUCUyRm9wdXMtbXQtZW4tUk9NQU5DRSclMkMlMEElMjAnSGVsc2lua2ktTkxQJTJGb3B1cy1tdC1lcy1OT1JXQVknJTJDJTBBJTIwJ0hlbHNpbmtpLU5MUCUyRm9wdXMtbXQtZmktTk9SV0FZJyUyQyUwQSUyMCdIZWxzaW5raS1OTFAlMkZvcHVzLW10LWZpLVpIJyUyQyUwQSUyMCdIZWxzaW5raS1OTFAlMkZvcHVzLW10LWZpX25iX25vX25uX3J1X3N2X2VuLVNBTUknJTJDJTBBJTIwJ0hlbHNpbmtpLU5MUCUyRm9wdXMtbXQtc3YtTk9SV0FZJyUyQyUwQSUyMCdIZWxzaW5raS1OTFAlMkZvcHVzLW10LXN2LVpIJyU1RCUwQUdST1VQX01FTUJFUlMlMjAlM0QlMjAlN0IlMEElMjAnWkgnJTNBJTIwJTVCJ2NtbiclMkMlMjAnY24nJTJDJTIwJ3l1ZSclMkMlMjAnemVfemgnJTJDJTIwJ3poX2NuJyUyQyUyMCd6aF9DTiclMkMlMjAnemhfSEsnJTJDJTIwJ3poX3R3JyUyQyUyMCd6aF9UVyclMkMlMjAnemhfeXVlJyUyQyUyMCd6aHMnJTJDJTIwJ3podCclMkMlMjAnemgnJTVEJTJDJTBBJTIwJ1JPTUFOQ0UnJTNBJTIwJTVCJ2ZyJyUyQyUyMCdmcl9CRSclMkMlMjAnZnJfQ0EnJTJDJTIwJ2ZyX0ZSJyUyQyUyMCd3YSclMkMlMjAnZnJwJyUyQyUyMCdvYyclMkMlMjAnY2EnJTJDJTIwJ3JtJyUyQyUyMCdsbGQnJTJDJTIwJ2Z1ciclMkMlMjAnbGlqJyUyQyUyMCdsbW8nJTJDJTIwJ2VzJyUyQyUyMCdlc19BUiclMkMlMjAnZXNfQ0wnJTJDJTIwJ2VzX0NPJyUyQyUyMCdlc19DUiclMkMlMjAnZXNfRE8nJTJDJTIwJ2VzX0VDJyUyQyUyMCdlc19FUyclMkMlMjAnZXNfR1QnJTJDJTIwJ2VzX0hOJyUyQyUyMCdlc19NWCclMkMlMjAnZXNfTkknJTJDJTIwJ2VzX1BBJyUyQyUyMCdlc19QRSclMkMlMjAnZXNfUFInJTJDJTIwJ2VzX1NWJyUyQyUyMCdlc19VWSclMkMlMjAnZXNfVkUnJTJDJTIwJ3B0JyUyQyUyMCdwdF9iciclMkMlMjAncHRfQlInJTJDJTIwJ3B0X1BUJyUyQyUyMCdnbCclMkMlMjAnbGFkJyUyQyUyMCdhbiclMkMlMjAnbXdsJyUyQyUyMCdpdCclMkMlMjAnaXRfSVQnJTJDJTIwJ2NvJyUyQyUyMCduYXAnJTJDJTIwJ3NjbiclMkMlMjAndmVjJyUyQyUyMCdzYyclMkMlMjAncm8nJTJDJTIwJ2xhJyU1RCUyQyUwQSUyMCdOT1JUSF9FVSclM0ElMjAlNUInZGUnJTJDJTIwJ25sJyUyQyUyMCdmeSclMkMlMjAnYWYnJTJDJTIwJ2RhJyUyQyUyMCdmbyclMkMlMjAnaXMnJTJDJTIwJ25vJyUyQyUyMCduYiclMkMlMjAnbm4nJTJDJTIwJ3N2JyU1RCUyQyUwQSUyMCdTQ0FORElOQVZJQSclM0ElMjAlNUInZGEnJTJDJTIwJ2ZvJyUyQyUyMCdpcyclMkMlMjAnbm8nJTJDJTIwJ25iJyUyQyUyMCdubiclMkMlMjAnc3YnJTVEJTJDJTBBJTIwJ1NBTUknJTNBJTIwJTVCJ3NlJyUyQyUyMCdzbWEnJTJDJTIwJ3NtaiclMkMlMjAnc21uJyUyQyUyMCdzbXMnJTVEJTJDJTBBJTIwJ05PUldBWSclM0ElMjAlNUInbmJfTk8nJTJDJTIwJ25iJyUyQyUyMCdubl9OTyclMkMlMjAnbm4nJTJDJTIwJ25vZyclMkMlMjAnbm9fbmInJTJDJTIwJ25vJyU1RCUyQyUwQSUyMCdDRUxUSUMnJTNBJTIwJTVCJ2dhJyUyQyUyMCdjeSclMkMlMjAnYnInJTJDJTIwJ2dkJyUyQyUyMCdrdyclMkMlMjAnZ3YnJTVEJTBBJTdE",highlighted:`[<span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-NORTH_EU-NORTH_EU&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-ROMANCE-en&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-SCANDINAVIA-SCANDINAVIA&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-de-ZH&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-en-CELTIC&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-en-ROMANCE&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-es-NORWAY&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-fi-NORWAY&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-fi-ZH&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-fi_nb_no_nn_ru_sv_en-SAMI&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-sv-NORWAY&#x27;</span>,
 <span class="hljs-string">&#x27;Helsinki-NLP/opus-mt-sv-ZH&#x27;</span>]
GROUP_MEMBERS = {
 <span class="hljs-string">&#x27;ZH&#x27;</span>: [<span class="hljs-string">&#x27;cmn&#x27;</span>, <span class="hljs-string">&#x27;cn&#x27;</span>, <span class="hljs-string">&#x27;yue&#x27;</span>, <span class="hljs-string">&#x27;ze_zh&#x27;</span>, <span class="hljs-string">&#x27;zh_cn&#x27;</span>, <span class="hljs-string">&#x27;zh_CN&#x27;</span>, <span class="hljs-string">&#x27;zh_HK&#x27;</span>, <span class="hljs-string">&#x27;zh_tw&#x27;</span>, <span class="hljs-string">&#x27;zh_TW&#x27;</span>, <span class="hljs-string">&#x27;zh_yue&#x27;</span>, <span class="hljs-string">&#x27;zhs&#x27;</span>, <span class="hljs-string">&#x27;zht&#x27;</span>, <span class="hljs-string">&#x27;zh&#x27;</span>],
 <span class="hljs-string">&#x27;ROMANCE&#x27;</span>: [<span class="hljs-string">&#x27;fr&#x27;</span>, <span class="hljs-string">&#x27;fr_BE&#x27;</span>, <span class="hljs-string">&#x27;fr_CA&#x27;</span>, <span class="hljs-string">&#x27;fr_FR&#x27;</span>, <span class="hljs-string">&#x27;wa&#x27;</span>, <span class="hljs-string">&#x27;frp&#x27;</span>, <span class="hljs-string">&#x27;oc&#x27;</span>, <span class="hljs-string">&#x27;ca&#x27;</span>, <span class="hljs-string">&#x27;rm&#x27;</span>, <span class="hljs-string">&#x27;lld&#x27;</span>, <span class="hljs-string">&#x27;fur&#x27;</span>, <span class="hljs-string">&#x27;lij&#x27;</span>, <span class="hljs-string">&#x27;lmo&#x27;</span>, <span class="hljs-string">&#x27;es&#x27;</span>, <span class="hljs-string">&#x27;es_AR&#x27;</span>, <span class="hljs-string">&#x27;es_CL&#x27;</span>, <span class="hljs-string">&#x27;es_CO&#x27;</span>, <span class="hljs-string">&#x27;es_CR&#x27;</span>, <span class="hljs-string">&#x27;es_DO&#x27;</span>, <span class="hljs-string">&#x27;es_EC&#x27;</span>, <span class="hljs-string">&#x27;es_ES&#x27;</span>, <span class="hljs-string">&#x27;es_GT&#x27;</span>, <span class="hljs-string">&#x27;es_HN&#x27;</span>, <span class="hljs-string">&#x27;es_MX&#x27;</span>, <span class="hljs-string">&#x27;es_NI&#x27;</span>, <span class="hljs-string">&#x27;es_PA&#x27;</span>, <span class="hljs-string">&#x27;es_PE&#x27;</span>, <span class="hljs-string">&#x27;es_PR&#x27;</span>, <span class="hljs-string">&#x27;es_SV&#x27;</span>, <span class="hljs-string">&#x27;es_UY&#x27;</span>, <span class="hljs-string">&#x27;es_VE&#x27;</span>, <span class="hljs-string">&#x27;pt&#x27;</span>, <span class="hljs-string">&#x27;pt_br&#x27;</span>, <span class="hljs-string">&#x27;pt_BR&#x27;</span>, <span class="hljs-string">&#x27;pt_PT&#x27;</span>, <span class="hljs-string">&#x27;gl&#x27;</span>, <span class="hljs-string">&#x27;lad&#x27;</span>, <span class="hljs-string">&#x27;an&#x27;</span>, <span class="hljs-string">&#x27;mwl&#x27;</span>, <span class="hljs-string">&#x27;it&#x27;</span>, <span class="hljs-string">&#x27;it_IT&#x27;</span>, <span class="hljs-string">&#x27;co&#x27;</span>, <span class="hljs-string">&#x27;nap&#x27;</span>, <span class="hljs-string">&#x27;scn&#x27;</span>, <span class="hljs-string">&#x27;vec&#x27;</span>, <span class="hljs-string">&#x27;sc&#x27;</span>, <span class="hljs-string">&#x27;ro&#x27;</span>, <span class="hljs-string">&#x27;la&#x27;</span>],
 <span class="hljs-string">&#x27;NORTH_EU&#x27;</span>: [<span class="hljs-string">&#x27;de&#x27;</span>, <span class="hljs-string">&#x27;nl&#x27;</span>, <span class="hljs-string">&#x27;fy&#x27;</span>, <span class="hljs-string">&#x27;af&#x27;</span>, <span class="hljs-string">&#x27;da&#x27;</span>, <span class="hljs-string">&#x27;fo&#x27;</span>, <span class="hljs-string">&#x27;is&#x27;</span>, <span class="hljs-string">&#x27;no&#x27;</span>, <span class="hljs-string">&#x27;nb&#x27;</span>, <span class="hljs-string">&#x27;nn&#x27;</span>, <span class="hljs-string">&#x27;sv&#x27;</span>],
 <span class="hljs-string">&#x27;SCANDINAVIA&#x27;</span>: [<span class="hljs-string">&#x27;da&#x27;</span>, <span class="hljs-string">&#x27;fo&#x27;</span>, <span class="hljs-string">&#x27;is&#x27;</span>, <span class="hljs-string">&#x27;no&#x27;</span>, <span class="hljs-string">&#x27;nb&#x27;</span>, <span class="hljs-string">&#x27;nn&#x27;</span>, <span class="hljs-string">&#x27;sv&#x27;</span>],
 <span class="hljs-string">&#x27;SAMI&#x27;</span>: [<span class="hljs-string">&#x27;se&#x27;</span>, <span class="hljs-string">&#x27;sma&#x27;</span>, <span class="hljs-string">&#x27;smj&#x27;</span>, <span class="hljs-string">&#x27;smn&#x27;</span>, <span class="hljs-string">&#x27;sms&#x27;</span>],
 <span class="hljs-string">&#x27;NORWAY&#x27;</span>: [<span class="hljs-string">&#x27;nb_NO&#x27;</span>, <span class="hljs-string">&#x27;nb&#x27;</span>, <span class="hljs-string">&#x27;nn_NO&#x27;</span>, <span class="hljs-string">&#x27;nn&#x27;</span>, <span class="hljs-string">&#x27;nog&#x27;</span>, <span class="hljs-string">&#x27;no_nb&#x27;</span>, <span class="hljs-string">&#x27;no&#x27;</span>],
 <span class="hljs-string">&#x27;CELTIC&#x27;</span>: [<span class="hljs-string">&#x27;ga&#x27;</span>, <span class="hljs-string">&#x27;cy&#x27;</span>, <span class="hljs-string">&#x27;br&#x27;</span>, <span class="hljs-string">&#x27;gd&#x27;</span>, <span class="hljs-string">&#x27;kw&#x27;</span>, <span class="hljs-string">&#x27;gv&#x27;</span>]
}`,wrap:!1}}),j=new We({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyME1hcmlhbk1UTW9kZWwlMkMlMjBNYXJpYW5Ub2tlbml6ZXIlMEElMEFzcmNfdGV4dCUyMCUzRCUyMCU1QiUwQSUyMCUyMCUyMCUyMCUyMiUzRSUzRWZyJTNDJTNDJTIwdGhpcyUyMGlzJTIwYSUyMHNlbnRlbmNlJTIwaW4lMjBlbmdsaXNoJTIwdGhhdCUyMHdlJTIwd2FudCUyMHRvJTIwdHJhbnNsYXRlJTIwdG8lMjBmcmVuY2glMjIlMkMlMEElMjAlMjAlMjAlMjAlMjIlM0UlM0VwdCUzQyUzQyUyMFRoaXMlMjBzaG91bGQlMjBnbyUyMHRvJTIwcG9ydHVndWVzZSUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMiUzRSUzRWVzJTNDJTNDJTIwQW5kJTIwdGhpcyUyMHRvJTIwU3BhbmlzaCUyMiUyQyUwQSU1RCUwQSUwQW1vZGVsX25hbWUlMjAlM0QlMjAlMjJIZWxzaW5raS1OTFAlMkZvcHVzLW10LWVuLVJPTUFOQ0UlMjIlMEF0b2tlbml6ZXIlMjAlM0QlMjBNYXJpYW5Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKG1vZGVsX25hbWUpJTBBJTBBbW9kZWwlMjAlM0QlMjBNYXJpYW5NVE1vZGVsLmZyb21fcHJldHJhaW5lZChtb2RlbF9uYW1lKSUwQXRyYW5zbGF0ZWQlMjAlM0QlMjBtb2RlbC5nZW5lcmF0ZSgqKnRva2VuaXplcihzcmNfdGV4dCUyQyUyMHJldHVybl90ZW5zb3JzJTNEJTIycHQlMjIlMkMlMjBwYWRkaW5nJTNEVHJ1ZSkpJTBBdGd0X3RleHQlMjAlM0QlMjAlNUJ0b2tlbml6ZXIuZGVjb2RlKHQlMkMlMjBza2lwX3NwZWNpYWxfdG9rZW5zJTNEVHJ1ZSklMjBmb3IlMjB0JTIwaW4lMjB0cmFuc2xhdGVkJTVE",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> MarianMTModel, MarianTokenizer

<span class="hljs-meta">&gt;&gt;&gt; </span>src_text = [
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;&gt;&gt;fr&lt;&lt; this is a sentence in english that we want to translate to french&quot;</span>,
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;&gt;&gt;pt&lt;&lt; This should go to portuguese&quot;</span>,
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;&gt;&gt;es&lt;&lt; And this to Spanish&quot;</span>,
<span class="hljs-meta">... </span>]

<span class="hljs-meta">&gt;&gt;&gt; </span>model_name = <span class="hljs-string">&quot;Helsinki-NLP/opus-mt-en-ROMANCE&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = MarianTokenizer.from_pretrained(model_name)

<span class="hljs-meta">&gt;&gt;&gt; </span>model = MarianMTModel.from_pretrained(model_name)
<span class="hljs-meta">&gt;&gt;&gt; </span>translated = model.generate(**tokenizer(src_text, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>, padding=<span class="hljs-literal">True</span>))
<span class="hljs-meta">&gt;&gt;&gt; </span>tgt_text = [tokenizer.decode(t, skip_special_tokens=<span class="hljs-literal">True</span>) <span class="hljs-keyword">for</span> t <span class="hljs-keyword">in</span> translated]
[<span class="hljs-string">&quot;c&#x27;est une phrase en anglais que nous voulons traduire en français&quot;</span>, 
 <span class="hljs-string">&#x27;Isto deve ir para o português.&#x27;</span>,
 <span class="hljs-string">&#x27;Y esto al español&#x27;</span>]`,wrap:!1}}),R=new je({props:{title:"자료",local:"Resources",headingTag:"h2"}}),Ue=new je({props:{title:"MarianConfig",local:"transformers.MarianConfig",headingTag:"h2"}}),U=new $e({props:{name:"class transformers.MarianConfig",anchor:"transformers.MarianConfig",parameters:[{name:"vocab_size",val:" = 58101"},{name:"decoder_vocab_size",val:" = None"},{name:"max_position_embeddings",val:" = 1024"},{name:"encoder_layers",val:" = 12"},{name:"encoder_ffn_dim",val:" = 4096"},{name:"encoder_attention_heads",val:" = 16"},{name:"decoder_layers",val:" = 12"},{name:"decoder_ffn_dim",val:" = 4096"},{name:"decoder_attention_heads",val:" = 16"},{name:"encoder_layerdrop",val:" = 0.0"},{name:"decoder_layerdrop",val:" = 0.0"},{name:"use_cache",val:" = True"},{name:"is_encoder_decoder",val:" = True"},{name:"activation_function",val:" = 'gelu'"},{name:"d_model",val:" = 1024"},{name:"dropout",val:" = 0.1"},{name:"attention_dropout",val:" = 0.0"},{name:"activation_dropout",val:" = 0.0"},{name:"init_std",val:" = 0.02"},{name:"decoder_start_token_id",val:" = 58100"},{name:"scale_embedding",val:" = False"},{name:"pad_token_id",val:" = 58100"},{name:"eos_token_id",val:" = 0"},{name:"forced_eos_token_id",val:" = 0"},{name:"share_encoder_decoder_embeddings",val:" = True"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.MarianConfig.vocab_size",description:`<strong>vocab_size</strong> (<code>int</code>, <em>optional</em>, defaults to 58101) &#x2014;
Vocabulary size of the Marian model. Defines the number of different tokens that can be represented by the
<code>inputs_ids</code> passed when calling <a href="/docs/transformers/main/ko/model_doc/marian#transformers.MarianModel">MarianModel</a> or <a href="/docs/transformers/main/ko/model_doc/marian#transformers.TFMarianModel">TFMarianModel</a>.`,name:"vocab_size"},{anchor:"transformers.MarianConfig.d_model",description:`<strong>d_model</strong> (<code>int</code>, <em>optional</em>, defaults to 1024) &#x2014;
Dimensionality of the layers and the pooler layer.`,name:"d_model"},{anchor:"transformers.MarianConfig.encoder_layers",description:`<strong>encoder_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 12) &#x2014;
Number of encoder layers.`,name:"encoder_layers"},{anchor:"transformers.MarianConfig.decoder_layers",description:`<strong>decoder_layers</strong> (<code>int</code>, <em>optional</em>, defaults to 12) &#x2014;
Number of decoder layers.`,name:"decoder_layers"},{anchor:"transformers.MarianConfig.encoder_attention_heads",description:`<strong>encoder_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 16) &#x2014;
Number of attention heads for each attention layer in the Transformer encoder.`,name:"encoder_attention_heads"},{anchor:"transformers.MarianConfig.decoder_attention_heads",description:`<strong>decoder_attention_heads</strong> (<code>int</code>, <em>optional</em>, defaults to 16) &#x2014;
Number of attention heads for each attention layer in the Transformer decoder.`,name:"decoder_attention_heads"},{anchor:"transformers.MarianConfig.decoder_ffn_dim",description:`<strong>decoder_ffn_dim</strong> (<code>int</code>, <em>optional</em>, defaults to 4096) &#x2014;
Dimensionality of the &#x201C;intermediate&#x201D; (often named feed-forward) layer in decoder.`,name:"decoder_ffn_dim"},{anchor:"transformers.MarianConfig.encoder_ffn_dim",description:`<strong>encoder_ffn_dim</strong> (<code>int</code>, <em>optional</em>, defaults to 4096) &#x2014;
Dimensionality of the &#x201C;intermediate&#x201D; (often named feed-forward) layer in decoder.`,name:"encoder_ffn_dim"},{anchor:"transformers.MarianConfig.activation_function",description:`<strong>activation_function</strong> (<code>str</code> or <code>function</code>, <em>optional</em>, defaults to <code>&quot;gelu&quot;</code>) &#x2014;
The non-linear activation function (function or string) in the encoder and pooler. If string, <code>&quot;gelu&quot;</code>,
<code>&quot;relu&quot;</code>, <code>&quot;silu&quot;</code> and <code>&quot;gelu_new&quot;</code> are supported.`,name:"activation_function"},{anchor:"transformers.MarianConfig.dropout",description:`<strong>dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.1) &#x2014;
The dropout probability for all fully connected layers in the embeddings, encoder, and pooler.`,name:"dropout"},{anchor:"transformers.MarianConfig.attention_dropout",description:`<strong>attention_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout ratio for the attention probabilities.`,name:"attention_dropout"},{anchor:"transformers.MarianConfig.activation_dropout",description:`<strong>activation_dropout</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The dropout ratio for activations inside the fully connected layer.`,name:"activation_dropout"},{anchor:"transformers.MarianConfig.max_position_embeddings",description:`<strong>max_position_embeddings</strong> (<code>int</code>, <em>optional</em>, defaults to 1024) &#x2014;
The maximum sequence length that this model might ever be used with. Typically set this to something large
just in case (e.g., 512 or 1024 or 2048).`,name:"max_position_embeddings"},{anchor:"transformers.MarianConfig.init_std",description:`<strong>init_std</strong> (<code>float</code>, <em>optional</em>, defaults to 0.02) &#x2014;
The standard deviation of the truncated_normal_initializer for initializing all weight matrices.`,name:"init_std"},{anchor:"transformers.MarianConfig.encoder_layerdrop",description:`<strong>encoder_layerdrop</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The LayerDrop probability for the encoder. See the [LayerDrop paper](see <a href="https://huggingface.co/papers/1909.11556" rel="nofollow">https://huggingface.co/papers/1909.11556</a>)
for more details.`,name:"encoder_layerdrop"},{anchor:"transformers.MarianConfig.decoder_layerdrop",description:`<strong>decoder_layerdrop</strong> (<code>float</code>, <em>optional</em>, defaults to 0.0) &#x2014;
The LayerDrop probability for the decoder. See the [LayerDrop paper](see <a href="https://huggingface.co/papers/1909.11556" rel="nofollow">https://huggingface.co/papers/1909.11556</a>)
for more details.`,name:"decoder_layerdrop"},{anchor:"transformers.MarianConfig.scale_embedding",description:`<strong>scale_embedding</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Scale embeddings by diving by sqrt(d_model).`,name:"scale_embedding"},{anchor:"transformers.MarianConfig.use_cache",description:`<strong>use_cache</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>True</code>) &#x2014;
Whether or not the model should return the last key/values attentions (not used by all models)`,name:"use_cache"},{anchor:"transformers.MarianConfig.forced_eos_token_id",description:`<strong>forced_eos_token_id</strong> (<code>int</code>, <em>optional</em>, defaults to 0) &#x2014;
The id of the token to force as the last generated token when <code>max_length</code> is reached. Usually set to
<code>eos_token_id</code>.`,name:"forced_eos_token_id"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/configuration_marian.py#L31"}}),Ge=new Se({props:{anchor:"transformers.MarianConfig.example",$$slots:{default:[$t]},$$scope:{ctx:J}}}),Ee=new je({props:{title:"MarianTokenizer",local:"transformers.MarianTokenizer",headingTag:"h2"}}),Qe=new $e({props:{name:"class transformers.MarianTokenizer",anchor:"transformers.MarianTokenizer",parameters:[{name:"source_spm",val:""},{name:"target_spm",val:""},{name:"vocab",val:""},{name:"target_vocab_file",val:" = None"},{name:"source_lang",val:" = None"},{name:"target_lang",val:" = None"},{name:"unk_token",val:" = '<unk>'"},{name:"eos_token",val:" = '</s>'"},{name:"pad_token",val:" = '<pad>'"},{name:"model_max_length",val:" = 512"},{name:"sp_model_kwargs",val:": typing.Optional[typing.Dict[str, typing.Any]] = None"},{name:"separate_vocabs",val:" = False"},{name:"**kwargs",val:""}],parametersDescription:[{anchor:"transformers.MarianTokenizer.source_spm",description:`<strong>source_spm</strong> (<code>str</code>) &#x2014;
<a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a> file (generally has a .spm extension) that
contains the vocabulary for the source language.`,name:"source_spm"},{anchor:"transformers.MarianTokenizer.target_spm",description:`<strong>target_spm</strong> (<code>str</code>) &#x2014;
<a href="https://github.com/google/sentencepiece" rel="nofollow">SentencePiece</a> file (generally has a .spm extension) that
contains the vocabulary for the target language.`,name:"target_spm"},{anchor:"transformers.MarianTokenizer.source_lang",description:`<strong>source_lang</strong> (<code>str</code>, <em>optional</em>) &#x2014;
A string representing the source language.`,name:"source_lang"},{anchor:"transformers.MarianTokenizer.target_lang",description:`<strong>target_lang</strong> (<code>str</code>, <em>optional</em>) &#x2014;
A string representing the target language.`,name:"target_lang"},{anchor:"transformers.MarianTokenizer.unk_token",description:`<strong>unk_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;unk&gt;&quot;</code>) &#x2014;
The unknown token. A token that is not in the vocabulary cannot be converted to an ID and is set to be this
token instead.`,name:"unk_token"},{anchor:"transformers.MarianTokenizer.eos_token",description:`<strong>eos_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;/s&gt;&quot;</code>) &#x2014;
The end of sequence token.`,name:"eos_token"},{anchor:"transformers.MarianTokenizer.pad_token",description:`<strong>pad_token</strong> (<code>str</code>, <em>optional</em>, defaults to <code>&quot;&lt;pad&gt;&quot;</code>) &#x2014;
The token used for padding, for example when batching sequences of different lengths.`,name:"pad_token"},{anchor:"transformers.MarianTokenizer.model_max_length",description:`<strong>model_max_length</strong> (<code>int</code>, <em>optional</em>, defaults to 512) &#x2014;
The maximum sentence length the model accepts.`,name:"model_max_length"},{anchor:"transformers.MarianTokenizer.additional_special_tokens",description:`<strong>additional_special_tokens</strong> (<code>List[str]</code>, <em>optional</em>, defaults to <code>[&quot;&lt;eop&gt;&quot;, &quot;&lt;eod&gt;&quot;]</code>) &#x2014;
Additional special tokens used by the tokenizer.`,name:"additional_special_tokens"},{anchor:"transformers.MarianTokenizer.sp_model_kwargs",description:`<strong>sp_model_kwargs</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Will be passed to the <code>SentencePieceProcessor.__init__()</code> method. The <a href="https://github.com/google/sentencepiece/tree/master/python" rel="nofollow">Python wrapper for
SentencePiece</a> can be used, among other things,
to set:</p>
<ul>
<li>
<p><code>enable_sampling</code>: Enable subword regularization.</p>
</li>
<li>
<p><code>nbest_size</code>: Sampling parameters for unigram. Invalid for BPE-Dropout.</p>
<ul>
<li><code>nbest_size = {0,1}</code>: No sampling is performed.</li>
<li><code>nbest_size &gt; 1</code>: samples from the nbest_size results.</li>
<li><code>nbest_size &lt; 0</code>: assuming that nbest_size is infinite and samples from the all hypothesis (lattice)
using forward-filtering-and-backward-sampling algorithm.</li>
</ul>
</li>
<li>
<p><code>alpha</code>: Smoothing parameter for unigram sampling, and dropout probability of merge operations for
BPE-dropout.</p>
</li>
</ul>`,name:"sp_model_kwargs"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/tokenization_marian.py#L45"}}),Xe=new Se({props:{anchor:"transformers.MarianTokenizer.example",$$slots:{default:[Jt]},$$scope:{ctx:J}}}),Oe=new $e({props:{name:"build_inputs_with_special_tokens",anchor:"transformers.MarianTokenizer.build_inputs_with_special_tokens",parameters:[{name:"token_ids_0",val:""},{name:"token_ids_1",val:" = None"}],source:"https://github.com/huggingface/transformers/blob/main/src/transformers/models/marian/tokenization_marian.py#L267"}}),Ae=new vt({props:{pytorch:!0,tensorflow:!0,jax:!0,$$slots:{jax:[Ot],tensorflow:[Gt],pytorch:[Zt]},$$scope:{ctx:J}}}),Ye=new jt({props:{source:"https://github.com/huggingface/transformers/blob/main/docs/source/ko/model_doc/marian.md"}}),{c(){e=p("meta"),c=r(),n=p("p"),s=r(),_(u.$$.fragment),o=r(),w=p("div"),w.innerHTML=he,Z=r(),_(H.$$.fragment),re=r(),C=p("p"),C.innerHTML=G,B=r(),_(f.$$.fragment),I=r(),ie=p("ul"),ie.innerHTML=A,Te=r(),_(O.$$.fragment),Y=r(),te=p("ul"),te.innerHTML=me,P=r(),_(D.$$.fragment),L=r(),F=p("ul"),F.innerHTML=le,ue=r(),_(W.$$.fragment),ye=r(),de=p("ul"),de.innerHTML=be,Ie=r(),K=p("p"),K.innerHTML=fe,E=r(),_(ne.$$.fragment),X=r(),Q=p("p"),Q.textContent=qe,ce=r(),_(pe.$$.fragment),Je=r(),_(N.$$.fragment),ke=r(),ee=p("p"),ee.textContent=oe,ge=r(),_(x.$$.fragment),$=r(),V=p("p"),V.textContent=S,q=r(),_(j.$$.fragment),z=r(),_(R.$$.fragment),se=r(),ae=p("ul"),ae.innerHTML=Fe,Re=r(),_(Ue.$$.fragment),Be=r(),m=p("div"),_(U.$$.fragment),ze=r(),_e=p("p"),_e.innerHTML=Ne,Le=r(),xe=p("p"),xe.innerHTML=nt,ct=r(),_(Ge.$$.fragment),st=r(),_(Ee.$$.fragment),at=r(),Ce=p("div"),_(Qe.$$.fragment),pt=r(),Ke=p("p"),Ke.innerHTML=_t,ht=r(),et=p("p"),et.innerHTML=Mt,mt=r(),_(Xe.$$.fragment),ut=r(),Pe=p("div"),_(Oe.$$.fragment),ft=r(),tt=p("p"),tt.textContent=Tt,rt=r(),_(Ae.$$.fragment),it=r(),_(Ye.$$.fragment),lt=r(),ot=p("p"),this.h()},l(t){const g=xt("svelte-u9bgzb",document.head);e=h(g,"META",{name:!0,content:!0}),g.forEach(a),c=i(t),n=h(t,"P",{}),we(n).forEach(a),s=i(t),M(u.$$.fragment,t),o=i(t),w=h(t,"DIV",{class:!0,"data-svelte-h":!0}),v(w)!=="svelte-28p0nh"&&(w.innerHTML=he),Z=i(t),M(H.$$.fragment,t),re=i(t),C=h(t,"P",{"data-svelte-h":!0}),v(C)!=="svelte-1nqgf1b"&&(C.innerHTML=G),B=i(t),M(f.$$.fragment,t),I=i(t),ie=h(t,"UL",{"data-svelte-h":!0}),v(ie)!=="svelte-1gycagx"&&(ie.innerHTML=A),Te=i(t),M(O.$$.fragment,t),Y=i(t),te=h(t,"UL",{"data-svelte-h":!0}),v(te)!=="svelte-1dw8355"&&(te.innerHTML=me),P=i(t),M(D.$$.fragment,t),L=i(t),F=h(t,"UL",{"data-svelte-h":!0}),v(F)!=="svelte-1uu74yq"&&(F.innerHTML=le),ue=i(t),M(W.$$.fragment,t),ye=i(t),de=h(t,"UL",{"data-svelte-h":!0}),v(de)!=="svelte-1i5q6sh"&&(de.innerHTML=be),Ie=i(t),K=h(t,"P",{"data-svelte-h":!0}),v(K)!=="svelte-5izl4p"&&(K.innerHTML=fe),E=i(t),M(ne.$$.fragment,t),X=i(t),Q=h(t,"P",{"data-svelte-h":!0}),v(Q)!=="svelte-15tfiz2"&&(Q.textContent=qe),ce=i(t),M(pe.$$.fragment,t),Je=i(t),M(N.$$.fragment,t),ke=i(t),ee=h(t,"P",{"data-svelte-h":!0}),v(ee)!=="svelte-ohp6tb"&&(ee.textContent=oe),ge=i(t),M(x.$$.fragment,t),$=i(t),V=h(t,"P",{"data-svelte-h":!0}),v(V)!=="svelte-qrwcnp"&&(V.textContent=S),q=i(t),M(j.$$.fragment,t),z=i(t),M(R.$$.fragment,t),se=i(t),ae=h(t,"UL",{"data-svelte-h":!0}),v(ae)!=="svelte-1mtr7x1"&&(ae.innerHTML=Fe),Re=i(t),M(Ue.$$.fragment,t),Be=i(t),m=h(t,"DIV",{class:!0});var He=we(m);M(U.$$.fragment,He),ze=i(He),_e=h(He,"P",{"data-svelte-h":!0}),v(_e)!=="svelte-a016wa"&&(_e.innerHTML=Ne),Le=i(He),xe=h(He,"P",{"data-svelte-h":!0}),v(xe)!=="svelte-qr3t5r"&&(xe.innerHTML=nt),ct=i(He),M(Ge.$$.fragment,He),He.forEach(a),st=i(t),M(Ee.$$.fragment,t),at=i(t),Ce=h(t,"DIV",{class:!0});var Ze=we(Ce);M(Qe.$$.fragment,Ze),pt=i(Ze),Ke=h(Ze,"P",{"data-svelte-h":!0}),v(Ke)!=="svelte-1giw7lm"&&(Ke.innerHTML=_t),ht=i(Ze),et=h(Ze,"P",{"data-svelte-h":!0}),v(et)!=="svelte-1urdkfw"&&(et.innerHTML=Mt),mt=i(Ze),M(Xe.$$.fragment,Ze),ut=i(Ze),Pe=h(Ze,"DIV",{class:!0});var De=we(Pe);M(Oe.$$.fragment,De),ft=i(De),tt=h(De,"P",{"data-svelte-h":!0}),v(tt)!=="svelte-wv4s2m"&&(tt.textContent=Tt),De.forEach(a),Ze.forEach(a),rt=i(t),M(Ae.$$.fragment,t),it=i(t),M(Ye.$$.fragment,t),lt=i(t),ot=h(t,"P",{}),we(ot).forEach(a),this.h()},h(){Me(e,"name","hf:doc:metadata"),Me(e,"content",Dt),Me(w,"class","flex flex-wrap space-x-1"),Me(m,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(Pe,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),Me(Ce,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(t,g){d(document.head,e),l(t,c,g),l(t,n,g),l(t,s,g),T(u,t,g),l(t,o,g),l(t,w,g),l(t,Z,g),T(H,t,g),l(t,re,g),l(t,C,g),l(t,B,g),T(f,t,g),l(t,I,g),l(t,ie,g),l(t,Te,g),T(O,t,g),l(t,Y,g),l(t,te,g),l(t,P,g),T(D,t,g),l(t,L,g),l(t,F,g),l(t,ue,g),T(W,t,g),l(t,ye,g),l(t,de,g),l(t,Ie,g),l(t,K,g),l(t,E,g),T(ne,t,g),l(t,X,g),l(t,Q,g),l(t,ce,g),T(pe,t,g),l(t,Je,g),T(N,t,g),l(t,ke,g),l(t,ee,g),l(t,ge,g),T(x,t,g),l(t,$,g),l(t,V,g),l(t,q,g),T(j,t,g),l(t,z,g),T(R,t,g),l(t,se,g),l(t,ae,g),l(t,Re,g),T(Ue,t,g),l(t,Be,g),l(t,m,g),T(U,m,null),d(m,ze),d(m,_e),d(m,Le),d(m,xe),d(m,ct),T(Ge,m,null),l(t,st,g),T(Ee,t,g),l(t,at,g),l(t,Ce,g),T(Qe,Ce,null),d(Ce,pt),d(Ce,Ke),d(Ce,ht),d(Ce,et),d(Ce,mt),T(Xe,Ce,null),d(Ce,ut),d(Ce,Pe),T(Oe,Pe,null),d(Pe,ft),d(Pe,tt),l(t,rt,g),T(Ae,t,g),l(t,it,g),T(Ye,t,g),l(t,lt,g),l(t,ot,g),dt=!0},p(t,[g]){const He={};g&2&&(He.$$scope={dirty:g,ctx:t}),Ge.$set(He);const Ze={};g&2&&(Ze.$$scope={dirty:g,ctx:t}),Xe.$set(Ze);const De={};g&2&&(De.$$scope={dirty:g,ctx:t}),Ae.$set(De)},i(t){dt||(y(u.$$.fragment,t),y(H.$$.fragment,t),y(f.$$.fragment,t),y(O.$$.fragment,t),y(D.$$.fragment,t),y(W.$$.fragment,t),y(ne.$$.fragment,t),y(pe.$$.fragment,t),y(N.$$.fragment,t),y(x.$$.fragment,t),y(j.$$.fragment,t),y(R.$$.fragment,t),y(Ue.$$.fragment,t),y(U.$$.fragment,t),y(Ge.$$.fragment,t),y(Ee.$$.fragment,t),y(Qe.$$.fragment,t),y(Xe.$$.fragment,t),y(Oe.$$.fragment,t),y(Ae.$$.fragment,t),y(Ye.$$.fragment,t),dt=!0)},o(t){b(u.$$.fragment,t),b(H.$$.fragment,t),b(f.$$.fragment,t),b(O.$$.fragment,t),b(D.$$.fragment,t),b(W.$$.fragment,t),b(ne.$$.fragment,t),b(pe.$$.fragment,t),b(N.$$.fragment,t),b(x.$$.fragment,t),b(j.$$.fragment,t),b(R.$$.fragment,t),b(Ue.$$.fragment,t),b(U.$$.fragment,t),b(Ge.$$.fragment,t),b(Ee.$$.fragment,t),b(Qe.$$.fragment,t),b(Xe.$$.fragment,t),b(Oe.$$.fragment,t),b(Ae.$$.fragment,t),b(Ye.$$.fragment,t),dt=!1},d(t){t&&(a(c),a(n),a(s),a(o),a(w),a(Z),a(re),a(C),a(B),a(I),a(ie),a(Te),a(Y),a(te),a(P),a(L),a(F),a(ue),a(ye),a(de),a(Ie),a(K),a(E),a(X),a(Q),a(ce),a(Je),a(ke),a(ee),a(ge),a($),a(V),a(q),a(z),a(se),a(ae),a(Re),a(Be),a(m),a(st),a(at),a(Ce),a(rt),a(it),a(lt),a(ot)),a(e),k(u,t),k(H,t),k(f,t),k(O,t),k(D,t),k(W,t),k(ne,t),k(pe,t),k(N,t),k(x,t),k(j,t),k(R,t),k(Ue,t),k(U),k(Ge),k(Ee,t),k(Qe),k(Xe),k(Oe),k(Ae,t),k(Ye,t)}}}const Dt='{"title":"MarianMT","local":"MarianMT","sections":[{"title":"개요","local":"Overview","sections":[],"depth":2},{"title":"구현 노트","local":"Implementation Notes","sections":[],"depth":2},{"title":"모델 이름 규칙","local":"Naming","sections":[],"depth":2},{"title":"예시","local":"Examples","sections":[],"depth":2},{"title":"다국어 모델 사용법","local":"Multilingual Models","sections":[],"depth":2},{"title":"구형 다국어 모델","local":"Old Style Multi-Lingual Models","sections":[],"depth":2},{"title":"자료","local":"Resources","sections":[],"depth":2},{"title":"MarianConfig","local":"transformers.MarianConfig","sections":[],"depth":2},{"title":"MarianTokenizer","local":"transformers.MarianTokenizer","sections":[],"depth":2},{"title":"MarianModel","local":"transformers.MarianModel","sections":[],"depth":2},{"title":"MarianMTModel","local":"transformers.MarianMTModel","sections":[],"depth":2},{"title":"MarianForCausalLM","local":"transformers.MarianForCausalLM","sections":[],"depth":2},{"title":"TFMarianModel","local":"transformers.TFMarianModel","sections":[],"depth":2},{"title":"TFMarianMTModel","local":"transformers.TFMarianMTModel","sections":[],"depth":2},{"title":"FlaxMarianModel","local":"transformers.FlaxMarianModel","sections":[],"depth":2},{"title":"FlaxMarianMTModel","local":"transformers.FlaxMarianMTModel","sections":[],"depth":2}],"depth":1}';function Kt(J){return bt(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class dn extends kt{constructor(e){super(),wt(this,e,Kt,Yt,yt,{})}}export{dn as component};
