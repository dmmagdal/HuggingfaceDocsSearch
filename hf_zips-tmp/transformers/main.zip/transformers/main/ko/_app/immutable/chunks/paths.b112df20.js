var s;const e=((s=globalThis.__sveltekit_1wylr6n)==null?void 0:s.base)??"/docs/transformers/main/ko";var a;const t=((a=globalThis.__sveltekit_1wylr6n)==null?void 0:a.assets)??e;export{t as a,e as b};
