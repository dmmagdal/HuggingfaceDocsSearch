var s;const t=((s=globalThis.__sveltekit_1lem9v6)==null?void 0:s.base)??"/docs/competitions/main/en";var e;const a=((e=globalThis.__sveltekit_1lem9v6)==null?void 0:e.assets)??t;export{a,t as b};
