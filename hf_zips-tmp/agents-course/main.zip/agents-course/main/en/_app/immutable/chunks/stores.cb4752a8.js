import{w as s}from"./index.18351ede.js";const a=s({}),e=s({});export{a,e as s};
