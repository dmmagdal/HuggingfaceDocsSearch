import{s as Yl,o as Ll,n as zl}from"../chunks/scheduler.37c15a92.js";import{S as Pl,i as Kl,g as p,s as n,r as o,m as rs,A as Dl,h as M,f as t,c as a,j as ul,u as c,x as i,n as ds,k as hs,y as jl,a as e,v as y,d as u,t as j,w as m}from"../chunks/index.2bf4358c.js";import{T as ql}from"../chunks/Tip.363c041f.js";import{C as f}from"../chunks/CodeBlock.4e987730.js";import{H as b}from"../chunks/Heading.8ada512a.js";import{E as Ol}from"../chunks/getInferenceSnippets.7a5d1a93.js";function st(js){let w,J,d="这个笔记本",T;return{c(){w=rs("您可以通过 "),J=p("a"),J.textContent=d,T=rs(" 中的代码进行实践，可使用 Google Colab 运行。"),this.h()},l(U){w=ds(U,"您可以通过 "),J=M(U,"A",{href:!0,target:!0,"data-svelte-h":!0}),i(J)!=="svelte-18x6fni"&&(J.textContent=d),T=ds(U," 中的代码进行实践，可使用 Google Colab 运行。"),this.h()},h(){hs(J,"href","https://huggingface.co/agents-course/notebooks/blob/main/unit2/llama-index/workflows.ipynb"),hs(J,"target","_blank")},m(U,r){e(U,w,r),e(U,J,r),e(U,T,r)},p:zl,d(U){U&&(t(w),t(J),t(T))}}}function lt(js){let w,J,d="LlamaIndex 文档",T;return{c(){w=rs("工作流还有一些更复杂的细微差别，您可以在"),J=p("a"),J.textContent=d,T=rs("中了解。"),this.h()},l(U){w=ds(U,"工作流还有一些更复杂的细微差别，您可以在"),J=M(U,"A",{href:!0,"data-svelte-h":!0}),i(J)!=="svelte-1wivvxd"&&(J.textContent=d),T=ds(U,"中了解。"),this.h()},h(){hs(J,"href","https://docs.llamaindex.ai/en/stable/understanding/workflows/")},m(U,r){e(U,w,r),e(U,J,r),e(U,T,r)},p:zl,d(U){U&&(t(w),t(J),t(T))}}}function tt(js){let w,J,d,T,U,r,B,ml="LlamaIndex 中的工作流提供了一种结构化方式来将代码组织成可管理的顺序步骤。",Cs,_,Tl=`这种工作流通过定义由<code>事件（Events）</code>触发的<code>步骤（Steps）</code>来创建，这些步骤本身也会发出<code>事件</code>来触发后续步骤。
让我们看看 Alfred 展示的用于 RAG 任务的 LlamaIndex 工作流。`,Is,k,rl='<img src="https://huggingface.co/datasets/agents-course/course-images/resolve/main/en/unit2/llama-index/workflows.png" alt="工作流示意图"/>',fs,g,dl="<strong>工作流具有以下关键优势：</strong>",bs,v,hl="<li>将代码清晰地组织为离散步骤</li> <li>事件驱动架构实现灵活控制流</li> <li>步骤间类型安全的通信</li> <li>内置状态管理</li> <li>支持简单和复杂的智能体交互</li>",Bs,V,Cl="正如您可能猜到的，<strong>工作流在保持对整体流程控制的同时，实现了智能体的自主性之间的完美平衡。</strong>",_s,Q,Il="现在让我们学习如何自己创建工作流！",ks,E,gs,h,vs,Z,Vs,C,ms,fl="安装工作流包",yl,$,Qs,G,bl=`我们可以通过定义一个继承自 <code>Workflow</code> 的类并用 <code>@step</code> 装饰你的函数来创建一个单步工作流。
我们还需要添加 <code>StartEvent</code> 和 <code>StopEvent</code>，它们是用于指示工作流开始和结束的特殊事件。`,Es,x,Zs,S,Bl="如您所见，我们现在可以通过调用“w.run()”来运行工作流程。",$s,F,Gs,W,_l=`为了连接多个步骤，我们<strong>创建在步骤之间传输数据的自定义事件</strong>。
为此，我们需要添加一个在步骤之间传递的“事件”，并将第一步的输出传输到第二步。`,xs,R,Ss,A,kl="类型提示在这里很重要，因为它可以确保工作流正确执行。让我们把事情复杂化一点吧！",Fs,N,Ws,X,gl="类型提示是工作流中最强大的部分，因为它允许我们创建分支、循环和连接以促进更复杂的工作流。",Rs,H,vl=`让我们展示一个使用联合运算符 <code>|</code> <strong>创建循环</strong> 的示例。
在下面的示例中，我们看到 <code>LoopEvent</code> 被作为步骤的输入，也可以作为输出返回。`,As,q,Ns,z,Xs,Y,Vl="我们还可以绘制工作流程。让我们使用 <code>draw_all_possible_flows</code> 函数来绘制工作流程。这会将工作流程存储在 HTML 文件中。",Hs,L,qs,P,Ql='<img src="https://huggingface.co/datasets/agents-course/course-images/resolve/main/en/unit2/llama-index/workflow-draw.png" alt="工作流程图"/>',zs,K,El="课程中我们将介绍最后一个很酷的技巧，即向工作流添加状态的能力。",Ys,D,Ls,O,Zl=`当您想要跟踪工作流的状态时，状态管理非常有用，这样每个步骤都可以访问相同的状态。
我们可以在步骤函数中的参数上使用“上下文”类型提示来实现这一点。`,Ps,ss,Ks,ls,$l="太棒了！现在您知道如何在 LlamaIndex 中创建基本工作流了！",Ds,I,Os,ts,Gl="但是，还有另一种创建工作流的方法，它依赖于 <code>AgentWorkflow</code> 类。让我们看看如何使用它来创建多智能体工作流。",sl,es,ll,ns,xl=`我们可以使用<strong><code>AgentWorkflow</code> 类来创建多智能体工作流</strong>，而无需手动创建工作流。
<code>AgentWorkflow</code> 使用工作流智能体，允许您创建一个或多个智能体的系统，这些智能体可以根据其专门功能进行协作并相互交接任务。
这可以构建复杂的智能体系统，其中不同的智能体处理任务的不同方面。
我们将从<code>llama_index.core.agent.workflow</code> 导入智能体类，而不是从<code>llama_index.core.agent</code> 导入类。
在<code>AgentWorkflow</code> 构造函数中，必须将一个智能体指定为根智能体。
当用户消息传入时，它首先被路由到根智能体。`,tl,as,Sl="然后每个智能体可以：",el,ps,Fl="<li>使用他们的工具直接处理请求</li> <li>交接给更适合该任务的另一个智能体</li> <li>向用户返回响应</li>",nl,Ms,Wl="让我们看看如何创建多智能体工作流。",al,is,pl,Us,Rl=`智能体工具还可以修改我们前面提到的工作流状态。在启动工作流之前，我们可以提供一个可供所有智能体使用的初始状态字典。
状态存储在工作流上下文的 state 键中。它将被注入到 state_prompt 中，以增强每个新用户消息。`,Ml,Js,Al="让我们通过修改前面的示例来注入一个计数器来计数函数调用：",il,ws,Ul,os,Nl="恭喜！您现在已经掌握了 LlamaIndex 中 Agent 的基础知识！🎉",Jl,cs,Xl="让我们继续进行最后一次测验来巩固您的知识！🚀",wl,ys,ol,Ts,cl;return U=new b({props:{title:"在 LlamaIndex 中创建智能工作流",local:"在-llamaindex-中创建智能工作流",headingTag:"h1"}}),E=new b({props:{title:"创建工作流",local:"创建工作流",headingTag:"h2"}}),h=new ql({props:{$$slots:{default:[st]},$$scope:{ctx:js}}}),Z=new b({props:{title:"基础工作流创建",local:"基础工作流创建",headingTag:"h3"}}),$=new f({props:{code:"cGlwJTIwaW5zdGFsbCUyMGxsYW1hLWluZGV4LXV0aWxzLXdvcmtmbG93",highlighted:"pip install llama-index-utils-workflow",wrap:!1}}),x=new f({props:{code:"ZnJvbSUyMGxsYW1hX2luZGV4LmNvcmUud29ya2Zsb3clMjBpbXBvcnQlMjBTdGFydEV2ZW50JTJDJTIwU3RvcEV2ZW50JTJDJTIwV29ya2Zsb3clMkMlMjBzdGVwJTBBJTBBY2xhc3MlMjBNeVdvcmtmbG93KFdvcmtmbG93KSUzQSUwQSUyMCUyMCUyMCUyMCU0MHN0ZXAlMEElMjAlMjAlMjAlMjBhc3luYyUyMGRlZiUyMG15X3N0ZXAoc2VsZiUyQyUyMGV2JTNBJTIwU3RhcnRFdmVudCklMjAtJTNFJTIwU3RvcEV2ZW50JTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIzJTIwZG8lMjBzb21ldGhpbmclMjBoZXJlJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwcmV0dXJuJTIwU3RvcEV2ZW50KHJlc3VsdCUzRCUyMkhlbGxvJTJDJTIwd29ybGQhJTIyKSUwQSUwQSUwQXclMjAlM0QlMjBNeVdvcmtmbG93KHRpbWVvdXQlM0QxMCUyQyUyMHZlcmJvc2UlM0RGYWxzZSklMEFyZXN1bHQlMjAlM0QlMjBhd2FpdCUyMHcucnVuKCk=",highlighted:`<span class="hljs-keyword">from</span> llama_index.core.workflow <span class="hljs-keyword">import</span> StartEvent, StopEvent, Workflow, step

<span class="hljs-keyword">class</span> <span class="hljs-title class_">MyWorkflow</span>(<span class="hljs-title class_ inherited__">Workflow</span>):
<span class="hljs-meta">    @step</span>
    <span class="hljs-keyword">async</span> <span class="hljs-keyword">def</span> <span class="hljs-title function_">my_step</span>(<span class="hljs-params">self, ev: StartEvent</span>) -&gt; StopEvent:
        <span class="hljs-comment"># do something here</span>
        <span class="hljs-keyword">return</span> StopEvent(result=<span class="hljs-string">&quot;Hello, world!&quot;</span>)


w = MyWorkflow(timeout=<span class="hljs-number">10</span>, verbose=<span class="hljs-literal">False</span>)
result = <span class="hljs-keyword">await</span> w.run()`,wrap:!1}}),F=new b({props:{title:"连接多个步骤",local:"连接多个步骤",headingTag:"h3"}}),R=new f({props:{code:"ZnJvbSUyMGxsYW1hX2luZGV4LmNvcmUud29ya2Zsb3clMjBpbXBvcnQlMjBFdmVudCUwQSUwQWNsYXNzJTIwUHJvY2Vzc2luZ0V2ZW50KEV2ZW50KSUzQSUwQSUyMCUyMCUyMCUyMGludGVybWVkaWF0ZV9yZXN1bHQlM0ElMjBzdHIlMEElMEFjbGFzcyUyME11bHRpU3RlcFdvcmtmbG93KFdvcmtmbG93KSUzQSUwQSUyMCUyMCUyMCUyMCU0MHN0ZXAlMEElMjAlMjAlMjAlMjBhc3luYyUyMGRlZiUyMHN0ZXBfb25lKHNlbGYlMkMlMjBldiUzQSUyMFN0YXJ0RXZlbnQpJTIwLSUzRSUyMFByb2Nlc3NpbmdFdmVudCUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMyUyMFByb2Nlc3MlMjBpbml0aWFsJTIwZGF0YSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHJldHVybiUyMFByb2Nlc3NpbmdFdmVudChpbnRlcm1lZGlhdGVfcmVzdWx0JTNEJTIyU3RlcCUyMDElMjBjb21wbGV0ZSUyMiklMEElMEElMjAlMjAlMjAlMjAlNDBzdGVwJTBBJTIwJTIwJTIwJTIwYXN5bmMlMjBkZWYlMjBzdGVwX3R3byhzZWxmJTJDJTIwZXYlM0ElMjBQcm9jZXNzaW5nRXZlbnQpJTIwLSUzRSUyMFN0b3BFdmVudCUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMyUyMFVzZSUyMHRoZSUyMGludGVybWVkaWF0ZSUyMHJlc3VsdCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGZpbmFsX3Jlc3VsdCUyMCUzRCUyMGYlMjJGaW5pc2hlZCUyMHByb2Nlc3NpbmclM0ElMjAlN0Jldi5pbnRlcm1lZGlhdGVfcmVzdWx0JTdEJTIyJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwcmV0dXJuJTIwU3RvcEV2ZW50KHJlc3VsdCUzRGZpbmFsX3Jlc3VsdCklMEElMEF3JTIwJTNEJTIwTXVsdGlTdGVwV29ya2Zsb3codGltZW91dCUzRDEwJTJDJTIwdmVyYm9zZSUzREZhbHNlKSUwQXJlc3VsdCUyMCUzRCUyMGF3YWl0JTIwdy5ydW4oKSUwQXJlc3VsdA==",highlighted:`<span class="hljs-keyword">from</span> llama_index.core.workflow <span class="hljs-keyword">import</span> Event

<span class="hljs-keyword">class</span> <span class="hljs-title class_">ProcessingEvent</span>(<span class="hljs-title class_ inherited__">Event</span>):
    intermediate_result: <span class="hljs-built_in">str</span>

<span class="hljs-keyword">class</span> <span class="hljs-title class_">MultiStepWorkflow</span>(<span class="hljs-title class_ inherited__">Workflow</span>):
<span class="hljs-meta">    @step</span>
    <span class="hljs-keyword">async</span> <span class="hljs-keyword">def</span> <span class="hljs-title function_">step_one</span>(<span class="hljs-params">self, ev: StartEvent</span>) -&gt; ProcessingEvent:
        <span class="hljs-comment"># Process initial data</span>
        <span class="hljs-keyword">return</span> ProcessingEvent(intermediate_result=<span class="hljs-string">&quot;Step 1 complete&quot;</span>)

<span class="hljs-meta">    @step</span>
    <span class="hljs-keyword">async</span> <span class="hljs-keyword">def</span> <span class="hljs-title function_">step_two</span>(<span class="hljs-params">self, ev: ProcessingEvent</span>) -&gt; StopEvent:
        <span class="hljs-comment"># Use the intermediate result</span>
        final_result = <span class="hljs-string">f&quot;Finished processing: <span class="hljs-subst">{ev.intermediate_result}</span>&quot;</span>
        <span class="hljs-keyword">return</span> StopEvent(result=final_result)

w = MultiStepWorkflow(timeout=<span class="hljs-number">10</span>, verbose=<span class="hljs-literal">False</span>)
result = <span class="hljs-keyword">await</span> w.run()
result`,wrap:!1}}),N=new b({props:{title:"循环和分支",local:"循环和分支",headingTag:"h3"}}),q=new f({props:{code:"ZnJvbSUyMGxsYW1hX2luZGV4LmNvcmUud29ya2Zsb3clMjBpbXBvcnQlMjBFdmVudCUwQWltcG9ydCUyMHJhbmRvbSUwQSUwQSUwQWNsYXNzJTIwUHJvY2Vzc2luZ0V2ZW50KEV2ZW50KSUzQSUwQSUyMCUyMCUyMCUyMGludGVybWVkaWF0ZV9yZXN1bHQlM0ElMjBzdHIlMEElMEElMEFjbGFzcyUyMExvb3BFdmVudChFdmVudCklM0ElMEElMjAlMjAlMjAlMjBsb29wX291dHB1dCUzQSUyMHN0ciUwQSUwQSUwQWNsYXNzJTIwTXVsdGlTdGVwV29ya2Zsb3coV29ya2Zsb3cpJTNBJTBBJTIwJTIwJTIwJTIwJTQwc3RlcCUwQSUyMCUyMCUyMCUyMGFzeW5jJTIwZGVmJTIwc3RlcF9vbmUoc2VsZiUyQyUyMGV2JTNBJTIwU3RhcnRFdmVudCUyMCU3QyUyMExvb3BFdmVudCklMjAtJTNFJTIwUHJvY2Vzc2luZ0V2ZW50JTIwJTdDJTIwTG9vcEV2ZW50JTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwaWYlMjByYW5kb20ucmFuZGludCgwJTJDJTIwMSklMjAlM0QlM0QlMjAwJTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwcHJpbnQoJTIyQmFkJTIwdGhpbmclMjBoYXBwZW5lZCUyMiklMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjByZXR1cm4lMjBMb29wRXZlbnQobG9vcF9vdXRwdXQlM0QlMjJCYWNrJTIwdG8lMjBzdGVwJTIwb25lLiUyMiklMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBlbHNlJTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwcHJpbnQoJTIyR29vZCUyMHRoaW5nJTIwaGFwcGVuZWQlMjIpJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwcmV0dXJuJTIwUHJvY2Vzc2luZ0V2ZW50KGludGVybWVkaWF0ZV9yZXN1bHQlM0QlMjJGaXJzdCUyMHN0ZXAlMjBjb21wbGV0ZS4lMjIpJTBBJTBBJTIwJTIwJTIwJTIwJTQwc3RlcCUwQSUyMCUyMCUyMCUyMGFzeW5jJTIwZGVmJTIwc3RlcF90d28oc2VsZiUyQyUyMGV2JTNBJTIwUHJvY2Vzc2luZ0V2ZW50KSUyMC0lM0UlMjBTdG9wRXZlbnQlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjMlMjBVc2UlMjB0aGUlMjBpbnRlcm1lZGlhdGUlMjByZXN1bHQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBmaW5hbF9yZXN1bHQlMjAlM0QlMjBmJTIyRmluaXNoZWQlMjBwcm9jZXNzaW5nJTNBJTIwJTdCZXYuaW50ZXJtZWRpYXRlX3Jlc3VsdCU3RCUyMiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHJldHVybiUyMFN0b3BFdmVudChyZXN1bHQlM0RmaW5hbF9yZXN1bHQpJTBBJTBBJTBBdyUyMCUzRCUyME11bHRpU3RlcFdvcmtmbG93KHZlcmJvc2UlM0RGYWxzZSklMEFyZXN1bHQlMjAlM0QlMjBhd2FpdCUyMHcucnVuKCklMEFyZXN1bHQ=",highlighted:`<span class="hljs-keyword">from</span> llama_index.core.workflow <span class="hljs-keyword">import</span> Event
<span class="hljs-keyword">import</span> random


<span class="hljs-keyword">class</span> <span class="hljs-title class_">ProcessingEvent</span>(<span class="hljs-title class_ inherited__">Event</span>):
    intermediate_result: <span class="hljs-built_in">str</span>


<span class="hljs-keyword">class</span> <span class="hljs-title class_">LoopEvent</span>(<span class="hljs-title class_ inherited__">Event</span>):
    loop_output: <span class="hljs-built_in">str</span>


<span class="hljs-keyword">class</span> <span class="hljs-title class_">MultiStepWorkflow</span>(<span class="hljs-title class_ inherited__">Workflow</span>):
<span class="hljs-meta">    @step</span>
    <span class="hljs-keyword">async</span> <span class="hljs-keyword">def</span> <span class="hljs-title function_">step_one</span>(<span class="hljs-params">self, ev: StartEvent | LoopEvent</span>) -&gt; ProcessingEvent | LoopEvent:
        <span class="hljs-keyword">if</span> random.randint(<span class="hljs-number">0</span>, <span class="hljs-number">1</span>) == <span class="hljs-number">0</span>:
            <span class="hljs-built_in">print</span>(<span class="hljs-string">&quot;Bad thing happened&quot;</span>)
            <span class="hljs-keyword">return</span> LoopEvent(loop_output=<span class="hljs-string">&quot;Back to step one.&quot;</span>)
        <span class="hljs-keyword">else</span>:
            <span class="hljs-built_in">print</span>(<span class="hljs-string">&quot;Good thing happened&quot;</span>)
            <span class="hljs-keyword">return</span> ProcessingEvent(intermediate_result=<span class="hljs-string">&quot;First step complete.&quot;</span>)

<span class="hljs-meta">    @step</span>
    <span class="hljs-keyword">async</span> <span class="hljs-keyword">def</span> <span class="hljs-title function_">step_two</span>(<span class="hljs-params">self, ev: ProcessingEvent</span>) -&gt; StopEvent:
        <span class="hljs-comment"># Use the intermediate result</span>
        final_result = <span class="hljs-string">f&quot;Finished processing: <span class="hljs-subst">{ev.intermediate_result}</span>&quot;</span>
        <span class="hljs-keyword">return</span> StopEvent(result=final_result)


w = MultiStepWorkflow(verbose=<span class="hljs-literal">False</span>)
result = <span class="hljs-keyword">await</span> w.run()
result`,wrap:!1}}),z=new b({props:{title:"绘制工作流程",local:"绘制工作流程",headingTag:"h3"}}),L=new f({props:{code:"ZnJvbSUyMGxsYW1hX2luZGV4LnV0aWxzLndvcmtmbG93JTIwaW1wb3J0JTIwZHJhd19hbGxfcG9zc2libGVfZmxvd3MlMEElMEF3JTIwJTNEJTIwLi4uJTIwJTIzJTIwYXMlMjBkZWZpbmVkJTIwaW4lMjB0aGUlMjBwcmV2aW91cyUyMHNlY3Rpb24lMEFkcmF3X2FsbF9wb3NzaWJsZV9mbG93cyh3JTJDJTIwJTIyZmxvdy5odG1sJTIyKQ==",highlighted:`<span class="hljs-keyword">from</span> llama_index.utils.workflow <span class="hljs-keyword">import</span> draw_all_possible_flows

w = ... <span class="hljs-comment"># as defined in the previous section</span>
draw_all_possible_flows(w, <span class="hljs-string">&quot;flow.html&quot;</span>)`,wrap:!1}}),D=new b({props:{title:"状态管理",local:"状态管理",headingTag:"h3"}}),ss=new f({props:{code:"ZnJvbSUyMGxsYW1hX2luZGV4LmNvcmUud29ya2Zsb3clMjBpbXBvcnQlMjBDb250ZXh0JTJDJTIwU3RhcnRFdmVudCUyQyUyMFN0b3BFdmVudCUwQSUwQSUwQSU0MHN0ZXAlMEFhc3luYyUyMGRlZiUyMHF1ZXJ5KHNlbGYlMkMlMjBjdHglM0ElMjBDb250ZXh0JTJDJTIwZXYlM0ElMjBTdGFydEV2ZW50KSUyMC0lM0UlMjBTdG9wRXZlbnQlM0ElMEElMjAlMjAlMjAlMjAlMjMlMjAlRTUlQUQlOTglRTUlODIlQTglRTUlOUMlQTglRTQlQjglOEElRTQlQjglOEIlRTYlOTYlODclRTQlQjglQUQlMEElMjAlMjAlMjAlMjBhd2FpdCUyMGN0eC5zZXQoJTIycXVlcnklMjIlMkMlMjAlMjJXaGF0JTIwaXMlMjB0aGUlMjBjYXBpdGFsJTIwb2YlMjBGcmFuY2UlM0YlMjIpJTBBJTBBJTIwJTIwJTIwJTIwJTIzJTIwJUU2JUEwJUI5JUU2JThEJUFFJUU0JUI4JThBJUU0JUI4JThCJUU2JTk2JTg3JUU1JTkyJThDJUU0JUJBJThCJUU0JUJCJUI2JUU1JTgxJTlBJUU2JTlGJTkwJUU0JUJBJThCJTBBJTIwJTIwJTIwJTIwdmFsJTIwJTNEJTIwLi4uJTBBJTBBJTIwJTIwJTIwJTIwJTIzJTIwJUU0JUJCJThFJUU0JUI4JThBJUU0JUI4JThCJUU2JTk2JTg3JUU0JUI4JUFEJUU2JUEzJTgwJUU3JUI0JUEyJTBBJTIwJTIwJTIwJTIwcXVlcnklMjAlM0QlMjBhd2FpdCUyMGN0eC5nZXQoJTIycXVlcnklMjIpJTBBJTBBJTIwJTIwJTIwJTIwcmV0dXJuJTIwU3RvcEV2ZW50KHJlc3VsdCUzRHJlc3VsdCk=",highlighted:`<span class="hljs-keyword">from</span> llama_index.core.workflow <span class="hljs-keyword">import</span> Context, StartEvent, StopEvent


<span class="hljs-meta">@step</span>
<span class="hljs-keyword">async</span> <span class="hljs-keyword">def</span> <span class="hljs-title function_">query</span>(<span class="hljs-params">self, ctx: Context, ev: StartEvent</span>) -&gt; StopEvent:
    <span class="hljs-comment"># 存储在上下文中</span>
    <span class="hljs-keyword">await</span> ctx.<span class="hljs-built_in">set</span>(<span class="hljs-string">&quot;query&quot;</span>, <span class="hljs-string">&quot;What is the capital of France?&quot;</span>)

    <span class="hljs-comment"># 根据上下文和事件做某事</span>
    val = ...

    <span class="hljs-comment"># 从上下文中检索</span>
    query = <span class="hljs-keyword">await</span> ctx.get(<span class="hljs-string">&quot;query&quot;</span>)

    <span class="hljs-keyword">return</span> StopEvent(result=result)`,wrap:!1}}),I=new ql({props:{$$slots:{default:[lt]},$$scope:{ctx:js}}}),es=new b({props:{title:"使用多智能体工作流自动化工作流",local:"使用多智能体工作流自动化工作流",headingTag:"h2"}}),is=new f({props:{code:"ZnJvbSUyMGxsYW1hX2luZGV4LmNvcmUuYWdlbnQud29ya2Zsb3clMjBpbXBvcnQlMjBBZ2VudFdvcmtmbG93JTJDJTIwUmVBY3RBZ2VudCUwQWZyb20lMjBsbGFtYV9pbmRleC5sbG1zLmh1Z2dpbmdmYWNlX2FwaSUyMGltcG9ydCUyMEh1Z2dpbmdGYWNlSW5mZXJlbmNlQVBJJTBBJTBBJTIzJTIwJUU1JUFFJTlBJUU0JUI5JTg5JUU0JUI4JTgwJUU0JUJBJTlCJUU1JUI3JUE1JUU1JTg1JUI3JTBBZGVmJTIwYWRkKGElM0ElMjBpbnQlMkMlMjBiJTNBJTIwaW50KSUyMC0lM0UlMjBpbnQlM0ElMEElMjAlMjAlMjAlMjAlMjIlMjIlMjJBZGQlMjB0d28lMjBudW1iZXJzLiUyMiUyMiUyMiUwQSUyMCUyMCUyMCUyMHJldHVybiUyMGElMjAlMkIlMjBiJTBBJTBBZGVmJTIwbXVsdGlwbHkoYSUzQSUyMGludCUyQyUyMGIlM0ElMjBpbnQpJTIwLSUzRSUyMGludCUzQSUwQSUyMCUyMCUyMCUyMCUyMiUyMiUyMk11bHRpcGx5JTIwdHdvJTIwbnVtYmVycy4lMjIlMjIlMjIlMEElMjAlMjAlMjAlMjByZXR1cm4lMjBhJTIwKiUyMGIlMEElMEFsbG0lMjAlM0QlMjBIdWdnaW5nRmFjZUluZmVyZW5jZUFQSShtb2RlbF9uYW1lJTNEJTIyUXdlbiUyRlF3ZW4yLjUtQ29kZXItMzJCLUluc3RydWN0JTIyKSUwQSUwQSUyMyUyMCVFNiU4OCU5MSVFNCVCQiVBQyVFNSU4RiVBRiVFNCVCQiVBNSVFNyU5QiVCNCVFNiU4RSVBNSVFNCVCQyVBMCVFOSU4MCU5MiVFNSU4NyVCRCVFNiU5NSVCMCVFRiVCQyU4QyVFOCU4MCU4QyVFNiU5NyVBMCVFOSU5QyU4MCUyMEZ1bmN0aW9uVG9vbCVFMiU4MCU5NCVFMiU4MCU5NGZuJTJGZG9jc3RyaW5nJTIwJUU0JUJDJTlBJUU4JUEyJUFCJUU4JUE3JUEzJUU2JTlFJTkwJUU0JUI4JUJBJUU1JTkwJThEJUU3JUE3JUIwJTJGJUU2JThGJThGJUU4JUJGJUIwJTBBbXVsdGlwbHlfYWdlbnQlMjAlM0QlMjBSZUFjdEFnZW50KCUwQSUyMCUyMCUyMCUyMG5hbWUlM0QlMjJtdWx0aXBseV9hZ2VudCUyMiUyQyUwQSUyMCUyMCUyMCUyMGRlc2NyaXB0aW9uJTNEJTIySXMlMjBhYmxlJTIwdG8lMjBtdWx0aXBseSUyMHR3byUyMGludGVnZXJzJTIyJTJDJTBBJTIwJTIwJTIwJTIwc3lzdGVtX3Byb21wdCUzRCUyMkElMjBoZWxwZnVsJTIwYXNzaXN0YW50JTIwdGhhdCUyMGNhbiUyMHVzZSUyMGElMjB0b29sJTIwdG8lMjBtdWx0aXBseSUyMG51bWJlcnMuJTIyJTJDJTBBJTIwJTIwJTIwJTIwdG9vbHMlM0QlNUJtdWx0aXBseSU1RCUyQyUwQSUyMCUyMCUyMCUyMGxsbSUzRGxsbSUyQyUwQSklMEElMEFhZGRpdGlvbl9hZ2VudCUyMCUzRCUyMFJlQWN0QWdlbnQoJTBBJTIwJTIwJTIwJTIwbmFtZSUzRCUyMmFkZF9hZ2VudCUyMiUyQyUwQSUyMCUyMCUyMCUyMGRlc2NyaXB0aW9uJTNEJTIySXMlMjBhYmxlJTIwdG8lMjBhZGQlMjB0d28lMjBpbnRlZ2VycyUyMiUyQyUwQSUyMCUyMCUyMCUyMHN5c3RlbV9wcm9tcHQlM0QlMjJBJTIwaGVscGZ1bCUyMGFzc2lzdGFudCUyMHRoYXQlMjBjYW4lMjB1c2UlMjBhJTIwdG9vbCUyMHRvJTIwYWRkJTIwbnVtYmVycy4lMjIlMkMlMEElMjAlMjAlMjAlMjB0b29scyUzRCU1QmFkZCU1RCUyQyUwQSUyMCUyMCUyMCUyMGxsbSUzRGxsbSUyQyUwQSklMEElMEElMjMlMjAlRTUlODglOUIlRTUlQkIlQkElRTUlQjclQTUlRTQlQkQlOUMlRTYlQjUlODElMEF3b3JrZmxvdyUyMCUzRCUyMEFnZW50V29ya2Zsb3coJTBBJTIwJTIwJTIwJTIwYWdlbnRzJTNEJTVCbXVsdGlwbHlfYWdlbnQlMkMlMjBhZGRpdGlvbl9hZ2VudCU1RCUyQyUwQSUyMCUyMCUyMCUyMHJvb3RfYWdlbnQlM0QlMjJtdWx0aXBseV9hZ2VudCUyMiUyQyUwQSklMEElMEElMjMlMjAlRTglQkYlOTAlRTglQTElOEMlRTclQjMlQkIlRTclQkIlOUYlMEFyZXNwb25zZSUyMCUzRCUyMGF3YWl0JTIwd29ya2Zsb3cucnVuKHVzZXJfbXNnJTNEJTIyQ2FuJTIweW91JTIwYWRkJTIwNSUyMGFuZCUyMDMlM0YlMjIp",highlighted:`<span class="hljs-keyword">from</span> llama_index.core.agent.workflow <span class="hljs-keyword">import</span> AgentWorkflow, ReActAgent
<span class="hljs-keyword">from</span> llama_index.llms.huggingface_api <span class="hljs-keyword">import</span> HuggingFaceInferenceAPI

<span class="hljs-comment"># 定义一些工具</span>
<span class="hljs-keyword">def</span> <span class="hljs-title function_">add</span>(<span class="hljs-params">a: <span class="hljs-built_in">int</span>, b: <span class="hljs-built_in">int</span></span>) -&gt; <span class="hljs-built_in">int</span>:
    <span class="hljs-string">&quot;&quot;&quot;Add two numbers.&quot;&quot;&quot;</span>
    <span class="hljs-keyword">return</span> a + b

<span class="hljs-keyword">def</span> <span class="hljs-title function_">multiply</span>(<span class="hljs-params">a: <span class="hljs-built_in">int</span>, b: <span class="hljs-built_in">int</span></span>) -&gt; <span class="hljs-built_in">int</span>:
    <span class="hljs-string">&quot;&quot;&quot;Multiply two numbers.&quot;&quot;&quot;</span>
    <span class="hljs-keyword">return</span> a * b

llm = HuggingFaceInferenceAPI(model_name=<span class="hljs-string">&quot;Qwen/Qwen2.5-Coder-32B-Instruct&quot;</span>)

<span class="hljs-comment"># 我们可以直接传递函数，而无需 FunctionTool——fn/docstring 会被解析为名称/描述</span>
multiply_agent = ReActAgent(
    name=<span class="hljs-string">&quot;multiply_agent&quot;</span>,
    description=<span class="hljs-string">&quot;Is able to multiply two integers&quot;</span>,
    system_prompt=<span class="hljs-string">&quot;A helpful assistant that can use a tool to multiply numbers.&quot;</span>,
    tools=[multiply],
    llm=llm,
)

addition_agent = ReActAgent(
    name=<span class="hljs-string">&quot;add_agent&quot;</span>,
    description=<span class="hljs-string">&quot;Is able to add two integers&quot;</span>,
    system_prompt=<span class="hljs-string">&quot;A helpful assistant that can use a tool to add numbers.&quot;</span>,
    tools=[add],
    llm=llm,
)

<span class="hljs-comment"># 创建工作流</span>
workflow = AgentWorkflow(
    agents=[multiply_agent, addition_agent],
    root_agent=<span class="hljs-string">&quot;multiply_agent&quot;</span>,
)

<span class="hljs-comment"># 运行系统</span>
response = <span class="hljs-keyword">await</span> workflow.run(user_msg=<span class="hljs-string">&quot;Can you add 5 and 3?&quot;</span>)`,wrap:!1}}),ws=new f({props:{code:"JTBBJTBBJTBBJTBBJTBBJTBBJTBB",highlighted:`<span class="hljs-keyword">from</span> llama_index.core.workflow <span class="hljs-keyword">import</span> Context

<span class="hljs-comment"># 定义一些工具</span>
<span class="hljs-keyword">async</span> <span class="hljs-keyword">def</span> <span class="hljs-title function_">add</span>(<span class="hljs-params">ctx: Context, a: <span class="hljs-built_in">int</span>, b: <span class="hljs-built_in">int</span></span>) -&gt; <span class="hljs-built_in">int</span>:
    <span class="hljs-string">&quot;&quot;&quot;Add two numbers.&quot;&quot;&quot;</span>
    <span class="hljs-comment"># update our count</span>
    cur_state = <span class="hljs-keyword">await</span> ctx.get(<span class="hljs-string">&quot;state&quot;</span>)
    cur_state[<span class="hljs-string">&quot;num_fn_calls&quot;</span>] += <span class="hljs-number">1</span>
    <span class="hljs-keyword">await</span> ctx.<span class="hljs-built_in">set</span>(<span class="hljs-string">&quot;state&quot;</span>, cur_state)

    <span class="hljs-keyword">return</span> a + b

<span class="hljs-keyword">async</span> <span class="hljs-keyword">def</span> <span class="hljs-title function_">multiply</span>(<span class="hljs-params">ctx: Context, a: <span class="hljs-built_in">int</span>, b: <span class="hljs-built_in">int</span></span>) -&gt; <span class="hljs-built_in">int</span>:
    <span class="hljs-string">&quot;&quot;&quot;Multiply two numbers.&quot;&quot;&quot;</span>
    <span class="hljs-comment"># update our count</span>
    cur_state = <span class="hljs-keyword">await</span> ctx.get(<span class="hljs-string">&quot;state&quot;</span>)
    cur_state[<span class="hljs-string">&quot;num_fn_calls&quot;</span>] += <span class="hljs-number">1</span>
    <span class="hljs-keyword">await</span> ctx.<span class="hljs-built_in">set</span>(<span class="hljs-string">&quot;state&quot;</span>, cur_state)

    <span class="hljs-keyword">return</span> a * b

...

workflow = AgentWorkflow(
    agents=[multiply_agent, addition_agent],
    root_agent=<span class="hljs-string">&quot;multiply_agent&quot;</span>
    initial_state={<span class="hljs-string">&quot;num_fn_calls&quot;</span>: <span class="hljs-number">0</span>},
    state_prompt=<span class="hljs-string">&quot;Current state: {state}. User message: {msg}&quot;</span>,
)

<span class="hljs-comment"># 使用上下文运行工作流程</span>
ctx = Context(workflow)
response = <span class="hljs-keyword">await</span> workflow.run(user_msg=<span class="hljs-string">&quot;Can you add 5 and 3?&quot;</span>, ctx=ctx)

<span class="hljs-comment"># 拉出并检查状态</span>
state = <span class="hljs-keyword">await</span> ctx.get(<span class="hljs-string">&quot;state&quot;</span>)
<span class="hljs-built_in">print</span>(state[<span class="hljs-string">&quot;num_fn_calls&quot;</span>])`,wrap:!1}}),ys=new Ol({props:{source:"https://github.com/huggingface/agents-course/blob/main/units/zh-CN/unit2/llama-index/workflows.mdx"}}),{c(){w=p("meta"),J=n(),d=p("p"),T=n(),o(U.$$.fragment),r=n(),B=p("p"),B.textContent=ml,Cs=n(),_=p("p"),_.innerHTML=Tl,Is=n(),k=p("p"),k.innerHTML=rl,fs=n(),g=p("p"),g.innerHTML=dl,bs=n(),v=p("ul"),v.innerHTML=hl,Bs=n(),V=p("p"),V.innerHTML=Cl,_s=n(),Q=p("p"),Q.textContent=Il,ks=n(),o(E.$$.fragment),gs=n(),o(h.$$.fragment),vs=n(),o(Z.$$.fragment),Vs=n(),C=p("details"),ms=p("summary"),ms.textContent=fl,yl=rs(`
如 [LlamaHub 章节](llama-hub) 介绍的，我们可以通过以下命令安装工作流包：

	`),o($.$$.fragment),Qs=n(),G=p("p"),G.innerHTML=bl,Es=n(),o(x.$$.fragment),Zs=n(),S=p("p"),S.textContent=Bl,$s=n(),o(F.$$.fragment),Gs=n(),W=p("p"),W.innerHTML=_l,xs=n(),o(R.$$.fragment),Ss=n(),A=p("p"),A.textContent=kl,Fs=n(),o(N.$$.fragment),Ws=n(),X=p("p"),X.textContent=gl,Rs=n(),H=p("p"),H.innerHTML=vl,As=n(),o(q.$$.fragment),Ns=n(),o(z.$$.fragment),Xs=n(),Y=p("p"),Y.innerHTML=Vl,Hs=n(),o(L.$$.fragment),qs=n(),P=p("p"),P.innerHTML=Ql,zs=n(),K=p("p"),K.textContent=El,Ys=n(),o(D.$$.fragment),Ls=n(),O=p("p"),O.textContent=Zl,Ps=n(),o(ss.$$.fragment),Ks=n(),ls=p("p"),ls.textContent=$l,Ds=n(),o(I.$$.fragment),Os=n(),ts=p("p"),ts.innerHTML=Gl,sl=n(),o(es.$$.fragment),ll=n(),ns=p("p"),ns.innerHTML=xl,tl=n(),as=p("p"),as.textContent=Sl,el=n(),ps=p("ul"),ps.innerHTML=Fl,nl=n(),Ms=p("p"),Ms.textContent=Wl,al=n(),o(is.$$.fragment),pl=n(),Us=p("p"),Us.textContent=Rl,Ml=n(),Js=p("p"),Js.textContent=Al,il=n(),o(ws.$$.fragment),Ul=n(),os=p("p"),os.textContent=Nl,Jl=n(),cs=p("p"),cs.textContent=Xl,wl=n(),o(ys.$$.fragment),ol=n(),Ts=p("p"),this.h()},l(s){const l=Dl("svelte-u9bgzb",document.head);w=M(l,"META",{name:!0,content:!0}),l.forEach(t),J=a(s),d=M(s,"P",{}),ul(d).forEach(t),T=a(s),c(U.$$.fragment,s),r=a(s),B=M(s,"P",{"data-svelte-h":!0}),i(B)!=="svelte-1zncfn"&&(B.textContent=ml),Cs=a(s),_=M(s,"P",{"data-svelte-h":!0}),i(_)!=="svelte-1phl6o4"&&(_.innerHTML=Tl),Is=a(s),k=M(s,"P",{"data-svelte-h":!0}),i(k)!=="svelte-1fdqx1j"&&(k.innerHTML=rl),fs=a(s),g=M(s,"P",{"data-svelte-h":!0}),i(g)!=="svelte-kcsc97"&&(g.innerHTML=dl),bs=a(s),v=M(s,"UL",{"data-svelte-h":!0}),i(v)!=="svelte-hv8940"&&(v.innerHTML=hl),Bs=a(s),V=M(s,"P",{"data-svelte-h":!0}),i(V)!=="svelte-941b0a"&&(V.innerHTML=Cl),_s=a(s),Q=M(s,"P",{"data-svelte-h":!0}),i(Q)!=="svelte-10dcwra"&&(Q.textContent=Il),ks=a(s),c(E.$$.fragment,s),gs=a(s),c(h.$$.fragment,s),vs=a(s),c(Z.$$.fragment,s),Vs=a(s),C=M(s,"DETAILS",{});var us=ul(C);ms=M(us,"SUMMARY",{"data-svelte-h":!0}),i(ms)!=="svelte-14m3ggn"&&(ms.textContent=fl),yl=ds(us,`
如 [LlamaHub 章节](llama-hub) 介绍的，我们可以通过以下命令安装工作流包：

	`),c($.$$.fragment,us),us.forEach(t),Qs=a(s),G=M(s,"P",{"data-svelte-h":!0}),i(G)!=="svelte-1dxezou"&&(G.innerHTML=bl),Es=a(s),c(x.$$.fragment,s),Zs=a(s),S=M(s,"P",{"data-svelte-h":!0}),i(S)!=="svelte-4urpti"&&(S.textContent=Bl),$s=a(s),c(F.$$.fragment,s),Gs=a(s),W=M(s,"P",{"data-svelte-h":!0}),i(W)!=="svelte-6xydj5"&&(W.innerHTML=_l),xs=a(s),c(R.$$.fragment,s),Ss=a(s),A=M(s,"P",{"data-svelte-h":!0}),i(A)!=="svelte-1aahnbx"&&(A.textContent=kl),Fs=a(s),c(N.$$.fragment,s),Ws=a(s),X=M(s,"P",{"data-svelte-h":!0}),i(X)!=="svelte-1fzqx5n"&&(X.textContent=gl),Rs=a(s),H=M(s,"P",{"data-svelte-h":!0}),i(H)!=="svelte-61qf0g"&&(H.innerHTML=vl),As=a(s),c(q.$$.fragment,s),Ns=a(s),c(z.$$.fragment,s),Xs=a(s),Y=M(s,"P",{"data-svelte-h":!0}),i(Y)!=="svelte-nsfhj0"&&(Y.innerHTML=Vl),Hs=a(s),c(L.$$.fragment,s),qs=a(s),P=M(s,"P",{"data-svelte-h":!0}),i(P)!=="svelte-1fejrbj"&&(P.innerHTML=Ql),zs=a(s),K=M(s,"P",{"data-svelte-h":!0}),i(K)!=="svelte-1g6o0kz"&&(K.textContent=El),Ys=a(s),c(D.$$.fragment,s),Ls=a(s),O=M(s,"P",{"data-svelte-h":!0}),i(O)!=="svelte-18z3r0o"&&(O.textContent=Zl),Ps=a(s),c(ss.$$.fragment,s),Ks=a(s),ls=M(s,"P",{"data-svelte-h":!0}),i(ls)!=="svelte-zlhwuy"&&(ls.textContent=$l),Ds=a(s),c(I.$$.fragment,s),Os=a(s),ts=M(s,"P",{"data-svelte-h":!0}),i(ts)!=="svelte-1f7ur07"&&(ts.innerHTML=Gl),sl=a(s),c(es.$$.fragment,s),ll=a(s),ns=M(s,"P",{"data-svelte-h":!0}),i(ns)!=="svelte-1q9g7so"&&(ns.innerHTML=xl),tl=a(s),as=M(s,"P",{"data-svelte-h":!0}),i(as)!=="svelte-x6am9b"&&(as.textContent=Sl),el=a(s),ps=M(s,"UL",{"data-svelte-h":!0}),i(ps)!=="svelte-1szl21w"&&(ps.innerHTML=Fl),nl=a(s),Ms=M(s,"P",{"data-svelte-h":!0}),i(Ms)!=="svelte-uyi5am"&&(Ms.textContent=Wl),al=a(s),c(is.$$.fragment,s),pl=a(s),Us=M(s,"P",{"data-svelte-h":!0}),i(Us)!=="svelte-kjz8yo"&&(Us.textContent=Rl),Ml=a(s),Js=M(s,"P",{"data-svelte-h":!0}),i(Js)!=="svelte-1kmhjoz"&&(Js.textContent=Al),il=a(s),c(ws.$$.fragment,s),Ul=a(s),os=M(s,"P",{"data-svelte-h":!0}),i(os)!=="svelte-65f1le"&&(os.textContent=Nl),Jl=a(s),cs=M(s,"P",{"data-svelte-h":!0}),i(cs)!=="svelte-xofn8o"&&(cs.textContent=Xl),wl=a(s),c(ys.$$.fragment,s),ol=a(s),Ts=M(s,"P",{}),ul(Ts).forEach(t),this.h()},h(){hs(w,"name","hf:doc:metadata"),hs(w,"content",et)},m(s,l){jl(document.head,w),e(s,J,l),e(s,d,l),e(s,T,l),y(U,s,l),e(s,r,l),e(s,B,l),e(s,Cs,l),e(s,_,l),e(s,Is,l),e(s,k,l),e(s,fs,l),e(s,g,l),e(s,bs,l),e(s,v,l),e(s,Bs,l),e(s,V,l),e(s,_s,l),e(s,Q,l),e(s,ks,l),y(E,s,l),e(s,gs,l),y(h,s,l),e(s,vs,l),y(Z,s,l),e(s,Vs,l),e(s,C,l),jl(C,ms),jl(C,yl),y($,C,null),e(s,Qs,l),e(s,G,l),e(s,Es,l),y(x,s,l),e(s,Zs,l),e(s,S,l),e(s,$s,l),y(F,s,l),e(s,Gs,l),e(s,W,l),e(s,xs,l),y(R,s,l),e(s,Ss,l),e(s,A,l),e(s,Fs,l),y(N,s,l),e(s,Ws,l),e(s,X,l),e(s,Rs,l),e(s,H,l),e(s,As,l),y(q,s,l),e(s,Ns,l),y(z,s,l),e(s,Xs,l),e(s,Y,l),e(s,Hs,l),y(L,s,l),e(s,qs,l),e(s,P,l),e(s,zs,l),e(s,K,l),e(s,Ys,l),y(D,s,l),e(s,Ls,l),e(s,O,l),e(s,Ps,l),y(ss,s,l),e(s,Ks,l),e(s,ls,l),e(s,Ds,l),y(I,s,l),e(s,Os,l),e(s,ts,l),e(s,sl,l),y(es,s,l),e(s,ll,l),e(s,ns,l),e(s,tl,l),e(s,as,l),e(s,el,l),e(s,ps,l),e(s,nl,l),e(s,Ms,l),e(s,al,l),y(is,s,l),e(s,pl,l),e(s,Us,l),e(s,Ml,l),e(s,Js,l),e(s,il,l),y(ws,s,l),e(s,Ul,l),e(s,os,l),e(s,Jl,l),e(s,cs,l),e(s,wl,l),y(ys,s,l),e(s,ol,l),e(s,Ts,l),cl=!0},p(s,[l]){const us={};l&2&&(us.$$scope={dirty:l,ctx:s}),h.$set(us);const Hl={};l&2&&(Hl.$$scope={dirty:l,ctx:s}),I.$set(Hl)},i(s){cl||(u(U.$$.fragment,s),u(E.$$.fragment,s),u(h.$$.fragment,s),u(Z.$$.fragment,s),u($.$$.fragment,s),u(x.$$.fragment,s),u(F.$$.fragment,s),u(R.$$.fragment,s),u(N.$$.fragment,s),u(q.$$.fragment,s),u(z.$$.fragment,s),u(L.$$.fragment,s),u(D.$$.fragment,s),u(ss.$$.fragment,s),u(I.$$.fragment,s),u(es.$$.fragment,s),u(is.$$.fragment,s),u(ws.$$.fragment,s),u(ys.$$.fragment,s),cl=!0)},o(s){j(U.$$.fragment,s),j(E.$$.fragment,s),j(h.$$.fragment,s),j(Z.$$.fragment,s),j($.$$.fragment,s),j(x.$$.fragment,s),j(F.$$.fragment,s),j(R.$$.fragment,s),j(N.$$.fragment,s),j(q.$$.fragment,s),j(z.$$.fragment,s),j(L.$$.fragment,s),j(D.$$.fragment,s),j(ss.$$.fragment,s),j(I.$$.fragment,s),j(es.$$.fragment,s),j(is.$$.fragment,s),j(ws.$$.fragment,s),j(ys.$$.fragment,s),cl=!1},d(s){s&&(t(J),t(d),t(T),t(r),t(B),t(Cs),t(_),t(Is),t(k),t(fs),t(g),t(bs),t(v),t(Bs),t(V),t(_s),t(Q),t(ks),t(gs),t(vs),t(Vs),t(C),t(Qs),t(G),t(Es),t(Zs),t(S),t($s),t(Gs),t(W),t(xs),t(Ss),t(A),t(Fs),t(Ws),t(X),t(Rs),t(H),t(As),t(Ns),t(Xs),t(Y),t(Hs),t(qs),t(P),t(zs),t(K),t(Ys),t(Ls),t(O),t(Ps),t(Ks),t(ls),t(Ds),t(Os),t(ts),t(sl),t(ll),t(ns),t(tl),t(as),t(el),t(ps),t(nl),t(Ms),t(al),t(pl),t(Us),t(Ml),t(Js),t(il),t(Ul),t(os),t(Jl),t(cs),t(wl),t(ol),t(Ts)),t(w),m(U,s),m(E,s),m(h,s),m(Z,s),m($),m(x,s),m(F,s),m(R,s),m(N,s),m(q,s),m(z,s),m(L,s),m(D,s),m(ss,s),m(I,s),m(es,s),m(is,s),m(ws,s),m(ys,s)}}}const et='{"title":"在 LlamaIndex 中创建智能工作流","local":"在-llamaindex-中创建智能工作流","sections":[{"title":"创建工作流","local":"创建工作流","sections":[{"title":"基础工作流创建","local":"基础工作流创建","sections":[],"depth":3},{"title":"连接多个步骤","local":"连接多个步骤","sections":[],"depth":3},{"title":"循环和分支","local":"循环和分支","sections":[],"depth":3},{"title":"绘制工作流程","local":"绘制工作流程","sections":[],"depth":3},{"title":"状态管理","local":"状态管理","sections":[],"depth":3}],"depth":2},{"title":"使用多智能体工作流自动化工作流","local":"使用多智能体工作流自动化工作流","sections":[],"depth":2}],"depth":1}';function nt(js){return Ll(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class wt extends Pl{constructor(w){super(),Kl(this,w,nt,tt,Yl,{})}}export{wt as component};
