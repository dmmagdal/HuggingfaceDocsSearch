import{s as yt,o as wt,n as Ke}from"../chunks/scheduler.6062bdaf.js";import{S as Tt,i as Mt,g as s,s as n,r as m,A as vt,h as d,f as o,c as a,j as ee,u as _,x as f,k as te,y as i,a as r,v as b,d as y,t as w,w as T}from"../chunks/index.4bca734e.js";import{T as xt}from"../chunks/Tip.b9ac1f03.js";import{D as ye}from"../chunks/Docstring.2bed5079.js";import{C as bt}from"../chunks/CodeBlock.cbbddafc.js";import{E as _t}from"../chunks/ExampleCodeBlock.60d0f16b.js";import{H as D,E as Ut}from"../chunks/getInferenceSnippets.8ccbc96a.js";function $t(O){let l,U;return l=new bt({props:{code:"JTVCJTIwJTIwOTYlNUQlMjAlMjAuJTBBJUUyJTk0JTk0JUUyJTk0JTgwJUUyJTk0JTgwJTIwJTVCJTIwMTYwJTVEJTIwJTIwbW9kZWxzLS1qdWxpZW4tYy0tRXNwZXJCRVJUby1zbWFsbCUwQSUyMCUyMCUyMCUyMCVFMiU5NCU5QyVFMiU5NCU4MCVFMiU5NCU4MCUyMCU1QiUyMDE2MCU1RCUyMCUyMGJsb2JzJTBBJTIwJTIwJTIwJTIwJUUyJTk0JTgyJTIwJTIwJTIwJUUyJTk0JTlDJUUyJTk0JTgwJUUyJTk0JTgwJTIwJTVCMzIxTSU1RCUyMCUyMDQwMzQ1MGUyMzRkNjU5NDNhN2RjZjdlMDVhNzcxY2UzYzkyZmFhODRkZDA3ZGI0YWMyMGY1OTIwMzdhMWU0YmQlMEElMjAlMjAlMjAlMjAlRTIlOTQlODIlMjAlMjAlMjAlRTIlOTQlOUMlRTIlOTQlODAlRTIlOTQlODAlMjAlNUIlMjAzOTglNUQlMjAlMjA3Y2IxOGRjOWJhZmJmY2Y3NDYyOWE0Yjc2MGFmMWIxNjA5NTdhODNlJTBBJTIwJTIwJTIwJTIwJUUyJTk0JTgyJTIwJTIwJTIwJUUyJTk0JTk0JUUyJTk0JTgwJUUyJTk0JTgwJTIwJTVCMS40SyU1RCUyMCUyMGQ3ZWRmNmJkMmE2ODFmYjAxNzVmNzczNTI5OTgzMWVlMWIyMmI4MTIlMEElMjAlMjAlMjAlMjAlRTIlOTQlOUMlRTIlOTQlODAlRTIlOTQlODAlMjAlNUIlMjAlMjA5NiU1RCUyMCUyMHJlZnMlMEElMjAlMjAlMjAlMjAlRTIlOTQlODIlMjAlMjAlMjAlRTIlOTQlOTQlRTIlOTQlODAlRTIlOTQlODAlMjAlNUIlMjAlMjA0MCU1RCUyMCUyMG1haW4lMEElMjAlMjAlMjAlMjAlRTIlOTQlOTQlRTIlOTQlODAlRTIlOTQlODAlMjAlNUIlMjAxMjglNUQlMjAlMjBzbmFwc2hvdHMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlRTIlOTQlOUMlRTIlOTQlODAlRTIlOTQlODAlMjAlNUIlMjAxMjglNUQlMjAlMjAyNDM5ZjYwZWYzM2EwZDQ2ZDg1ZGE1MDAxZDUyYWVkYTViMDBjZTlmJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJUUyJTk0JTgyJTIwJTIwJTIwJUUyJTk0JTlDJUUyJTk0JTgwJUUyJTk0JTgwJTIwJTVCJTIwJTIwNTIlNUQlMjAlMjBSRUFETUUubWQlMjAtJTNFJTIwLi4lMkYuLiUyRmJsb2JzJTJGZDdlZGY2YmQyYTY4MWZiMDE3NWY3NzM1Mjk5ODMxZWUxYjIyYjgxMiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCVFMiU5NCU4MiUyMCUyMCUyMCVFMiU5NCU5NCVFMiU5NCU4MCVFMiU5NCU4MCUyMCU1QiUyMCUyMDc2JTVEJTIwJTIwcHl0b3JjaF9tb2RlbC5iaW4lMjAtJTNFJTIwLi4lMkYuLiUyRmJsb2JzJTJGNDAzNDUwZTIzNGQ2NTk0M2E3ZGNmN2UwNWE3NzFjZTNjOTJmYWE4NGRkMDdkYjRhYzIwZjU5MjAzN2ExZTRiZCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCVFMiU5NCU5NCVFMiU5NCU4MCVFMiU5NCU4MCUyMCU1QiUyMDEyOCU1RCUyMCUyMGJiYzc3YzgxMzJhZjFjYzVjZjY3OGRhM2YxZGRmMmRlNDM2MDZkNDglMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlRTIlOTQlOUMlRTIlOTQlODAlRTIlOTQlODAlMjAlNUIlMjAlMjA1MiU1RCUyMCUyMFJFQURNRS5tZCUyMC0lM0UlMjAuLiUyRi4uJTJGYmxvYnMlMkY3Y2IxOGRjOWJhZmJmY2Y3NDYyOWE0Yjc2MGFmMWIxNjA5NTdhODNlJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJUUyJTk0JTk0JUUyJTk0JTgwJUUyJTk0JTgwJTIwJTVCJTIwJTIwNzYlNUQlMjAlMjBweXRvcmNoX21vZGVsLmJpbiUyMC0lM0UlMjAuLiUyRi4uJTJGYmxvYnMlMkY0MDM0NTBlMjM0ZDY1OTQzYTdkY2Y3ZTA1YTc3MWNlM2M5MmZhYTg0ZGQwN2RiNGFjMjBmNTkyMDM3YTFlNGJk",highlighted:`<span class="hljs-selector-attr">[  96]</span>  .
└── <span class="hljs-selector-attr">[ 160]</span>  models<span class="hljs-attr">--julien-c--EsperBERTo-small</span>
    ├── <span class="hljs-selector-attr">[ 160]</span>  blobs
    │   ├── <span class="hljs-selector-attr">[321M]</span>  <span class="hljs-number">403450</span>e234d65943a7dcf7e05a771ce3c92faa84dd07db4ac20f592037a1e4bd
    │   ├── <span class="hljs-selector-attr">[ 398]</span>  <span class="hljs-number">7</span>cb18dc9bafbfcf74629a4b760af1b160957a83e
    │   └── <span class="hljs-selector-attr">[1.4K]</span>  d7edf6bd2a681fb0175f7735299831ee1b22b812
    ├── <span class="hljs-selector-attr">[  96]</span>  refs
    │   └── <span class="hljs-selector-attr">[  40]</span>  <span class="hljs-selector-tag">main</span>
    └── <span class="hljs-selector-attr">[ 128]</span>  snapshots
        ├── <span class="hljs-selector-attr">[ 128]</span>  <span class="hljs-number">2439</span>f60ef33a0d46d85da5001d52aeda5b00ce9f
        │   ├── <span class="hljs-selector-attr">[  52]</span>  README<span class="hljs-selector-class">.md</span> -&gt; ../../blobs/d7edf6bd2a681fb0175f7735299831ee1b22b812
        │   └── <span class="hljs-selector-attr">[  76]</span>  pytorch_model<span class="hljs-selector-class">.bin</span> -&gt; ../../blobs/<span class="hljs-number">403450</span>e234d65943a7dcf7e05a771ce3c92faa84dd07db4ac20f592037a1e4bd
        └── <span class="hljs-selector-attr">[ 128]</span>  bbc77c8132af1cc5cf678da3f1ddf2de43606d48
            ├── <span class="hljs-selector-attr">[  52]</span>  README<span class="hljs-selector-class">.md</span> -&gt; ../../blobs/<span class="hljs-number">7</span>cb18dc9bafbfcf74629a4b760af1b160957a83e
            └── <span class="hljs-selector-attr">[  76]</span>  pytorch_model<span class="hljs-selector-class">.bin</span> -&gt; ../../blobs/<span class="hljs-number">403450</span>e234d65943a7dcf7e05a771ce3c92faa84dd07db4ac20f592037a1e4bd`,wrap:!1}}),{c(){m(l.$$.fragment)},l(c){_(l.$$.fragment,c)},m(c,p){b(l,c,p),U=!0},p:Ke,i(c){U||(y(l.$$.fragment,c),U=!0)},o(c){w(l.$$.fragment,c),U=!1},d(c){T(l,c)}}}function Jt(O){let l,U="Example:",c,p,$;return p=new bt({props:{code:"ZnJvbSUyMGh1Z2dpbmdmYWNlX2h1YiUyMGltcG9ydCUyMGhmX2h1Yl91cmwlMEElMEFoZl9odWJfdXJsKCUwQSUyMCUyMCUyMCUyMHJlcG9faWQlM0QlMjJqdWxpZW4tYyUyRkVzcGVyQkVSVG8tc21hbGwlMjIlMkMlMjBmaWxlbmFtZSUzRCUyMnB5dG9yY2hfbW9kZWwuYmluJTIyJTBBKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">from</span> huggingface_hub <span class="hljs-keyword">import</span> hf_hub_url

<span class="hljs-meta">&gt;&gt;&gt; </span>hf_hub_url(
<span class="hljs-meta">... </span>    repo_id=<span class="hljs-string">&quot;julien-c/EsperBERTo-small&quot;</span>, filename=<span class="hljs-string">&quot;pytorch_model.bin&quot;</span>
<span class="hljs-meta">... </span>)
<span class="hljs-string">&#x27;https://huggingface.co/julien-c/EsperBERTo-small/resolve/main/pytorch_model.bin&#x27;</span>`,wrap:!1}}),{c(){l=s("p"),l.textContent=U,c=n(),m(p.$$.fragment)},l(g){l=d(g,"P",{"data-svelte-h":!0}),f(l)!=="svelte-11lpom8"&&(l.textContent=U),c=a(g),_(p.$$.fragment,g)},m(g,M){r(g,l,M),r(g,c,M),b(p,g,M),$=!0},p:Ke,i(g){$||(y(p.$$.fragment,g),$=!0)},o(g){w(p.$$.fragment,g),$=!1},d(g){g&&(o(l),o(c)),T(p,g)}}}function Nt(O){let l,U="Notes:",c,p,$=`Cloudfront is replicated over the globe so downloads are way faster for
the end user (and it also lowers our bandwidth costs).`,g,M,L=`Cloudfront aggressively caches files by default (default TTL is 24
hours), however this is not an issue here because we implement a
git-based versioning system on huggingface.co, which means that we store
the files on S3/Cloudfront in a content-addressable way (i.e., the file
name is its hash). Using content-addressable filenames means cache can’t
ever be stale.`,C,I,u=`In terms of client-side caching from this library, we base our caching
on the objects’ entity tag (<code>ETag</code>), which is an identifier of a
specific version of a resource [1]_. An object’s ETag is: its git-sha1
if stored in git, or its sha256 if stored in git-lfs.`;return{c(){l=s("p"),l.textContent=U,c=n(),p=s("p"),p.textContent=$,g=n(),M=s("p"),M.textContent=L,C=n(),I=s("p"),I.innerHTML=u},l(h){l=d(h,"P",{"data-svelte-h":!0}),f(l)!=="svelte-1biq3pv"&&(l.textContent=U),c=a(h),p=d(h,"P",{"data-svelte-h":!0}),f(p)!=="svelte-1jvra57"&&(p.textContent=$),g=a(h),M=d(h,"P",{"data-svelte-h":!0}),f(M)!=="svelte-1937cx5"&&(M.textContent=L),C=a(h),I=d(h,"P",{"data-svelte-h":!0}),f(I)!=="svelte-9bitld"&&(I.innerHTML=u)},m(h,E){r(h,l,E),r(h,c,E),r(h,p,E),r(h,g,E),r(h,M,E),r(h,C,E),r(h,I,E)},p:Ke,d(h){h&&(o(l),o(c),o(p),o(g),o(M),o(C),o(I))}}}function jt(O){let l,U,c,p,$,g,M,L,C,I,u,h,E,oe,et="Download a given file if it’s not already present in the local cache.",Oe,ne,tt="The new cache file layout looks like this:",Fe,ae,ot=`<li>The cache directory contains one subfolder per repo_id (namespaced by repo type)</li> <li>inside each repo folder:<ul><li>refs is a list of the latest known revision =&gt; commit_hash pairs</li> <li>blobs contains the actual file blobs (identified by their git-sha or sha256, depending on
whether they’re LFS files or not)</li> <li>snapshots contains one subfolder per commit, each “commit” contains the subset of the files
that have been resolved at that particular commit. Each filename is a symlink to the blob
at that particular commit.</li></ul></li>`,Re,F,Ye,re,nt=`If <code>local_dir</code> is provided, the file structure from the repo will be replicated in this location. When using this
option, the <code>cache_dir</code> will not be used and a <code>.cache/huggingface/</code> folder will be created at the root of <code>local_dir</code>
to store some metadata related to the downloaded files. While this mechanism is not as robust as the main
cache-system, it’s optimized for regularly pulling the latest version of a repository.`,we,z,Te,v,q,Le,ie,at="Construct the URL of a file from the given information.",ze,le,rt=`The resolved address can either be a huggingface.co-hosted url, or a link to
Cloudfront (a Content Delivery Network, or CDN) for large files which are
more than a few MBs.`,qe,R,He,Y,Qe,se,it="References:",We,de,lt='<li>[1] <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag" rel="nofollow">https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag</a></li>',Me,H,ve,J,Q,Ze,ce,st="Download repo files.",Ge,he,dt=`Download a whole snapshot of a repo’s files at the specified revision. This is useful when you want all files from
a repo, because you don’t know which ones you will need a priori. All files are nested inside a folder in order
to keep their actual filename relative to that folder. You can also filter which files to download using
<code>allow_patterns</code> and <code>ignore_patterns</code>.`,Ve,ge,ct=`If <code>local_dir</code> is provided, the file structure from the repo will be replicated in this location. When using this
option, the <code>cache_dir</code> will not be used and a <code>.cache/huggingface/</code> folder will be created at the root of <code>local_dir</code>
to store some metadata related to the downloaded files. While this mechanism is not as robust as the main
cache-system, it’s optimized for regularly pulling the latest version of a repository.`,Pe,pe,ht=`An alternative would be to clone the repo but this requires git and git-lfs to be installed and properly
configured. It is also not possible to filter which files to download when cloning a repository using git.`,xe,W,Ue,Z,$e,A,G,Se,fe,gt="Fetch metadata of a file versioned on the Hub for a given url.",Je,V,Ne,k,P,Be,ue,pt="Data structure containing information about a file versioned on the Hub.",Xe,me,ft='Returned by <a href="/docs/huggingface_hub/main/en/package_reference/file_download#huggingface_hub.get_hf_file_metadata">get_hf_file_metadata()</a> based on a URL.',je,S,Ce,B,ut=`The methods displayed above are designed to work with a caching system that prevents
re-downloading files. The caching system was updated in v0.8.0 to become the central
cache-system shared across libraries that depend on the Hub.`,Ie,X,mt=`Read the <a href="../guides/manage-cache">cache-system guide</a> for a detailed presentation of caching at
at HF.`,Ee,K,ke,be,Ae;return $=new D({props:{title:"Downloading files",local:"downloading-files",headingTag:"h1"}}),M=new D({props:{title:"Download a single file",local:"download-a-single-file",headingTag:"h2"}}),C=new D({props:{title:"hf_hub_download",local:"huggingface_hub.hf_hub_download",headingTag:"h3"}}),h=new ye({props:{name:"huggingface_hub.hf_hub_download",anchor:"huggingface_hub.hf_hub_download",parameters:[{name:"repo_id",val:": str"},{name:"filename",val:": str"},{name:"subfolder",val:": typing.Optional[str] = None"},{name:"repo_type",val:": typing.Optional[str] = None"},{name:"revision",val:": typing.Optional[str] = None"},{name:"library_name",val:": typing.Optional[str] = None"},{name:"library_version",val:": typing.Optional[str] = None"},{name:"cache_dir",val:": typing.Union[str, pathlib.Path, NoneType] = None"},{name:"local_dir",val:": typing.Union[str, pathlib.Path, NoneType] = None"},{name:"user_agent",val:": typing.Union[typing.Dict, str, NoneType] = None"},{name:"force_download",val:": bool = False"},{name:"proxies",val:": typing.Optional[typing.Dict] = None"},{name:"etag_timeout",val:": float = 10"},{name:"token",val:": typing.Union[bool, str, NoneType] = None"},{name:"local_files_only",val:": bool = False"},{name:"headers",val:": typing.Optional[typing.Dict[str, str]] = None"},{name:"endpoint",val:": typing.Optional[str] = None"},{name:"resume_download",val:": typing.Optional[bool] = None"},{name:"force_filename",val:": typing.Optional[str] = None"},{name:"local_dir_use_symlinks",val:": typing.Union[bool, typing.Literal['auto']] = 'auto'"}],parametersDescription:[{anchor:"huggingface_hub.hf_hub_download.repo_id",description:`<strong>repo_id</strong> (<code>str</code>) &#x2014;
A user or an organization name and a repo name separated by a <code>/</code>.`,name:"repo_id"},{anchor:"huggingface_hub.hf_hub_download.filename",description:`<strong>filename</strong> (<code>str</code>) &#x2014;
The name of the file in the repo.`,name:"filename"},{anchor:"huggingface_hub.hf_hub_download.subfolder",description:`<strong>subfolder</strong> (<code>str</code>, <em>optional</em>) &#x2014;
An optional value corresponding to a folder inside the model repo.`,name:"subfolder"},{anchor:"huggingface_hub.hf_hub_download.repo_type",description:`<strong>repo_type</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Set to <code>&quot;dataset&quot;</code> or <code>&quot;space&quot;</code> if downloading from a dataset or space,
<code>None</code> or <code>&quot;model&quot;</code> if downloading from a model. Default is <code>None</code>.`,name:"repo_type"},{anchor:"huggingface_hub.hf_hub_download.revision",description:`<strong>revision</strong> (<code>str</code>, <em>optional</em>) &#x2014;
An optional Git revision id which can be a branch name, a tag, or a
commit hash.`,name:"revision"},{anchor:"huggingface_hub.hf_hub_download.library_name",description:`<strong>library_name</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The name of the library to which the object corresponds.`,name:"library_name"},{anchor:"huggingface_hub.hf_hub_download.library_version",description:`<strong>library_version</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The version of the library.`,name:"library_version"},{anchor:"huggingface_hub.hf_hub_download.cache_dir",description:`<strong>cache_dir</strong> (<code>str</code>, <code>Path</code>, <em>optional</em>) &#x2014;
Path to the folder where cached files are stored.`,name:"cache_dir"},{anchor:"huggingface_hub.hf_hub_download.local_dir",description:`<strong>local_dir</strong> (<code>str</code> or <code>Path</code>, <em>optional</em>) &#x2014;
If provided, the downloaded file will be placed under this directory.`,name:"local_dir"},{anchor:"huggingface_hub.hf_hub_download.user_agent",description:`<strong>user_agent</strong> (<code>dict</code>, <code>str</code>, <em>optional</em>) &#x2014;
The user-agent info in the form of a dictionary or a string.`,name:"user_agent"},{anchor:"huggingface_hub.hf_hub_download.force_download",description:`<strong>force_download</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether the file should be downloaded even if it already exists in
the local cache.`,name:"force_download"},{anchor:"huggingface_hub.hf_hub_download.proxies",description:`<strong>proxies</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Dictionary mapping protocol to the URL of the proxy passed to
<code>requests.request</code>.`,name:"proxies"},{anchor:"huggingface_hub.hf_hub_download.etag_timeout",description:`<strong>etag_timeout</strong> (<code>float</code>, <em>optional</em>, defaults to <code>10</code>) &#x2014;
When fetching ETag, how many seconds to wait for the server to send
data before giving up which is passed to <code>requests.request</code>.`,name:"etag_timeout"},{anchor:"huggingface_hub.hf_hub_download.token",description:`<strong>token</strong> (<code>str</code>, <code>bool</code>, <em>optional</em>) &#x2014;
A token to be used for the download.<ul>
<li>If <code>True</code>, the token is read from the HuggingFace config
folder.</li>
<li>If a string, it&#x2019;s used as the authentication token.</li>
</ul>`,name:"token"},{anchor:"huggingface_hub.hf_hub_download.local_files_only",description:`<strong>local_files_only</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
If <code>True</code>, avoid downloading the file and return the path to the
local cached file if it exists.`,name:"local_files_only"},{anchor:"huggingface_hub.hf_hub_download.headers",description:`<strong>headers</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Additional headers to be sent with the request.`,name:"headers"}],source:"https://github.com/huggingface/huggingface_hub/blob/main/src/huggingface_hub/file_download.py#L809",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>Local path of file or if networking is off, last version of file cached on disk.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>str</code></p>
`,raiseDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<ul>
<li><a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.RepositoryNotFoundError"
>RepositoryNotFoundError</a> —
If the repository to download from cannot be found. This may be because it doesn’t exist,
or because it is set to <code>private</code> and you do not have access.</li>
<li><a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.RevisionNotFoundError"
>RevisionNotFoundError</a> —
If the revision to download from cannot be found.</li>
<li><a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.EntryNotFoundError"
>EntryNotFoundError</a> —
If the file to download cannot be found.</li>
<li><a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.LocalEntryNotFoundError"
>LocalEntryNotFoundError</a> —
If network is disabled or unavailable and file is not found in cache.</li>
<li><a
  href="https://docs.python.org/3/library/exceptions.html#EnvironmentError"
  rel="nofollow"
><code>EnvironmentError</code></a> —
If <code>token=True</code> but the token cannot be found.</li>
<li><a
  href="https://docs.python.org/3/library/exceptions.html#OSError"
  rel="nofollow"
><code>OSError</code></a> —
If ETag cannot be determined.</li>
<li><a
  href="https://docs.python.org/3/library/exceptions.html#ValueError"
  rel="nofollow"
><code>ValueError</code></a> —
If some parameter value is invalid.</li>
</ul>
`,raiseType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.RepositoryNotFoundError"
>RepositoryNotFoundError</a> or <a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.RevisionNotFoundError"
>RevisionNotFoundError</a> or <a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.EntryNotFoundError"
>EntryNotFoundError</a> or <a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.LocalEntryNotFoundError"
>LocalEntryNotFoundError</a> or <code>EnvironmentError</code> or <code>OSError</code> or <code>ValueError</code></p>
`}}),F=new _t({props:{anchor:"huggingface_hub.hf_hub_download.example",$$slots:{default:[$t]},$$scope:{ctx:O}}}),z=new D({props:{title:"hf_hub_url",local:"huggingface_hub.hf_hub_url",headingTag:"h3"}}),q=new ye({props:{name:"huggingface_hub.hf_hub_url",anchor:"huggingface_hub.hf_hub_url",parameters:[{name:"repo_id",val:": str"},{name:"filename",val:": str"},{name:"subfolder",val:": typing.Optional[str] = None"},{name:"repo_type",val:": typing.Optional[str] = None"},{name:"revision",val:": typing.Optional[str] = None"},{name:"endpoint",val:": typing.Optional[str] = None"}],parametersDescription:[{anchor:"huggingface_hub.hf_hub_url.repo_id",description:`<strong>repo_id</strong> (<code>str</code>) &#x2014;
A namespace (user or an organization) name and a repo name separated
by a <code>/</code>.`,name:"repo_id"},{anchor:"huggingface_hub.hf_hub_url.filename",description:`<strong>filename</strong> (<code>str</code>) &#x2014;
The name of the file in the repo.`,name:"filename"},{anchor:"huggingface_hub.hf_hub_url.subfolder",description:`<strong>subfolder</strong> (<code>str</code>, <em>optional</em>) &#x2014;
An optional value corresponding to a folder inside the repo.`,name:"subfolder"},{anchor:"huggingface_hub.hf_hub_url.repo_type",description:`<strong>repo_type</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Set to <code>&quot;dataset&quot;</code> or <code>&quot;space&quot;</code> if downloading from a dataset or space,
<code>None</code> or <code>&quot;model&quot;</code> if downloading from a model. Default is <code>None</code>.`,name:"repo_type"},{anchor:"huggingface_hub.hf_hub_url.revision",description:`<strong>revision</strong> (<code>str</code>, <em>optional</em>) &#x2014;
An optional Git revision id which can be a branch name, a tag, or a
commit hash.`,name:"revision"}],source:"https://github.com/huggingface/huggingface_hub/blob/main/src/huggingface_hub/file_download.py#L175"}}),R=new _t({props:{anchor:"huggingface_hub.hf_hub_url.example",$$slots:{default:[Jt]},$$scope:{ctx:O}}}),Y=new xt({props:{$$slots:{default:[Nt]},$$scope:{ctx:O}}}),H=new D({props:{title:"Download a snapshot of the repo",local:"huggingface_hub.snapshot_download",headingTag:"h2"}}),Q=new ye({props:{name:"huggingface_hub.snapshot_download",anchor:"huggingface_hub.snapshot_download",parameters:[{name:"repo_id",val:": str"},{name:"repo_type",val:": typing.Optional[str] = None"},{name:"revision",val:": typing.Optional[str] = None"},{name:"cache_dir",val:": typing.Union[str, pathlib.Path, NoneType] = None"},{name:"local_dir",val:": typing.Union[str, pathlib.Path, NoneType] = None"},{name:"library_name",val:": typing.Optional[str] = None"},{name:"library_version",val:": typing.Optional[str] = None"},{name:"user_agent",val:": typing.Union[typing.Dict, str, NoneType] = None"},{name:"proxies",val:": typing.Optional[typing.Dict] = None"},{name:"etag_timeout",val:": float = 10"},{name:"force_download",val:": bool = False"},{name:"token",val:": typing.Union[bool, str, NoneType] = None"},{name:"local_files_only",val:": bool = False"},{name:"allow_patterns",val:": typing.Union[typing.List[str], str, NoneType] = None"},{name:"ignore_patterns",val:": typing.Union[typing.List[str], str, NoneType] = None"},{name:"max_workers",val:": int = 8"},{name:"tqdm_class",val:": typing.Optional[typing.Type[tqdm.asyncio.tqdm_asyncio]] = None"},{name:"headers",val:": typing.Optional[typing.Dict[str, str]] = None"},{name:"endpoint",val:": typing.Optional[str] = None"},{name:"local_dir_use_symlinks",val:": typing.Union[bool, typing.Literal['auto']] = 'auto'"},{name:"resume_download",val:": typing.Optional[bool] = None"}],parametersDescription:[{anchor:"huggingface_hub.snapshot_download.repo_id",description:`<strong>repo_id</strong> (<code>str</code>) &#x2014;
A user or an organization name and a repo name separated by a <code>/</code>.`,name:"repo_id"},{anchor:"huggingface_hub.snapshot_download.repo_type",description:`<strong>repo_type</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Set to <code>&quot;dataset&quot;</code> or <code>&quot;space&quot;</code> if downloading from a dataset or space,
<code>None</code> or <code>&quot;model&quot;</code> if downloading from a model. Default is <code>None</code>.`,name:"repo_type"},{anchor:"huggingface_hub.snapshot_download.revision",description:`<strong>revision</strong> (<code>str</code>, <em>optional</em>) &#x2014;
An optional Git revision id which can be a branch name, a tag, or a
commit hash.`,name:"revision"},{anchor:"huggingface_hub.snapshot_download.cache_dir",description:`<strong>cache_dir</strong> (<code>str</code>, <code>Path</code>, <em>optional</em>) &#x2014;
Path to the folder where cached files are stored.`,name:"cache_dir"},{anchor:"huggingface_hub.snapshot_download.local_dir",description:`<strong>local_dir</strong> (<code>str</code> or <code>Path</code>, <em>optional</em>) &#x2014;
If provided, the downloaded files will be placed under this directory.`,name:"local_dir"},{anchor:"huggingface_hub.snapshot_download.library_name",description:`<strong>library_name</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The name of the library to which the object corresponds.`,name:"library_name"},{anchor:"huggingface_hub.snapshot_download.library_version",description:`<strong>library_version</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The version of the library.`,name:"library_version"},{anchor:"huggingface_hub.snapshot_download.user_agent",description:`<strong>user_agent</strong> (<code>str</code>, <code>dict</code>, <em>optional</em>) &#x2014;
The user-agent info in the form of a dictionary or a string.`,name:"user_agent"},{anchor:"huggingface_hub.snapshot_download.proxies",description:`<strong>proxies</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Dictionary mapping protocol to the URL of the proxy passed to
<code>requests.request</code>.`,name:"proxies"},{anchor:"huggingface_hub.snapshot_download.etag_timeout",description:`<strong>etag_timeout</strong> (<code>float</code>, <em>optional</em>, defaults to <code>10</code>) &#x2014;
When fetching ETag, how many seconds to wait for the server to send
data before giving up which is passed to <code>requests.request</code>.`,name:"etag_timeout"},{anchor:"huggingface_hub.snapshot_download.force_download",description:`<strong>force_download</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
Whether the file should be downloaded even if it already exists in the local cache.`,name:"force_download"},{anchor:"huggingface_hub.snapshot_download.token",description:`<strong>token</strong> (<code>str</code>, <code>bool</code>, <em>optional</em>) &#x2014;
A token to be used for the download.<ul>
<li>If <code>True</code>, the token is read from the HuggingFace config
folder.</li>
<li>If a string, it&#x2019;s used as the authentication token.</li>
</ul>`,name:"token"},{anchor:"huggingface_hub.snapshot_download.headers",description:`<strong>headers</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Additional headers to include in the request. Those headers take precedence over the others.`,name:"headers"},{anchor:"huggingface_hub.snapshot_download.local_files_only",description:`<strong>local_files_only</strong> (<code>bool</code>, <em>optional</em>, defaults to <code>False</code>) &#x2014;
If <code>True</code>, avoid downloading the file and return the path to the
local cached file if it exists.`,name:"local_files_only"},{anchor:"huggingface_hub.snapshot_download.allow_patterns",description:`<strong>allow_patterns</strong> (<code>List[str]</code> or <code>str</code>, <em>optional</em>) &#x2014;
If provided, only files matching at least one pattern are downloaded.`,name:"allow_patterns"},{anchor:"huggingface_hub.snapshot_download.ignore_patterns",description:`<strong>ignore_patterns</strong> (<code>List[str]</code> or <code>str</code>, <em>optional</em>) &#x2014;
If provided, files matching any of the patterns are not downloaded.`,name:"ignore_patterns"},{anchor:"huggingface_hub.snapshot_download.max_workers",description:`<strong>max_workers</strong> (<code>int</code>, <em>optional</em>) &#x2014;
Number of concurrent threads to download files (1 thread = 1 file download).
Defaults to 8.`,name:"max_workers"},{anchor:"huggingface_hub.snapshot_download.tqdm_class",description:`<strong>tqdm_class</strong> (<code>tqdm</code>, <em>optional</em>) &#x2014;
If provided, overwrites the default behavior for the progress bar. Passed
argument must inherit from <code>tqdm.auto.tqdm</code> or at least mimic its behavior.
Note that the <code>tqdm_class</code> is not passed to each individual download.
Defaults to the custom HF progress bar that can be disabled by setting
<code>HF_HUB_DISABLE_PROGRESS_BARS</code> environment variable.`,name:"tqdm_class"}],source:"https://github.com/huggingface/huggingface_hub/blob/main/src/huggingface_hub/_snapshot_download.py#L28",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>folder path of the repo snapshot.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>str</code></p>
`,raiseDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<ul>
<li><a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.RepositoryNotFoundError"
>RepositoryNotFoundError</a> —
If the repository to download from cannot be found. This may be because it doesn’t exist,
or because it is set to <code>private</code> and you do not have access.</li>
<li><a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.RevisionNotFoundError"
>RevisionNotFoundError</a> —
If the revision to download from cannot be found.</li>
<li><a
  href="https://docs.python.org/3/library/exceptions.html#EnvironmentError"
  rel="nofollow"
><code>EnvironmentError</code></a> —
If <code>token=True</code> and the token cannot be found.</li>
<li><a
  href="https://docs.python.org/3/library/exceptions.html#OSError"
  rel="nofollow"
><code>OSError</code></a> — if
ETag cannot be determined.</li>
<li><a
  href="https://docs.python.org/3/library/exceptions.html#ValueError"
  rel="nofollow"
><code>ValueError</code></a> —
if some parameter value is invalid.</li>
</ul>
`,raiseType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.RepositoryNotFoundError"
>RepositoryNotFoundError</a> or <a
  href="/docs/huggingface_hub/main/en/package_reference/utilities#huggingface_hub.errors.RevisionNotFoundError"
>RevisionNotFoundError</a> or <code>EnvironmentError</code> or <code>OSError</code> or <code>ValueError</code></p>
`}}),W=new D({props:{title:"Get metadata about a file",local:"get-metadata-about-a-file",headingTag:"h2"}}),Z=new D({props:{title:"get_hf_file_metadata",local:"huggingface_hub.get_hf_file_metadata",headingTag:"h3"}}),G=new ye({props:{name:"huggingface_hub.get_hf_file_metadata",anchor:"huggingface_hub.get_hf_file_metadata",parameters:[{name:"url",val:": str"},{name:"token",val:": typing.Union[bool, str, NoneType] = None"},{name:"proxies",val:": typing.Optional[typing.Dict] = None"},{name:"timeout",val:": typing.Optional[float] = 10"},{name:"library_name",val:": typing.Optional[str] = None"},{name:"library_version",val:": typing.Optional[str] = None"},{name:"user_agent",val:": typing.Union[typing.Dict, str, NoneType] = None"},{name:"headers",val:": typing.Optional[typing.Dict[str, str]] = None"}],parametersDescription:[{anchor:"huggingface_hub.get_hf_file_metadata.url",description:`<strong>url</strong> (<code>str</code>) &#x2014;
File url, for example returned by <a href="/docs/huggingface_hub/main/en/package_reference/file_download#huggingface_hub.hf_hub_url">hf_hub_url()</a>.`,name:"url"},{anchor:"huggingface_hub.get_hf_file_metadata.token",description:`<strong>token</strong> (<code>str</code> or <code>bool</code>, <em>optional</em>) &#x2014;
A token to be used for the download.<ul>
<li>If <code>True</code>, the token is read from the HuggingFace config
folder.</li>
<li>If <code>False</code> or <code>None</code>, no token is provided.</li>
<li>If a string, it&#x2019;s used as the authentication token.</li>
</ul>`,name:"token"},{anchor:"huggingface_hub.get_hf_file_metadata.proxies",description:`<strong>proxies</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Dictionary mapping protocol to the URL of the proxy passed to
<code>requests.request</code>.`,name:"proxies"},{anchor:"huggingface_hub.get_hf_file_metadata.timeout",description:`<strong>timeout</strong> (<code>float</code>, <em>optional</em>, defaults to 10) &#x2014;
How many seconds to wait for the server to send metadata before giving up.`,name:"timeout"},{anchor:"huggingface_hub.get_hf_file_metadata.library_name",description:`<strong>library_name</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The name of the library to which the object corresponds.`,name:"library_name"},{anchor:"huggingface_hub.get_hf_file_metadata.library_version",description:`<strong>library_version</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The version of the library.`,name:"library_version"},{anchor:"huggingface_hub.get_hf_file_metadata.user_agent",description:`<strong>user_agent</strong> (<code>dict</code>, <code>str</code>, <em>optional</em>) &#x2014;
The user-agent info in the form of a dictionary or a string.`,name:"user_agent"},{anchor:"huggingface_hub.get_hf_file_metadata.headers",description:`<strong>headers</strong> (<code>dict</code>, <em>optional</em>) &#x2014;
Additional headers to be sent with the request.`,name:"headers"}],source:"https://github.com/huggingface/huggingface_hub/blob/main/src/huggingface_hub/file_download.py#L1400",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <a
  href="/docs/huggingface_hub/main/en/package_reference/file_download#huggingface_hub.HfFileMetadata"
>HfFileMetadata</a> object containing metadata such as location, etag, size and
commit_hash.</p>
`}}),V=new D({props:{title:"HfFileMetadata",local:"huggingface_hub.HfFileMetadata",headingTag:"h3"}}),P=new ye({props:{name:"class huggingface_hub.HfFileMetadata",anchor:"huggingface_hub.HfFileMetadata",parameters:[{name:"commit_hash",val:": typing.Optional[str]"},{name:"etag",val:": typing.Optional[str]"},{name:"location",val:": str"},{name:"size",val:": typing.Optional[int]"},{name:"xet_file_data",val:": typing.Optional[huggingface_hub.utils._xet.XetFileData]"}],parametersDescription:[{anchor:"huggingface_hub.HfFileMetadata.commit_hash",description:`<strong>commit_hash</strong> (<code>str</code>, <em>optional</em>) &#x2014;
The commit_hash related to the file.`,name:"commit_hash"},{anchor:"huggingface_hub.HfFileMetadata.etag",description:`<strong>etag</strong> (<code>str</code>, <em>optional</em>) &#x2014;
Etag of the file on the server.`,name:"etag"},{anchor:"huggingface_hub.HfFileMetadata.location",description:`<strong>location</strong> (<code>str</code>) &#x2014;
Location where to download the file. Can be a Hub url or not (CDN).`,name:"location"},{anchor:"huggingface_hub.HfFileMetadata.size",description:`<strong>size</strong> (<code>size</code>) &#x2014;
Size of the file. In case of an LFS file, contains the size of the actual
LFS file, not the pointer.`,name:"size"},{anchor:"huggingface_hub.HfFileMetadata.xet_file_data",description:`<strong>xet_file_data</strong> (<code>XetFileData</code>, <em>optional</em>) &#x2014;
Xet information for the file. This is only set if the file is stored using Xet storage.`,name:"xet_file_data"}],source:"https://github.com/huggingface/huggingface_hub/blob/main/src/huggingface_hub/file_download.py#L148"}}),S=new D({props:{title:"Caching",local:"caching",headingTag:"h2"}}),K=new Ut({props:{source:"https://github.com/huggingface/huggingface_hub/blob/main/docs/source/en/package_reference/file_download.md"}}),{c(){l=s("meta"),U=n(),c=s("p"),p=n(),m($.$$.fragment),g=n(),m(M.$$.fragment),L=n(),m(C.$$.fragment),I=n(),u=s("div"),m(h.$$.fragment),E=n(),oe=s("p"),oe.textContent=et,Oe=n(),ne=s("p"),ne.textContent=tt,Fe=n(),ae=s("ul"),ae.innerHTML=ot,Re=n(),m(F.$$.fragment),Ye=n(),re=s("p"),re.innerHTML=nt,we=n(),m(z.$$.fragment),Te=n(),v=s("div"),m(q.$$.fragment),Le=n(),ie=s("p"),ie.textContent=at,ze=n(),le=s("p"),le.textContent=rt,qe=n(),m(R.$$.fragment),He=n(),m(Y.$$.fragment),Qe=n(),se=s("p"),se.textContent=it,We=n(),de=s("ul"),de.innerHTML=lt,Me=n(),m(H.$$.fragment),ve=n(),J=s("div"),m(Q.$$.fragment),Ze=n(),ce=s("p"),ce.textContent=st,Ge=n(),he=s("p"),he.innerHTML=dt,Ve=n(),ge=s("p"),ge.innerHTML=ct,Pe=n(),pe=s("p"),pe.textContent=ht,xe=n(),m(W.$$.fragment),Ue=n(),m(Z.$$.fragment),$e=n(),A=s("div"),m(G.$$.fragment),Se=n(),fe=s("p"),fe.textContent=gt,Je=n(),m(V.$$.fragment),Ne=n(),k=s("div"),m(P.$$.fragment),Be=n(),ue=s("p"),ue.textContent=pt,Xe=n(),me=s("p"),me.innerHTML=ft,je=n(),m(S.$$.fragment),Ce=n(),B=s("p"),B.textContent=ut,Ie=n(),X=s("p"),X.innerHTML=mt,Ee=n(),m(K.$$.fragment),ke=n(),be=s("p"),this.h()},l(e){const t=vt("svelte-u9bgzb",document.head);l=d(t,"META",{name:!0,content:!0}),t.forEach(o),U=a(e),c=d(e,"P",{}),ee(c).forEach(o),p=a(e),_($.$$.fragment,e),g=a(e),_(M.$$.fragment,e),L=a(e),_(C.$$.fragment,e),I=a(e),u=d(e,"DIV",{class:!0});var N=ee(u);_(h.$$.fragment,N),E=a(N),oe=d(N,"P",{"data-svelte-h":!0}),f(oe)!=="svelte-gsbehr"&&(oe.textContent=et),Oe=a(N),ne=d(N,"P",{"data-svelte-h":!0}),f(ne)!=="svelte-1rkm1l0"&&(ne.textContent=tt),Fe=a(N),ae=d(N,"UL",{"data-svelte-h":!0}),f(ae)!=="svelte-1t8qnom"&&(ae.innerHTML=ot),Re=a(N),_(F.$$.fragment,N),Ye=a(N),re=d(N,"P",{"data-svelte-h":!0}),f(re)!=="svelte-mwwpv9"&&(re.innerHTML=nt),N.forEach(o),we=a(e),_(z.$$.fragment,e),Te=a(e),v=d(e,"DIV",{class:!0});var x=ee(v);_(q.$$.fragment,x),Le=a(x),ie=d(x,"P",{"data-svelte-h":!0}),f(ie)!=="svelte-x9zwnh"&&(ie.textContent=at),ze=a(x),le=d(x,"P",{"data-svelte-h":!0}),f(le)!=="svelte-1we5zn8"&&(le.textContent=rt),qe=a(x),_(R.$$.fragment,x),He=a(x),_(Y.$$.fragment,x),Qe=a(x),se=d(x,"P",{"data-svelte-h":!0}),f(se)!=="svelte-k74mug"&&(se.textContent=it),We=a(x),de=d(x,"UL",{"data-svelte-h":!0}),f(de)!=="svelte-1xz5d1h"&&(de.innerHTML=lt),x.forEach(o),Me=a(e),_(H.$$.fragment,e),ve=a(e),J=d(e,"DIV",{class:!0});var j=ee(J);_(Q.$$.fragment,j),Ze=a(j),ce=d(j,"P",{"data-svelte-h":!0}),f(ce)!=="svelte-t9d1pp"&&(ce.textContent=st),Ge=a(j),he=d(j,"P",{"data-svelte-h":!0}),f(he)!=="svelte-xxyl9g"&&(he.innerHTML=dt),Ve=a(j),ge=d(j,"P",{"data-svelte-h":!0}),f(ge)!=="svelte-mwwpv9"&&(ge.innerHTML=ct),Pe=a(j),pe=d(j,"P",{"data-svelte-h":!0}),f(pe)!=="svelte-k7g81c"&&(pe.textContent=ht),j.forEach(o),xe=a(e),_(W.$$.fragment,e),Ue=a(e),_(Z.$$.fragment,e),$e=a(e),A=d(e,"DIV",{class:!0});var De=ee(A);_(G.$$.fragment,De),Se=a(De),fe=d(De,"P",{"data-svelte-h":!0}),f(fe)!=="svelte-13tt6xv"&&(fe.textContent=gt),De.forEach(o),Je=a(e),_(V.$$.fragment,e),Ne=a(e),k=d(e,"DIV",{class:!0});var _e=ee(k);_(P.$$.fragment,_e),Be=a(_e),ue=d(_e,"P",{"data-svelte-h":!0}),f(ue)!=="svelte-gv2215"&&(ue.textContent=pt),Xe=a(_e),me=d(_e,"P",{"data-svelte-h":!0}),f(me)!=="svelte-34tmw1"&&(me.innerHTML=ft),_e.forEach(o),je=a(e),_(S.$$.fragment,e),Ce=a(e),B=d(e,"P",{"data-svelte-h":!0}),f(B)!=="svelte-1jrl9hf"&&(B.textContent=ut),Ie=a(e),X=d(e,"P",{"data-svelte-h":!0}),f(X)!=="svelte-y9fu31"&&(X.innerHTML=mt),Ee=a(e),_(K.$$.fragment,e),ke=a(e),be=d(e,"P",{}),ee(be).forEach(o),this.h()},h(){te(l,"name","hf:doc:metadata"),te(l,"content",Ct),te(u,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),te(v,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),te(J,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),te(A,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),te(k,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,t){i(document.head,l),r(e,U,t),r(e,c,t),r(e,p,t),b($,e,t),r(e,g,t),b(M,e,t),r(e,L,t),b(C,e,t),r(e,I,t),r(e,u,t),b(h,u,null),i(u,E),i(u,oe),i(u,Oe),i(u,ne),i(u,Fe),i(u,ae),i(u,Re),b(F,u,null),i(u,Ye),i(u,re),r(e,we,t),b(z,e,t),r(e,Te,t),r(e,v,t),b(q,v,null),i(v,Le),i(v,ie),i(v,ze),i(v,le),i(v,qe),b(R,v,null),i(v,He),b(Y,v,null),i(v,Qe),i(v,se),i(v,We),i(v,de),r(e,Me,t),b(H,e,t),r(e,ve,t),r(e,J,t),b(Q,J,null),i(J,Ze),i(J,ce),i(J,Ge),i(J,he),i(J,Ve),i(J,ge),i(J,Pe),i(J,pe),r(e,xe,t),b(W,e,t),r(e,Ue,t),b(Z,e,t),r(e,$e,t),r(e,A,t),b(G,A,null),i(A,Se),i(A,fe),r(e,Je,t),b(V,e,t),r(e,Ne,t),r(e,k,t),b(P,k,null),i(k,Be),i(k,ue),i(k,Xe),i(k,me),r(e,je,t),b(S,e,t),r(e,Ce,t),r(e,B,t),r(e,Ie,t),r(e,X,t),r(e,Ee,t),b(K,e,t),r(e,ke,t),r(e,be,t),Ae=!0},p(e,[t]){const N={};t&2&&(N.$$scope={dirty:t,ctx:e}),F.$set(N);const x={};t&2&&(x.$$scope={dirty:t,ctx:e}),R.$set(x);const j={};t&2&&(j.$$scope={dirty:t,ctx:e}),Y.$set(j)},i(e){Ae||(y($.$$.fragment,e),y(M.$$.fragment,e),y(C.$$.fragment,e),y(h.$$.fragment,e),y(F.$$.fragment,e),y(z.$$.fragment,e),y(q.$$.fragment,e),y(R.$$.fragment,e),y(Y.$$.fragment,e),y(H.$$.fragment,e),y(Q.$$.fragment,e),y(W.$$.fragment,e),y(Z.$$.fragment,e),y(G.$$.fragment,e),y(V.$$.fragment,e),y(P.$$.fragment,e),y(S.$$.fragment,e),y(K.$$.fragment,e),Ae=!0)},o(e){w($.$$.fragment,e),w(M.$$.fragment,e),w(C.$$.fragment,e),w(h.$$.fragment,e),w(F.$$.fragment,e),w(z.$$.fragment,e),w(q.$$.fragment,e),w(R.$$.fragment,e),w(Y.$$.fragment,e),w(H.$$.fragment,e),w(Q.$$.fragment,e),w(W.$$.fragment,e),w(Z.$$.fragment,e),w(G.$$.fragment,e),w(V.$$.fragment,e),w(P.$$.fragment,e),w(S.$$.fragment,e),w(K.$$.fragment,e),Ae=!1},d(e){e&&(o(U),o(c),o(p),o(g),o(L),o(I),o(u),o(we),o(Te),o(v),o(Me),o(ve),o(J),o(xe),o(Ue),o($e),o(A),o(Je),o(Ne),o(k),o(je),o(Ce),o(B),o(Ie),o(X),o(Ee),o(ke),o(be)),o(l),T($,e),T(M,e),T(C,e),T(h),T(F),T(z,e),T(q),T(R),T(Y),T(H,e),T(Q),T(W,e),T(Z,e),T(G),T(V,e),T(P),T(S,e),T(K,e)}}}const Ct='{"title":"Downloading files","local":"downloading-files","sections":[{"title":"Download a single file","local":"download-a-single-file","sections":[{"title":"hf_hub_download","local":"huggingface_hub.hf_hub_download","sections":[],"depth":3},{"title":"hf_hub_url","local":"huggingface_hub.hf_hub_url","sections":[],"depth":3}],"depth":2},{"title":"Download a snapshot of the repo","local":"huggingface_hub.snapshot_download","sections":[],"depth":2},{"title":"Get metadata about a file","local":"get-metadata-about-a-file","sections":[{"title":"get_hf_file_metadata","local":"huggingface_hub.get_hf_file_metadata","sections":[],"depth":3},{"title":"HfFileMetadata","local":"huggingface_hub.HfFileMetadata","sections":[],"depth":3}],"depth":2},{"title":"Caching","local":"caching","sections":[],"depth":2}],"depth":1}';function It(O){return wt(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Yt extends Tt{constructor(l){super(),Mt(this,l,It,jt,yt,{})}}export{Yt as component};
