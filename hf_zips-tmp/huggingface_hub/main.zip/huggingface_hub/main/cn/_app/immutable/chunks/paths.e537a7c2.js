var s;const e=((s=globalThis.__sveltekit_1jtc5te)==null?void 0:s.base)??"/docs/huggingface_hub/main/cn";var t;const a=((t=globalThis.__sveltekit_1jtc5te)==null?void 0:t.assets)??e;export{a,e as b};
