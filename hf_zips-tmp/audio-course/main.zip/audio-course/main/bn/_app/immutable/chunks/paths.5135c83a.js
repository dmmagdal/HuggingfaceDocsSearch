var s;const e=((s=globalThis.__sveltekit_1g5lngd)==null?void 0:s.base)??"/docs/audio-course/main/bn";var a;const t=((a=globalThis.__sveltekit_1g5lngd)==null?void 0:a.assets)??e;export{t as a,e as b};
