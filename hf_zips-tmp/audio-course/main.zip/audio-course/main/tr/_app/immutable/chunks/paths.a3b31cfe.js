var s;const e=((s=globalThis.__sveltekit_10k2o37)==null?void 0:s.base)??"/docs/audio-course/main/tr";var a;const o=((a=globalThis.__sveltekit_10k2o37)==null?void 0:a.assets)??e;export{o as a,e as b};
