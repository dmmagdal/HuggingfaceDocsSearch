var s;const e=((s=globalThis.__sveltekit_1gzdvlq)==null?void 0:s.base)??"/docs/audio-course/main/ko";var a;const o=((a=globalThis.__sveltekit_1gzdvlq)==null?void 0:a.assets)??e;export{o as a,e as b};
