import{s as Co,o as yo,n as Sn}from"../chunks/scheduler.9f522b10.js";import{S as qo,i as Do,g as r,s as n,r as m,A as Po,h as s,f as l,c as o,j as v,u as g,k,y as e,a as P,v as f,d as x,t as $,w as _,x as c}from"../chunks/index.192f26f8.js";import{T as Lo}from"../chunks/Tip.9be3a5fa.js";import{D as T}from"../chunks/Docstring.8ad4ab41.js";import{T as Mo,M as An}from"../chunks/TokenizersLanguageContent.585b569a.js";import{H as Eo,E as Io}from"../chunks/getInferenceSnippets.7dffe1fb.js";function Ho(E){let i,u=`This is deprecated and will be removed in a future version.
Please use <code>~tokenizers.Encoding.word_ids</code> instead.`;return{c(){i=r("p"),i.innerHTML=u},l(t){i=s(t,"P",{"data-svelte-h":!0}),c(i)!=="svelte-1tdbt0g"&&(i.innerHTML=u)},m(t,h){P(t,i,h)},p:Sn,d(t){t&&l(i)}}}function Vo(E){let i,u,t,h,w,L,M='The <a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a> represents the output of a <a href="/docs/tokenizers/main/en/api/tokenizer#tokenizers.Tokenizer">Tokenizer</a>.',Q,z,y,B,I,p="The attention mask",b,J,jn=`This indicates to the LM which tokens should be attended to, and which should not.
This is especially important when batching sequences, where we need to applying
padding.`,Pt,H,ae,Lt,ye,Wn="The generated IDs",Mt,qe,On=`The IDs are the main input to a Language Model. They are the token indices,
the numerical representations that a LM understands.`,It,X,de,Ht,De,Nn="The number of sequences represented",Vt,V,ce,Gt,Pe,Rn="The offsets associated to each token",St,Le,Fn=`These offsets let’s you slice the input string, and thus retrieve the original
part that led to producing the corresponding token.`,At,q,pe,jt,Me,Un='A <code>List</code> of overflowing <a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a>',Wt,Ie,Bn=`When using truncation, the <a href="/docs/tokenizers/main/en/api/tokenizer#tokenizers.Tokenizer">Tokenizer</a> takes care of splitting
the output into as many pieces as required to match the specified maximum length.
This field lets you retrieve all the subsequent pieces.`,Ot,He,Jn=`When you use pairs of sequences, the overflowing pieces will contain enough
variations to cover all the possible combinations, while respecting the provided
maximum length.`,Nt,G,le,Rt,Ve,Kn="The generated sequence indices.",Ft,Ge,Qn=`They represent the index of the input sequence associated to each token.
The sequence id can be None if the token is not related to any input sequence,
like for example with special tokens.`,Ut,S,ue,Bt,Se,Xn="The special token mask",Jt,Ae,Yn="This indicates which tokens are special tokens, and which are not.",Kt,A,he,Qt,je,Zn="The generated tokens",Xt,We,eo="They are the string representation of the IDs.",Yt,j,me,Zt,Oe,to="The generated type IDs",en,Ne,no=`Generally used for tasks like sequence classification or question answering,
these tokens let the LM know which input sequence corresponds to each tokens.`,tn,D,ge,nn,Re,oo="The generated word indices.",on,Fe,ro=`They represent the index of the word associated to each token.
When the input is pre-tokenized, they correspond to the ID of the given input label,
otherwise they correspond to the words indices as defined by the
<a href="/docs/tokenizers/main/en/api/pre-tokenizers#tokenizers.pre_tokenizers.PreTokenizer">PreTokenizer</a> that was used.`,rn,Ue,so=`For special tokens and such (any token that was generated from something that was
not part of the input), the output is <code>None</code>`,sn,C,fe,an,Be,io="The generated word indices.",dn,Y,cn,Je,ao=`They represent the index of the word associated to each token.
When the input is pre-tokenized, they correspond to the ID of the given input label,
otherwise they correspond to the words indices as defined by the
<a href="/docs/tokenizers/main/en/api/pre-tokenizers#tokenizers.pre_tokenizers.PreTokenizer">PreTokenizer</a> that was used.`,pn,Ke,co=`For special tokens and such (any token that was generated from something that was
not part of the input), the output is <code>None</code>`,ln,Z,xe,un,Qe,po="Get the token that contains the char at the given position in the input sequence.",hn,ee,$e,mn,Xe,lo="Get the word that contains the char at the given position in the input sequence.",gn,te,_e,fn,Ye,uo='Merge the list of encodings into one final <a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a>',xn,ne,ve,$n,Ze,ho='Pad the <a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a> at the given length',_n,W,ke,vn,et,mo="Set the given sequence index",kn,tt,go=`Set the given sequence index for the whole range of tokens contained in this
<a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a>.`,Tn,O,Te,wn,nt,fo="Get the offsets of the token at the given index.",bn,ot,xo=`The returned offsets are related to the input sequence that contains the
token.  In order to determine in which input sequence it belongs, you
must call <code>~tokenizers.Encoding.token_to_sequence()</code>.`,zn,N,we,En,rt,$o="Get the index of the sequence represented by the given token.",Cn,st,_o=`In the general use case, this method returns <code>0</code> for a single sequence or
the first sequence of a pair, and <code>1</code> for the second sequence of a pair`,yn,R,be,qn,it,vo="Get the index of the word that contains the token in one of the input sequences.",Dn,at,ko=`The returned word index is related to the input sequence that contains
the token.  In order to determine in which input sequence it belongs, you
must call <code>~tokenizers.Encoding.token_to_sequence()</code>.`,Pn,F,ze,Ln,dt,To='Truncate the <a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a> at the given length',Mn,ct,wo=`If this <a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a> represents multiple sequences, when truncating
this information is lost. It will be considered as representing a single sequence.`,In,oe,Ee,Hn,pt,bo="Get the offsets of the word at the given index in one of the input sequences.",Vn,re,Ce,Gn,lt,zo=`Get the encoded tokens corresponding to the word at the given index
in one of the input sequences.`,wt;return i=new Eo({props:{title:"Encoding",local:"tokenizers.Encoding",headingTag:"h2"}}),h=new T({props:{name:"class tokenizers.Encoding",anchor:"tokenizers.Encoding",parameters:""}}),y=new T({props:{name:"attention_mask",anchor:"tokenizers.Encoding.attention_mask",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The attention mask</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`,isGetSetDescriptor:!0}}),ae=new T({props:{name:"ids",anchor:"tokenizers.Encoding.ids",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The list of IDs</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`,isGetSetDescriptor:!0}}),de=new T({props:{name:"n_sequences",anchor:"tokenizers.Encoding.n_sequences",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The number of sequences in this <a
  href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding"
>Encoding</a></p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>int</code></p>
`,isGetSetDescriptor:!0}}),ce=new T({props:{name:"offsets",anchor:"tokenizers.Encoding.offsets",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The list of offsets</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>List</code> of <code>Tuple[int, int]</code></p>
`,isGetSetDescriptor:!0}}),pe=new T({props:{name:"overflowing",anchor:"tokenizers.Encoding.overflowing",parameters:[],isGetSetDescriptor:!0}}),le=new T({props:{name:"sequence_ids",anchor:"tokenizers.Encoding.sequence_ids",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A list of optional sequence index.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>List</code> of <code>Optional[int]</code></p>
`,isGetSetDescriptor:!0}}),ue=new T({props:{name:"special_tokens_mask",anchor:"tokenizers.Encoding.special_tokens_mask",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The special tokens mask</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`,isGetSetDescriptor:!0}}),he=new T({props:{name:"tokens",anchor:"tokenizers.Encoding.tokens",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The list of tokens</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[str]</code></p>
`,isGetSetDescriptor:!0}}),me=new T({props:{name:"type_ids",anchor:"tokenizers.Encoding.type_ids",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The list of type ids</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>List[int]</code></p>
`,isGetSetDescriptor:!0}}),ge=new T({props:{name:"word_ids",anchor:"tokenizers.Encoding.word_ids",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A list of optional word index.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>List</code> of <code>Optional[int]</code></p>
`,isGetSetDescriptor:!0}}),fe=new T({props:{name:"words",anchor:"tokenizers.Encoding.words",parameters:[],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A list of optional word index.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p>A <code>List</code> of <code>Optional[int]</code></p>
`,isGetSetDescriptor:!0}}),Y=new Lo({props:{warning:!0,$$slots:{default:[Ho]},$$scope:{ctx:E}}}),xe=new T({props:{name:"char_to_token",anchor:"tokenizers.Encoding.char_to_token",parameters:[{name:"char_pos",val:""},{name:"sequence_index",val:" = 0"}],parametersDescription:[{anchor:"tokenizers.Encoding.char_to_token.char_pos",description:`<strong>char_pos</strong> (<code>int</code>) &#x2014;
The position of a char in the input string`,name:"char_pos"},{anchor:"tokenizers.Encoding.char_to_token.sequence_index",description:`<strong>sequence_index</strong> (<code>int</code>, defaults to <code>0</code>) &#x2014;
The index of the sequence that contains the target char`,name:"sequence_index"}],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The index of the token that contains this char in the encoded sequence</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>int</code></p>
`}}),$e=new T({props:{name:"char_to_word",anchor:"tokenizers.Encoding.char_to_word",parameters:[{name:"char_pos",val:""},{name:"sequence_index",val:" = 0"}],parametersDescription:[{anchor:"tokenizers.Encoding.char_to_word.char_pos",description:`<strong>char_pos</strong> (<code>int</code>) &#x2014;
The position of a char in the input string`,name:"char_pos"},{anchor:"tokenizers.Encoding.char_to_word.sequence_index",description:`<strong>sequence_index</strong> (<code>int</code>, defaults to <code>0</code>) &#x2014;
The index of the sequence that contains the target char`,name:"sequence_index"}],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The index of the word that contains this char in the input sequence</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>int</code></p>
`}}),_e=new T({props:{name:"merge",anchor:"tokenizers.Encoding.merge",parameters:[{name:"encodings",val:""},{name:"growing_offsets",val:" = True"}],parametersDescription:[{anchor:"tokenizers.Encoding.merge.encodings",description:`<strong>encodings</strong> (A <code>List</code> of <a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a>) &#x2014;
The list of encodings that should be merged in one`,name:"encodings"},{anchor:"tokenizers.Encoding.merge.growing_offsets",description:`<strong>growing_offsets</strong> (<code>bool</code>, defaults to <code>True</code>) &#x2014;
Whether the offsets should accumulate while merging`,name:"growing_offsets"}],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The resulting Encoding</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><a href="/docs/tokenizers/main/en/api/encoding#tokenizers.Encoding">Encoding</a></p>
`}}),ve=new T({props:{name:"pad",anchor:"tokenizers.Encoding.pad",parameters:[{name:"length",val:""},{name:"direction",val:" = 'right'"},{name:"pad_id",val:" = 0"},{name:"pad_type_id",val:" = 0"},{name:"pad_token",val:" = '[PAD]'"}],parametersDescription:[{anchor:"tokenizers.Encoding.pad.length",description:`<strong>length</strong> (<code>int</code>) &#x2014;
The desired length`,name:"length"},{anchor:"tokenizers.Encoding.pad.direction",description:`<strong>direction</strong> &#x2014; (<code>str</code>, defaults to <code>right</code>):
The expected padding direction. Can be either <code>right</code> or <code>left</code>`,name:"direction"},{anchor:"tokenizers.Encoding.pad.pad_id",description:`<strong>pad_id</strong> (<code>int</code>, defaults to <code>0</code>) &#x2014;
The ID corresponding to the padding token`,name:"pad_id"},{anchor:"tokenizers.Encoding.pad.pad_type_id",description:`<strong>pad_type_id</strong> (<code>int</code>, defaults to <code>0</code>) &#x2014;
The type ID corresponding to the padding token`,name:"pad_type_id"},{anchor:"tokenizers.Encoding.pad.pad_token",description:`<strong>pad_token</strong> (<code>str</code>, defaults to <em>[PAD]</em>) &#x2014;
The pad token to use`,name:"pad_token"}]}}),ke=new T({props:{name:"set_sequence_id",anchor:"tokenizers.Encoding.set_sequence_id",parameters:[{name:"sequence_id",val:""}]}}),Te=new T({props:{name:"token_to_chars",anchor:"tokenizers.Encoding.token_to_chars",parameters:[{name:"token_index",val:""}],parametersDescription:[{anchor:"tokenizers.Encoding.token_to_chars.token_index",description:`<strong>token_index</strong> (<code>int</code>) &#x2014;
The index of a token in the encoded sequence.`,name:"token_index"}],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The token offsets <code>(first, last + 1)</code></p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>Tuple[int, int]</code></p>
`}}),we=new T({props:{name:"token_to_sequence",anchor:"tokenizers.Encoding.token_to_sequence",parameters:[{name:"token_index",val:""}],parametersDescription:[{anchor:"tokenizers.Encoding.token_to_sequence.token_index",description:`<strong>token_index</strong> (<code>int</code>) &#x2014;
The index of a token in the encoded sequence.`,name:"token_index"}],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The sequence id of the given token</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>int</code></p>
`}}),be=new T({props:{name:"token_to_word",anchor:"tokenizers.Encoding.token_to_word",parameters:[{name:"token_index",val:""}],parametersDescription:[{anchor:"tokenizers.Encoding.token_to_word.token_index",description:`<strong>token_index</strong> (<code>int</code>) &#x2014;
The index of a token in the encoded sequence.`,name:"token_index"}],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The index of the word in the relevant input sequence.</p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>int</code></p>
`}}),ze=new T({props:{name:"truncate",anchor:"tokenizers.Encoding.truncate",parameters:[{name:"max_length",val:""},{name:"stride",val:" = 0"},{name:"direction",val:" = 'right'"}],parametersDescription:[{anchor:"tokenizers.Encoding.truncate.max_length",description:`<strong>max_length</strong> (<code>int</code>) &#x2014;
The desired length`,name:"max_length"},{anchor:"tokenizers.Encoding.truncate.stride",description:`<strong>stride</strong> (<code>int</code>, defaults to <code>0</code>) &#x2014;
The length of previous content to be included in each overflowing piece`,name:"stride"},{anchor:"tokenizers.Encoding.truncate.direction",description:`<strong>direction</strong> (<code>str</code>, defaults to <code>right</code>) &#x2014;
Truncate direction`,name:"direction"}]}}),Ee=new T({props:{name:"word_to_chars",anchor:"tokenizers.Encoding.word_to_chars",parameters:[{name:"word_index",val:""},{name:"sequence_index",val:" = 0"}],parametersDescription:[{anchor:"tokenizers.Encoding.word_to_chars.word_index",description:`<strong>word_index</strong> (<code>int</code>) &#x2014;
The index of a word in one of the input sequences.`,name:"word_index"},{anchor:"tokenizers.Encoding.word_to_chars.sequence_index",description:`<strong>sequence_index</strong> (<code>int</code>, defaults to <code>0</code>) &#x2014;
The index of the sequence that contains the target word`,name:"sequence_index"}],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The range of characters (span) <code>(first, last + 1)</code></p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>Tuple[int, int]</code></p>
`}}),Ce=new T({props:{name:"word_to_tokens",anchor:"tokenizers.Encoding.word_to_tokens",parameters:[{name:"word_index",val:""},{name:"sequence_index",val:" = 0"}],parametersDescription:[{anchor:"tokenizers.Encoding.word_to_tokens.word_index",description:`<strong>word_index</strong> (<code>int</code>) &#x2014;
The index of a word in one of the input sequences.`,name:"word_index"},{anchor:"tokenizers.Encoding.word_to_tokens.sequence_index",description:`<strong>sequence_index</strong> (<code>int</code>, defaults to <code>0</code>) &#x2014;
The index of the sequence that contains the target word`,name:"sequence_index"}],returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p>The range of tokens: <code>(first, last + 1)</code></p>
`,returnType:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>Tuple[int, int]</code></p>
`}}),{c(){m(i.$$.fragment),u=n(),t=r("div"),m(h.$$.fragment),w=n(),L=r("p"),L.innerHTML=M,Q=n(),z=r("div"),m(y.$$.fragment),B=n(),I=r("p"),I.textContent=p,b=n(),J=r("p"),J.textContent=jn,Pt=n(),H=r("div"),m(ae.$$.fragment),Lt=n(),ye=r("p"),ye.textContent=Wn,Mt=n(),qe=r("p"),qe.textContent=On,It=n(),X=r("div"),m(de.$$.fragment),Ht=n(),De=r("p"),De.textContent=Nn,Vt=n(),V=r("div"),m(ce.$$.fragment),Gt=n(),Pe=r("p"),Pe.textContent=Rn,St=n(),Le=r("p"),Le.textContent=Fn,At=n(),q=r("div"),m(pe.$$.fragment),jt=n(),Me=r("p"),Me.innerHTML=Un,Wt=n(),Ie=r("p"),Ie.innerHTML=Bn,Ot=n(),He=r("p"),He.textContent=Jn,Nt=n(),G=r("div"),m(le.$$.fragment),Rt=n(),Ve=r("p"),Ve.textContent=Kn,Ft=n(),Ge=r("p"),Ge.textContent=Qn,Ut=n(),S=r("div"),m(ue.$$.fragment),Bt=n(),Se=r("p"),Se.textContent=Xn,Jt=n(),Ae=r("p"),Ae.textContent=Yn,Kt=n(),A=r("div"),m(he.$$.fragment),Qt=n(),je=r("p"),je.textContent=Zn,Xt=n(),We=r("p"),We.textContent=eo,Yt=n(),j=r("div"),m(me.$$.fragment),Zt=n(),Oe=r("p"),Oe.textContent=to,en=n(),Ne=r("p"),Ne.textContent=no,tn=n(),D=r("div"),m(ge.$$.fragment),nn=n(),Re=r("p"),Re.textContent=oo,on=n(),Fe=r("p"),Fe.innerHTML=ro,rn=n(),Ue=r("p"),Ue.innerHTML=so,sn=n(),C=r("div"),m(fe.$$.fragment),an=n(),Be=r("p"),Be.textContent=io,dn=n(),m(Y.$$.fragment),cn=n(),Je=r("p"),Je.innerHTML=ao,pn=n(),Ke=r("p"),Ke.innerHTML=co,ln=n(),Z=r("div"),m(xe.$$.fragment),un=n(),Qe=r("p"),Qe.textContent=po,hn=n(),ee=r("div"),m($e.$$.fragment),mn=n(),Xe=r("p"),Xe.textContent=lo,gn=n(),te=r("div"),m(_e.$$.fragment),fn=n(),Ye=r("p"),Ye.innerHTML=uo,xn=n(),ne=r("div"),m(ve.$$.fragment),$n=n(),Ze=r("p"),Ze.innerHTML=ho,_n=n(),W=r("div"),m(ke.$$.fragment),vn=n(),et=r("p"),et.textContent=mo,kn=n(),tt=r("p"),tt.innerHTML=go,Tn=n(),O=r("div"),m(Te.$$.fragment),wn=n(),nt=r("p"),nt.textContent=fo,bn=n(),ot=r("p"),ot.innerHTML=xo,zn=n(),N=r("div"),m(we.$$.fragment),En=n(),rt=r("p"),rt.textContent=$o,Cn=n(),st=r("p"),st.innerHTML=_o,yn=n(),R=r("div"),m(be.$$.fragment),qn=n(),it=r("p"),it.textContent=vo,Dn=n(),at=r("p"),at.innerHTML=ko,Pn=n(),F=r("div"),m(ze.$$.fragment),Ln=n(),dt=r("p"),dt.innerHTML=To,Mn=n(),ct=r("p"),ct.innerHTML=wo,In=n(),oe=r("div"),m(Ee.$$.fragment),Hn=n(),pt=r("p"),pt.textContent=bo,Vn=n(),re=r("div"),m(Ce.$$.fragment),Gn=n(),lt=r("p"),lt.textContent=zo,this.h()},l(a){g(i.$$.fragment,a),u=o(a),t=s(a,"DIV",{class:!0});var d=v(t);g(h.$$.fragment,d),w=o(d),L=s(d,"P",{"data-svelte-h":!0}),c(L)!=="svelte-f2kahe"&&(L.innerHTML=M),Q=o(d),z=s(d,"DIV",{class:!0});var K=v(z);g(y.$$.fragment,K),B=o(K),I=s(K,"P",{"data-svelte-h":!0}),c(I)!=="svelte-nafsul"&&(I.textContent=p),b=o(K),J=s(K,"P",{"data-svelte-h":!0}),c(J)!=="svelte-2cl9fs"&&(J.textContent=jn),K.forEach(l),Pt=o(d),H=s(d,"DIV",{class:!0});var ut=v(H);g(ae.$$.fragment,ut),Lt=o(ut),ye=s(ut,"P",{"data-svelte-h":!0}),c(ye)!=="svelte-13hu4qs"&&(ye.textContent=Wn),Mt=o(ut),qe=s(ut,"P",{"data-svelte-h":!0}),c(qe)!=="svelte-3xucbe"&&(qe.textContent=On),ut.forEach(l),It=o(d),X=s(d,"DIV",{class:!0});var bt=v(X);g(de.$$.fragment,bt),Ht=o(bt),De=s(bt,"P",{"data-svelte-h":!0}),c(De)!=="svelte-128n7bm"&&(De.textContent=Nn),bt.forEach(l),Vt=o(d),V=s(d,"DIV",{class:!0});var ht=v(V);g(ce.$$.fragment,ht),Gt=o(ht),Pe=s(ht,"P",{"data-svelte-h":!0}),c(Pe)!=="svelte-1jccc0s"&&(Pe.textContent=Rn),St=o(ht),Le=s(ht,"P",{"data-svelte-h":!0}),c(Le)!=="svelte-rqkny6"&&(Le.textContent=Fn),ht.forEach(l),At=o(d),q=s(d,"DIV",{class:!0});var se=v(q);g(pe.$$.fragment,se),jt=o(se),Me=s(se,"P",{"data-svelte-h":!0}),c(Me)!=="svelte-105elxx"&&(Me.innerHTML=Un),Wt=o(se),Ie=s(se,"P",{"data-svelte-h":!0}),c(Ie)!=="svelte-c1ygzh"&&(Ie.innerHTML=Bn),Ot=o(se),He=s(se,"P",{"data-svelte-h":!0}),c(He)!=="svelte-77thau"&&(He.textContent=Jn),se.forEach(l),Nt=o(d),G=s(d,"DIV",{class:!0});var mt=v(G);g(le.$$.fragment,mt),Rt=o(mt),Ve=s(mt,"P",{"data-svelte-h":!0}),c(Ve)!=="svelte-olyk0g"&&(Ve.textContent=Kn),Ft=o(mt),Ge=s(mt,"P",{"data-svelte-h":!0}),c(Ge)!=="svelte-1w4yrxp"&&(Ge.textContent=Qn),mt.forEach(l),Ut=o(d),S=s(d,"DIV",{class:!0});var gt=v(S);g(ue.$$.fragment,gt),Bt=o(gt),Se=s(gt,"P",{"data-svelte-h":!0}),c(Se)!=="svelte-1kqf199"&&(Se.textContent=Xn),Jt=o(gt),Ae=s(gt,"P",{"data-svelte-h":!0}),c(Ae)!=="svelte-1vxwt8f"&&(Ae.textContent=Yn),gt.forEach(l),Kt=o(d),A=s(d,"DIV",{class:!0});var ft=v(A);g(he.$$.fragment,ft),Qt=o(ft),je=s(ft,"P",{"data-svelte-h":!0}),c(je)!=="svelte-10jm6aw"&&(je.textContent=Zn),Xt=o(ft),We=s(ft,"P",{"data-svelte-h":!0}),c(We)!=="svelte-d380jx"&&(We.textContent=eo),ft.forEach(l),Yt=o(d),j=s(d,"DIV",{class:!0});var xt=v(j);g(me.$$.fragment,xt),Zt=o(xt),Oe=s(xt,"P",{"data-svelte-h":!0}),c(Oe)!=="svelte-1q6qddw"&&(Oe.textContent=to),en=o(xt),Ne=s(xt,"P",{"data-svelte-h":!0}),c(Ne)!=="svelte-r57n1l"&&(Ne.textContent=no),xt.forEach(l),tn=o(d),D=s(d,"DIV",{class:!0});var ie=v(D);g(ge.$$.fragment,ie),nn=o(ie),Re=s(ie,"P",{"data-svelte-h":!0}),c(Re)!=="svelte-7pgnnj"&&(Re.textContent=oo),on=o(ie),Fe=s(ie,"P",{"data-svelte-h":!0}),c(Fe)!=="svelte-v2kvzn"&&(Fe.innerHTML=ro),rn=o(ie),Ue=s(ie,"P",{"data-svelte-h":!0}),c(Ue)!=="svelte-o7jdc6"&&(Ue.innerHTML=so),ie.forEach(l),sn=o(d),C=s(d,"DIV",{class:!0});var U=v(C);g(fe.$$.fragment,U),an=o(U),Be=s(U,"P",{"data-svelte-h":!0}),c(Be)!=="svelte-7pgnnj"&&(Be.textContent=io),dn=o(U),g(Y.$$.fragment,U),cn=o(U),Je=s(U,"P",{"data-svelte-h":!0}),c(Je)!=="svelte-v2kvzn"&&(Je.innerHTML=ao),pn=o(U),Ke=s(U,"P",{"data-svelte-h":!0}),c(Ke)!=="svelte-o7jdc6"&&(Ke.innerHTML=co),U.forEach(l),ln=o(d),Z=s(d,"DIV",{class:!0});var zt=v(Z);g(xe.$$.fragment,zt),un=o(zt),Qe=s(zt,"P",{"data-svelte-h":!0}),c(Qe)!=="svelte-1ffrb0"&&(Qe.textContent=po),zt.forEach(l),hn=o(d),ee=s(d,"DIV",{class:!0});var Et=v(ee);g($e.$$.fragment,Et),mn=o(Et),Xe=s(Et,"P",{"data-svelte-h":!0}),c(Xe)!=="svelte-1ykgp61"&&(Xe.textContent=lo),Et.forEach(l),gn=o(d),te=s(d,"DIV",{class:!0});var Ct=v(te);g(_e.$$.fragment,Ct),fn=o(Ct),Ye=s(Ct,"P",{"data-svelte-h":!0}),c(Ye)!=="svelte-8vierk"&&(Ye.innerHTML=uo),Ct.forEach(l),xn=o(d),ne=s(d,"DIV",{class:!0});var yt=v(ne);g(ve.$$.fragment,yt),$n=o(yt),Ze=s(yt,"P",{"data-svelte-h":!0}),c(Ze)!=="svelte-1fuz43x"&&(Ze.innerHTML=ho),yt.forEach(l),_n=o(d),W=s(d,"DIV",{class:!0});var $t=v(W);g(ke.$$.fragment,$t),vn=o($t),et=s($t,"P",{"data-svelte-h":!0}),c(et)!=="svelte-1k2furt"&&(et.textContent=mo),kn=o($t),tt=s($t,"P",{"data-svelte-h":!0}),c(tt)!=="svelte-1rri1q2"&&(tt.innerHTML=go),$t.forEach(l),Tn=o(d),O=s(d,"DIV",{class:!0});var _t=v(O);g(Te.$$.fragment,_t),wn=o(_t),nt=s(_t,"P",{"data-svelte-h":!0}),c(nt)!=="svelte-1ax7nb7"&&(nt.textContent=fo),bn=o(_t),ot=s(_t,"P",{"data-svelte-h":!0}),c(ot)!=="svelte-rntbkv"&&(ot.innerHTML=xo),_t.forEach(l),zn=o(d),N=s(d,"DIV",{class:!0});var vt=v(N);g(we.$$.fragment,vt),En=o(vt),rt=s(vt,"P",{"data-svelte-h":!0}),c(rt)!=="svelte-gsdag5"&&(rt.textContent=$o),Cn=o(vt),st=s(vt,"P",{"data-svelte-h":!0}),c(st)!=="svelte-s4bu5e"&&(st.innerHTML=_o),vt.forEach(l),yn=o(d),R=s(d,"DIV",{class:!0});var kt=v(R);g(be.$$.fragment,kt),qn=o(kt),it=s(kt,"P",{"data-svelte-h":!0}),c(it)!=="svelte-r4v2i2"&&(it.textContent=vo),Dn=o(kt),at=s(kt,"P",{"data-svelte-h":!0}),c(at)!=="svelte-10g7eg5"&&(at.innerHTML=ko),kt.forEach(l),Pn=o(d),F=s(d,"DIV",{class:!0});var Tt=v(F);g(ze.$$.fragment,Tt),Ln=o(Tt),dt=s(Tt,"P",{"data-svelte-h":!0}),c(dt)!=="svelte-o5vws2"&&(dt.innerHTML=To),Mn=o(Tt),ct=s(Tt,"P",{"data-svelte-h":!0}),c(ct)!=="svelte-1pqeob"&&(ct.innerHTML=wo),Tt.forEach(l),In=o(d),oe=s(d,"DIV",{class:!0});var qt=v(oe);g(Ee.$$.fragment,qt),Hn=o(qt),pt=s(qt,"P",{"data-svelte-h":!0}),c(pt)!=="svelte-ftg3o5"&&(pt.textContent=bo),qt.forEach(l),Vn=o(d),re=s(d,"DIV",{class:!0});var Dt=v(re);g(Ce.$$.fragment,Dt),Gn=o(Dt),lt=s(Dt,"P",{"data-svelte-h":!0}),c(lt)!=="svelte-17aw0gq"&&(lt.textContent=zo),Dt.forEach(l),d.forEach(l),this.h()},h(){k(z,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(H,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(X,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(V,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(q,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(G,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(S,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(A,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(j,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(D,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(C,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(Z,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(ee,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(te,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(ne,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(W,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(O,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(N,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(R,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(F,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(oe,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(re,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8"),k(t,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(a,d){f(i,a,d),P(a,u,d),P(a,t,d),f(h,t,null),e(t,w),e(t,L),e(t,Q),e(t,z),f(y,z,null),e(z,B),e(z,I),e(z,b),e(z,J),e(t,Pt),e(t,H),f(ae,H,null),e(H,Lt),e(H,ye),e(H,Mt),e(H,qe),e(t,It),e(t,X),f(de,X,null),e(X,Ht),e(X,De),e(t,Vt),e(t,V),f(ce,V,null),e(V,Gt),e(V,Pe),e(V,St),e(V,Le),e(t,At),e(t,q),f(pe,q,null),e(q,jt),e(q,Me),e(q,Wt),e(q,Ie),e(q,Ot),e(q,He),e(t,Nt),e(t,G),f(le,G,null),e(G,Rt),e(G,Ve),e(G,Ft),e(G,Ge),e(t,Ut),e(t,S),f(ue,S,null),e(S,Bt),e(S,Se),e(S,Jt),e(S,Ae),e(t,Kt),e(t,A),f(he,A,null),e(A,Qt),e(A,je),e(A,Xt),e(A,We),e(t,Yt),e(t,j),f(me,j,null),e(j,Zt),e(j,Oe),e(j,en),e(j,Ne),e(t,tn),e(t,D),f(ge,D,null),e(D,nn),e(D,Re),e(D,on),e(D,Fe),e(D,rn),e(D,Ue),e(t,sn),e(t,C),f(fe,C,null),e(C,an),e(C,Be),e(C,dn),f(Y,C,null),e(C,cn),e(C,Je),e(C,pn),e(C,Ke),e(t,ln),e(t,Z),f(xe,Z,null),e(Z,un),e(Z,Qe),e(t,hn),e(t,ee),f($e,ee,null),e(ee,mn),e(ee,Xe),e(t,gn),e(t,te),f(_e,te,null),e(te,fn),e(te,Ye),e(t,xn),e(t,ne),f(ve,ne,null),e(ne,$n),e(ne,Ze),e(t,_n),e(t,W),f(ke,W,null),e(W,vn),e(W,et),e(W,kn),e(W,tt),e(t,Tn),e(t,O),f(Te,O,null),e(O,wn),e(O,nt),e(O,bn),e(O,ot),e(t,zn),e(t,N),f(we,N,null),e(N,En),e(N,rt),e(N,Cn),e(N,st),e(t,yn),e(t,R),f(be,R,null),e(R,qn),e(R,it),e(R,Dn),e(R,at),e(t,Pn),e(t,F),f(ze,F,null),e(F,Ln),e(F,dt),e(F,Mn),e(F,ct),e(t,In),e(t,oe),f(Ee,oe,null),e(oe,Hn),e(oe,pt),e(t,Vn),e(t,re),f(Ce,re,null),e(re,Gn),e(re,lt),wt=!0},p(a,d){const K={};d&2&&(K.$$scope={dirty:d,ctx:a}),Y.$set(K)},i(a){wt||(x(i.$$.fragment,a),x(h.$$.fragment,a),x(y.$$.fragment,a),x(ae.$$.fragment,a),x(de.$$.fragment,a),x(ce.$$.fragment,a),x(pe.$$.fragment,a),x(le.$$.fragment,a),x(ue.$$.fragment,a),x(he.$$.fragment,a),x(me.$$.fragment,a),x(ge.$$.fragment,a),x(fe.$$.fragment,a),x(Y.$$.fragment,a),x(xe.$$.fragment,a),x($e.$$.fragment,a),x(_e.$$.fragment,a),x(ve.$$.fragment,a),x(ke.$$.fragment,a),x(Te.$$.fragment,a),x(we.$$.fragment,a),x(be.$$.fragment,a),x(ze.$$.fragment,a),x(Ee.$$.fragment,a),x(Ce.$$.fragment,a),wt=!0)},o(a){$(i.$$.fragment,a),$(h.$$.fragment,a),$(y.$$.fragment,a),$(ae.$$.fragment,a),$(de.$$.fragment,a),$(ce.$$.fragment,a),$(pe.$$.fragment,a),$(le.$$.fragment,a),$(ue.$$.fragment,a),$(he.$$.fragment,a),$(me.$$.fragment,a),$(ge.$$.fragment,a),$(fe.$$.fragment,a),$(Y.$$.fragment,a),$(xe.$$.fragment,a),$($e.$$.fragment,a),$(_e.$$.fragment,a),$(ve.$$.fragment,a),$(ke.$$.fragment,a),$(Te.$$.fragment,a),$(we.$$.fragment,a),$(be.$$.fragment,a),$(ze.$$.fragment,a),$(Ee.$$.fragment,a),$(Ce.$$.fragment,a),wt=!1},d(a){a&&(l(u),l(t)),_(i,a),_(h),_(y),_(ae),_(de),_(ce),_(pe),_(le),_(ue),_(he),_(me),_(ge),_(fe),_(Y),_(xe),_($e),_(_e),_(ve),_(ke),_(Te),_(we),_(be),_(ze),_(Ee),_(Ce)}}}function Go(E){let i,u;return i=new An({props:{$$slots:{default:[Vo]},$$scope:{ctx:E}}}),{c(){m(i.$$.fragment)},l(t){g(i.$$.fragment,t)},m(t,h){f(i,t,h),u=!0},p(t,h){const w={};h&2&&(w.$$scope={dirty:h,ctx:t}),i.$set(w)},i(t){u||(x(i.$$.fragment,t),u=!0)},o(t){$(i.$$.fragment,t),u=!1},d(t){_(i,t)}}}function So(E){let i,u='The Rust API Reference is available directly on the <a href="https://docs.rs/tokenizers/latest/tokenizers/" rel="nofollow">Docs.rs</a> website.';return{c(){i=r("p"),i.innerHTML=u},l(t){i=s(t,"P",{"data-svelte-h":!0}),c(i)!=="svelte-4ytcyb"&&(i.innerHTML=u)},m(t,h){P(t,i,h)},p:Sn,d(t){t&&l(i)}}}function Ao(E){let i,u;return i=new An({props:{$$slots:{default:[So]},$$scope:{ctx:E}}}),{c(){m(i.$$.fragment)},l(t){g(i.$$.fragment,t)},m(t,h){f(i,t,h),u=!0},p(t,h){const w={};h&2&&(w.$$scope={dirty:h,ctx:t}),i.$set(w)},i(t){u||(x(i.$$.fragment,t),u=!0)},o(t){$(i.$$.fragment,t),u=!1},d(t){_(i,t)}}}function jo(E){let i,u="The node API has not been documented yet.";return{c(){i=r("p"),i.textContent=u},l(t){i=s(t,"P",{"data-svelte-h":!0}),c(i)!=="svelte-1mrchm6"&&(i.textContent=u)},m(t,h){P(t,i,h)},p:Sn,d(t){t&&l(i)}}}function Wo(E){let i,u;return i=new An({props:{$$slots:{default:[jo]},$$scope:{ctx:E}}}),{c(){m(i.$$.fragment)},l(t){g(i.$$.fragment,t)},m(t,h){f(i,t,h),u=!0},p(t,h){const w={};h&2&&(w.$$scope={dirty:h,ctx:t}),i.$set(w)},i(t){u||(x(i.$$.fragment,t),u=!0)},o(t){$(i.$$.fragment,t),u=!1},d(t){_(i,t)}}}function Oo(E){let i,u,t,h,w,L,M,Q,z,y,B,I;return w=new Eo({props:{title:"Encoding",local:"encoding",headingTag:"h1"}}),M=new Mo({props:{python:!0,rust:!0,node:!0,$$slots:{node:[Wo],rust:[Ao],python:[Go]},$$scope:{ctx:E}}}),z=new Io({props:{source:"https://github.com/huggingface/tokenizers/blob/main/docs/source-doc-builder/api/encoding.mdx"}}),{c(){i=r("meta"),u=n(),t=r("p"),h=n(),m(w.$$.fragment),L=n(),m(M.$$.fragment),Q=n(),m(z.$$.fragment),y=n(),B=r("p"),this.h()},l(p){const b=Po("svelte-u9bgzb",document.head);i=s(b,"META",{name:!0,content:!0}),b.forEach(l),u=o(p),t=s(p,"P",{}),v(t).forEach(l),h=o(p),g(w.$$.fragment,p),L=o(p),g(M.$$.fragment,p),Q=o(p),g(z.$$.fragment,p),y=o(p),B=s(p,"P",{}),v(B).forEach(l),this.h()},h(){k(i,"name","hf:doc:metadata"),k(i,"content",No)},m(p,b){e(document.head,i),P(p,u,b),P(p,t,b),P(p,h,b),f(w,p,b),P(p,L,b),f(M,p,b),P(p,Q,b),f(z,p,b),P(p,y,b),P(p,B,b),I=!0},p(p,[b]){const J={};b&2&&(J.$$scope={dirty:b,ctx:p}),M.$set(J)},i(p){I||(x(w.$$.fragment,p),x(M.$$.fragment,p),x(z.$$.fragment,p),I=!0)},o(p){$(w.$$.fragment,p),$(M.$$.fragment,p),$(z.$$.fragment,p),I=!1},d(p){p&&(l(u),l(t),l(h),l(L),l(Q),l(y),l(B)),l(i),_(w,p),_(M,p),_(z,p)}}}const No='{"title":"Encoding","local":"encoding","sections":[{"title":"Encoding","local":"tokenizers.Encoding","sections":[],"depth":2}],"depth":1}';function Ro(E){return yo(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Xo extends qo{constructor(i){super(),Do(this,i,Ro,Oo,Co,{})}}export{Xo as component};
