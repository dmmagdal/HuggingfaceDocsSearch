var s;const e=((s=globalThis.__sveltekit_1e8a8k3)==null?void 0:s.base)??"/docs/datasets/main/en";var a;const t=((a=globalThis.__sveltekit_1e8a8k3)==null?void 0:a.assets)??e;export{t as a,e as b};
