import{s as H,n as D,o as $}from"../chunks/scheduler.b108d059.js";import{S as x,i as _,g as o,s as J,r as c,A as L,h as u,f as M,c as a,j as Y,u as r,x as k,k as F,y as P,a as t,v as A,d as h,t as d,w as q}from"../chunks/index.008de539.js";import{C as X}from"../chunks/CodeBlock.7b00c886.js";import{H as v,E as K}from"../chunks/getInferenceSnippets.593e515c.js";function O(f){let T,m,i,B,n,g,y,V='<thead><tr><th>Feature</th> <th>Available</th></tr></thead> <tbody><tr><td><a href="../tools">Tools</a></td> <td>No</td></tr> <tr><td><a href="../multimodal">Multimodal</a></td> <td>Yes</td></tr></tbody>',b,I,R="We also support Anthropic models (including multimodal ones via <code>multmodal: true</code>) through the official SDK. You may provide your API key via the <code>ANTHROPIC_API_KEY</code> env variable, or alternatively, through the <code>endpoints.apiKey</code> as per the following example.",E,j,Q,U,Z,w,z="We also support using Anthropic models running on Vertex AI. Authentication is done using Google Application Default Credentials. Project ID can be provided through the <code>endpoints.projectId</code> as per the following example:",S,p,G,e,N,C,W;return n=new v({props:{title:"Anthropic",local:"anthropic",headingTag:"h1"}}),j=new X({props:{code:"TU9ERUxTJTNEJTYwJTVCJTBBJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIybmFtZSUyMiUzQSUyMCUyMmNsYXVkZS0zLWhhaWt1LTIwMjQwMzA3JTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGlzcGxheU5hbWUlMjIlM0ElMjAlMjJDbGF1ZGUlMjAzJTIwSGFpa3UlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjJkZXNjcmlwdGlvbiUyMiUzQSUyMCUyMkZhc3Rlc3QlMjBhbmQlMjBtb3N0JTIwY29tcGFjdCUyMG1vZGVsJTIwZm9yJTIwbmVhci1pbnN0YW50JTIwcmVzcG9uc2l2ZW5lc3MlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjJtdWx0aW1vZGFsJTIyJTNBJTIwdHJ1ZSUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMnBhcmFtZXRlcnMlMjIlM0ElMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJtYXhfbmV3X3Rva2VucyUyMiUzQSUyMDQwOTYlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjJlbmRwb2ludHMlMjIlM0ElMjAlNUIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJ0eXBlJTIyJTNBJTIwJTIyYW50aHJvcGljJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTJGJTJGJTIwb3B0aW9uYWxzJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyYXBpS2V5JTIyJTNBJTIwJTIyc2stYW50LS4uLiUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmJhc2VVUkwlMjIlM0ElMjAlMjJodHRwcyUzQSUyRiUyRmFwaS5hbnRocm9waWMuY29tJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGVmYXVsdEhlYWRlcnMlMjIlM0ElMjAlN0IlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJkZWZhdWx0UXVlcnklMjIlM0ElMjAlN0IlN0QlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMEElMjAlMjAlMjAlMjAlMjAlMjAlNUQlMEElMjAlMjAlN0QlMkMlMEElMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjJuYW1lJTIyJTNBJTIwJTIyY2xhdWRlLTMtc29ubmV0LTIwMjQwMjI5JTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGlzcGxheU5hbWUlMjIlM0ElMjAlMjJDbGF1ZGUlMjAzJTIwU29ubmV0JTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGVzY3JpcHRpb24lMjIlM0ElMjAlMjJJZGVhbCUyMGJhbGFuY2UlMjBvZiUyMGludGVsbGlnZW5jZSUyMGFuZCUyMHNwZWVkJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIybXVsdGltb2RhbCUyMiUzQSUyMHRydWUlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjJwYXJhbWV0ZXJzJTIyJTNBJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIybWF4X25ld190b2tlbnMlMjIlM0ElMjA0MDk2JTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIyZW5kcG9pbnRzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIydHlwZSUyMiUzQSUyMCUyMmFudGhyb3BpYyUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyRiUyRiUyMG9wdGlvbmFscyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmFwaUtleSUyMiUzQSUyMCUyMnNrLWFudC0uLi4lMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJiYXNlVVJMJTIyJTNBJTIwJTIyaHR0cHMlM0ElMkYlMkZhcGkuYW50aHJvcGljLmNvbSUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmRlZmF1bHRIZWFkZXJzJTIyJTNBJTIwJTdCJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGVmYXVsdFF1ZXJ5JTIyJTNBJTIwJTdCJTdEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTVEJTBBJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIybmFtZSUyMiUzQSUyMCUyMmNsYXVkZS0zLW9wdXMtMjAyNDAyMjklMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjJkaXNwbGF5TmFtZSUyMiUzQSUyMCUyMkNsYXVkZSUyMDMlMjBPcHVzJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGVzY3JpcHRpb24lMjIlM0ElMjAlMjJNb3N0JTIwcG93ZXJmdWwlMjBtb2RlbCUyMGZvciUyMGhpZ2hseSUyMGNvbXBsZXglMjB0YXNrcyUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMm11bHRpbW9kYWwlMjIlM0ElMjB0cnVlJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIycGFyYW1ldGVycyUyMiUzQSUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMm1heF9uZXdfdG9rZW5zJTIyJTNBJTIwNDA5NiUwQSUyMCUyMCUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMmVuZHBvaW50cyUyMiUzQSUyMCU1QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMnR5cGUlMjIlM0ElMjAlMjJhbnRocm9waWMlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMkYlMkYlMjBvcHRpb25hbHMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJhcGlLZXklMjIlM0ElMjAlMjJzay1hbnQtLi4uJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyYmFzZVVSTCUyMiUzQSUyMCUyMmh0dHBzJTNBJTJGJTJGYXBpLmFudGhyb3BpYy5jb20lMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJkZWZhdWx0SGVhZGVycyUyMiUzQSUyMCU3QiU3RCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmRlZmF1bHRRdWVyeSUyMiUzQSUyMCU3QiU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCU3RCUwQSU1RCU2MA==",highlighted:`<span class="hljs-attr">MODELS</span>=\`[
  {
      <span class="hljs-string">&quot;name&quot;</span>: <span class="hljs-string">&quot;claude-3-haiku-20240307&quot;</span>,
      <span class="hljs-string">&quot;displayName&quot;</span>: <span class="hljs-string">&quot;Claude 3 Haiku&quot;</span>,
      <span class="hljs-string">&quot;description&quot;</span>: <span class="hljs-string">&quot;Fastest and most compact model for near-instant responsiveness&quot;</span>,
      <span class="hljs-string">&quot;multimodal&quot;</span>: <span class="hljs-literal">true</span>,
      <span class="hljs-string">&quot;parameters&quot;</span>: {
        <span class="hljs-string">&quot;max_new_tokens&quot;</span>: <span class="hljs-number">4096</span>,
      },
      <span class="hljs-string">&quot;endpoints&quot;</span>: [
        {
          <span class="hljs-string">&quot;type&quot;</span>: <span class="hljs-string">&quot;anthropic&quot;</span>,
          // optionals
          <span class="hljs-string">&quot;apiKey&quot;</span>: <span class="hljs-string">&quot;sk-ant-...&quot;</span>,
          <span class="hljs-string">&quot;baseURL&quot;</span>: <span class="hljs-string">&quot;https://api.anthropic.com&quot;</span>,
          <span class="hljs-string">&quot;defaultHeaders&quot;</span>: {},
          <span class="hljs-string">&quot;defaultQuery&quot;</span>: {}
        }
      ]
  },
  {
      <span class="hljs-string">&quot;name&quot;</span>: <span class="hljs-string">&quot;claude-3-sonnet-20240229&quot;</span>,
      <span class="hljs-string">&quot;displayName&quot;</span>: <span class="hljs-string">&quot;Claude 3 Sonnet&quot;</span>,
      <span class="hljs-string">&quot;description&quot;</span>: <span class="hljs-string">&quot;Ideal balance of intelligence and speed&quot;</span>,
      <span class="hljs-string">&quot;multimodal&quot;</span>: <span class="hljs-literal">true</span>,
      <span class="hljs-string">&quot;parameters&quot;</span>: {
        <span class="hljs-string">&quot;max_new_tokens&quot;</span>: <span class="hljs-number">4096</span>,
      },
      <span class="hljs-string">&quot;endpoints&quot;</span>: [
        {
          <span class="hljs-string">&quot;type&quot;</span>: <span class="hljs-string">&quot;anthropic&quot;</span>,
          // optionals
          <span class="hljs-string">&quot;apiKey&quot;</span>: <span class="hljs-string">&quot;sk-ant-...&quot;</span>,
          <span class="hljs-string">&quot;baseURL&quot;</span>: <span class="hljs-string">&quot;https://api.anthropic.com&quot;</span>,
          <span class="hljs-string">&quot;defaultHeaders&quot;</span>: {},
          <span class="hljs-string">&quot;defaultQuery&quot;</span>: {}
        }
      ]
  },
  {
      <span class="hljs-string">&quot;name&quot;</span>: <span class="hljs-string">&quot;claude-3-opus-20240229&quot;</span>,
      <span class="hljs-string">&quot;displayName&quot;</span>: <span class="hljs-string">&quot;Claude 3 Opus&quot;</span>,
      <span class="hljs-string">&quot;description&quot;</span>: <span class="hljs-string">&quot;Most powerful model for highly complex tasks&quot;</span>,
      <span class="hljs-string">&quot;multimodal&quot;</span>: <span class="hljs-literal">true</span>,
      <span class="hljs-string">&quot;parameters&quot;</span>: {
         <span class="hljs-string">&quot;max_new_tokens&quot;</span>: <span class="hljs-number">4096</span>
      },
      <span class="hljs-string">&quot;endpoints&quot;</span>: [
        {
          <span class="hljs-string">&quot;type&quot;</span>: <span class="hljs-string">&quot;anthropic&quot;</span>,
          // optionals
          <span class="hljs-string">&quot;apiKey&quot;</span>: <span class="hljs-string">&quot;sk-ant-...&quot;</span>,
          <span class="hljs-string">&quot;baseURL&quot;</span>: <span class="hljs-string">&quot;https://api.anthropic.com&quot;</span>,
          <span class="hljs-string">&quot;defaultHeaders&quot;</span>: {},
          <span class="hljs-string">&quot;defaultQuery&quot;</span>: {}
        }
      ]
  }
]\``,wrap:!1}}),U=new v({props:{title:"VertexAI",local:"vertexai",headingTag:"h2"}}),p=new X({props:{code:"TU9ERUxTJTNEJTYwJTVCJTBBJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIybmFtZSUyMiUzQSUyMCUyMmNsYXVkZS0zLWhhaWt1JTQwMjAyNDAzMDclMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjJkaXNwbGF5TmFtZSUyMiUzQSUyMCUyMkNsYXVkZSUyMDMlMjBIYWlrdSUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMmRlc2NyaXB0aW9uJTIyJTNBJTIwJTIyRmFzdGVzdCUyQyUyMG1vc3QlMjBjb21wYWN0JTIwbW9kZWwlMjBmb3IlMjBuZWFyLWluc3RhbnQlMjByZXNwb25zaXZlbmVzcyUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMm11bHRpbW9kYWwlMjIlM0ElMjB0cnVlJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIycGFyYW1ldGVycyUyMiUzQSUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMm1heF9uZXdfdG9rZW5zJTIyJTNBJTIwNDA5NiUwQSUyMCUyMCUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMmVuZHBvaW50cyUyMiUzQSUyMCU1QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMnR5cGUlMjIlM0ElMjAlMjJhbnRocm9waWMtdmVydGV4JTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIycmVnaW9uJTIyJTNBJTIwJTIydXMtY2VudHJhbDElMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJwcm9qZWN0SWQlMjIlM0ElMjAlMjJnY3AtcHJvamVjdC1pZCUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyRiUyRiUyMG9wdGlvbmFscyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmRlZmF1bHRIZWFkZXJzJTIyJTNBJTIwJTdCJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGVmYXVsdFF1ZXJ5JTIyJTNBJTIwJTdCJTdEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTVEJTBBJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIybmFtZSUyMiUzQSUyMCUyMmNsYXVkZS0zLXNvbm5ldCU0MDIwMjQwMjI5JTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGlzcGxheU5hbWUlMjIlM0ElMjAlMjJDbGF1ZGUlMjAzJTIwU29ubmV0JTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGVzY3JpcHRpb24lMjIlM0ElMjAlMjJJZGVhbCUyMGJhbGFuY2UlMjBvZiUyMGludGVsbGlnZW5jZSUyMGFuZCUyMHNwZWVkJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIybXVsdGltb2RhbCUyMiUzQSUyMHRydWUlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjJwYXJhbWV0ZXJzJTIyJTNBJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIybWF4X25ld190b2tlbnMlMjIlM0ElMjA0MDk2JTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIyZW5kcG9pbnRzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIydHlwZSUyMiUzQSUyMCUyMmFudGhyb3BpYy12ZXJ0ZXglMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJyZWdpb24lMjIlM0ElMjAlMjJ1cy1jZW50cmFsMSUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMnByb2plY3RJZCUyMiUzQSUyMCUyMmdjcC1wcm9qZWN0LWlkJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTJGJTJGJTIwb3B0aW9uYWxzJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZGVmYXVsdEhlYWRlcnMlMjIlM0ElMjAlN0IlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJkZWZhdWx0UXVlcnklMjIlM0ElMjAlN0IlN0QlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMEElMjAlMjAlMjAlMjAlMjAlMjAlNUQlMEElMjAlMjAlN0QlMkMlMEElNUQlNjA=",highlighted:`<span class="hljs-attr">MODELS</span>=\`[
  {
      <span class="hljs-string">&quot;name&quot;</span>: <span class="hljs-string">&quot;claude-3-haiku@20240307&quot;</span>,
      <span class="hljs-string">&quot;displayName&quot;</span>: <span class="hljs-string">&quot;Claude 3 Haiku&quot;</span>,
      <span class="hljs-string">&quot;description&quot;</span>: <span class="hljs-string">&quot;Fastest, most compact model for near-instant responsiveness&quot;</span>,
      <span class="hljs-string">&quot;multimodal&quot;</span>: <span class="hljs-literal">true</span>,
      <span class="hljs-string">&quot;parameters&quot;</span>: {
         <span class="hljs-string">&quot;max_new_tokens&quot;</span>: <span class="hljs-number">4096</span>
      },
      <span class="hljs-string">&quot;endpoints&quot;</span>: [
        {
          <span class="hljs-string">&quot;type&quot;</span>: <span class="hljs-string">&quot;anthropic-vertex&quot;</span>,
          <span class="hljs-string">&quot;region&quot;</span>: <span class="hljs-string">&quot;us-central1&quot;</span>,
          <span class="hljs-string">&quot;projectId&quot;</span>: <span class="hljs-string">&quot;gcp-project-id&quot;</span>,
          // optionals
          <span class="hljs-string">&quot;defaultHeaders&quot;</span>: {},
          <span class="hljs-string">&quot;defaultQuery&quot;</span>: {}
        }
      ]
  },
  {
      <span class="hljs-string">&quot;name&quot;</span>: <span class="hljs-string">&quot;claude-3-sonnet@20240229&quot;</span>,
      <span class="hljs-string">&quot;displayName&quot;</span>: <span class="hljs-string">&quot;Claude 3 Sonnet&quot;</span>,
      <span class="hljs-string">&quot;description&quot;</span>: <span class="hljs-string">&quot;Ideal balance of intelligence and speed&quot;</span>,
      <span class="hljs-string">&quot;multimodal&quot;</span>: <span class="hljs-literal">true</span>,
      <span class="hljs-string">&quot;parameters&quot;</span>: {
        <span class="hljs-string">&quot;max_new_tokens&quot;</span>: <span class="hljs-number">4096</span>,
      },
      <span class="hljs-string">&quot;endpoints&quot;</span>: [
        {
          <span class="hljs-string">&quot;type&quot;</span>: <span class="hljs-string">&quot;anthropic-vertex&quot;</span>,
          <span class="hljs-string">&quot;region&quot;</span>: <span class="hljs-string">&quot;us-central1&quot;</span>,
          <span class="hljs-string">&quot;projectId&quot;</span>: <span class="hljs-string">&quot;gcp-project-id&quot;</span>,
          // optionals
          <span class="hljs-string">&quot;defaultHeaders&quot;</span>: {},
          <span class="hljs-string">&quot;defaultQuery&quot;</span>: {}
        }
      ]
  },
]\``,wrap:!1}}),e=new K({props:{source:"https://github.com/huggingface/chat-ui/blob/main/docs/source/configuration/models/providers/anthropic.md"}}),{c(){T=o("meta"),m=J(),i=o("p"),B=J(),c(n.$$.fragment),g=J(),y=o("table"),y.innerHTML=V,b=J(),I=o("p"),I.innerHTML=R,E=J(),c(j.$$.fragment),Q=J(),c(U.$$.fragment),Z=J(),w=o("p"),w.innerHTML=z,S=J(),c(p.$$.fragment),G=J(),c(e.$$.fragment),N=J(),C=o("p"),this.h()},l(l){const s=L("svelte-u9bgzb",document.head);T=u(s,"META",{name:!0,content:!0}),s.forEach(M),m=a(l),i=u(l,"P",{}),Y(i).forEach(M),B=a(l),r(n.$$.fragment,l),g=a(l),y=u(l,"TABLE",{"data-svelte-h":!0}),k(y)!=="svelte-7vhis4"&&(y.innerHTML=V),b=a(l),I=u(l,"P",{"data-svelte-h":!0}),k(I)!=="svelte-1p6l4n9"&&(I.innerHTML=R),E=a(l),r(j.$$.fragment,l),Q=a(l),r(U.$$.fragment,l),Z=a(l),w=u(l,"P",{"data-svelte-h":!0}),k(w)!=="svelte-hk1clc"&&(w.innerHTML=z),S=a(l),r(p.$$.fragment,l),G=a(l),r(e.$$.fragment,l),N=a(l),C=u(l,"P",{}),Y(C).forEach(M),this.h()},h(){F(T,"name","hf:doc:metadata"),F(T,"content",ll)},m(l,s){P(document.head,T),t(l,m,s),t(l,i,s),t(l,B,s),A(n,l,s),t(l,g,s),t(l,y,s),t(l,b,s),t(l,I,s),t(l,E,s),A(j,l,s),t(l,Q,s),A(U,l,s),t(l,Z,s),t(l,w,s),t(l,S,s),A(p,l,s),t(l,G,s),A(e,l,s),t(l,N,s),t(l,C,s),W=!0},p:D,i(l){W||(h(n.$$.fragment,l),h(j.$$.fragment,l),h(U.$$.fragment,l),h(p.$$.fragment,l),h(e.$$.fragment,l),W=!0)},o(l){d(n.$$.fragment,l),d(j.$$.fragment,l),d(U.$$.fragment,l),d(p.$$.fragment,l),d(e.$$.fragment,l),W=!1},d(l){l&&(M(m),M(i),M(B),M(g),M(y),M(b),M(I),M(E),M(Q),M(Z),M(w),M(S),M(G),M(N),M(C)),M(T),q(n,l),q(j,l),q(U,l),q(p,l),q(e,l)}}}const ll='{"title":"Anthropic","local":"anthropic","sections":[{"title":"VertexAI","local":"vertexai","sections":[],"depth":2}],"depth":1}';function sl(f){return $(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Tl extends x{constructor(T){super(),_(this,T,sl,O,H,{})}}export{Tl as component};
