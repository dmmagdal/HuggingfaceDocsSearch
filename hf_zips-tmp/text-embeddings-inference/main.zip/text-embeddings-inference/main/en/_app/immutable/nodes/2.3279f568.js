import{s as S,n as p,o as W}from"../chunks/scheduler.b108d059.js";import{S as Q,i as F,g as m,s as t,r as c,A as Y,h as s,f as T,c as j,j as r,u as G,x as X,k as N,y as v,a as J,v as Z,d as V,t as E,w as h}from"../chunks/index.008de539.js";import{C as H}from"../chunks/CodeBlock.7b00c886.js";import{H as f,E as k}from"../chunks/getInferenceSnippets.593e515c.js";function g(u){let U,B,C,n,w,A,y,R="To see all options to serve your models, run the following:",o,I,b,e,d,a,i;return w=new f({props:{title:"CLI arguments",local:"cli-arguments",headingTag:"h1"}}),I=new H({props:{code:"JTI0JTIwdGV4dC1lbWJlZGRpbmdzLXJvdXRlciUyMC0taGVscCUwQVRleHQlMjBFbWJlZGRpbmclMjBXZWJzZXJ2ZXIlMEElMEFVc2FnZSUzQSUyMHRleHQtZW1iZWRkaW5ncy1yb3V0ZXIlMjAlNUJPUFRJT05TJTVEJTBBJTBBT3B0aW9ucyUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0tbW9kZWwtaWQlMjAlM0NNT0RFTF9JRCUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFRoZSUyMG5hbWUlMjBvZiUyMHRoZSUyMG1vZGVsJTIwdG8lMjBsb2FkLiUyMENhbiUyMGJlJTIwYSUyME1PREVMX0lEJTIwYXMlMjBsaXN0ZWQlMjBvbiUyMCUzQ2h0dHBzJTNBJTJGJTJGaGYuY28lMkZtb2RlbHMlM0UlMjBsaWtlJTIwJTYwQkFBSSUyRmJnZS1sYXJnZS1lbi12MS41JTYwLiUyME9yJTIwaXQlMjBjYW4lMjBiZSUyMGElMjBsb2NhbCUyMGRpcmVjdG9yeSUyMGNvbnRhaW5pbmclMjB0aGUlMjBuZWNlc3NhcnklMjBmaWxlcyUyMGFzJTIwc2F2ZWQlMjBieSUyMCU2MHNhdmVfcHJldHJhaW5lZCguLi4pJTYwJTIwbWV0aG9kcyUyMG9mJTIwdHJhbnNmb3JtZXJzJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwTU9ERUxfSUQlM0QlNUQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJkZWZhdWx0JTNBJTIwQkFBSSUyRmJnZS1sYXJnZS1lbi12MS41JTVEJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwLS1yZXZpc2lvbiUyMCUzQ1JFVklTSU9OJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwVGhlJTIwYWN0dWFsJTIwcmV2aXNpb24lMjBvZiUyMHRoZSUyMG1vZGVsJTIwaWYlMjB5b3UncmUlMjByZWZlcnJpbmclMjB0byUyMGElMjBtb2RlbCUyMG9uJTIwdGhlJTIwaHViLiUyMFlvdSUyMGNhbiUyMHVzZSUyMGElMjBzcGVjaWZpYyUyMGNvbW1pdCUyMGlkJTIwb3IlMjBhJTIwYnJhbmNoJTIwbGlrZSUyMCU2MHJlZnMlMkZwciUyRjIlNjAlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBSRVZJU0lPTiUzRCU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0tdG9rZW5pemF0aW9uLXdvcmtlcnMlMjAlM0NUT0tFTklaQVRJT05fV09SS0VSUyUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyME9wdGlvbmFsbHklMjBjb250cm9sJTIwdGhlJTIwbnVtYmVyJTIwb2YlMjB0b2tlbml6ZXIlMjB3b3JrZXJzJTIwdXNlZCUyMGZvciUyMHBheWxvYWQlMjB0b2tlbml6YXRpb24lMkMlMjB2YWxpZGF0aW9uJTIwYW5kJTIwdHJ1bmNhdGlvbi4lMjBEZWZhdWx0JTIwdG8lMjB0aGUlMjBudW1iZXIlMjBvZiUyMENQVSUyMGNvcmVzJTIwb24lMjB0aGUlMjBtYWNoaW5lJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwVE9LRU5JWkFUSU9OX1dPUktFUlMlM0QlNUQlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAtLWR0eXBlJTIwJTNDRFRZUEUlM0UlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBUaGUlMjBkdHlwZSUyMHRvJTIwYmUlMjBmb3JjZWQlMjB1cG9uJTIwdGhlJTIwbW9kZWwlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBEVFlQRSUzRCU1RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QnBvc3NpYmxlJTIwdmFsdWVzJTNBJTIwZmxvYXQxNiUyQyUyMGZsb2F0MzIlNUQlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAtLXBvb2xpbmclMjAlM0NQT09MSU5HJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwT3B0aW9uYWxseSUyMGNvbnRyb2wlMjB0aGUlMjBwb29saW5nJTIwbWV0aG9kJTIwZm9yJTIwZW1iZWRkaW5nJTIwbW9kZWxzLiUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMElmJTIwJTYwcG9vbGluZyU2MCUyMGlzJTIwbm90JTIwc2V0JTJDJTIwdGhlJTIwcG9vbGluZyUyMGNvbmZpZ3VyYXRpb24lMjB3aWxsJTIwYmUlMjBwYXJzZWQlMjBmcm9tJTIwdGhlJTIwbW9kZWwlMjAlNjAxX1Bvb2xpbmclMkZjb25maWcuanNvbiU2MCUyMGNvbmZpZ3VyYXRpb24uJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwSWYlMjAlNjBwb29saW5nJTYwJTIwaXMlMjBzZXQlMkMlMjBpdCUyMHdpbGwlMjBvdmVycmlkZSUyMHRoZSUyMG1vZGVsJTIwcG9vbGluZyUyMGNvbmZpZ3VyYXRpb24lMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBQT09MSU5HJTNEJTVEJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwUG9zc2libGUlMjB2YWx1ZXMlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAtJTIwY2xzJTNBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwU2VsZWN0JTIwdGhlJTIwQ0xTJTIwdG9rZW4lMjBhcyUyMGVtYmVkZGluZyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMC0lMjBtZWFuJTNBJTIwJTIwJTIwJTIwJTIwJTIwJTIwQXBwbHklMjBNZWFuJTIwcG9vbGluZyUyMHRvJTIwdGhlJTIwbW9kZWwlMjBlbWJlZGRpbmdzJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwLSUyMHNwbGFkZSUzQSUyMCUyMCUyMCUyMCUyMEFwcGx5JTIwU1BMQURFJTIwKFNwYXJzZSUyMExleGljYWwlMjBhbmQlMjBFeHBhbnNpb24pJTIwdG8lMjB0aGUlMjBtb2RlbCUyMGVtYmVkZGluZ3MuJTIwVGhpcyUyMG9wdGlvbiUyMGlzJTIwb25seSUyMGF2YWlsYWJsZSUyMGlmJTIwdGhlJTIwbG9hZGVkJTIwbW9kZWwlMjBpcyUyMGElMjAlNjBGb3JNYXNrZWRMTSU2MCUyMFRyYW5zZm9ybWVyJTIwbW9kZWwlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAtJTIwbGFzdC10b2tlbiUzQSUyMFNlbGVjdCUyMHRoZSUyMGxhc3QlMjB0b2tlbiUyMGFzJTIwZW1iZWRkaW5nJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwLS1tYXgtY29uY3VycmVudC1yZXF1ZXN0cyUyMCUzQ01BWF9DT05DVVJSRU5UX1JFUVVFU1RTJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwVGhlJTIwbWF4aW11bSUyMGFtb3VudCUyMG9mJTIwY29uY3VycmVudCUyMHJlcXVlc3RzJTIwZm9yJTIwdGhpcyUyMHBhcnRpY3VsYXIlMjBkZXBsb3ltZW50LiUyMEhhdmluZyUyMGElMjBsb3clMjBsaW1pdCUyMHdpbGwlMjByZWZ1c2UlMjBjbGllbnRzJTIwcmVxdWVzdHMlMjBpbnN0ZWFkJTIwb2YlMjBoYXZpbmclMjB0aGVtJTIwd2FpdCUyMGZvciUyMHRvbyUyMGxvbmclMjBhbmQlMjBpcyUyMHVzdWFsbHklMjBnb29kJTIwdG8lMjBoYW5kbGUlMjBiYWNrcHJlc3N1cmUlMjBjb3JyZWN0bHklMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBNQVhfQ09OQ1VSUkVOVF9SRVFVRVNUUyUzRCU1RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmRlZmF1bHQlM0ElMjA1MTIlNUQlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAtLW1heC1iYXRjaC10b2tlbnMlMjAlM0NNQVhfQkFUQ0hfVE9LRU5TJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwKipJTVBPUlRBTlQqKiUyMFRoaXMlMjBpcyUyMG9uZSUyMGNyaXRpY2FsJTIwY29udHJvbCUyMHRvJTIwYWxsb3clMjBtYXhpbXVtJTIwdXNhZ2UlMjBvZiUyMHRoZSUyMGF2YWlsYWJsZSUyMGhhcmR3YXJlLiUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFRoaXMlMjByZXByZXNlbnRzJTIwdGhlJTIwdG90YWwlMjBhbW91bnQlMjBvZiUyMHBvdGVudGlhbCUyMHRva2VucyUyMHdpdGhpbiUyMGElMjBiYXRjaC4lMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBGb3IlMjAlNjBtYXhfYmF0Y2hfdG9rZW5zJTNEMTAwMCU2MCUyQyUyMHlvdSUyMGNvdWxkJTIwZml0JTIwJTYwMTAlNjAlMjBxdWVyaWVzJTIwb2YlMjAlNjB0b3RhbF90b2tlbnMlM0QxMDAlNjAlMjBvciUyMGElMjBzaW5nbGUlMjBxdWVyeSUyMG9mJTIwJTYwMTAwMCU2MCUyMHRva2Vucy4lMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBPdmVyYWxsJTIwdGhpcyUyMG51bWJlciUyMHNob3VsZCUyMGJlJTIwdGhlJTIwbGFyZ2VzdCUyMHBvc3NpYmxlJTIwdW50aWwlMjB0aGUlMjBtb2RlbCUyMGlzJTIwY29tcHV0ZSUyMGJvdW5kLiUyMFNpbmNlJTIwdGhlJTIwYWN0dWFsJTIwbWVtb3J5JTIwb3ZlcmhlYWQlMjBkZXBlbmRzJTIwb24lMjB0aGUlMjBtb2RlbCUyMGltcGxlbWVudGF0aW9uJTJDJTIwdGV4dC1lbWJlZGRpbmdzLWluZmVyZW5jZSUyMGNhbm5vdCUyMGluZmVyJTIwdGhpcyUyMG51bWJlciUyMGF1dG9tYXRpY2FsbHkuJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwTUFYX0JBVENIX1RPS0VOUyUzRCU1RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmRlZmF1bHQlM0ElMjAxNjM4NCU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0tbWF4LWJhdGNoLXJlcXVlc3RzJTIwJTNDTUFYX0JBVENIX1JFUVVFU1RTJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwT3B0aW9uYWxseSUyMGNvbnRyb2wlMjB0aGUlMjBtYXhpbXVtJTIwbnVtYmVyJTIwb2YlMjBpbmRpdmlkdWFsJTIwcmVxdWVzdHMlMjBpbiUyMGElMjBiYXRjaCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmVudiUzQSUyME1BWF9CQVRDSF9SRVFVRVNUUyUzRCU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0tbWF4LWNsaWVudC1iYXRjaC1zaXplJTIwJTNDTUFYX0NMSUVOVF9CQVRDSF9TSVpFJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwQ29udHJvbCUyMHRoZSUyMG1heGltdW0lMjBudW1iZXIlMjBvZiUyMGlucHV0cyUyMHRoYXQlMjBhJTIwY2xpZW50JTIwY2FuJTIwc2VuZCUyMGluJTIwYSUyMHNpbmdsZSUyMHJlcXVlc3QlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBNQVhfQ0xJRU5UX0JBVENIX1NJWkUlM0QlNUQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJkZWZhdWx0JTNBJTIwMzIlNUQlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAtLWF1dG8tdHJ1bmNhdGUlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBBdXRvbWF0aWNhbGx5JTIwdHJ1bmNhdGUlMjBpbnB1dHMlMjB0aGF0JTIwYXJlJTIwbG9uZ2VyJTIwdGhhbiUyMHRoZSUyMG1heGltdW0lMjBzdXBwb3J0ZWQlMjBzaXplJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwVW51c2VkJTIwZm9yJTIwZ1JQQyUyMHNlcnZlcnMlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBBVVRPX1RSVU5DQVRFJTNEJTVEJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwLS1kZWZhdWx0LXByb21wdC1uYW1lJTIwJTNDREVGQVVMVF9QUk9NUFRfTkFNRSUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFRoZSUyMG5hbWUlMjBvZiUyMHRoZSUyMHByb21wdCUyMHRoYXQlMjBzaG91bGQlMjBiZSUyMHVzZWQlMjBieSUyMGRlZmF1bHQlMjBmb3IlMjBlbmNvZGluZy4lMjBJZiUyMG5vdCUyMHNldCUyQyUyMG5vJTIwcHJvbXB0JTIwd2lsbCUyMGJlJTIwYXBwbGllZC4lMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBNdXN0JTIwYmUlMjBhJTIwa2V5JTIwaW4lMjB0aGUlMjAlNjBzZW50ZW5jZS10cmFuc2Zvcm1lcnMlNjAlMjBjb25maWd1cmF0aW9uJTIwJTYwcHJvbXB0cyU2MCUyMGRpY3Rpb25hcnkuJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwRm9yJTIwZXhhbXBsZSUyMGlmJTIwJTYwJTYwZGVmYXVsdF9wcm9tcHRfbmFtZSU2MCU2MCUyMGlzJTIwJTIycXVlcnklMjIlMjBhbmQlMjB0aGUlMjAlNjAlNjBwcm9tcHRzJTYwJTYwJTIwaXMlMjAlN0IlMjJxdWVyeSUyMiUzQSUyMCUyMnF1ZXJ5JTNBJTIwJTIyJTJDJTIwLi4uJTdEJTJDJTIwdGhlbiUyMHRoZSUyMHNlbnRlbmNlJTIwJTIyV2hhdCUyMGlzJTIwdGhlJTIwY2FwaXRhbCUyMG9mJTIwRnJhbmNlJTNGJTIyJTIwd2lsbCUyMGJlJTIwZW5jb2RlZCUyMGFzJTIwJTIycXVlcnklM0ElMjBXaGF0JTIwaXMlMjB0aGUlMjBjYXBpdGFsJTIwb2YlMjBGcmFuY2UlM0YlMjIlMjBiZWNhdXNlJTIwdGhlJTIwcHJvbXB0JTIwdGV4dCUyMHdpbGwlMjBiZSUyMHByZXBlbmRlZCUyMGJlZm9yZSUyMGFueSUyMHRleHQlMjB0byUyMGVuY29kZS4lMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBUaGUlMjBhcmd1bWVudCUyMCctLWRlZmF1bHQtcHJvbXB0LW5hbWUlMjAlM0NERUZBVUxUX1BST01QVF9OQU1FJTNFJyUyMGNhbm5vdCUyMGJlJTIwdXNlZCUyMHdpdGglMjAnLS1kZWZhdWx0LXByb21wdCUyMCUzQ0RFRkFVTFRfUFJPTVBUJTNFJTYwJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwREVGQVVMVF9QUk9NUFRfTkFNRSUzRCU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0tZGVmYXVsdC1wcm9tcHQlMjAlM0NERUZBVUxUX1BST01QVCUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFRoZSUyMHByb21wdCUyMHRoYXQlMjBzaG91bGQlMjBiZSUyMHVzZWQlMjBieSUyMGRlZmF1bHQlMjBmb3IlMjBlbmNvZGluZy4lMjBJZiUyMG5vdCUyMHNldCUyQyUyMG5vJTIwcHJvbXB0JTIwd2lsbCUyMGJlJTIwYXBwbGllZC4lMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBGb3IlMjBleGFtcGxlJTIwaWYlMjAlNjAlNjBkZWZhdWx0X3Byb21wdCU2MCU2MCUyMGlzJTIwJTIycXVlcnklM0ElMjAlMjIlMjB0aGVuJTIwdGhlJTIwc2VudGVuY2UlMjAlMjJXaGF0JTIwaXMlMjB0aGUlMjBjYXBpdGFsJTIwb2YlMjBGcmFuY2UlM0YlMjIlMjB3aWxsJTIwYmUlMjBlbmNvZGVkJTIwYXMlMjAlMjJxdWVyeSUzQSUyMFdoYXQlMjBpcyUyMHRoZSUyMGNhcGl0YWwlMjBvZiUyMEZyYW5jZSUzRiUyMiUyMGJlY2F1c2UlMjB0aGUlMjBwcm9tcHQlMjB0ZXh0JTIwd2lsbCUyMGJlJTIwcHJlcGVuZGVkJTIwYmVmb3JlJTIwYW55JTIwdGV4dCUyMHRvJTIwZW5jb2RlLiUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFRoZSUyMGFyZ3VtZW50JTIwJy0tZGVmYXVsdC1wcm9tcHQlMjAlM0NERUZBVUxUX1BST01QVCUzRSclMjBjYW5ub3QlMjBiZSUyMHVzZWQlMjB3aXRoJTIwJy0tZGVmYXVsdC1wcm9tcHQtbmFtZSUyMCUzQ0RFRkFVTFRfUFJPTVBUX05BTUUlM0UlNjAlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBERUZBVUxUX1BST01QVCUzRCU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0taGYtdG9rZW4lMjAlM0NIRl9UT0tFTiUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFlvdXIlMjBIdWdnaW5nJTIwRmFjZSUyMEh1YiUyMHRva2VuJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwSEZfVE9LRU4lM0QlNUQlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAtLWhvc3RuYW1lJTIwJTNDSE9TVE5BTUUlM0UlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBUaGUlMjBJUCUyMGFkZHJlc3MlMjB0byUyMGxpc3RlbiUyMG9uJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwSE9TVE5BTUUlM0QlNUQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJkZWZhdWx0JTNBJTIwMC4wLjAuMCU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC1wJTJDJTIwLS1wb3J0JTIwJTNDUE9SVCUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFRoZSUyMHBvcnQlMjB0byUyMGxpc3RlbiUyMG9uJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwUE9SVCUzRCU1RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmRlZmF1bHQlM0ElMjAzMDAwJTVEJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwLS11ZHMtcGF0aCUyMCUzQ1VEU19QQVRIJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwVGhlJTIwbmFtZSUyMG9mJTIwdGhlJTIwdW5peCUyMHNvY2tldCUyMHNvbWUlMjB0ZXh0LWVtYmVkZGluZ3MtaW5mZXJlbmNlJTIwYmFja2VuZHMlMjB3aWxsJTIwdXNlJTIwYXMlMjB0aGV5JTIwY29tbXVuaWNhdGUlMjBpbnRlcm5hbGx5JTIwd2l0aCUyMGdSUEMlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBVRFNfUEFUSCUzRCU1RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmRlZmF1bHQlM0ElMjAlMkZ0bXAlMkZ0ZXh0LWVtYmVkZGluZ3MtaW5mZXJlbmNlLXNlcnZlciU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0taHVnZ2luZ2ZhY2UtaHViLWNhY2hlJTIwJTNDSFVHR0lOR0ZBQ0VfSFVCX0NBQ0hFJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwVGhlJTIwbG9jYXRpb24lMjBvZiUyMHRoZSUyMGh1Z2dpbmdmYWNlJTIwaHViJTIwY2FjaGUuJTIwVXNlZCUyMHRvJTIwb3ZlcnJpZGUlMjB0aGUlMjBsb2NhdGlvbiUyMGlmJTIweW91JTIwd2FudCUyMHRvJTIwcHJvdmlkZSUyMGElMjBtb3VudGVkJTIwZGlzayUyMGZvciUyMGluc3RhbmNlJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwSFVHR0lOR0ZBQ0VfSFVCX0NBQ0hFJTNEJTVEJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwLS1wYXlsb2FkLWxpbWl0JTIwJTNDUEFZTE9BRF9MSU1JVCUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFBheWxvYWQlMjBzaXplJTIwbGltaXQlMjBpbiUyMGJ5dGVzJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwRGVmYXVsdCUyMGlzJTIwMk1CJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwUEFZTE9BRF9MSU1JVCUzRCU1RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmRlZmF1bHQlM0ElMjAyMDAwMDAwJTVEJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwLS1hcGkta2V5JTIwJTNDQVBJX0tFWSUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFNldCUyMGFuJTIwYXBpJTIwa2V5JTIwZm9yJTIwcmVxdWVzdCUyMGF1dGhvcml6YXRpb24uJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwQnklMjBkZWZhdWx0JTIwdGhlJTIwc2VydmVyJTIwcmVzcG9uZHMlMjB0byUyMGV2ZXJ5JTIwcmVxdWVzdC4lMjBXaXRoJTIwYW4lMjBhcGklMjBrZXklMjBzZXQlMkMlMjB0aGUlMjByZXF1ZXN0cyUyMG11c3QlMjBoYXZlJTIwdGhlJTIwQXV0aG9yaXphdGlvbiUyMGhlYWRlciUyMHNldCUyMHdpdGglMjB0aGUlMjBhcGklMjBrZXklMjBhcyUyMEJlYXJlciUyMHRva2VuLiUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmVudiUzQSUyMEFQSV9LRVklM0QlNUQlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAtLWpzb24tb3V0cHV0JTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwT3V0cHV0cyUyMHRoZSUyMGxvZ3MlMjBpbiUyMEpTT04lMjBmb3JtYXQlMjAodXNlZnVsJTIwZm9yJTIwdGVsZW1ldHJ5KSUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmVudiUzQSUyMEpTT05fT1VUUFVUJTNEJTVEJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwLS1kaXNhYmxlLXNwYW5zJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwRElTQUJMRV9TUEFOUyUzRCU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0tb3RscC1lbmRwb2ludCUyMCUzQ09UTFBfRU5EUE9JTlQlM0UlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBUaGUlMjBncnBjJTIwZW5kcG9pbnQlMjBmb3IlMjBvcGVudGVsZW1ldHJ5LiUyMFRlbGVtZXRyeSUyMGlzJTIwc2VudCUyMHRvJTIwdGhpcyUyMGVuZHBvaW50JTIwYXMlMjBPVExQJTIwb3ZlciUyMGdSUEMuJTIwZS5nLiUyMCU2MGh0dHAlM0ElMkYlMkZsb2NhbGhvc3QlM0E0MzE3JTYwJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwT1RMUF9FTkRQT0lOVCUzRCU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0tb3RscC1zZXJ2aWNlLW5hbWUlMjAlM0NPVExQX1NFUlZJQ0VfTkFNRSUzRSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFRoZSUyMHNlcnZpY2UlMjBuYW1lJTIwZm9yJTIwb3BlbnRlbGVtZXRyeS4lMjBlLmcuJTIwJTYwdGV4dC1lbWJlZGRpbmdzLWluZmVyZW5jZS5zZXJ2ZXIlNjAlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJlbnYlM0ElMjBPVExQX1NFUlZJQ0VfTkFNRSUzRCU1RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmRlZmF1bHQlM0ElMjB0ZXh0LWVtYmVkZGluZ3MtaW5mZXJlbmNlLnNlcnZlciU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMC0tcHJvbWV0aGV1cy1wb3J0JTIwJTNDUFJPTUVUSEVVU19QT1JUJTNFJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwVGhlJTIwUHJvbWV0aGV1cyUyMHBvcnQlMjB0byUyMGxpc3RlbiUyMG9uJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZW52JTNBJTIwUFJPTUVUSEVVU19QT1JUJTNEJTVEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCZGVmYXVsdCUzQSUyMDkwMDAlNUQlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAtLWNvcnMtYWxsb3ctb3JpZ2luJTIwJTNDQ09SU19BTExPV19PUklHSU4lM0UlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBVbnVzZWQlMjBmb3IlMjBnUlBDJTIwc2VydmVycyUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1QmVudiUzQSUyMENPUlNfQUxMT1dfT1JJR0lOJTNEJTVEJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwLWglMkMlMjAtLWhlbHAlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBQcmludCUyMGhlbHAlMjAoc2VlJTIwYSUyMHN1bW1hcnklMjB3aXRoJTIwJy1oJyklMEElMEElMjAlMjAlMjAlMjAlMjAlMjAtViUyQyUyMC0tdmVyc2lvbiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMFByaW50JTIwdmVyc2lvbg==",highlighted:`<span class="hljs-meta prompt_">$ </span><span class="language-bash">text-embeddings-router --<span class="hljs-built_in">help</span></span>
Text Embedding Webserver

Usage: text-embeddings-router [OPTIONS]

Options:
      --model-id &lt;MODEL_ID&gt;
          The name of the model to load. Can be a MODEL_ID as listed on &lt;https://hf.co/models&gt; like \`BAAI/bge-large-en-v1.5\`. Or it can be a local directory containing the necessary files as saved by \`save_pretrained(...)\` methods of transformers

          [env: MODEL_ID=]
          [default: BAAI/bge-large-en-v1.5]

      --revision &lt;REVISION&gt;
          The actual revision of the model if you&#x27;re referring to a model on the hub. You can use a specific commit id or a branch like \`refs/pr/2\`

          [env: REVISION=]

      --tokenization-workers &lt;TOKENIZATION_WORKERS&gt;
          Optionally control the number of tokenizer workers used for payload tokenization, validation and truncation. Default to the number of CPU cores on the machine

          [env: TOKENIZATION_WORKERS=]

      --dtype &lt;DTYPE&gt;
          The dtype to be forced upon the model

          [env: DTYPE=]
          [possible values: float16, float32]

      --pooling &lt;POOLING&gt;
          Optionally control the pooling method for embedding models.

          If \`pooling\` is not set, the pooling configuration will be parsed from the model \`1_Pooling/config.json\` configuration.

          If \`pooling\` is set, it will override the model pooling configuration

          [env: POOLING=]

          Possible values:
          - cls:        Select the CLS token as embedding
          - mean:       Apply Mean pooling to the model embeddings
          - splade:     Apply SPLADE (Sparse Lexical and Expansion) to the model embeddings. This option is only available if the loaded model is a \`ForMaskedLM\` Transformer model
          - last-token: Select the last token as embedding

      --max-concurrent-requests &lt;MAX_CONCURRENT_REQUESTS&gt;
          The maximum amount of concurrent requests for this particular deployment. Having a low limit will refuse clients requests instead of having them wait for too long and is usually good to handle backpressure correctly

          [env: MAX_CONCURRENT_REQUESTS=]
          [default: 512]

      --max-batch-tokens &lt;MAX_BATCH_TOKENS&gt;
          **IMPORTANT** This is one critical control to allow maximum usage of the available hardware.

          This represents the total amount of potential tokens within a batch.

          For \`max_batch_tokens=1000\`, you could fit \`10\` queries of \`total_tokens=100\` or a single query of \`1000\` tokens.

          Overall this number should be the largest possible until the model is compute bound. Since the actual memory overhead depends on the model implementation, text-embeddings-inference cannot infer this number automatically.

          [env: MAX_BATCH_TOKENS=]
          [default: 16384]

      --max-batch-requests &lt;MAX_BATCH_REQUESTS&gt;
          Optionally control the maximum number of individual requests in a batch

          [env: MAX_BATCH_REQUESTS=]

      --max-client-batch-size &lt;MAX_CLIENT_BATCH_SIZE&gt;
          Control the maximum number of inputs that a client can send in a single request

          [env: MAX_CLIENT_BATCH_SIZE=]
          [default: 32]

      --auto-truncate
          Automatically truncate inputs that are longer than the maximum supported size

          Unused for gRPC servers

          [env: AUTO_TRUNCATE=]

      --default-prompt-name &lt;DEFAULT_PROMPT_NAME&gt;
          The name of the prompt that should be used by default for encoding. If not set, no prompt will be applied.

          Must be a key in the \`sentence-transformers\` configuration \`prompts\` dictionary.

          For example if \`\`default_prompt_name\`\` is &quot;query&quot; and the \`\`prompts\`\` is {&quot;query&quot;: &quot;query: &quot;, ...}, then the sentence &quot;What is the capital of France?&quot; will be encoded as &quot;query: What is the capital of France?&quot; because the prompt text will be prepended before any text to encode.

          The argument &#x27;--default-prompt-name &lt;DEFAULT_PROMPT_NAME&gt;&#x27; cannot be used with &#x27;--default-prompt &lt;DEFAULT_PROMPT&gt;\`

          [env: DEFAULT_PROMPT_NAME=]

      --default-prompt &lt;DEFAULT_PROMPT&gt;
          The prompt that should be used by default for encoding. If not set, no prompt will be applied.

          For example if \`\`default_prompt\`\` is &quot;query: &quot; then the sentence &quot;What is the capital of France?&quot; will be encoded as &quot;query: What is the capital of France?&quot; because the prompt text will be prepended before any text to encode.

          The argument &#x27;--default-prompt &lt;DEFAULT_PROMPT&gt;&#x27; cannot be used with &#x27;--default-prompt-name &lt;DEFAULT_PROMPT_NAME&gt;\`

          [env: DEFAULT_PROMPT=]

      --hf-token &lt;HF_TOKEN&gt;
          Your Hugging Face Hub token

          [env: HF_TOKEN=]

      --hostname &lt;HOSTNAME&gt;
          The IP address to listen on

          [env: HOSTNAME=]
          [default: 0.0.0.0]

      -p, --port &lt;PORT&gt;
          The port to listen on

          [env: PORT=]
          [default: 3000]

      --uds-path &lt;UDS_PATH&gt;
          The name of the unix socket some text-embeddings-inference backends will use as they communicate internally with gRPC

          [env: UDS_PATH=]
          [default: /tmp/text-embeddings-inference-server]

      --huggingface-hub-cache &lt;HUGGINGFACE_HUB_CACHE&gt;
          The location of the huggingface hub cache. Used to override the location if you want to provide a mounted disk for instance

          [env: HUGGINGFACE_HUB_CACHE=]

      --payload-limit &lt;PAYLOAD_LIMIT&gt;
          Payload size limit in bytes

          Default is 2MB

          [env: PAYLOAD_LIMIT=]
          [default: 2000000]

      --api-key &lt;API_KEY&gt;
          Set an api key for request authorization.

          By default the server responds to every request. With an api key set, the requests must have the Authorization header set with the api key as Bearer token.

          [env: API_KEY=]

      --json-output
          Outputs the logs in JSON format (useful for telemetry)

          [env: JSON_OUTPUT=]

      --disable-spans
          [env: DISABLE_SPANS=]

      --otlp-endpoint &lt;OTLP_ENDPOINT&gt;
          The grpc endpoint for opentelemetry. Telemetry is sent to this endpoint as OTLP over gRPC. e.g. \`http://localhost:4317\`

          [env: OTLP_ENDPOINT=]

      --otlp-service-name &lt;OTLP_SERVICE_NAME&gt;
          The service name for opentelemetry. e.g. \`text-embeddings-inference.server\`

          [env: OTLP_SERVICE_NAME=]
          [default: text-embeddings-inference.server]

      --prometheus-port &lt;PROMETHEUS_PORT&gt;
          The Prometheus port to listen on

          [env: PROMETHEUS_PORT=]
          [default: 9000]

      --cors-allow-origin &lt;CORS_ALLOW_ORIGIN&gt;
          Unused for gRPC servers

          [env: CORS_ALLOW_ORIGIN=]

      -h, --help
          Print help (see a summary with &#x27;-h&#x27;)

      -V, --version
          Print version`,wrap:!1}}),e=new k({props:{source:"https://github.com/huggingface/text-embeddings-inference/blob/main/docs/source/en/cli_arguments.md"}}),{c(){U=m("meta"),B=t(),C=m("p"),n=t(),c(w.$$.fragment),A=t(),y=m("p"),y.textContent=R,o=t(),c(I.$$.fragment),b=t(),c(e.$$.fragment),d=t(),a=m("p"),this.h()},l(M){const l=Y("svelte-u9bgzb",document.head);U=s(l,"META",{name:!0,content:!0}),l.forEach(T),B=j(M),C=s(M,"P",{}),r(C).forEach(T),n=j(M),G(w.$$.fragment,M),A=j(M),y=s(M,"P",{"data-svelte-h":!0}),X(y)!=="svelte-1d21239"&&(y.textContent=R),o=j(M),G(I.$$.fragment,M),b=j(M),G(e.$$.fragment,M),d=j(M),a=s(M,"P",{}),r(a).forEach(T),this.h()},h(){N(U,"name","hf:doc:metadata"),N(U,"content",z)},m(M,l){v(document.head,U),J(M,B,l),J(M,C,l),J(M,n,l),Z(w,M,l),J(M,A,l),J(M,y,l),J(M,o,l),Z(I,M,l),J(M,b,l),Z(e,M,l),J(M,d,l),J(M,a,l),i=!0},p,i(M){i||(V(w.$$.fragment,M),V(I.$$.fragment,M),V(e.$$.fragment,M),i=!0)},o(M){E(w.$$.fragment,M),E(I.$$.fragment,M),E(e.$$.fragment,M),i=!1},d(M){M&&(T(B),T(C),T(n),T(A),T(y),T(o),T(b),T(d),T(a)),T(U),h(w,M),h(I,M),h(e,M)}}}const z='{"title":"CLI arguments","local":"cli-arguments","sections":[],"depth":1}';function x(u){return W(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class D extends Q{constructor(U){super(),F(this,U,x,g,S,{})}}export{D as component};
