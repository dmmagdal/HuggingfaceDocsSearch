var s;const t=((s=globalThis.__sveltekit_kfuw8p)==null?void 0:s.base)??"/docs/setfit/main/en";var e;const a=((e=globalThis.__sveltekit_kfuw8p)==null?void 0:e.assets)??t;export{a,t as b};
