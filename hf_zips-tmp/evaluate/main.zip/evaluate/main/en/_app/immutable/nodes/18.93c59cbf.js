import{s as j,n as G,o as O}from"../chunks/scheduler.7da89386.js";import{S as U,i as W,g as f,s as l,r as y,A as B,h,f as a,c as r,j as H,u as C,x as I,k as S,y as F,a as o,v as D,d as E,t as P,w as L}from"../chunks/index.20910acc.js";import{D as J}from"../chunks/Docstring.f6b633ee.js";import{H as N,E as K}from"../chunks/EditOnGithub.ba36cbd0.js";function Q(R){let n,_,g,x,s,b,d,V="Methods for visualizing evaluations results:",$,c,z,i,p,M,m,A=`Create a complex radar chart with different scales for each variable
Source: <a href="https://towardsdatascience.com/how-to-create-and-visualize-complex-radar-charts-f7764d0f3652" rel="nofollow">https://towardsdatascience.com/how-to-create-and-visualize-complex-radar-charts-f7764d0f3652</a>`,w,u,T,v,k;return s=new N({props:{title:"Visualization methods",local:"visualization-methods",headingTag:"h1"}}),c=new N({props:{title:"Radar Plot",local:"evaluate.visualization.radar_plot",headingTag:"h2"}}),p=new J({props:{name:"evaluate.visualization.radar_plot",anchor:"evaluate.visualization.radar_plot",parameters:[{name:"data",val:""},{name:"model_names",val:""},{name:"invert_range",val:" = []"},{name:"config",val:" = None"},{name:"fig",val:" = None"}],parametersDescription:[{anchor:"evaluate.visualization.radar_plot.data",description:`<strong>data</strong> (<code>List[dict]</code>) &#x2014; the results (list of metric + value pairs).
E.g. data = [{&#x201C;accuracy&#x201D;: 0.9, &#x201C;precision&#x201D;:0.8},{&#x201C;accuracy&#x201D;: 0.7, &#x201C;precision&#x201D;:0.6}]`,name:"data"},{anchor:"evaluate.visualization.radar_plot.names",description:`<strong>names</strong> (<code>List[dict]</code>) &#x2014; model names.
E.g. names = [&#x201C;model1&#x201D;, &#x201C;model 2&#x201D;, &#x2026;]`,name:"names"},{anchor:"evaluate.visualization.radar_plot.invert_range",description:`<strong>invert_range</strong> (<code>List[dict]</code>, optional) &#x2014; the metrics to invert (in cases when smaller is better, e.g. speed)
E.g. invert_range=[&#x201C;latency_in_seconds&#x201D;]`,name:"invert_range"},{anchor:"evaluate.visualization.radar_plot.config",description:`<strong>config</strong> (<code>dict</code>, optional)  &#x2014; a specification of the formatting configurations, namely:</p>
<ul>
<li>
<p>rad_ln_args (<code>dict</code>, default <code>{&quot;visible&quot;: True}</code>): The visibility of the radial (circle) lines.</p>
</li>
<li>
<p>outer_ring (<code>dict</code>, default <code>{&quot;visible&quot;: True}</code>): The visibility of the outer ring.</p>
</li>
<li>
<p>angle_ln_args (<code>dict</code>, default <code>{&quot;visible&quot;: True}</code>): The visibility of the angle lines.</p>
</li>
<li>
<p>rgrid_tick_lbls_args (<code>dict</code>, default <code>{&quot;fontsize&quot;: 12}</code>): The font size of the tick labels on the scales.</p>
</li>
<li>
<p>theta_tick_lbls (<code>dict</code>, default <code>{&quot;fontsize&quot;: 12}</code>): The font size of the variable labels on the plot.</p>
</li>
<li>
<p>theta_tick_lbls_pad (<code>int</code>, default <code>3</code>): The padding of the variable labels on the plot.</p>
</li>
<li>
<p>theta_tick_lbls_brk_lng_wrds (<code>bool</code>, default <code>True</code> ): Whether long words in the label are broken up or not.</p>
</li>
<li>
<p>theta_tick_lbls_txt_wrap (<code>int</code>, default <code>15</code>): Text wrap for tick labels</p>
</li>
<li>
<p>incl_endpoint (<code>bool</code>, default <code>False</code>): Include value endpoints on calse</p>
</li>
<li>
<p>marker (<code>str</code>, default <code>&quot;o&quot;</code>): the shape of the marker used in the radar plot.</p>
</li>
<li>
<p>markersize (<code>int</code>, default <code>3</code>): the shape of the marker used in the radar plot.</p>
</li>
<li>
<p>legend_loc (<code>str</code>, default <code>&quot;upper right&quot;</code>): the location of the legend in the radar plot. Must be one of: &#x2018;upper left&#x2019;, &#x2018;upper right&#x2019;, &#x2018;lower left&#x2019;, &#x2018;lower right&#x2019;.</p>
</li>
<li>
<p>bbox_to_anchor (<code>tuple</code>, default <code>(2, 1)</code>: anchor for the legend.</p>
</li>
</ul>`,name:"config"},{anchor:"evaluate.visualization.radar_plot.fig",description:"<strong>fig</strong> (<code>matplotlib.figure.Figure</code>, optional) &#x2014; figure used to plot the radar plot.",name:"fig"}],source:"https://github.com/huggingface/evaluate/blob/main/src/evaluate/visualization.py#L138",returnDescription:`<script context="module">export const metadata = 'undefined';<\/script>


<p><code>matplotlib.figure.Figure</code></p>
`}}),u=new K({props:{source:"https://github.com/huggingface/evaluate/blob/main/docs/source/package_reference/visualization_methods.mdx"}}),{c(){n=f("meta"),_=l(),g=f("p"),x=l(),y(s.$$.fragment),b=l(),d=f("p"),d.textContent=V,$=l(),y(c.$$.fragment),z=l(),i=f("div"),y(p.$$.fragment),M=l(),m=f("p"),m.innerHTML=A,w=l(),y(u.$$.fragment),T=l(),v=f("p"),this.h()},l(e){const t=B("svelte-u9bgzb",document.head);n=h(t,"META",{name:!0,content:!0}),t.forEach(a),_=r(e),g=h(e,"P",{}),H(g).forEach(a),x=r(e),C(s.$$.fragment,e),b=r(e),d=h(e,"P",{"data-svelte-h":!0}),I(d)!=="svelte-l0fsuf"&&(d.textContent=V),$=r(e),C(c.$$.fragment,e),z=r(e),i=h(e,"DIV",{class:!0});var q=H(i);C(p.$$.fragment,q),M=r(q),m=h(q,"P",{"data-svelte-h":!0}),I(m)!=="svelte-15m4dvt"&&(m.innerHTML=A),q.forEach(a),w=r(e),C(u.$$.fragment,e),T=r(e),v=h(e,"P",{}),H(v).forEach(a),this.h()},h(){S(n,"name","hf:doc:metadata"),S(n,"content",X),S(i,"class","docstring border-l-2 border-t-2 pl-4 pt-3.5 border-gray-100 rounded-tl-xl mb-6 mt-8")},m(e,t){F(document.head,n),o(e,_,t),o(e,g,t),o(e,x,t),D(s,e,t),o(e,b,t),o(e,d,t),o(e,$,t),D(c,e,t),o(e,z,t),o(e,i,t),D(p,i,null),F(i,M),F(i,m),o(e,w,t),D(u,e,t),o(e,T,t),o(e,v,t),k=!0},p:G,i(e){k||(E(s.$$.fragment,e),E(c.$$.fragment,e),E(p.$$.fragment,e),E(u.$$.fragment,e),k=!0)},o(e){P(s.$$.fragment,e),P(c.$$.fragment,e),P(p.$$.fragment,e),P(u.$$.fragment,e),k=!1},d(e){e&&(a(_),a(g),a(x),a(b),a(d),a($),a(z),a(i),a(w),a(T),a(v)),a(n),L(s,e),L(c,e),L(p),L(u,e)}}}const X='{"title":"Visualization methods","local":"visualization-methods","sections":[{"title":"Radar Plot","local":"evaluate.visualization.radar_plot","sections":[],"depth":2}],"depth":1}';function Y(R){return O(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class oe extends U{constructor(n){super(),W(this,n,Y,Q,j,{})}}export{oe as component};
