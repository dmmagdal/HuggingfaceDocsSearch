var Rt=Object.defineProperty;var Bt=(e,a,t)=>a in e?Rt(e,a,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[a]=t;var _=(e,a,t)=>(Bt(e,typeof a!="symbol"?a+"":a,t),t);import{s as Ne,n as _e}from"./scheduler.389d799c.js";import{S as De,i as Pe,B as et,C as tt,j as O,f as A,k as w,a as H,y as S,e as at,p as qt,t as Q,b as Vt,d as J,g as C,r as ne,s as X,m as oe,h as U,u as re,c as Y,n as se,v as le,o as ce,w as pe,x as Ue}from"./index.8f81d18f.js";function Ft(e){let a,t;return{c(){a=et("svg"),t=et("path"),this.h()},l(i){a=tt(i,"svg",{class:!0,xmlns:!0,"xmlns:xlink":!0,"aria-hidden":!0,role:!0,width:!0,height:!0,preserveAspectRatio:!0,viewBox:!0});var n=O(a);t=tt(n,"path",{d:!0,fill:!0}),O(t).forEach(A),n.forEach(A),this.h()},h(){w(t,"d","M167.594 88.393a8.001 8.001 0 0 1 0 11.314l-67.882 67.882a8 8 0 1 1-11.314-11.315l67.882-67.881a8.003 8.003 0 0 1 11.314 0zm-28.287 84.86l-28.284 28.284a40 40 0 0 1-56.567-56.567l28.284-28.284a8 8 0 0 0-11.315-11.315l-28.284 28.284a56 56 0 0 0 79.196 79.197l28.285-28.285a8 8 0 1 0-11.315-11.314zM212.852 43.14a56.002 56.002 0 0 0-79.196 0l-28.284 28.284a8 8 0 1 0 11.314 11.314l28.284-28.284a40 40 0 0 1 56.568 56.567l-28.285 28.285a8 8 0 0 0 11.315 11.314l28.284-28.284a56.065 56.065 0 0 0 0-79.196z"),w(t,"fill","currentColor"),w(a,"class",e[0]),w(a,"xmlns","http://www.w3.org/2000/svg"),w(a,"xmlns:xlink","http://www.w3.org/1999/xlink"),w(a,"aria-hidden","true"),w(a,"role","img"),w(a,"width","1em"),w(a,"height","1em"),w(a,"preserveAspectRatio","xMidYMid meet"),w(a,"viewBox","0 0 256 256")},m(i,n){H(i,a,n),S(a,t)},p(i,[n]){n&1&&w(a,"class",i[0])},i:_e,o:_e,d(i){i&&A(a)}}}function zt(e,a,t){let{classNames:i=""}=a;return e.$$set=n=>{"classNames"in n&&t(0,i=n.classNames)},[i]}class de extends De{constructor(a){super(),Pe(this,a,zt,Ft,Ne,{classNames:0})}}function Ht(e){let a,t,i,n,o,r,u,d,p;return n=new de({}),{c(){a=C("h6"),t=C("a"),i=C("span"),ne(n.$$.fragment),r=X(),u=C("span"),d=oe(e[0]),this.h()},l(c){a=U(c,"H6",{class:!0});var l=O(a);t=U(l,"A",{id:!0,class:!0,href:!0});var h=O(t);i=U(h,"SPAN",{});var g=O(i);re(n.$$.fragment,g),g.forEach(A),h.forEach(A),r=Y(l),u=U(l,"SPAN",{});var b=O(u);d=se(b,e[0]),b.forEach(A),l.forEach(A),this.h()},h(){w(t,"id",e[1]),w(t,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),w(t,"href",o="#"+e[1]),w(a,"class","relative group")},m(c,l){H(c,a,l),S(a,t),S(t,i),le(n,i,null),S(a,r),S(a,u),S(u,d),p=!0},p(c,l){(!p||l&2)&&w(t,"id",c[1]),(!p||l&2&&o!==(o="#"+c[1]))&&w(t,"href",o),(!p||l&1)&&ce(d,c[0])},i(c){p||(J(n.$$.fragment,c),p=!0)},o(c){Q(n.$$.fragment,c),p=!1},d(c){c&&A(a),pe(n)}}}function Wt(e){let a,t,i,n,o,r,u,d,p;return n=new de({}),{c(){a=C("h5"),t=C("a"),i=C("span"),ne(n.$$.fragment),r=X(),u=C("span"),d=oe(e[0]),this.h()},l(c){a=U(c,"H5",{class:!0});var l=O(a);t=U(l,"A",{id:!0,class:!0,href:!0});var h=O(t);i=U(h,"SPAN",{});var g=O(i);re(n.$$.fragment,g),g.forEach(A),h.forEach(A),r=Y(l),u=U(l,"SPAN",{});var b=O(u);d=se(b,e[0]),b.forEach(A),l.forEach(A),this.h()},h(){w(t,"id",e[1]),w(t,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),w(t,"href",o="#"+e[1]),w(a,"class","relative group")},m(c,l){H(c,a,l),S(a,t),S(t,i),le(n,i,null),S(a,r),S(a,u),S(u,d),p=!0},p(c,l){(!p||l&2)&&w(t,"id",c[1]),(!p||l&2&&o!==(o="#"+c[1]))&&w(t,"href",o),(!p||l&1)&&ce(d,c[0])},i(c){p||(J(n.$$.fragment,c),p=!0)},o(c){Q(n.$$.fragment,c),p=!1},d(c){c&&A(a),pe(n)}}}function Kt(e){let a,t,i,n,o,r,u,d,p;return n=new de({}),{c(){a=C("h4"),t=C("a"),i=C("span"),ne(n.$$.fragment),r=X(),u=C("span"),d=oe(e[0]),this.h()},l(c){a=U(c,"H4",{class:!0});var l=O(a);t=U(l,"A",{id:!0,class:!0,href:!0});var h=O(t);i=U(h,"SPAN",{});var g=O(i);re(n.$$.fragment,g),g.forEach(A),h.forEach(A),r=Y(l),u=U(l,"SPAN",{});var b=O(u);d=se(b,e[0]),b.forEach(A),l.forEach(A),this.h()},h(){w(t,"id",e[1]),w(t,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),w(t,"href",o="#"+e[1]),w(a,"class","relative group")},m(c,l){H(c,a,l),S(a,t),S(t,i),le(n,i,null),S(a,r),S(a,u),S(u,d),p=!0},p(c,l){(!p||l&2)&&w(t,"id",c[1]),(!p||l&2&&o!==(o="#"+c[1]))&&w(t,"href",o),(!p||l&1)&&ce(d,c[0])},i(c){p||(J(n.$$.fragment,c),p=!0)},o(c){Q(n.$$.fragment,c),p=!1},d(c){c&&A(a),pe(n)}}}function Qt(e){let a,t,i,n,o,r,u,d,p;return n=new de({}),{c(){a=C("h3"),t=C("a"),i=C("span"),ne(n.$$.fragment),r=X(),u=C("span"),d=oe(e[0]),this.h()},l(c){a=U(c,"H3",{class:!0});var l=O(a);t=U(l,"A",{id:!0,class:!0,href:!0});var h=O(t);i=U(h,"SPAN",{});var g=O(i);re(n.$$.fragment,g),g.forEach(A),h.forEach(A),r=Y(l),u=U(l,"SPAN",{});var b=O(u);d=se(b,e[0]),b.forEach(A),l.forEach(A),this.h()},h(){w(t,"id",e[1]),w(t,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),w(t,"href",o="#"+e[1]),w(a,"class","relative group")},m(c,l){H(c,a,l),S(a,t),S(t,i),le(n,i,null),S(a,r),S(a,u),S(u,d),p=!0},p(c,l){(!p||l&2)&&w(t,"id",c[1]),(!p||l&2&&o!==(o="#"+c[1]))&&w(t,"href",o),(!p||l&1)&&ce(d,c[0])},i(c){p||(J(n.$$.fragment,c),p=!0)},o(c){Q(n.$$.fragment,c),p=!1},d(c){c&&A(a),pe(n)}}}function Jt(e){let a,t,i,n,o,r,u,d,p;return n=new de({}),{c(){a=C("h2"),t=C("a"),i=C("span"),ne(n.$$.fragment),r=X(),u=C("span"),d=oe(e[0]),this.h()},l(c){a=U(c,"H2",{class:!0});var l=O(a);t=U(l,"A",{id:!0,class:!0,href:!0});var h=O(t);i=U(h,"SPAN",{});var g=O(i);re(n.$$.fragment,g),g.forEach(A),h.forEach(A),r=Y(l),u=U(l,"SPAN",{});var b=O(u);d=se(b,e[0]),b.forEach(A),l.forEach(A),this.h()},h(){w(t,"id",e[1]),w(t,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),w(t,"href",o="#"+e[1]),w(a,"class","relative group")},m(c,l){H(c,a,l),S(a,t),S(t,i),le(n,i,null),S(a,r),S(a,u),S(u,d),p=!0},p(c,l){(!p||l&2)&&w(t,"id",c[1]),(!p||l&2&&o!==(o="#"+c[1]))&&w(t,"href",o),(!p||l&1)&&ce(d,c[0])},i(c){p||(J(n.$$.fragment,c),p=!0)},o(c){Q(n.$$.fragment,c),p=!1},d(c){c&&A(a),pe(n)}}}function Xt(e){let a,t,i,n,o,r,u,d,p;return n=new de({}),{c(){a=C("h1"),t=C("a"),i=C("span"),ne(n.$$.fragment),r=X(),u=C("span"),d=oe(e[0]),this.h()},l(c){a=U(c,"H1",{class:!0});var l=O(a);t=U(l,"A",{id:!0,class:!0,href:!0});var h=O(t);i=U(h,"SPAN",{});var g=O(i);re(n.$$.fragment,g),g.forEach(A),h.forEach(A),r=Y(l),u=U(l,"SPAN",{});var b=O(u);d=se(b,e[0]),b.forEach(A),l.forEach(A),this.h()},h(){w(t,"id",e[1]),w(t,"class","header-link block pr-1.5 text-lg no-hover:hidden with-hover:absolute with-hover:p-1.5 with-hover:opacity-0 with-hover:group-hover:opacity-100 with-hover:right-full"),w(t,"href",o="#"+e[1]),w(a,"class","relative group")},m(c,l){H(c,a,l),S(a,t),S(t,i),le(n,i,null),S(a,r),S(a,u),S(u,d),p=!0},p(c,l){(!p||l&2)&&w(t,"id",c[1]),(!p||l&2&&o!==(o="#"+c[1]))&&w(t,"href",o),(!p||l&1)&&ce(d,c[0])},i(c){p||(J(n.$$.fragment,c),p=!0)},o(c){Q(n.$$.fragment,c),p=!1},d(c){c&&A(a),pe(n)}}}function Yt(e){let a,t,i,n;const o=[Xt,Jt,Qt,Kt,Wt,Ht],r=[];function u(d,p){return d[2]==="h1"?0:d[2]==="h2"?1:d[2]==="h3"?2:d[2]==="h4"?3:d[2]==="h5"?4:5}return a=u(e),t=r[a]=o[a](e),{c(){t.c(),i=at()},l(d){t.l(d),i=at()},m(d,p){r[a].m(d,p),H(d,i,p),n=!0},p(d,[p]){let c=a;a=u(d),a===c?r[a].p(d,p):(qt(),Q(r[c],1,1,()=>{r[c]=null}),Vt(),t=r[a],t?t.p(d,p):(t=r[a]=o[a](d),t.c()),J(t,1),t.m(i.parentNode,i))},i(d){n||(J(t),n=!0)},o(d){Q(t),n=!1},d(d){d&&A(i),r[a].d(d)}}}function Zt(e,a,t){let{title:i}=a,{local:n}=a,{headingTag:o}=a;return e.$$set=r=>{"title"in r&&t(0,i=r.title),"local"in r&&t(1,n=r.local),"headingTag"in r&&t(2,o=r.headingTag)},[i,n,o]}class Sl extends De{constructor(a){super(),Pe(this,a,Zt,Yt,Ne,{title:0,local:1,headingTag:2})}}function Gt(e){let a,t,i="<",n,o,r=">",u,d,p='<span class="underline ml-1.5">Update</span> on GitHub';return{c(){a=C("a"),t=C("span"),t.textContent=i,n=X(),o=C("span"),o.textContent=r,u=X(),d=C("span"),d.innerHTML=p,this.h()},l(c){a=U(c,"A",{class:!0,href:!0,target:!0});var l=O(a);t=U(l,"SPAN",{"data-svelte-h":!0}),Ue(t)!=="svelte-1kd6by1"&&(t.textContent=i),n=Y(l),o=U(l,"SPAN",{"data-svelte-h":!0}),Ue(o)!=="svelte-x0xyl0"&&(o.textContent=r),u=Y(l),d=U(l,"SPAN",{"data-svelte-h":!0}),Ue(d)!=="svelte-1dajgef"&&(d.innerHTML=p),l.forEach(A),this.h()},h(){w(a,"class","!text-gray-400 !no-underline text-sm flex items-center not-prose mt-4"),w(a,"href",e[0]),w(a,"target","_blank")},m(c,l){H(c,a,l),S(a,t),S(a,n),S(a,o),S(a,u),S(a,d)},p(c,[l]){l&1&&w(a,"href",c[0])},i:_e,o:_e,d(c){c&&A(a)}}}function ea(e,a,t){let{source:i=""}=a;return e.$$set=n=>{"source"in n&&t(0,i=n.source)},[i]}class Il extends De{constructor(a){super(),Pe(this,a,ea,Gt,Ne,{source:0})}}const ta={"adapter-transformers":["question-answering","text-classification","token-classification"],allennlp:["question-answering"],asteroid:["audio-to-audio"],bertopic:["text-classification"],diffusers:["image-to-image","text-to-image"],doctr:["object-detection"],espnet:["text-to-speech","automatic-speech-recognition"],fairseq:["text-to-speech","audio-to-audio"],fastai:["image-classification"],fasttext:["feature-extraction","text-classification"],flair:["token-classification"],k2:["automatic-speech-recognition"],keras:["image-classification"],nemo:["automatic-speech-recognition"],open_clip:["zero-shot-classification","zero-shot-image-classification"],paddlenlp:["fill-mask","summarization","zero-shot-classification"],peft:["text-generation"],"pyannote-audio":["automatic-speech-recognition"],"sentence-transformers":["feature-extraction","sentence-similarity"],setfit:["text-classification"],sklearn:["tabular-classification","tabular-regression","text-classification"],spacy:["token-classification","text-classification","sentence-similarity"],"span-marker":["token-classification"],speechbrain:["audio-classification","audio-to-audio","automatic-speech-recognition","text-to-speech","text2text-generation"],stanza:["token-classification"],timm:["image-classification","image-feature-extraction"],transformers:["audio-classification","automatic-speech-recognition","depth-estimation","document-question-answering","feature-extraction","fill-mask","image-classification","image-feature-extraction","image-segmentation","image-to-image","image-to-text","image-text-to-text","mask-generation","object-detection","question-answering","summarization","table-question-answering","text2text-generation","text-classification","text-generation","text-to-audio","text-to-speech","token-classification","translation","video-classification","visual-question-answering","zero-shot-classification","zero-shot-image-classification","zero-shot-object-detection"],mindspore:["image-classification"]},je={"text-classification":{name:"Text Classification",subtasks:[{type:"acceptability-classification",name:"Acceptability Classification"},{type:"entity-linking-classification",name:"Entity Linking Classification"},{type:"fact-checking",name:"Fact Checking"},{type:"intent-classification",name:"Intent Classification"},{type:"language-identification",name:"Language Identification"},{type:"multi-class-classification",name:"Multi Class Classification"},{type:"multi-label-classification",name:"Multi Label Classification"},{type:"multi-input-text-classification",name:"Multi-input Text Classification"},{type:"natural-language-inference",name:"Natural Language Inference"},{type:"semantic-similarity-classification",name:"Semantic Similarity Classification"},{type:"sentiment-classification",name:"Sentiment Classification"},{type:"topic-classification",name:"Topic Classification"},{type:"semantic-similarity-scoring",name:"Semantic Similarity Scoring"},{type:"sentiment-scoring",name:"Sentiment Scoring"},{type:"sentiment-analysis",name:"Sentiment Analysis"},{type:"hate-speech-detection",name:"Hate Speech Detection"},{type:"text-scoring",name:"Text Scoring"}],modality:"nlp",color:"orange"},"token-classification":{name:"Token Classification",subtasks:[{type:"named-entity-recognition",name:"Named Entity Recognition"},{type:"part-of-speech",name:"Part of Speech"},{type:"parsing",name:"Parsing"},{type:"lemmatization",name:"Lemmatization"},{type:"word-sense-disambiguation",name:"Word Sense Disambiguation"},{type:"coreference-resolution",name:"Coreference-resolution"}],modality:"nlp",color:"blue"},"table-question-answering":{name:"Table Question Answering",modality:"nlp",color:"green"},"question-answering":{name:"Question Answering",subtasks:[{type:"extractive-qa",name:"Extractive QA"},{type:"open-domain-qa",name:"Open Domain QA"},{type:"closed-domain-qa",name:"Closed Domain QA"}],modality:"nlp",color:"blue"},"zero-shot-classification":{name:"Zero-Shot Classification",modality:"nlp",color:"yellow"},translation:{name:"Translation",modality:"nlp",color:"green"},summarization:{name:"Summarization",subtasks:[{type:"news-articles-summarization",name:"News Articles Summarization"},{type:"news-articles-headline-generation",name:"News Articles Headline Generation"}],modality:"nlp",color:"indigo"},"feature-extraction":{name:"Feature Extraction",modality:"nlp",color:"red"},"text-generation":{name:"Text Generation",subtasks:[{type:"dialogue-modeling",name:"Dialogue Modeling"},{type:"dialogue-generation",name:"Dialogue Generation"},{type:"conversational",name:"Conversational"},{type:"language-modeling",name:"Language Modeling"}],modality:"nlp",color:"indigo"},"text2text-generation":{name:"Text2Text Generation",subtasks:[{type:"text-simplification",name:"Text simplification"},{type:"explanation-generation",name:"Explanation Generation"},{type:"abstractive-qa",name:"Abstractive QA"},{type:"open-domain-abstractive-qa",name:"Open Domain Abstractive QA"},{type:"closed-domain-qa",name:"Closed Domain QA"},{type:"open-book-qa",name:"Open Book QA"},{type:"closed-book-qa",name:"Closed Book QA"}],modality:"nlp",color:"indigo"},"fill-mask":{name:"Fill-Mask",subtasks:[{type:"slot-filling",name:"Slot Filling"},{type:"masked-language-modeling",name:"Masked Language Modeling"}],modality:"nlp",color:"red"},"sentence-similarity":{name:"Sentence Similarity",modality:"nlp",color:"yellow"},"text-to-speech":{name:"Text-to-Speech",modality:"audio",color:"yellow"},"text-to-audio":{name:"Text-to-Audio",modality:"audio",color:"yellow"},"automatic-speech-recognition":{name:"Automatic Speech Recognition",modality:"audio",color:"yellow"},"audio-to-audio":{name:"Audio-to-Audio",modality:"audio",color:"blue"},"audio-classification":{name:"Audio Classification",subtasks:[{type:"keyword-spotting",name:"Keyword Spotting"},{type:"speaker-identification",name:"Speaker Identification"},{type:"audio-intent-classification",name:"Audio Intent Classification"},{type:"audio-emotion-recognition",name:"Audio Emotion Recognition"},{type:"audio-language-identification",name:"Audio Language Identification"}],modality:"audio",color:"green"},"audio-text-to-text":{name:"Audio-Text-to-Text",modality:"multimodal",color:"red",hideInDatasets:!0},"voice-activity-detection":{name:"Voice Activity Detection",modality:"audio",color:"red"},"depth-estimation":{name:"Depth Estimation",modality:"cv",color:"yellow"},"image-classification":{name:"Image Classification",subtasks:[{type:"multi-label-image-classification",name:"Multi Label Image Classification"},{type:"multi-class-image-classification",name:"Multi Class Image Classification"}],modality:"cv",color:"blue"},"object-detection":{name:"Object Detection",subtasks:[{type:"face-detection",name:"Face Detection"},{type:"vehicle-detection",name:"Vehicle Detection"}],modality:"cv",color:"yellow"},"image-segmentation":{name:"Image Segmentation",subtasks:[{type:"instance-segmentation",name:"Instance Segmentation"},{type:"semantic-segmentation",name:"Semantic Segmentation"},{type:"panoptic-segmentation",name:"Panoptic Segmentation"}],modality:"cv",color:"green"},"text-to-image":{name:"Text-to-Image",modality:"cv",color:"yellow"},"image-to-text":{name:"Image-to-Text",subtasks:[{type:"image-captioning",name:"Image Captioning"}],modality:"cv",color:"red"},"image-to-image":{name:"Image-to-Image",subtasks:[{type:"image-inpainting",name:"Image Inpainting"},{type:"image-colorization",name:"Image Colorization"},{type:"super-resolution",name:"Super Resolution"}],modality:"cv",color:"indigo"},"image-to-video":{name:"Image-to-Video",modality:"cv",color:"indigo"},"unconditional-image-generation":{name:"Unconditional Image Generation",modality:"cv",color:"green"},"video-classification":{name:"Video Classification",modality:"cv",color:"blue"},"reinforcement-learning":{name:"Reinforcement Learning",modality:"rl",color:"red"},robotics:{name:"Robotics",modality:"rl",subtasks:[{type:"grasping",name:"Grasping"},{type:"task-planning",name:"Task Planning"}],color:"blue"},"tabular-classification":{name:"Tabular Classification",modality:"tabular",subtasks:[{type:"tabular-multi-class-classification",name:"Tabular Multi Class Classification"},{type:"tabular-multi-label-classification",name:"Tabular Multi Label Classification"}],color:"blue"},"tabular-regression":{name:"Tabular Regression",modality:"tabular",subtasks:[{type:"tabular-single-column-regression",name:"Tabular Single Column Regression"}],color:"blue"},"tabular-to-text":{name:"Tabular to Text",modality:"tabular",subtasks:[{type:"rdf-to-text",name:"RDF to text"}],color:"blue",hideInModels:!0},"table-to-text":{name:"Table to Text",modality:"nlp",color:"blue",hideInModels:!0},"multiple-choice":{name:"Multiple Choice",subtasks:[{type:"multiple-choice-qa",name:"Multiple Choice QA"},{type:"multiple-choice-coreference-resolution",name:"Multiple Choice Coreference Resolution"}],modality:"nlp",color:"blue",hideInModels:!0},"text-ranking":{name:"Text Ranking",modality:"nlp",color:"red"},"text-retrieval":{name:"Text Retrieval",subtasks:[{type:"document-retrieval",name:"Document Retrieval"},{type:"utterance-retrieval",name:"Utterance Retrieval"},{type:"entity-linking-retrieval",name:"Entity Linking Retrieval"},{type:"fact-checking-retrieval",name:"Fact Checking Retrieval"}],modality:"nlp",color:"indigo",hideInModels:!0},"time-series-forecasting":{name:"Time Series Forecasting",modality:"tabular",subtasks:[{type:"univariate-time-series-forecasting",name:"Univariate Time Series Forecasting"},{type:"multivariate-time-series-forecasting",name:"Multivariate Time Series Forecasting"}],color:"blue"},"text-to-video":{name:"Text-to-Video",modality:"cv",color:"green"},"image-text-to-text":{name:"Image-Text-to-Text",modality:"multimodal",color:"red",hideInDatasets:!0},"visual-question-answering":{name:"Visual Question Answering",subtasks:[{type:"visual-question-answering",name:"Visual Question Answering"}],modality:"multimodal",color:"red"},"document-question-answering":{name:"Document Question Answering",subtasks:[{type:"document-question-answering",name:"Document Question Answering"}],modality:"multimodal",color:"blue",hideInDatasets:!0},"zero-shot-image-classification":{name:"Zero-Shot Image Classification",modality:"cv",color:"yellow"},"graph-ml":{name:"Graph Machine Learning",modality:"other",color:"green"},"mask-generation":{name:"Mask Generation",modality:"cv",color:"indigo"},"zero-shot-object-detection":{name:"Zero-Shot Object Detection",modality:"cv",color:"yellow"},"text-to-3d":{name:"Text-to-3D",modality:"cv",color:"yellow"},"image-to-3d":{name:"Image-to-3D",modality:"cv",color:"green"},"image-feature-extraction":{name:"Image Feature Extraction",modality:"cv",color:"indigo"},"video-text-to-text":{name:"Video-Text-to-Text",modality:"multimodal",color:"blue",hideInDatasets:!1},"keypoint-detection":{name:"Keypoint Detection",subtasks:[{type:"pose-estimation",name:"Pose Estimation"}],modality:"cv",color:"red",hideInDatasets:!0},"visual-document-retrieval":{name:"Visual Document Retrieval",modality:"multimodal",color:"yellow",hideInDatasets:!0},"any-to-any":{name:"Any-to-Any",modality:"multimodal",color:"yellow",hideInDatasets:!0},other:{name:"Other",modality:"other",color:"blue",hideInModels:!0,hideInDatasets:!0}},aa=Object.keys(je);Object.values(je).flatMap(e=>"subtasks"in e?e.subtasks:[]).map(e=>e.type);new Set(aa);const ia={datasets:[{description:"A benchmark of 10 different audio tasks.",id:"s3prl/superb"},{description:"A dataset of YouTube clips and their sound categories.",id:"agkphysics/AudioSet"}],demo:{inputs:[{filename:"audio.wav",type:"audio"}],outputs:[{data:[{label:"Up",score:.2},{label:"Down",score:.8}],type:"chart"}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"An easy-to-use model for command recognition.",id:"speechbrain/google_speech_command_xvector"},{description:"An emotion recognition model.",id:"ehcalabres/wav2vec2-lg-xlsr-en-speech-emotion-recognition"},{description:"A language identification model.",id:"facebook/mms-lid-126"}],spaces:[{description:"An application that can classify music into different genre.",id:"kurianbenoy/audioclassification"}],summary:"Audio classification is the task of assigning a label or class to a given audio. It can be used for recognizing which command a user is giving or the emotion of a statement, as well as identifying a speaker.",widgetModels:["MIT/ast-finetuned-audioset-10-10-0.4593"],youtubeId:"KWwzcmG98Ds"},na={datasets:[{description:"512-element X-vector embeddings of speakers from CMU ARCTIC dataset.",id:"Matthijs/cmu-arctic-xvectors"}],demo:{inputs:[{filename:"input.wav",type:"audio"}],outputs:[{filename:"label-0.wav",type:"audio"},{filename:"label-1.wav",type:"audio"}]},metrics:[{description:"The Signal-to-Noise ratio is the relationship between the target signal level and the background noise level. It is calculated as the logarithm of the target signal divided by the background noise, in decibels.",id:"snri"},{description:"The Signal-to-Distortion ratio is the relationship between the target signal and the sum of noise, interference, and artifact errors",id:"sdri"}],models:[{description:"A speech enhancement model.",id:"ResembleAI/resemble-enhance"},{description:"A model that can change the voice in a speech recording.",id:"microsoft/speecht5_vc"}],spaces:[{description:"An application for speech separation.",id:"younver/speechbrain-speech-separation"},{description:"An application for audio style transfer.",id:"nakas/audio-diffusion_style_transfer"}],summary:"Audio-to-Audio is a family of tasks in which the input is an audio and the output is one or multiple generated audios. Some example tasks are speech enhancement and source separation.",widgetModels:["speechbrain/sepformer-wham"],youtubeId:"iohj7nCCYoM"},oa={datasets:[{description:"31,175 hours of multilingual audio-text dataset in 108 languages.",id:"mozilla-foundation/common_voice_17_0"},{description:"Multilingual and diverse audio dataset with 101k hours of audio.",id:"amphion/Emilia-Dataset"},{description:"A dataset with 44.6k hours of English speaker data and 6k hours of other language speakers.",id:"parler-tts/mls_eng"},{description:"A multilingual audio dataset with 370K hours of audio.",id:"espnet/yodas"}],demo:{inputs:[{filename:"input.flac",type:"audio"}],outputs:[{label:"Transcript",content:"Going along slushy country roads and speaking to damp audiences in...",type:"text"}]},metrics:[{description:"",id:"wer"},{description:"",id:"cer"}],models:[{description:"A powerful ASR model by OpenAI.",id:"openai/whisper-large-v3"},{description:"A good generic speech model by MetaAI for fine-tuning.",id:"facebook/w2v-bert-2.0"},{description:"An end-to-end model that performs ASR and Speech Translation by MetaAI.",id:"facebook/seamless-m4t-v2-large"},{description:"A powerful multilingual ASR and Speech Translation model by Nvidia.",id:"nvidia/canary-1b"},{description:"Powerful speaker diarization model.",id:"pyannote/speaker-diarization-3.1"}],spaces:[{description:"A powerful general-purpose speech recognition application.",id:"hf-audio/whisper-large-v3"},{description:"Latest ASR model from Useful Sensors.",id:"mrfakename/Moonshinex"},{description:"A high quality speech and text translation model by Meta.",id:"facebook/seamless_m4t"},{description:"A powerful multilingual ASR and Speech Translation model by Nvidia",id:"nvidia/canary-1b"}],summary:"Automatic Speech Recognition (ASR), also known as Speech to Text (STT), is the task of transcribing a given audio to text. It has many applications, such as voice user interfaces.",widgetModels:["openai/whisper-large-v3"],youtubeId:"TksaY_FDgnk"},ra={datasets:[{description:"Largest document understanding dataset.",id:"HuggingFaceM4/Docmatix"},{description:"Dataset from the 2020 DocVQA challenge. The documents are taken from the UCSF Industry Documents Library.",id:"eliolio/docvqa"}],demo:{inputs:[{label:"Question",content:"What is the idea behind the consumer relations efficiency team?",type:"text"},{filename:"document-question-answering-input.png",type:"img"}],outputs:[{label:"Answer",content:"Balance cost efficiency with quality customer service",type:"text"}]},metrics:[{description:"The evaluation metric for the DocVQA challenge is the Average Normalized Levenshtein Similarity (ANLS). This metric is flexible to character regognition errors and compares the predicted answer with the ground truth answer.",id:"anls"},{description:"Exact Match is a metric based on the strict character match of the predicted answer and the right answer. For answers predicted correctly, the Exact Match will be 1. Even if only one character is different, Exact Match will be 0",id:"exact-match"}],models:[{description:"A robust document question answering model.",id:"impira/layoutlm-document-qa"},{description:"A document question answering model specialized in invoices.",id:"impira/layoutlm-invoices"},{description:"A special model for OCR-free document question answering.",id:"microsoft/udop-large"},{description:"A powerful model for document question answering.",id:"google/pix2struct-docvqa-large"}],spaces:[{description:"A robust document question answering application.",id:"impira/docquery"},{description:"An application that can answer questions from invoices.",id:"impira/invoices"},{description:"An application to compare different document question answering models.",id:"merve/compare_docvqa_models"}],summary:"Document Question Answering (also known as Document Visual Question Answering) is the task of answering questions on document images. Document question answering models take a (document, question) pair as input and return an answer in natural language. Models usually rely on multi-modal features, combining text, position of words (bounding-boxes) and image.",widgetModels:["impira/layoutlm-invoices"],youtubeId:""},sa={datasets:[{description:"Wikipedia dataset containing cleaned articles of all languages. Can be used to train `feature-extraction` models.",id:"wikipedia"}],demo:{inputs:[{label:"Input",content:"India, officially the Republic of India, is a country in South Asia.",type:"text"}],outputs:[{table:[["Dimension 1","Dimension 2","Dimension 3"],["2.583383083343506","2.757075071334839","0.9023529887199402"],["8.29393482208252","1.1071064472198486","2.03399395942688"],["-0.7754912972450256","-1.647324562072754","-0.6113331913948059"],["0.07087723910808563","1.5942802429199219","1.4610432386398315"]],type:"tabular"}]},metrics:[],models:[{description:"A powerful feature extraction model for natural language processing tasks.",id:"thenlper/gte-large"},{description:"A strong feature extraction model for retrieval.",id:"Alibaba-NLP/gte-Qwen1.5-7B-instruct"}],spaces:[{description:"A leaderboard to rank text feature extraction models based on a benchmark.",id:"mteb/leaderboard"},{description:"A leaderboard to rank best feature extraction models based on human feedback.",id:"mteb/arena"}],summary:"Feature extraction is the task of extracting features learnt in a model.",widgetModels:["facebook/bart-base"]},la={datasets:[{description:"A common dataset that is used to train models for many languages.",id:"wikipedia"},{description:"A large English dataset with text crawled from the web.",id:"c4"}],demo:{inputs:[{label:"Input",content:"The <mask> barked at me",type:"text"}],outputs:[{type:"chart",data:[{label:"wolf",score:.487},{label:"dog",score:.061},{label:"cat",score:.058},{label:"fox",score:.047},{label:"squirrel",score:.025}]}]},metrics:[{description:"Cross Entropy is a metric that calculates the difference between two probability distributions. Each probability distribution is the distribution of predicted words",id:"cross_entropy"},{description:"Perplexity is the exponential of the cross-entropy loss. It evaluates the probabilities assigned to the next word by the model. Lower perplexity indicates better performance",id:"perplexity"}],models:[{description:"State-of-the-art masked language model.",id:"answerdotai/ModernBERT-large"},{description:"A multilingual model trained on 100 languages.",id:"FacebookAI/xlm-roberta-base"}],spaces:[],summary:"Masked language modeling is the task of masking some of the words in a sentence and predicting which words should replace those masks. These models are useful when we want to get a statistical understanding of the language in which the model is trained in.",widgetModels:["distilroberta-base"],youtubeId:"mqElG5QJWUg"},ca={datasets:[{description:"Benchmark dataset used for image classification with images that belong to 100 classes.",id:"cifar100"},{description:"Dataset consisting of images of garments.",id:"fashion_mnist"}],demo:{inputs:[{filename:"image-classification-input.jpeg",type:"img"}],outputs:[{type:"chart",data:[{label:"Egyptian cat",score:.514},{label:"Tabby cat",score:.193},{label:"Tiger cat",score:.068}]}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"A strong image classification model.",id:"google/vit-base-patch16-224"},{description:"A robust image classification model.",id:"facebook/deit-base-distilled-patch16-224"},{description:"A strong image classification model.",id:"facebook/convnext-large-224"}],spaces:[{description:"A leaderboard to evaluate different image classification models.",id:"timm/leaderboard"}],summary:"Image classification is the task of assigning a label or class to an entire image. Images are expected to have only one class for each image. Image classification models take an image as input and return a prediction about which class the image belongs to.",widgetModels:["google/vit-base-patch16-224"],youtubeId:"tjAIM7BOYhw"},pa={datasets:[{description:"ImageNet-1K is a image classification dataset in which images are used to train image-feature-extraction models.",id:"imagenet-1k"}],demo:{inputs:[{filename:"mask-generation-input.png",type:"img"}],outputs:[{table:[["Dimension 1","Dimension 2","Dimension 3"],["0.21236686408519745","1.0919708013534546","0.8512550592422485"],["0.809657871723175","-0.18544459342956543","-0.7851548194885254"],["1.3103108406066895","-0.2479034662246704","-0.9107287526130676"],["1.8536205291748047","-0.36419737339019775","0.09717650711536407"]],type:"tabular"}]},metrics:[],models:[{description:"A powerful image feature extraction model.",id:"timm/vit_large_patch14_dinov2.lvd142m"},{description:"A strong image feature extraction model.",id:"nvidia/MambaVision-T-1K"},{description:"A robust image feature extraction model.",id:"facebook/dino-vitb16"},{description:"Cutting-edge image feature extraction model.",id:"apple/aimv2-large-patch14-336-distilled"},{description:"Strong image feature extraction model that can be used on images and documents.",id:"OpenGVLab/InternViT-6B-448px-V1-2"}],spaces:[{description:"A leaderboard to evaluate different image-feature-extraction models on classification performances",id:"timm/leaderboard"}],summary:"Image feature extraction is the task of extracting features learnt in a computer vision model.",widgetModels:[]},da={datasets:[{description:"Synthetic dataset, for image relighting",id:"VIDIT"},{description:"Multiple images of celebrities, used for facial expression translation",id:"huggan/CelebA-faces"},{description:"12M image-caption pairs.",id:"Spawning/PD12M"}],demo:{inputs:[{filename:"image-to-image-input.jpeg",type:"img"}],outputs:[{filename:"image-to-image-output.png",type:"img"}]},isPlaceholder:!1,metrics:[{description:"Peak Signal to Noise Ratio (PSNR) is an approximation of the human perception, considering the ratio of the absolute intensity with respect to the variations. Measured in dB, a high value indicates a high fidelity.",id:"PSNR"},{description:"Structural Similarity Index (SSIM) is a perceptual metric which compares the luminance, contrast and structure of two images. The values of SSIM range between -1 and 1, and higher values indicate closer resemblance to the original image.",id:"SSIM"},{description:"Inception Score (IS) is an analysis of the labels predicted by an image classification model when presented with a sample of the generated images.",id:"IS"}],models:[{description:"An image-to-image model to improve image resolution.",id:"fal/AuraSR-v2"},{description:"A model that increases the resolution of an image.",id:"keras-io/super-resolution"},{description:"A model for applying edits to images through image controls.",id:"Yuanshi/OminiControl"},{description:"A model that generates images based on segments in the input image and the text prompt.",id:"mfidabel/controlnet-segment-anything"},{description:"Strong model for inpainting and outpainting.",id:"black-forest-labs/FLUX.1-Fill-dev"},{description:"Strong model for image editing using depth maps.",id:"black-forest-labs/FLUX.1-Depth-dev-lora"}],spaces:[{description:"Image enhancer application for low light.",id:"keras-io/low-light-image-enhancement"},{description:"Style transfer application.",id:"keras-io/neural-style-transfer"},{description:"An application that generates images based on segment control.",id:"mfidabel/controlnet-segment-anything"},{description:"Image generation application that takes image control and text prompt.",id:"hysts/ControlNet"},{description:"Colorize any image using this app.",id:"ioclab/brightness-controlnet"},{description:"Edit images with instructions.",id:"timbrooks/instruct-pix2pix"}],summary:"Image-to-image is the task of transforming an input image through a variety of possible manipulations and enhancements, such as super-resolution, image inpainting, colorization, and more.",widgetModels:["stabilityai/stable-diffusion-2-inpainting"],youtubeId:""},ua={datasets:[{description:"Dataset from 12M image-text of Reddit",id:"red_caps"},{description:"Dataset from 3.3M images of Google",id:"datasets/conceptual_captions"}],demo:{inputs:[{filename:"savanna.jpg",type:"img"}],outputs:[{label:"Detailed description",content:"a herd of giraffes and zebras grazing in a field",type:"text"}]},metrics:[],models:[{description:"A robust image captioning model.",id:"Salesforce/blip2-opt-2.7b"},{description:"A powerful and accurate image-to-text model that can also localize concepts in images.",id:"microsoft/kosmos-2-patch14-224"},{description:"A strong optical character recognition model.",id:"facebook/nougat-base"},{description:"A powerful model that lets you have a conversation with the image.",id:"llava-hf/llava-1.5-7b-hf"}],spaces:[{description:"An application that compares various image captioning models.",id:"nielsr/comparing-captioning-models"},{description:"A robust image captioning application.",id:"flax-community/image-captioning"},{description:"An application that transcribes handwritings into text.",id:"nielsr/TrOCR-handwritten"},{description:"An application that can caption images and answer questions about a given image.",id:"Salesforce/BLIP"},{description:"An application that can caption images and answer questions with a conversational agent.",id:"Salesforce/BLIP2"},{description:"An image captioning application that demonstrates the effect of noise on captions.",id:"johko/capdec-image-captioning"}],summary:"Image to text models output a text from a given image. Image captioning or optical character recognition can be considered as the most common applications of image to text.",widgetModels:["Salesforce/blip-image-captioning-large"],youtubeId:""},ma={datasets:[{description:"Instructions composed of image and text.",id:"liuhaotian/LLaVA-Instruct-150K"},{description:"Collection of image-text pairs on scientific topics.",id:"DAMO-NLP-SG/multimodal_textbook"},{description:"A collection of datasets made for model fine-tuning.",id:"HuggingFaceM4/the_cauldron"},{description:"Screenshots of websites with their HTML/CSS codes.",id:"HuggingFaceM4/WebSight"}],demo:{inputs:[{filename:"image-text-to-text-input.png",type:"img"},{label:"Text Prompt",content:"Describe the position of the bee in detail.",type:"text"}],outputs:[{label:"Answer",content:"The bee is sitting on a pink flower, surrounded by other flowers. The bee is positioned in the center of the flower, with its head and front legs sticking out.",type:"text"}]},metrics:[],models:[{description:"Small and efficient yet powerful vision language model.",id:"HuggingFaceTB/SmolVLM-Instruct"},{description:"A screenshot understanding model used to control computers.",id:"microsoft/OmniParser-v2.0"},{description:"Cutting-edge vision language model.",id:"allenai/Molmo-7B-D-0924"},{description:"Small yet powerful model.",id:"vikhyatk/moondream2"},{description:"Strong image-text-to-text model.",id:"Qwen/Qwen2.5-VL-7B-Instruct"},{description:"Image-text-to-text model with agentic capabilities.",id:"microsoft/Magma-8B"},{description:"Strong image-text-to-text model focused on documents.",id:"allenai/olmOCR-7B-0225-preview"},{description:"Small yet strong image-text-to-text model.",id:"ibm-granite/granite-vision-3.2-2b"}],spaces:[{description:"Leaderboard to evaluate vision language models.",id:"opencompass/open_vlm_leaderboard"},{description:"Vision language models arena, where models are ranked by votes of users.",id:"WildVision/vision-arena"},{description:"Powerful vision-language model assistant.",id:"akhaliq/Molmo-7B-D-0924"},{description:"Powerful vision language assistant that can understand multiple images.",id:"HuggingFaceTB/SmolVLM2"},{description:"An application for chatting with an image-text-to-text model.",id:"GanymedeNil/Qwen2-VL-7B"},{description:"An application that parses screenshots into actions.",id:"showlab/ShowUI"},{description:"An application that detects gaze.",id:"moondream/gaze-demo"}],summary:"Image-text-to-text models take in an image and text prompt and output text. These models are also called vision-language models, or VLMs. The difference from image-to-text models is that these models take an additional text input, not restricting the model to certain use cases like image captioning, and may also be trained to accept a conversation as input.",widgetModels:["Qwen/Qwen2-VL-7B-Instruct"],youtubeId:"IoGaGfU1CIg"},fa={datasets:[{description:"Scene segmentation dataset.",id:"scene_parse_150"}],demo:{inputs:[{filename:"image-segmentation-input.jpeg",type:"img"}],outputs:[{filename:"image-segmentation-output.png",type:"img"}]},metrics:[{description:"Average Precision (AP) is the Area Under the PR Curve (AUC-PR). It is calculated for each semantic class separately",id:"Average Precision"},{description:"Mean Average Precision (mAP) is the overall average of the AP values",id:"Mean Average Precision"},{description:"Intersection over Union (IoU) is the overlap of segmentation masks. Mean IoU is the average of the IoU of all semantic classes",id:"Mean Intersection over Union"},{description:"APα is the Average Precision at the IoU threshold of a α value, for example, AP50 and AP75",id:"APα"}],models:[{description:"Solid semantic segmentation model trained on ADE20k.",id:"openmmlab/upernet-convnext-small"},{description:"Background removal model.",id:"briaai/RMBG-1.4"},{description:"A multipurpose image segmentation model for high resolution images.",id:"ZhengPeng7/BiRefNet"},{description:"Powerful human-centric image segmentation model.",id:"facebook/sapiens-seg-1b"},{description:"Panoptic segmentation model trained on the COCO (common objects) dataset.",id:"facebook/mask2former-swin-large-coco-panoptic"}],spaces:[{description:"A semantic segmentation application that can predict unseen instances out of the box.",id:"facebook/ov-seg"},{description:"One of the strongest segmentation applications.",id:"jbrinkma/segment-anything"},{description:"A human-centric segmentation model.",id:"facebook/sapiens-pose"},{description:"An instance segmentation application to predict neuronal cell types from microscopy images.",id:"rashmi/sartorius-cell-instance-segmentation"},{description:"An application that segments videos.",id:"ArtGAN/Segment-Anything-Video"},{description:"An panoptic segmentation application built for outdoor environments.",id:"segments/panoptic-segment-anything"}],summary:"Image Segmentation divides an image into segments where each pixel in the image is mapped to an object. This task has multiple variants such as instance segmentation, panoptic segmentation and semantic segmentation.",widgetModels:["nvidia/segformer-b0-finetuned-ade-512-512"],youtubeId:"dKE8SIt9C-w"},ha={datasets:[{description:"Widely used benchmark dataset for multiple Vision tasks.",id:"merve/coco2017"},{description:"Medical Imaging dataset of the Human Brain for segmentation and mask generating tasks",id:"rocky93/BraTS_segmentation"}],demo:{inputs:[{filename:"mask-generation-input.png",type:"img"}],outputs:[{filename:"mask-generation-output.png",type:"img"}]},metrics:[{description:"IoU is used to measure the overlap between predicted mask and the ground truth mask.",id:"Intersection over Union (IoU)"}],models:[{description:"Small yet powerful mask generation model.",id:"Zigeng/SlimSAM-uniform-50"},{description:"Very strong mask generation model.",id:"facebook/sam2-hiera-large"}],spaces:[{description:"An application that combines a mask generation model with a zero-shot object detection model for text-guided image segmentation.",id:"merve/OWLSAM2"},{description:"An application that compares the performance of a large and a small mask generation model.",id:"merve/slimsam"},{description:"An application based on an improved mask generation model.",id:"SkalskiP/segment-anything-model-2"},{description:"An application to remove objects from videos using mask generation models.",id:"SkalskiP/SAM_and_ProPainter"}],summary:"Mask generation is the task of generating masks that identify a specific object or region of interest in a given image. Masks are often used in segmentation tasks, where they provide a precise way to isolate the object of interest for further processing or analysis.",widgetModels:[],youtubeId:""},ga={datasets:[{description:"Widely used benchmark dataset for multiple vision tasks.",id:"merve/coco2017"},{description:"Multi-task computer vision benchmark.",id:"merve/pascal-voc"}],demo:{inputs:[{filename:"object-detection-input.jpg",type:"img"}],outputs:[{filename:"object-detection-output.jpg",type:"img"}]},metrics:[{description:"The Average Precision (AP) metric is the Area Under the PR Curve (AUC-PR). It is calculated for each class separately",id:"Average Precision"},{description:"The Mean Average Precision (mAP) metric is the overall average of the AP values",id:"Mean Average Precision"},{description:"The APα metric is the Average Precision at the IoU threshold of a α value, for example, AP50 and AP75",id:"APα"}],models:[{description:"Solid object detection model pre-trained on the COCO 2017 dataset.",id:"facebook/detr-resnet-50"},{description:"Accurate object detection model.",id:"IDEA-Research/dab-detr-resnet-50"},{description:"Fast and accurate object detection model.",id:"PekingU/rtdetr_v2_r50vd"},{description:"Object detection model for low-lying objects.",id:"StephanST/WALDO30"}],spaces:[{description:"Leaderboard to compare various object detection models across several metrics.",id:"hf-vision/object_detection_leaderboard"},{description:"An application that contains various object detection models to try from.",id:"Gradio-Blocks/Object-Detection-With-DETR-and-YOLOS"},{description:"A cutting-edge object detection application.",id:"sunsmarterjieleaf/yolov12"},{description:"An object tracking, segmentation and inpainting application.",id:"VIPLab/Track-Anything"},{description:"Very fast object tracking application based on object detection.",id:"merve/RT-DETR-tracking-coco"}],summary:"Object Detection models allow users to identify objects of certain defined classes. Object detection models receive an image as input and output the images with bounding boxes and labels on detected objects.",widgetModels:["facebook/detr-resnet-50"],youtubeId:"WdAeKSOpxhw"},ba={datasets:[{description:"NYU Depth V2 Dataset: Video dataset containing both RGB and depth sensor data.",id:"sayakpaul/nyu_depth_v2"},{description:"Monocular depth estimation benchmark based without noise and errors.",id:"depth-anything/DA-2K"}],demo:{inputs:[{filename:"depth-estimation-input.jpg",type:"img"}],outputs:[{filename:"depth-estimation-output.png",type:"img"}]},metrics:[],models:[{description:"Cutting-edge depth estimation model.",id:"depth-anything/Depth-Anything-V2-Large"},{description:"A strong monocular depth estimation model.",id:"jingheya/lotus-depth-g-v1-0"},{description:"A depth estimation model that predicts depth in videos.",id:"tencent/DepthCrafter"},{description:"A robust depth estimation model.",id:"apple/DepthPro-hf"}],spaces:[{description:"An application that predicts the depth of an image and then reconstruct the 3D model as voxels.",id:"radames/dpt-depth-estimation-3d-voxels"},{description:"An application for bleeding-edge depth estimation.",id:"akhaliq/depth-pro"},{description:"An application on cutting-edge depth estimation in videos.",id:"tencent/DepthCrafter"},{description:"A human-centric depth estimation application.",id:"facebook/sapiens-depth"}],summary:"Depth estimation is the task of predicting depth of the objects present in an image.",widgetModels:[""],youtubeId:""},we={datasets:[],demo:{inputs:[],outputs:[]},isPlaceholder:!0,metrics:[],models:[],spaces:[],summary:"",widgetModels:[],youtubeId:void 0,canonicalId:void 0},ya={datasets:[{description:"A curation of widely used datasets for Data Driven Deep Reinforcement Learning (D4RL)",id:"edbeeching/decision_transformer_gym_replay"}],demo:{inputs:[{label:"State",content:"Red traffic light, pedestrians are about to pass.",type:"text"}],outputs:[{label:"Action",content:"Stop the car.",type:"text"},{label:"Next State",content:"Yellow light, pedestrians have crossed.",type:"text"}]},metrics:[{description:"Accumulated reward across all time steps discounted by a factor that ranges between 0 and 1 and determines how much the agent optimizes for future relative to immediate rewards. Measures how good is the policy ultimately found by a given algorithm considering uncertainty over the future.",id:"Discounted Total Reward"},{description:"Average return obtained after running the policy for a certain number of evaluation episodes. As opposed to total reward, mean reward considers how much reward a given algorithm receives while learning.",id:"Mean Reward"},{description:"Measures how good a given algorithm is after a predefined time. Some algorithms may be guaranteed to converge to optimal behavior across many time steps. However, an agent that reaches an acceptable level of optimality after a given time horizon may be preferable to one that ultimately reaches optimality but takes a long time.",id:"Level of Performance After Some Time"}],models:[{description:"A Reinforcement Learning model trained on expert data from the Gym Hopper environment",id:"edbeeching/decision-transformer-gym-hopper-expert"},{description:"A PPO agent playing seals/CartPole-v0 using the stable-baselines3 library and the RL Zoo.",id:"HumanCompatibleAI/ppo-seals-CartPole-v0"}],spaces:[{description:"An application for a cute puppy agent learning to catch a stick.",id:"ThomasSimonini/Huggy"},{description:"An application to play Snowball Fight with a reinforcement learning agent.",id:"ThomasSimonini/SnowballFight"}],summary:"Reinforcement learning is the computational approach of learning from action by interacting with an environment through trial and error and receiving rewards (negative or positive) as feedback",widgetModels:[],youtubeId:"q0BiUn5LiBc"},wa={datasets:[{description:"A famous question answering dataset based on English articles from Wikipedia.",id:"squad_v2"},{description:"A dataset of aggregated anonymized actual queries issued to the Google search engine.",id:"natural_questions"}],demo:{inputs:[{label:"Question",content:"Which name is also used to describe the Amazon rainforest in English?",type:"text"},{label:"Context",content:"The Amazon rainforest, also known in English as Amazonia or the Amazon Jungle",type:"text"}],outputs:[{label:"Answer",content:"Amazonia",type:"text"}]},metrics:[{description:"Exact Match is a metric based on the strict character match of the predicted answer and the right answer. For answers predicted correctly, the Exact Match will be 1. Even if only one character is different, Exact Match will be 0",id:"exact-match"},{description:" The F1-Score metric is useful if we value both false positives and false negatives equally. The F1-Score is calculated on each word in the predicted sequence against the correct answer",id:"f1"}],models:[{description:"A robust baseline model for most question answering domains.",id:"deepset/roberta-base-squad2"},{description:"Small yet robust model that can answer questions.",id:"distilbert/distilbert-base-cased-distilled-squad"},{description:"A special model that can answer questions from tables.",id:"google/tapas-base-finetuned-wtq"}],spaces:[{description:"An application that can answer a long question from Wikipedia.",id:"deepset/wikipedia-assistant"}],summary:"Question Answering models can retrieve the answer to a question from a given text, which is useful for searching for an answer in a document. Some question answering models can generate answers without context!",widgetModels:["deepset/roberta-base-squad2"],youtubeId:"ajPx5LwJD-I"},va={datasets:[{description:"Bing queries with relevant passages from various web sources.",id:"microsoft/ms_marco"}],demo:{inputs:[{label:"Source sentence",content:"Machine learning is so easy.",type:"text"},{label:"Sentences to compare to",content:"Deep learning is so straightforward.",type:"text"},{label:"",content:"This is so difficult, like rocket science.",type:"text"},{label:"",content:"I can't believe how much I struggled with this.",type:"text"}],outputs:[{type:"chart",data:[{label:"Deep learning is so straightforward.",score:.623},{label:"This is so difficult, like rocket science.",score:.413},{label:"I can't believe how much I struggled with this.",score:.256}]}]},metrics:[{description:"Reciprocal Rank is a measure used to rank the relevancy of documents given a set of documents. Reciprocal Rank is the reciprocal of the rank of the document retrieved, meaning, if the rank is 3, the Reciprocal Rank is 0.33. If the rank is 1, the Reciprocal Rank is 1",id:"Mean Reciprocal Rank"},{description:"The similarity of the embeddings is evaluated mainly on cosine similarity. It is calculated as the cosine of the angle between two vectors. It is particularly useful when your texts are not the same length",id:"Cosine Similarity"}],models:[{description:"This model works well for sentences and paragraphs and can be used for clustering/grouping and semantic searches.",id:"sentence-transformers/all-mpnet-base-v2"},{description:"A multilingual robust sentence similarity model.",id:"BAAI/bge-m3"},{description:"A robust sentence similarity model.",id:"HIT-TMG/KaLM-embedding-multilingual-mini-instruct-v1.5"}],spaces:[{description:"An application that leverages sentence similarity to answer questions from YouTube videos.",id:"Gradio-Blocks/Ask_Questions_To_YouTube_Videos"},{description:"An application that retrieves relevant PubMed abstracts for a given online article which can be used as further references.",id:"Gradio-Blocks/pubmed-abstract-retriever"},{description:"An application that leverages sentence similarity to summarize text.",id:"nickmuchi/article-text-summarizer"},{description:"A guide that explains how Sentence Transformers can be used for semantic search.",id:"sentence-transformers/Sentence_Transformers_for_semantic_search"}],summary:"Sentence Similarity is the task of determining how similar two texts are. Sentence similarity models convert input texts into vectors (embeddings) that capture semantic information and calculate how close (similar) they are between them. This task is particularly useful for information retrieval and clustering/grouping.",widgetModels:["BAAI/bge-small-en-v1.5"],youtubeId:"VCZq5AkbNEU"},_a={canonicalId:"text2text-generation",datasets:[{description:"News articles in five different languages along with their summaries. Widely used for benchmarking multilingual summarization models.",id:"mlsum"},{description:"English conversations and their summaries. Useful for benchmarking conversational agents.",id:"samsum"}],demo:{inputs:[{label:"Input",content:"The tower is 324 metres (1,063 ft) tall, about the same height as an 81-storey building, and the tallest structure in Paris. Its base is square, measuring 125 metres (410 ft) on each side. It was the first structure to reach a height of 300 metres. Excluding transmitters, the Eiffel Tower is the second tallest free-standing structure in France after the Millau Viaduct.",type:"text"}],outputs:[{label:"Output",content:"The tower is 324 metres (1,063 ft) tall, about the same height as an 81-storey building. It was the first structure to reach a height of 300 metres.",type:"text"}]},metrics:[{description:"The generated sequence is compared against its summary, and the overlap of tokens are counted. ROUGE-N refers to overlap of N subsequent tokens, ROUGE-1 refers to overlap of single tokens and ROUGE-2 is the overlap of two subsequent tokens.",id:"rouge"}],models:[{description:"A strong summarization model trained on English news articles. Excels at generating factual summaries.",id:"facebook/bart-large-cnn"},{description:"A summarization model trained on medical articles.",id:"Falconsai/medical_summarization"}],spaces:[{description:"An application that can summarize long paragraphs.",id:"pszemraj/summarize-long-text"},{description:"A much needed summarization application for terms and conditions.",id:"ml6team/distilbart-tos-summarizer-tosdr"},{description:"An application that summarizes long documents.",id:"pszemraj/document-summarization"},{description:"An application that can detect errors in abstractive summarization.",id:"ml6team/post-processing-summarization"}],summary:"Summarization is the task of producing a shorter version of a document while preserving its important information. Some models can extract text from the original input, while other models can generate entirely new text.",widgetModels:["facebook/bart-large-cnn"],youtubeId:"yHnr5Dk2zCI"},ka={datasets:[{description:"The WikiTableQuestions dataset is a large-scale dataset for the task of question answering on semi-structured tables.",id:"wikitablequestions"},{description:"WikiSQL is a dataset of 80654 hand-annotated examples of questions and SQL queries distributed across 24241 tables from Wikipedia.",id:"wikisql"}],demo:{inputs:[{table:[["Rank","Name","No.of reigns","Combined days"],["1","lou Thesz","3","3749"],["2","Ric Flair","8","3103"],["3","Harley Race","7","1799"]],type:"tabular"},{label:"Question",content:"What is the number of reigns for Harley Race?",type:"text"}],outputs:[{label:"Result",content:"7",type:"text"}]},metrics:[{description:"Checks whether the predicted answer(s) is the same as the ground-truth answer(s).",id:"Denotation Accuracy"}],models:[{description:"A table question answering model that is capable of neural SQL execution, i.e., employ TAPEX to execute a SQL query on a given table.",id:"microsoft/tapex-base"},{description:"A robust table question answering model.",id:"google/tapas-base-finetuned-wtq"}],spaces:[{description:"An application that answers questions based on table CSV files.",id:"katanaml/table-query"}],summary:"Table Question Answering (Table QA) is the answering a question about an information on a given table.",widgetModels:["google/tapas-base-finetuned-wtq"]},xa={datasets:[{description:"A comprehensive curation of datasets covering all benchmarks.",id:"inria-soda/tabular-benchmark"}],demo:{inputs:[{table:[["Glucose","Blood Pressure ","Skin Thickness","Insulin","BMI"],["148","72","35","0","33.6"],["150","50","30","0","35.1"],["141","60","29","1","39.2"]],type:"tabular"}],outputs:[{table:[["Diabetes"],["1"],["1"],["0"]],type:"tabular"}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"Breast cancer prediction model based on decision trees.",id:"scikit-learn/cancer-prediction-trees"}],spaces:[{description:"An application that can predict defective products on a production line.",id:"scikit-learn/tabular-playground"},{description:"An application that compares various tabular classification techniques on different datasets.",id:"scikit-learn/classification"}],summary:"Tabular classification is the task of classifying a target category (a group) based on set of attributes.",widgetModels:["scikit-learn/tabular-playground"],youtubeId:""},Aa={datasets:[{description:"A comprehensive curation of datasets covering all benchmarks.",id:"inria-soda/tabular-benchmark"}],demo:{inputs:[{table:[["Car Name","Horsepower","Weight"],["ford torino","140","3,449"],["amc hornet","97","2,774"],["toyota corolla","65","1,773"]],type:"tabular"}],outputs:[{table:[["MPG (miles per gallon)"],["17"],["18"],["31"]],type:"tabular"}]},metrics:[{description:"",id:"mse"},{description:"Coefficient of determination (or R-squared) is a measure of how well the model fits the data. Higher R-squared is considered a better fit.",id:"r-squared"}],models:[{description:"Fish weight prediction based on length measurements and species.",id:"scikit-learn/Fish-Weight"}],spaces:[{description:"An application that can predict weight of a fish based on set of attributes.",id:"scikit-learn/fish-weight-prediction"}],summary:"Tabular regression is the task of predicting a numerical value given a set of attributes.",widgetModels:["scikit-learn/Fish-Weight"],youtubeId:""},Sa={datasets:[{description:"RedCaps is a large-scale dataset of 12M image-text pairs collected from Reddit.",id:"red_caps"},{description:"Conceptual Captions is a dataset consisting of ~3.3M images annotated with captions.",id:"conceptual_captions"},{description:"12M image-caption pairs.",id:"Spawning/PD12M"}],demo:{inputs:[{label:"Input",content:"A city above clouds, pastel colors, Victorian style",type:"text"}],outputs:[{filename:"image.jpeg",type:"img"}]},metrics:[{description:"The Inception Score (IS) measure assesses diversity and meaningfulness. It uses a generated image sample to predict its label. A higher score signifies more diverse and meaningful images.",id:"IS"},{description:"The Fréchet Inception Distance (FID) calculates the distance between distributions between synthetic and real samples. A lower FID score indicates better similarity between the distributions of real and generated images.",id:"FID"},{description:"R-precision assesses how the generated image aligns with the provided text description. It uses the generated images as queries to retrieve relevant text descriptions. The top 'r' relevant descriptions are selected and used to calculate R-precision as r/R, where 'R' is the number of ground truth descriptions associated with the generated images. A higher R-precision value indicates a better model.",id:"R-Precision"}],models:[{description:"One of the most powerful image generation models that can generate realistic outputs.",id:"black-forest-labs/FLUX.1-dev"},{description:"A powerful yet fast image generation model.",id:"latent-consistency/lcm-lora-sdxl"},{description:"Text-to-image model for photorealistic generation.",id:"Kwai-Kolors/Kolors"},{description:"A powerful text-to-image model.",id:"stabilityai/stable-diffusion-3-medium-diffusers"}],spaces:[{description:"A powerful text-to-image application.",id:"stabilityai/stable-diffusion-3-medium"},{description:"A text-to-image application to generate comics.",id:"jbilcke-hf/ai-comic-factory"},{description:"An application to match multiple custom image generation models.",id:"multimodalart/flux-lora-lab"},{description:"A powerful yet very fast image generation application.",id:"latent-consistency/lcm-lora-for-sdxl"},{description:"A gallery to explore various text-to-image models.",id:"multimodalart/LoraTheExplorer"},{description:"An application for `text-to-image`, `image-to-image` and image inpainting.",id:"ArtGAN/Stable-Diffusion-ControlNet-WebUI"},{description:"An application to generate realistic images given photos of a person and a prompt.",id:"InstantX/InstantID"}],summary:"Text-to-image is the task of generating images from input text. These pipelines can also be used to modify and edit images based on text prompts.",widgetModels:["black-forest-labs/FLUX.1-dev"],youtubeId:""},Ia={canonicalId:"text-to-audio",datasets:[{description:"10K hours of multi-speaker English dataset.",id:"parler-tts/mls_eng_10k"},{description:"Multi-speaker English dataset.",id:"mythicinfinity/libritts_r"},{description:"Multi-lingual dataset.",id:"facebook/multilingual_librispeech"}],demo:{inputs:[{label:"Input",content:"I love audio models on the Hub!",type:"text"}],outputs:[{filename:"audio.wav",type:"audio"}]},metrics:[{description:"The Mel Cepstral Distortion (MCD) metric is used to calculate the quality of generated speech.",id:"mel cepstral distortion"}],models:[{description:"A prompt based, powerful TTS model.",id:"parler-tts/parler-tts-large-v1"},{description:"A powerful TTS model that supports English and Chinese.",id:"SWivid/F5-TTS"},{description:"A massively multi-lingual TTS model.",id:"fishaudio/fish-speech-1.5"},{description:"A powerful TTS model.",id:"OuteAI/OuteTTS-0.1-350M"},{description:"Small yet powerful TTS model.",id:"hexgrad/Kokoro-82M"}],spaces:[{description:"An application for generate high quality speech in different languages.",id:"hexgrad/Kokoro-TTS"},{description:"A multilingual text-to-speech application.",id:"fishaudio/fish-speech-1"},{description:"An application that generates speech in different styles in English and Chinese.",id:"mrfakename/E2-F5-TTS"},{description:"An application that synthesizes emotional speech for diverse speaker prompts.",id:"parler-tts/parler-tts-expresso"},{description:"An application that generates podcast episodes.",id:"ngxson/kokoro-podcast-generator"}],summary:"Text-to-Speech (TTS) is the task of generating natural sounding speech given text input. TTS models can be extended to have a single model that generates speech for multiple speakers and multiple languages.",widgetModels:["suno/bark"],youtubeId:"NW62DpzJ274"},Ea={datasets:[{description:"A widely used dataset useful to benchmark named entity recognition models.",id:"eriktks/conll2003"},{description:"A multilingual dataset of Wikipedia articles annotated for named entity recognition in over 150 different languages.",id:"unimelb-nlp/wikiann"}],demo:{inputs:[{label:"Input",content:"My name is Omar and I live in Zürich.",type:"text"}],outputs:[{text:"My name is Omar and I live in Zürich.",tokens:[{type:"PERSON",start:11,end:15},{type:"GPE",start:30,end:36}],type:"text-with-tokens"}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"A robust performance model to identify people, locations, organizations and names of miscellaneous entities.",id:"dslim/bert-base-NER"},{description:"A strong model to identify people, locations, organizations and names in multiple languages.",id:"FacebookAI/xlm-roberta-large-finetuned-conll03-english"},{description:"A token classification model specialized on medical entity recognition.",id:"blaze999/Medical-NER"},{description:"Flair models are typically the state of the art in named entity recognition tasks.",id:"flair/ner-english"}],spaces:[{description:"An application that can recognizes entities, extracts noun chunks and recognizes various linguistic features of each token.",id:"spacy/gradio_pipeline_visualizer"}],summary:"Token classification is a natural language understanding task in which a label is assigned to some tokens in a text. Some popular token classification subtasks are Named Entity Recognition (NER) and Part-of-Speech (PoS) tagging. NER models could be trained to identify specific entities in a text, such as dates, individuals and places; and PoS tagging would identify, for example, which words in a text are verbs, nouns, and punctuation marks.",widgetModels:["FacebookAI/xlm-roberta-large-finetuned-conll03-english"],youtubeId:"wVHdVlPScxA"},Ta={canonicalId:"text2text-generation",datasets:[{description:"A dataset of copyright-free books translated into 16 different languages.",id:"Helsinki-NLP/opus_books"},{description:"An example of translation between programming languages. This dataset consists of functions in Java and C#.",id:"google/code_x_glue_cc_code_to_code_trans"}],demo:{inputs:[{label:"Input",content:"My name is Omar and I live in Zürich.",type:"text"}],outputs:[{label:"Output",content:"Mein Name ist Omar und ich wohne in Zürich.",type:"text"}]},metrics:[{description:"BLEU score is calculated by counting the number of shared single or subsequent tokens between the generated sequence and the reference. Subsequent n tokens are called “n-grams”. Unigram refers to a single token while bi-gram refers to token pairs and n-grams refer to n subsequent tokens. The score ranges from 0 to 1, where 1 means the translation perfectly matched and 0 did not match at all",id:"bleu"},{description:"",id:"sacrebleu"}],models:[{description:"Very powerful model that can translate many languages between each other, especially low-resource languages.",id:"facebook/nllb-200-1.3B"},{description:"A general-purpose Transformer that can be used to translate from English to German, French, or Romanian.",id:"google-t5/t5-base"}],spaces:[{description:"An application that can translate between 100 languages.",id:"Iker/Translate-100-languages"},{description:"An application that can translate between many languages.",id:"Geonmo/nllb-translation-demo"}],summary:"Translation is the task of converting text from one language to another.",widgetModels:["facebook/mbart-large-50-many-to-many-mmt"],youtubeId:"1JvfrvZgi6c"},Ca={datasets:[{description:"A widely used dataset used to benchmark multiple variants of text classification.",id:"nyu-mll/glue"},{description:"A text classification dataset used to benchmark natural language inference models",id:"stanfordnlp/snli"}],demo:{inputs:[{label:"Input",content:"I love Hugging Face!",type:"text"}],outputs:[{type:"chart",data:[{label:"POSITIVE",score:.9},{label:"NEUTRAL",score:.1},{label:"NEGATIVE",score:0}]}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"The F1 metric is the harmonic mean of the precision and recall. It can be calculated as: F1 = 2 * (precision * recall) / (precision + recall)",id:"f1"}],models:[{description:"A robust model trained for sentiment analysis.",id:"distilbert/distilbert-base-uncased-finetuned-sst-2-english"},{description:"A sentiment analysis model specialized in financial sentiment.",id:"ProsusAI/finbert"},{description:"A sentiment analysis model specialized in analyzing tweets.",id:"cardiffnlp/twitter-roberta-base-sentiment-latest"},{description:"A model that can classify languages.",id:"papluca/xlm-roberta-base-language-detection"},{description:"A model that can classify text generation attacks.",id:"meta-llama/Prompt-Guard-86M"}],spaces:[{description:"An application that can classify financial sentiment.",id:"IoannisTr/Tech_Stocks_Trading_Assistant"},{description:"A dashboard that contains various text classification tasks.",id:"miesnerjacob/Multi-task-NLP"},{description:"An application that analyzes user reviews in healthcare.",id:"spacy/healthsea-demo"}],summary:"Text Classification is the task of assigning a label or class to a given text. Some use cases are sentiment analysis, natural language inference, and assessing grammatical correctness.",widgetModels:["distilbert/distilbert-base-uncased-finetuned-sst-2-english"],youtubeId:"leNG9fN9FQU"},Ua={datasets:[{description:"Multilingual dataset used to evaluate text generation models.",id:"CohereForAI/Global-MMLU"},{description:"High quality multilingual data used to train text-generation models.",id:"HuggingFaceFW/fineweb-2"},{description:"Truly open-source, curated and cleaned dialogue dataset.",id:"HuggingFaceH4/ultrachat_200k"},{description:"A reasoning dataset.",id:"open-r1/OpenThoughts-114k-math"},{description:"A multilingual instruction dataset with preference ratings on responses.",id:"allenai/tulu-3-sft-mixture"},{description:"A large synthetic dataset for alignment of text generation models.",id:"HuggingFaceTB/smoltalk"},{description:"A dataset made for training text generation models solving math questions.",id:"HuggingFaceTB/finemath"}],demo:{inputs:[{label:"Input",content:"Once upon a time,",type:"text"}],outputs:[{label:"Output",content:"Once upon a time, we knew that our ancestors were on the verge of extinction. The great explorers and poets of the Old World, from Alexander the Great to Chaucer, are dead and gone. A good many of our ancient explorers and poets have",type:"text"}]},metrics:[{description:"Cross Entropy is a metric that calculates the difference between two probability distributions. Each probability distribution is the distribution of predicted words",id:"Cross Entropy"},{description:"The Perplexity metric is the exponential of the cross-entropy loss. It evaluates the probabilities assigned to the next word by the model. Lower perplexity indicates better performance",id:"Perplexity"}],models:[{description:"A text-generation model trained to follow instructions.",id:"google/gemma-2-2b-it"},{description:"Smaller variant of one of the most powerful models.",id:"deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B"},{description:"Very powerful text generation model trained to follow instructions.",id:"meta-llama/Meta-Llama-3.1-8B-Instruct"},{description:"Powerful text generation model by Microsoft.",id:"microsoft/phi-4"},{description:"A very powerful model with reasoning capabilities.",id:"simplescaling/s1.1-32B"},{description:"Strong conversational model that supports very long instructions.",id:"Qwen/Qwen2.5-7B-Instruct-1M"},{description:"Text generation model used to write code.",id:"Qwen/Qwen2.5-Coder-32B-Instruct"},{description:"Powerful reasoning based open large language model.",id:"deepseek-ai/DeepSeek-R1"}],spaces:[{description:"A leaderboard to compare different open-source text generation models based on various benchmarks.",id:"open-llm-leaderboard/open_llm_leaderboard"},{description:"A leaderboard for comparing chain-of-thought performance of models.",id:"logikon/open_cot_leaderboard"},{description:"An text generation based application based on a very powerful LLaMA2 model.",id:"ysharma/Explore_llamav2_with_TGI"},{description:"An text generation based application to converse with Zephyr model.",id:"HuggingFaceH4/zephyr-chat"},{description:"A leaderboard that ranks text generation models based on blind votes from people.",id:"lmsys/chatbot-arena-leaderboard"},{description:"An chatbot to converse with a very powerful text generation model.",id:"mlabonne/phixtral-chat"}],summary:"Generating text is the task of generating new text given another text. These models can, for example, fill in incomplete text or paraphrase.",widgetModels:["mistralai/Mistral-Nemo-Instruct-2407"],youtubeId:"e9gNEAlsOvU"},Oa={datasets:[{description:"Bing queries with relevant passages from various web sources.",id:"microsoft/ms_marco"}],demo:{inputs:[{label:"Source sentence",content:"Machine learning is so easy.",type:"text"},{label:"Sentences to compare to",content:"Deep learning is so straightforward.",type:"text"},{label:"",content:"This is so difficult, like rocket science.",type:"text"},{label:"",content:"I can't believe how much I struggled with this.",type:"text"}],outputs:[{type:"chart",data:[{label:"Deep learning is so straightforward.",score:2.2006407},{label:"This is so difficult, like rocket science.",score:-6.2634873},{label:"I can't believe how much I struggled with this.",score:-10.251488}]}]},metrics:[{description:"Discounted Cumulative Gain (DCG) measures the gain, or usefulness, of search results discounted by their position. The normalization is done by dividing the DCG by the ideal DCG, which is the DCG of the perfect ranking.",id:"Normalized Discounted Cumulative Gain"},{description:"Reciprocal Rank is a measure used to rank the relevancy of documents given a set of documents. Reciprocal Rank is the reciprocal of the rank of the document retrieved, meaning, if the rank is 3, the Reciprocal Rank is 0.33. If the rank is 1, the Reciprocal Rank is 1",id:"Mean Reciprocal Rank"},{description:"Mean Average Precision (mAP) is the overall average of the Average Precision (AP) values, where AP is the Area Under the PR Curve (AUC-PR)",id:"Mean Average Precision"}],models:[{description:"An extremely efficient text ranking model trained on a web search dataset.",id:"cross-encoder/ms-marco-MiniLM-L6-v2"},{description:"A strong multilingual text reranker model.",id:"Alibaba-NLP/gte-multilingual-reranker-base"},{description:"An efficient text ranking model that punches above its weight.",id:"Alibaba-NLP/gte-reranker-modernbert-base"}],spaces:[],summary:"Text Ranking is the task of ranking a set of texts based on their relevance to a query. Text ranking models are trained on large datasets of queries and relevant documents to learn how to rank documents based on their relevance to the query. This task is particularly useful for search engines and information retrieval systems.",widgetModels:["cross-encoder/ms-marco-MiniLM-L6-v2"],youtubeId:""},Ma={datasets:[{description:"Microsoft Research Video to Text is a large-scale dataset for open domain video captioning",id:"iejMac/CLIP-MSR-VTT"},{description:"UCF101 Human Actions dataset consists of 13,320 video clips from YouTube, with 101 classes.",id:"quchenyuan/UCF101-ZIP"},{description:"A high-quality dataset for human action recognition in YouTube videos.",id:"nateraw/kinetics"},{description:"A dataset of video clips of humans performing pre-defined basic actions with everyday objects.",id:"HuggingFaceM4/something_something_v2"},{description:"This dataset consists of text-video pairs and contains noisy samples with irrelevant video descriptions",id:"HuggingFaceM4/webvid"},{description:"A dataset of short Flickr videos for the temporal localization of events with descriptions.",id:"iejMac/CLIP-DiDeMo"}],demo:{inputs:[{label:"Input",content:"Darth Vader is surfing on the waves.",type:"text"}],outputs:[{filename:"text-to-video-output.gif",type:"img"}]},metrics:[{description:"Inception Score uses an image classification model that predicts class labels and evaluates how distinct and diverse the images are. A higher score indicates better video generation.",id:"is"},{description:"Frechet Inception Distance uses an image classification model to obtain image embeddings. The metric compares mean and standard deviation of the embeddings of real and generated images. A smaller score indicates better video generation.",id:"fid"},{description:"Frechet Video Distance uses a model that captures coherence for changes in frames and the quality of each frame. A smaller score indicates better video generation.",id:"fvd"},{description:"CLIPSIM measures similarity between video frames and text using an image-text similarity model. A higher score indicates better video generation.",id:"clipsim"}],models:[{description:"A strong model for consistent video generation.",id:"tencent/HunyuanVideo"},{description:"A text-to-video model with high fidelity motion and strong prompt adherence.",id:"Lightricks/LTX-Video"},{description:"A text-to-video model focusing on physics-aware applications like robotics.",id:"nvidia/Cosmos-1.0-Diffusion-7B-Text2World"},{description:"A robust model for video generation.",id:"Wan-AI/Wan2.1-T2V-1.3B"}],spaces:[{description:"An application that generates video from text.",id:"VideoCrafter/VideoCrafter"},{description:"Consistent video generation application.",id:"Wan-AI/Wan2.1"},{description:"A cutting edge video generation application.",id:"Pyramid-Flow/pyramid-flow"}],summary:"Text-to-video models can be used in any application that requires generating consistent sequence of images from text. ",widgetModels:["Wan-AI/Wan2.1-T2V-14B"],youtubeId:void 0},$a={datasets:[{description:"The CIFAR-100 dataset consists of 60000 32x32 colour images in 100 classes, with 600 images per class.",id:"cifar100"},{description:"Multiple images of celebrities, used for facial expression translation.",id:"CelebA"}],demo:{inputs:[{label:"Seed",content:"42",type:"text"},{label:"Number of images to generate:",content:"4",type:"text"}],outputs:[{filename:"unconditional-image-generation-output.jpeg",type:"img"}]},metrics:[{description:"The inception score (IS) evaluates the quality of generated images. It measures the diversity of the generated images (the model predictions are evenly distributed across all possible labels) and their 'distinction' or 'sharpness' (the model confidently predicts a single label for each image).",id:"Inception score (IS)"},{description:"The Fréchet Inception Distance (FID) evaluates the quality of images created by a generative model by calculating the distance between feature vectors for real and generated images.",id:"Frećhet Inception Distance (FID)"}],models:[{description:"High-quality image generation model trained on the CIFAR-10 dataset. It synthesizes images of the ten classes presented in the dataset using diffusion probabilistic models, a class of latent variable models inspired by considerations from nonequilibrium thermodynamics.",id:"google/ddpm-cifar10-32"},{description:"High-quality image generation model trained on the 256x256 CelebA-HQ dataset. It synthesizes images of faces using diffusion probabilistic models, a class of latent variable models inspired by considerations from nonequilibrium thermodynamics.",id:"google/ddpm-celebahq-256"}],spaces:[{description:"An application that can generate realistic faces.",id:"CompVis/celeba-latent-diffusion"}],summary:"Unconditional image generation is the task of generating images with no condition in any context (like a prompt text or another image). Once trained, the model will create images that resemble its training data distribution.",widgetModels:[""],youtubeId:""},La={datasets:[{description:"Benchmark dataset used for video classification with videos that belong to 400 classes.",id:"kinetics400"}],demo:{inputs:[{filename:"video-classification-input.gif",type:"img"}],outputs:[{type:"chart",data:[{label:"Playing Guitar",score:.514},{label:"Playing Tennis",score:.193},{label:"Cooking",score:.068}]}]},metrics:[{description:"",id:"accuracy"},{description:"",id:"recall"},{description:"",id:"precision"},{description:"",id:"f1"}],models:[{description:"Strong Video Classification model trained on the Kinetics 400 dataset.",id:"google/vivit-b-16x2-kinetics400"},{description:"Strong Video Classification model trained on the Kinetics 400 dataset.",id:"microsoft/xclip-base-patch32"}],spaces:[{description:"An application that classifies video at different timestamps.",id:"nateraw/lavila"},{description:"An application that classifies video.",id:"fcakyon/video-classification"}],summary:"Video classification is the task of assigning a label or class to an entire video. Videos are expected to have only one class for each video. Video classification models take a video as input and return a prediction about which class the video belongs to.",widgetModels:[],youtubeId:""},Na={datasets:[{description:"A widely used dataset containing questions (with answers) about images.",id:"Graphcore/vqa"},{description:"A dataset to benchmark visual reasoning based on text in images.",id:"facebook/textvqa"}],demo:{inputs:[{filename:"elephant.jpeg",type:"img"},{label:"Question",content:"What is in this image?",type:"text"}],outputs:[{type:"chart",data:[{label:"elephant",score:.97},{label:"elephants",score:.06},{label:"animal",score:.003}]}]},isPlaceholder:!1,metrics:[{description:"",id:"accuracy"},{description:"Measures how much a predicted answer differs from the ground truth based on the difference in their semantic meaning.",id:"wu-palmer similarity"}],models:[{description:"A visual question answering model trained to convert charts and plots to text.",id:"google/deplot"},{description:"A visual question answering model trained for mathematical reasoning and chart derendering from images.",id:"google/matcha-base"},{description:"A strong visual question answering that answers questions from book covers.",id:"google/pix2struct-ocrvqa-large"}],spaces:[{description:"An application that compares visual question answering models across different tasks.",id:"merve/pix2struct"},{description:"An application that can answer questions based on images.",id:"nielsr/vilt-vqa"},{description:"An application that can caption images and answer questions about a given image. ",id:"Salesforce/BLIP"},{description:"An application that can caption images and answer questions about a given image. ",id:"vumichien/Img2Prompt"}],summary:"Visual Question Answering is the task of answering open-ended questions based on an image. They output natural language responses to natural language questions.",widgetModels:["dandelin/vilt-b32-finetuned-vqa"],youtubeId:""},Da={datasets:[{description:"A widely used dataset used to benchmark multiple variants of text classification.",id:"nyu-mll/glue"},{description:"The Multi-Genre Natural Language Inference (MultiNLI) corpus is a crowd-sourced collection of 433k sentence pairs annotated with textual entailment information.",id:"nyu-mll/multi_nli"},{description:"FEVER is a publicly available dataset for fact extraction and verification against textual sources.",id:"fever/fever"}],demo:{inputs:[{label:"Text Input",content:"Dune is the best movie ever.",type:"text"},{label:"Candidate Labels",content:"CINEMA, ART, MUSIC",type:"text"}],outputs:[{type:"chart",data:[{label:"CINEMA",score:.9},{label:"ART",score:.1},{label:"MUSIC",score:0}]}]},metrics:[],models:[{description:"Powerful zero-shot text classification model.",id:"facebook/bart-large-mnli"},{description:"Cutting-edge zero-shot multilingual text classification model.",id:"MoritzLaurer/ModernBERT-large-zeroshot-v2.0"},{description:"Zero-shot text classification model that can be used for topic and sentiment classification.",id:"knowledgator/gliclass-modern-base-v2.0-init"}],spaces:[],summary:"Zero-shot text classification is a task in natural language processing where a model is trained on a set of labeled examples but is then able to classify new examples from previously unseen classes.",widgetModels:["facebook/bart-large-mnli"]},Pa={datasets:[{description:"",id:""}],demo:{inputs:[{filename:"image-classification-input.jpeg",type:"img"},{label:"Classes",content:"cat, dog, bird",type:"text"}],outputs:[{type:"chart",data:[{label:"Cat",score:.664},{label:"Dog",score:.329},{label:"Bird",score:.008}]}]},metrics:[{description:"Computes the number of times the correct label appears in top K labels predicted",id:"top-K accuracy"}],models:[{description:"Multilingual image classification model for 80 languages.",id:"visheratin/mexma-siglip"},{description:"Strong zero-shot image classification model.",id:"google/siglip2-base-patch16-224"},{description:"Robust zero-shot image classification model.",id:"intfloat/mmE5-mllama-11b-instruct"},{description:"Powerful zero-shot image classification model supporting 94 languages.",id:"jinaai/jina-clip-v2"},{description:"Strong image classification model for biomedical domain.",id:"microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224"}],spaces:[{description:"An application that leverages zero-shot image classification to find best captions to generate an image. ",id:"pharma/CLIP-Interrogator"},{description:"An application to compare different zero-shot image classification models. ",id:"merve/compare_clip_siglip"}],summary:"Zero-shot image classification is the task of classifying previously unseen classes during training of a model.",widgetModels:["google/siglip-so400m-patch14-224"],youtubeId:""},ja={datasets:[],demo:{inputs:[{filename:"zero-shot-object-detection-input.jpg",type:"img"},{label:"Classes",content:"cat, dog, bird",type:"text"}],outputs:[{filename:"zero-shot-object-detection-output.jpg",type:"img"}]},metrics:[{description:"The Average Precision (AP) metric is the Area Under the PR Curve (AUC-PR). It is calculated for each class separately",id:"Average Precision"},{description:"The Mean Average Precision (mAP) metric is the overall average of the AP values",id:"Mean Average Precision"},{description:"The APα metric is the Average Precision at the IoU threshold of a α value, for example, AP50 and AP75",id:"APα"}],models:[{description:"Solid zero-shot object detection model.",id:"IDEA-Research/grounding-dino-base"},{description:"Cutting-edge zero-shot object detection model.",id:"google/owlv2-base-patch16-ensemble"}],spaces:[{description:"A demo to try the state-of-the-art zero-shot object detection model, OWLv2.",id:"merve/owlv2"},{description:"A demo that combines a zero-shot object detection and mask generation model for zero-shot segmentation.",id:"merve/OWLSAM"}],summary:"Zero-shot object detection is a computer vision task to detect objects and their classes in images, without any prior training or knowledge of the classes. Zero-shot object detection models receive an image as input, as well as a list of candidate classes, and output the bounding boxes and labels where the objects have been detected.",widgetModels:[],youtubeId:""},Ra={datasets:[{description:"A large dataset of over 10 million 3D objects.",id:"allenai/objaverse-xl"},{description:"A dataset of isolated object images for evaluating image-to-3D models.",id:"dylanebert/iso3d"}],demo:{inputs:[{filename:"image-to-3d-image-input.png",type:"img"}],outputs:[{label:"Result",content:"image-to-3d-3d-output-filename.glb",type:"text"}]},metrics:[],models:[{description:"Fast image-to-3D mesh model by Tencent.",id:"TencentARC/InstantMesh"},{description:"Fast image-to-3D mesh model by StabilityAI",id:"stabilityai/TripoSR"},{description:"A scaled up image-to-3D mesh model derived from TripoSR.",id:"hwjiang/Real3D"},{description:"Consistent image-to-3d generation model.",id:"stabilityai/stable-point-aware-3d"}],spaces:[{description:"Leaderboard to evaluate image-to-3D models.",id:"dylanebert/3d-arena"},{description:"Image-to-3D demo with mesh outputs.",id:"TencentARC/InstantMesh"},{description:"Image-to-3D demo.",id:"stabilityai/stable-point-aware-3d"},{description:"Image-to-3D demo with mesh outputs.",id:"hwjiang/Real3D"},{description:"Image-to-3D demo with splat outputs.",id:"dylanebert/LGM-mini"}],summary:"Image-to-3D models take in image input and produce 3D output.",widgetModels:[],youtubeId:""},Ba={datasets:[{description:"A large dataset of over 10 million 3D objects.",id:"allenai/objaverse-xl"},{description:"Descriptive captions for 3D objects in Objaverse.",id:"tiange/Cap3D"}],demo:{inputs:[{label:"Prompt",content:"a cat statue",type:"text"}],outputs:[{label:"Result",content:"text-to-3d-3d-output-filename.glb",type:"text"}]},metrics:[],models:[{description:"Text-to-3D mesh model by OpenAI",id:"openai/shap-e"},{description:"Generative 3D gaussian splatting model.",id:"ashawkey/LGM"}],spaces:[{description:"Text-to-3D demo with mesh outputs.",id:"hysts/Shap-E"},{description:"Text/image-to-3D demo with splat outputs.",id:"ashawkey/LGM"}],summary:"Text-to-3D models take in text input and produce 3D output.",widgetModels:[],youtubeId:""},qa={datasets:[{description:"A dataset of hand keypoints of over 500k examples.",id:"Vincent-luo/hagrid-mediapipe-hands"}],demo:{inputs:[{filename:"keypoint-detection-input.png",type:"img"}],outputs:[{filename:"keypoint-detection-output.png",type:"img"}]},metrics:[],models:[{description:"A robust keypoint detection model.",id:"magic-leap-community/superpoint"},{description:"A robust keypoint matching model.",id:"magic-leap-community/superglue_outdoor"},{description:"Strong keypoint detection model used to detect human pose.",id:"facebook/sapiens-pose-1b"},{description:"Powerful keypoint detection model used to detect human pose.",id:"usyd-community/vitpose-plus-base"}],spaces:[{description:"An application that detects hand keypoints in real-time.",id:"datasciencedojo/Hand-Keypoint-Detection-Realtime"},{description:"An application to try a universal keypoint detection model.",id:"merve/SuperPoint"}],summary:"Keypoint detection is the task of identifying meaningful distinctive points or features in an image.",widgetModels:[],youtubeId:""},Va={datasets:[{description:"Multiple-choice questions and answers about videos.",id:"lmms-lab/Video-MME"},{description:"A dataset of instructions and question-answer pairs about videos.",id:"lmms-lab/VideoChatGPT"},{description:"Large video understanding dataset.",id:"HuggingFaceFV/finevideo"}],demo:{inputs:[{filename:"video-text-to-text-input.gif",type:"img"},{label:"Text Prompt",content:"What is happening in this video?",type:"text"}],outputs:[{label:"Answer",content:"The video shows a series of images showing a fountain with water jets and a variety of colorful flowers and butterflies in the background.",type:"text"}]},metrics:[],models:[{description:"A robust video-text-to-text model.",id:"Vision-CAIR/LongVU_Qwen2_7B"},{description:"Strong video-text-to-text model with reasoning capabilities.",id:"GoodiesHere/Apollo-LMMs-Apollo-7B-t32"},{description:"Strong video-text-to-text model.",id:"HuggingFaceTB/SmolVLM2-2.2B-Instruct"}],spaces:[{description:"An application to chat with a video-text-to-text model.",id:"llava-hf/video-llava"},{description:"A leaderboard for various video-text-to-text models.",id:"opencompass/openvlm_video_leaderboard"},{description:"An application to generate highlights from a video.",id:"HuggingFaceTB/SmolVLM2-HighlightGenerator"}],summary:"Video-text-to-text models take in a video and a text prompt and output text. These models are also called video-language models.",widgetModels:[""],youtubeId:""},Fa={"audio-classification":["speechbrain","transformers","transformers.js"],"audio-to-audio":["asteroid","fairseq","speechbrain"],"automatic-speech-recognition":["espnet","nemo","speechbrain","transformers","transformers.js"],"audio-text-to-text":[],"depth-estimation":["transformers","transformers.js"],"document-question-answering":["transformers","transformers.js"],"feature-extraction":["sentence-transformers","transformers","transformers.js"],"fill-mask":["transformers","transformers.js"],"graph-ml":["transformers"],"image-classification":["keras","timm","transformers","transformers.js"],"image-feature-extraction":["timm","transformers"],"image-segmentation":["transformers","transformers.js"],"image-text-to-text":["transformers"],"image-to-image":["diffusers","transformers","transformers.js"],"image-to-text":["transformers","transformers.js"],"image-to-video":["diffusers"],"keypoint-detection":["transformers"],"video-classification":["transformers"],"mask-generation":["transformers"],"multiple-choice":["transformers"],"object-detection":["transformers","transformers.js","ultralytics"],other:[],"question-answering":["adapter-transformers","allennlp","transformers","transformers.js"],robotics:[],"reinforcement-learning":["transformers","stable-baselines3","ml-agents","sample-factory"],"sentence-similarity":["sentence-transformers","spacy","transformers.js"],summarization:["transformers","transformers.js"],"table-question-answering":["transformers"],"table-to-text":["transformers"],"tabular-classification":["sklearn"],"tabular-regression":["sklearn"],"tabular-to-text":["transformers"],"text-classification":["adapter-transformers","setfit","spacy","transformers","transformers.js"],"text-generation":["transformers","transformers.js"],"text-ranking":["sentence-transformers","transformers"],"text-retrieval":[],"text-to-image":["diffusers"],"text-to-speech":["espnet","tensorflowtts","transformers","transformers.js"],"text-to-audio":["transformers","transformers.js"],"text-to-video":["diffusers"],"text2text-generation":["transformers","transformers.js"],"time-series-forecasting":[],"token-classification":["adapter-transformers","flair","spacy","span-marker","stanza","transformers","transformers.js"],translation:["transformers","transformers.js"],"unconditional-image-generation":["diffusers"],"video-text-to-text":["transformers"],"visual-question-answering":["transformers","transformers.js"],"voice-activity-detection":[],"zero-shot-classification":["transformers","transformers.js"],"zero-shot-image-classification":["transformers","transformers.js"],"zero-shot-object-detection":["transformers","transformers.js"],"text-to-3d":["diffusers"],"image-to-3d":["diffusers"],"any-to-any":["transformers"],"visual-document-retrieval":["transformers"]};function k(e,a=we){return{...a,id:e,label:je[e].name,libraries:Fa[e]}}k("any-to-any",we),k("audio-classification",ia),k("audio-to-audio",na),k("audio-text-to-text",we),k("automatic-speech-recognition",oa),k("depth-estimation",ba),k("document-question-answering",ra),k("visual-document-retrieval",we),k("feature-extraction",sa),k("fill-mask",la),k("image-classification",ca),k("image-feature-extraction",pa),k("image-segmentation",fa),k("image-to-image",da),k("image-text-to-text",ma),k("image-to-text",ua),k("keypoint-detection",qa),k("mask-generation",ha),k("object-detection",ga),k("video-classification",La),k("question-answering",wa),k("reinforcement-learning",ya),k("sentence-similarity",va),k("summarization",_a),k("table-question-answering",ka),k("tabular-classification",xa),k("tabular-regression",Aa),k("text-classification",Ca),k("text-generation",Ua),k("text-ranking",Oa),k("text-to-image",Sa),k("text-to-speech",Ia),k("text-to-video",Ma),k("token-classification",Ea),k("translation",Ta),k("unconditional-image-generation",$a),k("video-text-to-text",Va),k("visual-question-answering",Na),k("zero-shot-classification",Da),k("zero-shot-image-classification",Pa),k("zero-shot-object-detection",ja),k("text-to-3d",Ba),k("image-to-3d",Ra);const za=()=>'"Hi, I recently bought a device from your company but it is not working as advertised and I would like to get reimbursed!"',Ha=()=>'"Меня зовут Вольфганг и я живу в Берлине"',Wa=()=>'"The tower is 324 metres (1,063 ft) tall, about the same height as an 81-storey building, and the tallest structure in Paris. Its base is square, measuring 125 metres (410 ft) on each side. During its construction, the Eiffel Tower surpassed the Washington Monument to become the tallest man-made structure in the world, a title it held for 41 years until the Chrysler Building in New York City was finished in 1930. It was the first structure to reach a height of 300 metres. Due to the addition of a broadcasting aerial at the top of the tower in 1957, it is now taller than the Chrysler Building by 5.2 metres (17 ft). Excluding transmitters, the Eiffel Tower is the second tallest free-standing structure in France after the Millau Viaduct."',Ka=()=>`{
    "query": "How many stars does the transformers repository have?",
    "table": {
        "Repository": ["Transformers", "Datasets", "Tokenizers"],
        "Stars": ["36542", "4512", "3934"],
        "Contributors": ["651", "77", "34"],
        "Programming language": [
            "Python",
            "Python",
            "Rust, Python and NodeJS"
        ]
    }
}`,Qa=()=>`{
        "image": "cat.png",
        "question": "What is in this image?"
    }`,Ja=()=>`{
    "question": "What is my name?",
    "context": "My name is Clara and I live in Berkeley."
}`,Xa=()=>'"I like you. I love you"',Ya=()=>'"My name is Sarah Jessica Parker but you can call me Jessica"',it=e=>e.tags.includes("conversational")?e.pipeline_tag==="text-generation"?[{role:"user",content:"What is the capital of France?"}]:[{role:"user",content:[{type:"text",text:"Describe this image in one sentence."},{type:"image_url",image_url:{url:"https://cdn.britannica.com/61/93061-050-99147DCE/Statue-of-Liberty-Island-New-York-Bay.jpg"}}]}]:'"Can you please let us know more details about your "',Za=()=>'"The answer to the universe is"',Ga=e=>`"The answer to the universe is ${e.mask_token}."`,ei=()=>`{
    "source_sentence": "That is a happy person",
    "sentences": [
        "That is a happy dog",
        "That is a very happy person",
        "Today is a sunny day"
    ]
}`,ti=()=>'"Today is a sunny day and I will get some ice cream."',ai=()=>'"cats.jpg"',ii=()=>'"cats.jpg"',ni=()=>`{
    "image": "cat.png",
    "prompt": "Turn the cat into a tiger."
}`,oi=()=>'"cats.jpg"',ri=()=>'"cats.jpg"',si=()=>'"sample1.flac"',li=()=>'"sample1.flac"',ci=()=>'"Astronaut riding a horse"',pi=()=>'"A young man walking on the street"',di=()=>'"The answer to the universe is 42"',ui=()=>'"liquid drum and bass, atmospheric synths, airy sounds"',mi=()=>'"sample1.flac"',nt=()=>`'{"Height":[11.52,12.48],"Length1":[23.2,24.0],"Length2":[25.4,26.3],"Species": ["Bream","Bream"]}'`,fi=()=>'"cats.jpg"',hi={"audio-to-audio":si,"audio-classification":li,"automatic-speech-recognition":mi,"document-question-answering":Qa,"feature-extraction":ti,"fill-mask":Ga,"image-classification":ai,"image-to-text":ii,"image-to-image":ni,"image-segmentation":oi,"object-detection":ri,"question-answering":Ja,"sentence-similarity":ei,summarization:Wa,"table-question-answering":Ka,"tabular-regression":nt,"tabular-classification":nt,"text-classification":Xa,"text-generation":it,"image-text-to-text":it,"text-to-image":ci,"text-to-video":pi,"text-to-speech":di,"text-to-audio":ui,"text2text-generation":Za,"token-classification":Ya,translation:Ha,"zero-shot-classification":za,"zero-shot-image-classification":fi};function be(e,a=!1,t=!1){if(e.pipeline_tag){const i=hi[e.pipeline_tag];if(i){let n=i(e);if(typeof n=="string"&&(a&&(n=n.replace(/(?:(?:\r?\n|\r)\t*)|\t+/g," ")),t)){const o=/^"(.+)"$/s,r=n.match(o);n=r?r[1]:n}return n}}return"No input example has been defined for this model task."}function gi(e,a){let t=JSON.stringify(e,null,"	");return a!=null&&a.indent&&(t=t.replaceAll(`
`,`
${a.indent}`)),a!=null&&a.attributeKeyQuotes||(t=t.replace(/"([^"]+)":/g,"$1:")),a!=null&&a.customContentEscaper&&(t=a.customContentEscaper(t)),t}const At="custom_code";function K(e){const a=e.split("/");return a.length===1?a[0]:a[1]}const bi=e=>JSON.stringify(e).slice(1,-1),yi=e=>{var a,t;return[`from adapters import AutoAdapterModel

model = AutoAdapterModel.from_pretrained("${(t=(a=e.config)==null?void 0:a.adapter_transformers)==null?void 0:t.model_name}")
model.load_adapter("${e.id}", set_active=True)`]},wi=e=>[`import allennlp_models
from allennlp.predictors.predictor import Predictor

predictor = Predictor.from_path("hf://${e.id}")`],vi=e=>[`import allennlp_models
from allennlp.predictors.predictor import Predictor

predictor = Predictor.from_path("hf://${e.id}")
predictor_input = {"passage": "My name is Wolfgang and I live in Berlin", "question": "Where do I live?"}
predictions = predictor.predict_json(predictor_input)`],_i=e=>e.tags.includes("question-answering")?vi(e):wi(e),ki=e=>[`from araclip import AraClip

model = AraClip.from_pretrained("${e.id}")`],xi=e=>[`from asteroid.models import BaseModel

model = BaseModel.from_pretrained("${e.id}")`],Ai=e=>{const a=`# Watermark Generator
from audioseal import AudioSeal

model = AudioSeal.load_generator("${e.id}")
# pass a tensor (tensor_wav) of shape (batch, channels, samples) and a sample rate
wav, sr = tensor_wav, 16000
	
watermark = model.get_watermark(wav, sr)
watermarked_audio = wav + watermark`,t=`# Watermark Detector
from audioseal import AudioSeal

detector = AudioSeal.load_detector("${e.id}")
	
result, message = detector.detect_watermark(watermarked_audio, sr)`;return[a,t]};function Re(e){var a,t;return((t=(a=e.cardData)==null?void 0:a.base_model)==null?void 0:t.toString())??"fill-in-base-model"}function St(e){var t,i,n;const a=((i=(t=e.widgetData)==null?void 0:t[0])==null?void 0:i.text)??((n=e.cardData)==null?void 0:n.instance_prompt);if(a)return bi(a)}const Si=e=>[`import requests
from PIL import Image
from ben2 import AutoModel

url = "https://huggingface.co/datasets/mishig/sample_images/resolve/main/teapot.jpg"
image = Image.open(requests.get(url, stream=True).raw)

model = AutoModel.from_pretrained("${e.id}")
model.to("cuda").eval()
foreground = model.inference(image)
`],Ii=e=>[`from bertopic import BERTopic

model = BERTopic.load("${e.id}")`],Ei=e=>[`from bm25s.hf import BM25HF

retriever = BM25HF.load_from_hub("${e.id}")`],Ti=()=>[`# pip install git+https://github.com/Google-Health/cxr-foundation.git#subdirectory=python

# Load image as grayscale (Stillwaterising, CC0, via Wikimedia Commons)
import requests
from PIL import Image
from io import BytesIO
image_url = "https://upload.wikimedia.org/wikipedia/commons/c/c8/Chest_Xray_PA_3-8-2010.png"
img = Image.open(requests.get(image_url, headers={'User-Agent': 'Demo'}, stream=True).raw).convert('L')

# Run inference
from clientside.clients import make_hugging_face_client
cxr_client = make_hugging_face_client('cxr_model')
print(cxr_client.get_image_embeddings_from_images([img]))`],Ci=e=>{let a,t,i;return a="<ENCODER>",t="<NUMBER_OF_FEATURES>",i="<OUT_CHANNELS>",e.id==="depth-anything/Depth-Anything-V2-Small"?(a="vits",t="64",i="[48, 96, 192, 384]"):e.id==="depth-anything/Depth-Anything-V2-Base"?(a="vitb",t="128",i="[96, 192, 384, 768]"):e.id==="depth-anything/Depth-Anything-V2-Large"&&(a="vitl",t="256",i="[256, 512, 1024, 1024"),[`
# Install from https://github.com/DepthAnything/Depth-Anything-V2

# Load the model and infer depth from an image
import cv2
import torch

from depth_anything_v2.dpt import DepthAnythingV2

# instantiate the model
model = DepthAnythingV2(encoder="${a}", features=${t}, out_channels=${i})

# load the weights
filepath = hf_hub_download(repo_id="${e.id}", filename="depth_anything_v2_${a}.pth", repo_type="model")
state_dict = torch.load(filepath, map_location="cpu")
model.load_state_dict(state_dict).eval()

raw_img = cv2.imread("your/image/path")
depth = model.infer_image(raw_img) # HxW raw depth map in numpy
    `]},Ui=e=>[`# Download checkpoint
pip install huggingface-hub
huggingface-cli download --local-dir checkpoints ${e.id}`,`import depth_pro

# Load model and preprocessing transform
model, transform = depth_pro.create_model_and_transforms()
model.eval()

# Load and preprocess an image.
image, _, f_px = depth_pro.load_rgb("example.png")
image = transform(image)

# Run inference.
prediction = model.infer(image, f_px=f_px)

# Results: 1. Depth in meters
depth = prediction["depth"]
# Results: 2. Focal length in pixels
focallength_px = prediction["focallength_px"]`],Oi=()=>[`from huggingface_hub import from_pretrained_keras
import tensorflow as tf, requests

# Load and format input
IMAGE_URL = "https://storage.googleapis.com/dx-scin-public-data/dataset/images/3445096909671059178.png"
input_tensor = tf.train.Example(
    features=tf.train.Features(
        feature={
            "image/encoded": tf.train.Feature(
                bytes_list=tf.train.BytesList(value=[requests.get(IMAGE_URL, stream=True).content])
            )
        }
    )
).SerializeToString()

# Load model and run inference
loaded_model = from_pretrained_keras("google/derm-foundation")
infer = loaded_model.signatures["serving_default"]
print(infer(inputs=tf.constant([input_tensor])))`],It="Astronaut in a jungle, cold color palette, muted colors, detailed, 8k",Mi=e=>[`from diffusers import DiffusionPipeline

pipe = DiffusionPipeline.from_pretrained("${e.id}")

prompt = "${St(e)??It}"
image = pipe(prompt).images[0]`],$i=e=>[`from diffusers import ControlNetModel, StableDiffusionControlNetPipeline

controlnet = ControlNetModel.from_pretrained("${e.id}")
pipe = StableDiffusionControlNetPipeline.from_pretrained(
	"${Re(e)}", controlnet=controlnet
)`],Li=e=>[`from diffusers import DiffusionPipeline

pipe = DiffusionPipeline.from_pretrained("${Re(e)}")
pipe.load_lora_weights("${e.id}")

prompt = "${St(e)??It}"
image = pipe(prompt).images[0]`],Ni=e=>[`from diffusers import DiffusionPipeline

pipe = DiffusionPipeline.from_pretrained("${Re(e)}")
pipe.load_textual_inversion("${e.id}")`],Di=e=>e.tags.includes("controlnet")?$i(e):e.tags.includes("lora")?Li(e):e.tags.includes("textual_inversion")?Ni(e):Mi(e),Pi=e=>{const a=`# Pipeline for Stable Diffusion 3
from diffusionkit.mlx import DiffusionPipeline

pipeline = DiffusionPipeline(
	shift=3.0,
	use_t5=False,
	model_version=${e.id},
	low_memory_mode=True,
	a16=True,
	w16=True,
)`,t=`# Pipeline for Flux
from diffusionkit.mlx import FluxPipeline

pipeline = FluxPipeline(
  shift=1.0,
  model_version=${e.id},
  low_memory_mode=True,
  a16=True,
  w16=True,
)`,i=`# Image Generation
HEIGHT = 512
WIDTH = 512
NUM_STEPS = ${e.tags.includes("flux")?4:50}
CFG_WEIGHT = ${e.tags.includes("flux")?0:5}

image, _ = pipeline.generate_image(
  "a photo of a cat",
  cfg_weight=CFG_WEIGHT,
  num_steps=NUM_STEPS,
  latent_size=(HEIGHT // 8, WIDTH // 8),
)`;return[e.tags.includes("flux")?t:a,i]},ji=e=>[`# pip install --no-binary :all: cartesia-pytorch
from cartesia_pytorch import ReneLMHeadModel
from transformers import AutoTokenizer

model = ReneLMHeadModel.from_pretrained("${e.id}")
tokenizer = AutoTokenizer.from_pretrained("allenai/OLMo-1B-hf")

in_message = ["Rene Descartes was"]
inputs = tokenizer(in_message, return_tensors="pt")

outputs = model.generate(inputs.input_ids, max_length=50, top_k=100, top_p=0.99)
out_message = tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]

print(out_message)
)`],Ri=e=>[`import mlx.core as mx
import cartesia_mlx as cmx

model = cmx.from_pretrained("${e.id}")
model.set_dtype(mx.float32)   

prompt = "Rene Descartes was"

for text in model.generate(
    prompt,
    max_tokens=500,
    eval_every_n=5,
    verbose=True,
    top_p=0.99,
    temperature=0.85,
):
    print(text, end="", flush=True)
`],Bi=e=>{const a=K(e.id).replaceAll("-","_");return[`# Load it from the Hub directly
import edsnlp
nlp = edsnlp.load("${e.id}")
`,`# Or install it as a package
!pip install git+https://huggingface.co/${e.id}

# and import it as a module
import ${a}

nlp = ${a}.load()  # or edsnlp.load("${a}")
`]},qi=e=>[`from espnet2.bin.tts_inference import Text2Speech

model = Text2Speech.from_pretrained("${e.id}")

speech, *_ = model("text to generate speech from")`],Vi=e=>[`from espnet2.bin.asr_inference import Speech2Text

model = Speech2Text.from_pretrained(
  "${e.id}"
)

speech, rate = soundfile.read("speech.wav")
text, *_ = model(speech)[0]`],Fi=()=>["unknown model type (must be text-to-speech or automatic-speech-recognition)"],zi=e=>e.tags.includes("text-to-speech")?qi(e):e.tags.includes("automatic-speech-recognition")?Vi(e):Fi(),Hi=e=>[`from fairseq.checkpoint_utils import load_model_ensemble_and_task_from_hf_hub

models, cfg, task = load_model_ensemble_and_task_from_hf_hub(
    "${e.id}"
)`],Wi=e=>[`from flair.models import SequenceTagger

tagger = SequenceTagger.load("${e.id}")`],Ki=e=>[`from gliner import GLiNER

model = GLiNER.from_pretrained("${e.id}")`],Qi=e=>[`# CLI usage
# see docs: https://ai-riksarkivet.github.io/htrflow/latest/getting_started/quick_start.html
htrflow pipeline <path/to/pipeline.yaml> <path/to/image>`,`# Python usage
from htrflow.pipeline.pipeline import Pipeline
from htrflow.pipeline.steps import Task
from htrflow.models.framework.model import ModelClass

pipeline = Pipeline(
    [
        Task(
            ModelClass, {"model": "${e.id}"}, {}
        ),
    ])`],Ji=e=>[`# Available backend options are: "jax", "torch", "tensorflow".
import os
os.environ["KERAS_BACKEND"] = "jax"
	
import keras

model = keras.saving.load_model("hf://${e.id}")
`],Xi=e=>`
import keras_hub

# Load CausalLM model (optional: use half precision for inference)
causal_lm = keras_hub.models.CausalLM.from_preset("hf://${e}", dtype="bfloat16")
causal_lm.compile(sampler="greedy")  # (optional) specify a sampler

# Generate text
causal_lm.generate("Keras: deep learning for", max_length=64)
`,Yi=e=>`
import keras_hub

# Load TextToImage model (optional: use half precision for inference)
text_to_image = keras_hub.models.TextToImage.from_preset("hf://${e}", dtype="bfloat16")

# Generate images with a TextToImage model.
text_to_image.generate("Astronaut in a jungle")
`,Zi=e=>`
import keras_hub

# Load TextClassifier model
text_classifier = keras_hub.models.TextClassifier.from_preset(
    "hf://${e}",
    num_classes=2,
)
# Fine-tune
text_classifier.fit(x=["Thilling adventure!", "Total snoozefest."], y=[1, 0])
# Classify text
text_classifier.predict(["Not my cup of tea."])
`,Gi=e=>`
import keras_hub
import keras

# Load ImageClassifier model
image_classifier = keras_hub.models.ImageClassifier.from_preset(
    "hf://${e}",
    num_classes=2,
)
# Fine-tune
image_classifier.fit(
    x=keras.random.randint((32, 64, 64, 3), 0, 256),
    y=keras.random.randint((32, 1), 0, 2),
)
# Classify image
image_classifier.predict(keras.random.randint((1, 64, 64, 3), 0, 256))
`,ot={CausalLM:Xi,TextToImage:Yi,TextClassifier:Zi,ImageClassifier:Gi},en=(e,a)=>`
import keras_hub

# Create a ${e} model
task = keras_hub.models.${e}.from_preset("hf://${a}")
`,tn=e=>`
import keras_hub

# Create a Backbone model unspecialized for any task
backbone = keras_hub.models.Backbone.from_preset("hf://${e}")
`,an=e=>{var n,o;const a=e.id,t=((o=(n=e.config)==null?void 0:n.keras_hub)==null?void 0:o.tasks)??[],i=[];for(const[r,u]of Object.entries(ot))t.includes(r)&&i.push(u(a));for(const r of t)Object.keys(ot).includes(r)||i.push(en(r,a));return i.push(tn(a)),i},nn=e=>{const a=[`from llama_cpp import Llama

llm = Llama.from_pretrained(
	repo_id="${e.id}",
	filename="{{GGUF_FILE}}",
)
`];if(e.tags.includes("conversational")){const t=be(e);a.push(`llm.create_chat_completion(
	messages = ${gi(t,{attributeKeyQuotes:!0,indent:"	"})}
)`)}else a.push(`output = llm(
	"Once upon a time,",
	max_tokens=512,
	echo=True
)
print(output)`);return a},on=e=>[`# Note: 'keras<3.x' or 'tf_keras' must be installed (legacy)
# See https://github.com/keras-team/tf-keras for more details.
from huggingface_hub import from_pretrained_keras

model = from_pretrained_keras("${e.id}")
`],rn=e=>[`from mamba_ssm import MambaLMHeadModel

model = MambaLMHeadModel.from_pretrained("${e.id}")`],sn=e=>[`# Install from https://github.com/Camb-ai/MARS5-TTS

from inference import Mars5TTS
mars5 = Mars5TTS.from_pretrained("${e.id}")`],ln=e=>[`# Install from https://github.com/pq-yang/MatAnyone.git

from matanyone.model.matanyone import MatAnyone
model = MatAnyone.from_pretrained("${e.id}")`],cn=()=>[`# Install from https://github.com/buaacyw/MeshAnything.git

from MeshAnything.models.meshanything import MeshAnything

# refer to https://github.com/buaacyw/MeshAnything/blob/main/main.py#L91 on how to define args
# and https://github.com/buaacyw/MeshAnything/blob/main/app.py regarding usage
model = MeshAnything(args)`],pn=e=>[`import open_clip

model, preprocess_train, preprocess_val = open_clip.create_model_and_transforms('hf-hub:${e.id}')
tokenizer = open_clip.get_tokenizer('hf-hub:${e.id}')`],dn=e=>{var a,t;if((t=(a=e.config)==null?void 0:a.architectures)!=null&&t[0]){const i=e.config.architectures[0];return[[`from paddlenlp.transformers import AutoTokenizer, ${i}`,"",`tokenizer = AutoTokenizer.from_pretrained("${e.id}", from_hf_hub=True)`,`model = ${i}.from_pretrained("${e.id}", from_hf_hub=True)`].join(`
`)]}else return[["# ⚠️ Type of model unknown","from paddlenlp.transformers import AutoTokenizer, AutoModel","",`tokenizer = AutoTokenizer.from_pretrained("${e.id}", from_hf_hub=True)`,`model = AutoModel.from_pretrained("${e.id}", from_hf_hub=True)`].join(`
`)]},un=e=>[`from pyannote.audio import Pipeline
  
pipeline = Pipeline.from_pretrained("${e.id}")

# inference on the whole file
pipeline("file.wav")

# inference on an excerpt
from pyannote.core import Segment
excerpt = Segment(start=2.0, end=5.0)

from pyannote.audio import Audio
waveform, sample_rate = Audio().crop("file.wav", excerpt)
pipeline({"waveform": waveform, "sample_rate": sample_rate})`],mn=e=>[`from pyannote.audio import Model, Inference

model = Model.from_pretrained("${e.id}")
inference = Inference(model)

# inference on the whole file
inference("file.wav")

# inference on an excerpt
from pyannote.core import Segment
excerpt = Segment(start=2.0, end=5.0)
inference.crop("file.wav", excerpt)`],fn=e=>e.tags.includes("pyannote-audio-pipeline")?un(e):mn(e),hn=e=>[`from relik import Relik
 
relik = Relik.from_pretrained("${e.id}")`],gn=e=>[`from tensorflow_tts.inference import AutoProcessor, TFAutoModel

processor = AutoProcessor.from_pretrained("${e.id}")
model = TFAutoModel.from_pretrained("${e.id}")
`],bn=e=>[`from tensorflow_tts.inference import TFAutoModel

model = TFAutoModel.from_pretrained("${e.id}")
audios = model.inference(mels)
`],yn=e=>[`from tensorflow_tts.inference import TFAutoModel

model = TFAutoModel.from_pretrained("${e.id}")
`],wn=e=>e.tags.includes("text-to-mel")?gn(e):e.tags.includes("mel-to-wav")?bn(e):yn(e),vn=e=>[`import timm

model = timm.create_model("hf_hub:${e.id}", pretrained=True)`],_n=()=>[`# pip install sae-lens
from sae_lens import SAE

sae, cfg_dict, sparsity = SAE.from_pretrained(
    release = "RELEASE_ID", # e.g., "gpt2-small-res-jb". See other options in https://github.com/jbloomAus/SAELens/blob/main/sae_lens/pretrained_saes.yaml
    sae_id = "SAE_ID", # e.g., "blocks.8.hook_resid_pre". Won't always be a hook point
)`],kn=()=>[`# seed_story_cfg_path refers to 'https://github.com/TencentARC/SEED-Story/blob/master/configs/clm_models/agent_7b_sft.yaml'
# llm_cfg_path refers to 'https://github.com/TencentARC/SEED-Story/blob/master/configs/clm_models/llama2chat7b_lora.yaml'
from omegaconf import OmegaConf
import hydra

# load Llama2
llm_cfg = OmegaConf.load(llm_cfg_path)
llm = hydra.utils.instantiate(llm_cfg, torch_dtype="fp16")

# initialize seed_story
seed_story_cfg = OmegaConf.load(seed_story_cfg_path)
seed_story = hydra.utils.instantiate(seed_story_cfg, llm=llm) `],xn=(e,a)=>[`import joblib
from skops.hub_utils import download
download("${e.id}", "path_to_folder")
model = joblib.load(
	"${a}"
)
# only load pickle files from sources you trust
# read more about it here https://skops.readthedocs.io/en/stable/persistence.html`],An=(e,a)=>[`from skops.hub_utils import download
from skops.io import load
download("${e.id}", "path_to_folder")
# make sure model file is in skops format
# if model is a pickle file, make sure it's from a source you trust
model = load("path_to_folder/${a}")`],Sn=e=>[`from huggingface_hub import hf_hub_download
import joblib
model = joblib.load(
	hf_hub_download("${e.id}", "sklearn_model.joblib")
)
# only load pickle files from sources you trust
# read more about it here https://skops.readthedocs.io/en/stable/persistence.html`],In=e=>{var a,t,i,n,o;if(e.tags.includes("skops")){const r=(i=(t=(a=e.config)==null?void 0:a.sklearn)==null?void 0:t.model)==null?void 0:i.file,u=(o=(n=e.config)==null?void 0:n.sklearn)==null?void 0:o.model_format;return r?u==="pickle"?xn(e,r):An(e,r):["# ⚠️ Model filename not specified in config.json"]}else return Sn(e)},En=e=>[`import torch
import torchaudio
from einops import rearrange
from stable_audio_tools import get_pretrained_model
from stable_audio_tools.inference.generation import generate_diffusion_cond

device = "cuda" if torch.cuda.is_available() else "cpu"

# Download model
model, model_config = get_pretrained_model("${e.id}")
sample_rate = model_config["sample_rate"]
sample_size = model_config["sample_size"]

model = model.to(device)

# Set up text and timing conditioning
conditioning = [{
	"prompt": "128 BPM tech house drum loop",
}]

# Generate stereo audio
output = generate_diffusion_cond(
	model,
	conditioning=conditioning,
	sample_size=sample_size,
	device=device
)

# Rearrange audio batch to a single sequence
output = rearrange(output, "b d n -> d (b n)")

# Peak normalize, clip, convert to int16, and save to file
output = output.to(torch.float32).div(torch.max(torch.abs(output))).clamp(-1, 1).mul(32767).to(torch.int16).cpu()
torchaudio.save("output.wav", output, sample_rate)`],Tn=e=>[`from huggingface_hub import from_pretrained_fastai

learn = from_pretrained_fastai("${e.id}")`],Cn=e=>{const a=`# Use SAM2 with images
import torch
from sam2.sam2_image_predictor import SAM2ImagePredictor

predictor = SAM2ImagePredictor.from_pretrained(${e.id})

with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
    predictor.set_image(<your_image>)
    masks, _, _ = predictor.predict(<input_prompts>)`,t=`# Use SAM2 with videos
import torch
from sam2.sam2_video_predictor import SAM2VideoPredictor
	
predictor = SAM2VideoPredictor.from_pretrained(${e.id})

with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
    state = predictor.init_state(<your_video>)

    # add new prompts and instantly get the output on the same frame
    frame_idx, object_ids, masks = predictor.add_new_points(state, <your_prompts>):

    # propagate the prompts to get masklets throughout the video
    for frame_idx, object_ids, masks in predictor.propagate_in_video(state):
        ...`;return[a,t]},Un=e=>[`python -m sample_factory.huggingface.load_from_hub -r ${e.id} -d ./train_dir`];function On(e){var t;const a=(t=e.widgetData)==null?void 0:t[0];if(a)return[a.source_sentence,...a.sentences]}const Mn=e=>{const a=e.tags.includes(At)?", trust_remote_code=True":"",t=On(e)??["The weather is lovely today.","It's so sunny outside!","He drove to the stadium."];return[`from sentence_transformers import SentenceTransformer

model = SentenceTransformer("${e.id}"${a})

sentences = ${JSON.stringify(t,null,4)}
embeddings = model.encode(sentences)

similarities = model.similarity(embeddings, embeddings)
print(similarities.shape)
# [${t.length}, ${t.length}]`]},$n=e=>[`from setfit import SetFitModel

model = SetFitModel.from_pretrained("${e.id}")`],Ln=e=>[`!pip install https://huggingface.co/${e.id}/resolve/main/${K(e.id)}-any-py3-none-any.whl

# Using spacy.load().
import spacy
nlp = spacy.load("${K(e.id)}")

# Importing as module.
import ${K(e.id)}
nlp = ${K(e.id)}.load()`],Nn=e=>[`from span_marker import SpanMarkerModel

model = SpanMarkerModel.from_pretrained("${e.id}")`],Dn=e=>[`import stanza

stanza.download("${K(e.id).replace("stanza-","")}")
nlp = stanza.Pipeline("${K(e.id).replace("stanza-","")}")`],Pn=e=>{switch(e){case"EncoderClassifier":return"classify_file";case"EncoderDecoderASR":case"EncoderASR":return"transcribe_file";case"SpectralMaskEnhancement":return"enhance_file";case"SepformerSeparation":return"separate_file";default:return}},jn=e=>{var i,n;const a=(n=(i=e.config)==null?void 0:i.speechbrain)==null?void 0:n.speechbrain_interface;if(a===void 0)return["# interface not specified in config.json"];const t=Pn(a);return t===void 0?["# interface in config.json invalid"]:[`from speechbrain.pretrained import ${a}
model = ${a}.from_hparams(
  "${e.id}"
)
model.${t}("file.wav")`]},Rn=e=>[`from terratorch.registry import BACKBONE_REGISTRY

model = BACKBONE_REGISTRY.build("${e.id}")`],Bn=e=>{var n,o,r,u,d;const a=e.transformersInfo;if(!a)return["# ⚠️ Type of model unknown"];const t=e.tags.includes(At)?", trust_remote_code=True":"";let i;if(a.processor){const p=a.processor==="AutoTokenizer"?"tokenizer":a.processor==="AutoFeatureExtractor"?"extractor":"processor";i=["# Load model directly",`from transformers import ${a.processor}, ${a.auto_model}`,"",`${p} = ${a.processor}.from_pretrained("${e.id}"`+t+")",`model = ${a.auto_model}.from_pretrained("${e.id}"`+t+")"].join(`
`)}else i=["# Load model directly",`from transformers import ${a.auto_model}`,`model = ${a.auto_model}.from_pretrained("${e.id}"`+t+")"].join(`
`);if(e.pipeline_tag&&((n=ta.transformers)!=null&&n.includes(e.pipeline_tag))){const p=["# Use a pipeline as a high-level helper","from transformers import pipeline",""];return e.tags.includes("conversational")&&((r=(o=e.config)==null?void 0:o.tokenizer_config)!=null&&r.chat_template)&&p.push("messages = [",'    {"role": "user", "content": "Who are you?"},',"]"),p.push(`pipe = pipeline("${e.pipeline_tag}", model="${e.id}"`+t+")"),e.tags.includes("conversational")&&((d=(u=e.config)==null?void 0:u.tokenizer_config)!=null&&d.chat_template)&&p.push("pipe(messages)"),[p.join(`
`),i]}return[i]},qn=e=>{if(!e.pipeline_tag)return["// ⚠️ Unknown pipeline tag"];const a="@huggingface/transformers";return[`// npm i ${a}
import { pipeline } from '${a}';

// Allocate pipeline
const pipe = await pipeline('${e.pipeline_tag}', '${e.id}');`]},Vn=e=>{switch(e){case"CAUSAL_LM":return"CausalLM";case"SEQ_2_SEQ_LM":return"Seq2SeqLM";case"TOKEN_CLS":return"TokenClassification";case"SEQ_CLS":return"SequenceClassification";default:return}},Fn=e=>{var n;const{base_model_name_or_path:a,task_type:t}=((n=e.config)==null?void 0:n.peft)??{},i=Vn(t);return i?a?[`from peft import PeftModel
from transformers import AutoModelFor${i}

base_model = AutoModelFor${i}.from_pretrained("${a}")
model = PeftModel.from_pretrained(base_model, "${e.id}")`]:["Base model is not found."]:["Task type is invalid."]},zn=e=>[`from huggingface_hub import hf_hub_download
import fasttext

model = fasttext.load_model(hf_hub_download("${e.id}", "model.bin"))`],Hn=e=>[`from huggingface_sb3 import load_from_hub
checkpoint = load_from_hub(
	repo_id="${e.id}",
	filename="{MODEL FILENAME}.zip",
)`],Wn=(e,a)=>{switch(e){case"ASR":return[`import nemo.collections.asr as nemo_asr
asr_model = nemo_asr.models.ASRModel.from_pretrained("${a.id}")

transcriptions = asr_model.transcribe(["file.wav"])`];default:return}},Kn=e=>[`mlagents-load-from-hf --repo-id="${e.id}" --local-dir="./download: string[]s"`],Qn=()=>[`string modelName = "[Your model name here].sentis";
Model model = ModelLoader.Load(Application.streamingAssetsPath + "/" + modelName);
IWorker engine = WorkerFactory.CreateWorker(BackendType.GPUCompute, model);
// Please see provided C# file for more details
`],Jn=e=>[`
# Load the model and infer image from text
import torch
from app.sana_pipeline import SanaPipeline
from torchvision.utils import save_image

sana = SanaPipeline("configs/sana_config/1024ms/Sana_1600M_img1024.yaml")
sana.from_pretrained("hf://${e.id}")

image = sana(
    prompt='a cyberpunk cat with a neon sign that says "Sana"',
    height=1024,
    width=1024,
    guidance_scale=5.0,
    pag_guidance_scale=2.0,
    num_inference_steps=18,
) `],Xn=e=>[`from Trainer_finetune import Model

model = Model.from_pretrained("${e.id}")`],Yn=e=>[`from voicecraft import VoiceCraft

model = VoiceCraft.from_pretrained("${e.id}")`],Zn=()=>[`import ChatTTS
import torchaudio

chat = ChatTTS.Chat()
chat.load_models(compile=False) # Set to True for better performance

texts = ["PUT YOUR TEXT HERE",]

wavs = chat.infer(texts, )

torchaudio.save("output1.wav", torch.from_numpy(wavs[0]), 24000)`],rt=e=>{const a=e.tags.find(n=>n.match(/^yolov\d+$/)),t=a?`YOLOv${a.slice(4)}`:"YOLOvXX";return[(a?"":`# Couldn't find a valid YOLO version tag.
# Replace XX with the correct version.
`)+`from ultralytics import ${t}

model = ${t}.from_pretrained("${e.id}")
source = 'http://images.cocodataset.org/val2017/000000039769.jpg'
model.predict(source=source, save=True)`]},Gn=e=>[`# Option 1: use with transformers

from transformers import AutoModelForImageSegmentation
birefnet = AutoModelForImageSegmentation.from_pretrained("${e.id}", trust_remote_code=True)
`,`# Option 2: use with BiRefNet

# Install from https://github.com/ZhengPeng7/BiRefNet

from models.birefnet import BiRefNet
model = BiRefNet.from_pretrained("${e.id}")`],eo=e=>[`from swarmformer import SwarmFormerModel

model = SwarmFormerModel.from_pretrained("${e.id}")
`],to=e=>[`pip install huggingface_hub hf_transfer

export HF_HUB_ENABLE_HF_TRANSFER=1
huggingface-cli download --local-dir ${K(e.id)} ${e.id}`],ao=e=>[`from mlxim.model import create_model

model = create_model(${e.id})`],io=e=>[`from model2vec import StaticModel

model = StaticModel.from_pretrained("${e.id}")`],no=e=>{let a;return e.tags.includes("automatic-speech-recognition")&&(a=Wn("ASR",e)),a??["# tag did not correspond to a valid NeMo domain."]},oo=e=>[`from pxia import AutoModel

model = AutoModel.from_pretrained("${e.id}")`],ro=e=>[`from pythae.models import AutoModel

model = AutoModel.load_from_hf_hub("${e.id}")`],so=e=>[`from audiocraft.models import MusicGen

model = MusicGen.get_pretrained("${e.id}")

descriptions = ['happy rock', 'energetic EDM', 'sad jazz']
wav = model.generate(descriptions)  # generates 3 samples.`],lo=e=>[`from audiocraft.models import MAGNeT
	
model = MAGNeT.get_pretrained("${e.id}")

descriptions = ['disco beat', 'energetic EDM', 'funky groove']
wav = model.generate(descriptions)  # generates 3 samples.`],co=e=>[`from audiocraft.models import AudioGen
	
model = AudioGen.get_pretrained("${e.id}")
model.set_generation_params(duration=5)  # generate 5 seconds.
descriptions = ['dog barking', 'sirene of an emergency vehicle', 'footsteps in a corridor']
wav = model.generate(descriptions)  # generates 3 samples.`],po=e=>[`from anemoi.inference.runners.default import DefaultRunner
from anemoi.inference.config import Configuration
# Create Configuration
config = Configuration(checkpoint = {"huggingface":{"repo_id":"${e.id}"}})
# Load Runner
runner = DefaultRunner(config)`],uo=e=>e.tags.includes("musicgen")?so(e):e.tags.includes("audiogen")?co(e):e.tags.includes("magnet")?lo(e):["# Type of model unknown."],mo=()=>[`# Install CLI with Homebrew on macOS device
brew install whisperkit-cli

# View all available inference options
whisperkit-cli transcribe --help
	
# Download and run inference using whisper base model
whisperkit-cli transcribe --audio-path /path/to/audio.mp3

# Or use your preferred model variant
whisperkit-cli transcribe --model "large-v3" --model-prefix "distil" --audio-path /path/to/audio.mp3 --verbose`],fo=e=>[`from threedtopia_xl.models import threedtopia_xl

model = threedtopia_xl.from_pretrained("${e.id}")
model.generate(cond="path/to/image.png")`],ho={"adapter-transformers":{prettyLabel:"Adapters",repoName:"adapters",repoUrl:"https://github.com/Adapter-Hub/adapters",docsUrl:"https://huggingface.co/docs/hub/adapters",snippets:yi,filter:!0,countDownloads:'path:"adapter_config.json"'},allennlp:{prettyLabel:"AllenNLP",repoName:"AllenNLP",repoUrl:"https://github.com/allenai/allennlp",docsUrl:"https://huggingface.co/docs/hub/allennlp",snippets:_i,filter:!0},anemoi:{prettyLabel:"AnemoI",repoName:"AnemoI",repoUrl:"https://github.com/ecmwf/anemoi-inference",docsUrl:"https://anemoi-docs.readthedocs.io/en/latest/",filter:!1,countDownloads:'path_extension:"ckpt"',snippets:po},araclip:{prettyLabel:"AraClip",repoName:"AraClip",repoUrl:"https://huggingface.co/Arabic-Clip/araclip",filter:!1,snippets:ki},asteroid:{prettyLabel:"Asteroid",repoName:"Asteroid",repoUrl:"https://github.com/asteroid-team/asteroid",docsUrl:"https://huggingface.co/docs/hub/asteroid",snippets:xi,filter:!0,countDownloads:'path:"pytorch_model.bin"'},audiocraft:{prettyLabel:"Audiocraft",repoName:"audiocraft",repoUrl:"https://github.com/facebookresearch/audiocraft",snippets:uo,filter:!1,countDownloads:'path:"state_dict.bin"'},audioseal:{prettyLabel:"AudioSeal",repoName:"audioseal",repoUrl:"https://github.com/facebookresearch/audioseal",filter:!1,countDownloads:'path_extension:"pth"',snippets:Ai},ben2:{prettyLabel:"BEN2",repoName:"BEN2",repoUrl:"https://github.com/PramaLLC/BEN2",snippets:Si,filter:!1},bertopic:{prettyLabel:"BERTopic",repoName:"BERTopic",repoUrl:"https://github.com/MaartenGr/BERTopic",snippets:Ii,filter:!0},big_vision:{prettyLabel:"Big Vision",repoName:"big_vision",repoUrl:"https://github.com/google-research/big_vision",filter:!1,countDownloads:'path_extension:"npz"'},birder:{prettyLabel:"Birder",repoName:"Birder",repoUrl:"https://gitlab.com/birder/birder",filter:!1,countDownloads:'path_extension:"pt"'},birefnet:{prettyLabel:"BiRefNet",repoName:"BiRefNet",repoUrl:"https://github.com/ZhengPeng7/BiRefNet",snippets:Gn,filter:!1},bm25s:{prettyLabel:"BM25S",repoName:"bm25s",repoUrl:"https://github.com/xhluca/bm25s",snippets:Ei,filter:!1,countDownloads:'path:"params.index.json"'},champ:{prettyLabel:"Champ",repoName:"Champ",repoUrl:"https://github.com/fudan-generative-vision/champ",countDownloads:'path:"champ/motion_module.pth"'},chat_tts:{prettyLabel:"ChatTTS",repoName:"ChatTTS",repoUrl:"https://github.com/2noise/ChatTTS.git",snippets:Zn,filter:!1,countDownloads:'path:"asset/GPT.pt"'},colpali:{prettyLabel:"ColPali",repoName:"ColPali",repoUrl:"https://github.com/ManuelFay/colpali",filter:!1,countDownloads:'path:"adapter_config.json"'},comet:{prettyLabel:"COMET",repoName:"COMET",repoUrl:"https://github.com/Unbabel/COMET/",countDownloads:'path:"hparams.yaml"'},cosmos:{prettyLabel:"Cosmos",repoName:"Cosmos",repoUrl:"https://github.com/NVIDIA/Cosmos",countDownloads:'path:"config.json" OR path_extension:"pt"'},"cxr-foundation":{prettyLabel:"CXR Foundation",repoName:"cxr-foundation",repoUrl:"https://github.com/google-health/cxr-foundation",snippets:Ti,filter:!1,countDownloads:'path:"precomputed_embeddings/embeddings.npz" OR path:"pax-elixr-b-text/saved_model.pb"'},deepforest:{prettyLabel:"DeepForest",repoName:"deepforest",docsUrl:"https://deepforest.readthedocs.io/en/latest/",repoUrl:"https://github.com/weecology/DeepForest"},"depth-anything-v2":{prettyLabel:"DepthAnythingV2",repoName:"Depth Anything V2",repoUrl:"https://github.com/DepthAnything/Depth-Anything-V2",snippets:Ci,filter:!1,countDownloads:'path_extension:"pth"'},"depth-pro":{prettyLabel:"Depth Pro",repoName:"Depth Pro",repoUrl:"https://github.com/apple/ml-depth-pro",countDownloads:'path_extension:"pt"',snippets:Ui,filter:!1},"derm-foundation":{prettyLabel:"Derm Foundation",repoName:"derm-foundation",repoUrl:"https://github.com/google-health/derm-foundation",snippets:Oi,filter:!1,countDownloads:'path:"scin_dataset_precomputed_embeddings.npz" OR path:"saved_model.pb"'},diffree:{prettyLabel:"Diffree",repoName:"Diffree",repoUrl:"https://github.com/OpenGVLab/Diffree",filter:!1,countDownloads:'path:"diffree-step=000010999.ckpt"'},diffusers:{prettyLabel:"Diffusers",repoName:"🤗/diffusers",repoUrl:"https://github.com/huggingface/diffusers",docsUrl:"https://huggingface.co/docs/hub/diffusers",snippets:Di,filter:!0},diffusionkit:{prettyLabel:"DiffusionKit",repoName:"DiffusionKit",repoUrl:"https://github.com/argmaxinc/DiffusionKit",snippets:Pi},doctr:{prettyLabel:"docTR",repoName:"doctr",repoUrl:"https://github.com/mindee/doctr"},cartesia_pytorch:{prettyLabel:"Cartesia Pytorch",repoName:"Cartesia Pytorch",repoUrl:"https://github.com/cartesia-ai/cartesia_pytorch",snippets:ji},cartesia_mlx:{prettyLabel:"Cartesia MLX",repoName:"Cartesia MLX",repoUrl:"https://github.com/cartesia-ai/cartesia_mlx",snippets:Ri},clipscope:{prettyLabel:"clipscope",repoName:"clipscope",repoUrl:"https://github.com/Lewington-pitsos/clipscope",filter:!1,countDownloads:'path_extension:"pt"'},cosyvoice:{prettyLabel:"CosyVoice",repoName:"CosyVoice",repoUrl:"https://github.com/FunAudioLLM/CosyVoice",filter:!1,countDownloads:'path_extension:"onnx" OR path_extension:"pt"'},cotracker:{prettyLabel:"CoTracker",repoName:"CoTracker",repoUrl:"https://github.com/facebookresearch/co-tracker",filter:!1,countDownloads:'path_extension:"pth"'},edsnlp:{prettyLabel:"EDS-NLP",repoName:"edsnlp",repoUrl:"https://github.com/aphp/edsnlp",docsUrl:"https://aphp.github.io/edsnlp/latest/",filter:!1,snippets:Bi,countDownloads:'path_filename:"config" AND path_extension:"cfg"'},elm:{prettyLabel:"ELM",repoName:"elm",repoUrl:"https://github.com/slicex-ai/elm",filter:!1,countDownloads:'path_filename:"slicex_elm_config" AND path_extension:"json"'},espnet:{prettyLabel:"ESPnet",repoName:"ESPnet",repoUrl:"https://github.com/espnet/espnet",docsUrl:"https://huggingface.co/docs/hub/espnet",snippets:zi,filter:!0},fairseq:{prettyLabel:"Fairseq",repoName:"fairseq",repoUrl:"https://github.com/pytorch/fairseq",snippets:Hi,filter:!0},fastai:{prettyLabel:"fastai",repoName:"fastai",repoUrl:"https://github.com/fastai/fastai",docsUrl:"https://huggingface.co/docs/hub/fastai",snippets:Tn,filter:!0},fasttext:{prettyLabel:"fastText",repoName:"fastText",repoUrl:"https://fasttext.cc/",snippets:zn,filter:!0,countDownloads:'path_extension:"bin"'},flair:{prettyLabel:"Flair",repoName:"Flair",repoUrl:"https://github.com/flairNLP/flair",docsUrl:"https://huggingface.co/docs/hub/flair",snippets:Wi,filter:!0,countDownloads:'path:"pytorch_model.bin"'},"gemma.cpp":{prettyLabel:"gemma.cpp",repoName:"gemma.cpp",repoUrl:"https://github.com/google/gemma.cpp",filter:!1,countDownloads:'path_extension:"sbs"'},gliner:{prettyLabel:"GLiNER",repoName:"GLiNER",repoUrl:"https://github.com/urchade/GLiNER",snippets:Ki,filter:!1,countDownloads:'path:"gliner_config.json"'},"glyph-byt5":{prettyLabel:"Glyph-ByT5",repoName:"Glyph-ByT5",repoUrl:"https://github.com/AIGText/Glyph-ByT5",filter:!1,countDownloads:'path:"checkpoints/byt5_model.pt"'},grok:{prettyLabel:"Grok",repoName:"Grok",repoUrl:"https://github.com/xai-org/grok-1",filter:!1,countDownloads:'path:"ckpt/tensor00000_000" OR path:"ckpt-0/tensor00000_000"'},hallo:{prettyLabel:"Hallo",repoName:"Hallo",repoUrl:"https://github.com/fudan-generative-vision/hallo",countDownloads:'path:"hallo/net.pth"'},hezar:{prettyLabel:"Hezar",repoName:"Hezar",repoUrl:"https://github.com/hezarai/hezar",docsUrl:"https://hezarai.github.io/hezar",countDownloads:'path:"model_config.yaml" OR path:"embedding/embedding_config.yaml"'},htrflow:{prettyLabel:"HTRflow",repoName:"HTRflow",repoUrl:"https://github.com/AI-Riksarkivet/htrflow",docsUrl:"https://ai-riksarkivet.github.io/htrflow",snippets:Qi},"hunyuan-dit":{prettyLabel:"HunyuanDiT",repoName:"HunyuanDiT",repoUrl:"https://github.com/Tencent/HunyuanDiT",countDownloads:'path:"pytorch_model_ema.pt" OR path:"pytorch_model_distill.pt"'},"hunyuan3d-2":{prettyLabel:"Hunyuan3D-2",repoName:"Hunyuan3D-2",repoUrl:"https://github.com/Tencent/Hunyuan3D-2",countDownloads:'path_filename:"model_index" OR path_filename:"config"'},imstoucan:{prettyLabel:"IMS Toucan",repoName:"IMS-Toucan",repoUrl:"https://github.com/DigitalPhonetics/IMS-Toucan",countDownloads:'path:"embedding_gan.pt" OR path:"Vocoder.pt" OR path:"ToucanTTS.pt"'},keras:{prettyLabel:"Keras",repoName:"Keras",repoUrl:"https://github.com/keras-team/keras",docsUrl:"https://huggingface.co/docs/hub/keras",snippets:Ji,filter:!0,countDownloads:'path:"config.json" OR path_extension:"keras"'},"tf-keras":{prettyLabel:"TF-Keras",repoName:"TF-Keras",repoUrl:"https://github.com/keras-team/tf-keras",docsUrl:"https://huggingface.co/docs/hub/tf-keras",snippets:on,countDownloads:'path:"saved_model.pb"'},"keras-hub":{prettyLabel:"KerasHub",repoName:"KerasHub",repoUrl:"https://github.com/keras-team/keras-hub",docsUrl:"https://keras.io/keras_hub/",snippets:an,filter:!0},k2:{prettyLabel:"K2",repoName:"k2",repoUrl:"https://github.com/k2-fsa/k2"},liveportrait:{prettyLabel:"LivePortrait",repoName:"LivePortrait",repoUrl:"https://github.com/KwaiVGI/LivePortrait",filter:!1,countDownloads:'path:"liveportrait/landmark.onnx"'},"llama-cpp-python":{prettyLabel:"llama-cpp-python",repoName:"llama-cpp-python",repoUrl:"https://github.com/abetlen/llama-cpp-python",snippets:nn},"mini-omni2":{prettyLabel:"Mini-Omni2",repoName:"Mini-Omni2",repoUrl:"https://github.com/gpt-omni/mini-omni2",countDownloads:'path:"model_config.yaml"'},mindspore:{prettyLabel:"MindSpore",repoName:"mindspore",repoUrl:"https://github.com/mindspore-ai/mindspore"},"mamba-ssm":{prettyLabel:"MambaSSM",repoName:"MambaSSM",repoUrl:"https://github.com/state-spaces/mamba",filter:!1,snippets:rn},"mars5-tts":{prettyLabel:"MARS5-TTS",repoName:"MARS5-TTS",repoUrl:"https://github.com/Camb-ai/MARS5-TTS",filter:!1,countDownloads:'path:"mars5_ar.safetensors"',snippets:sn},matanyone:{prettyLabel:"MatAnyone",repoName:"MatAnyone",repoUrl:"https://github.com/pq-yang/MatAnyone",snippets:ln,filter:!1},"mesh-anything":{prettyLabel:"MeshAnything",repoName:"MeshAnything",repoUrl:"https://github.com/buaacyw/MeshAnything",filter:!1,countDownloads:'path:"MeshAnything_350m.pth"',snippets:cn},merlin:{prettyLabel:"Merlin",repoName:"Merlin",repoUrl:"https://github.com/StanfordMIMI/Merlin",filter:!1,countDownloads:'path_extension:"pt"'},medvae:{prettyLabel:"MedVAE",repoName:"MedVAE",repoUrl:"https://github.com/StanfordMIMI/MedVAE",filter:!1,countDownloads:'path_extension:"ckpt"'},mitie:{prettyLabel:"MITIE",repoName:"MITIE",repoUrl:"https://github.com/mit-nlp/MITIE",countDownloads:'path_filename:"total_word_feature_extractor"'},"ml-agents":{prettyLabel:"ml-agents",repoName:"ml-agents",repoUrl:"https://github.com/Unity-Technologies/ml-agents",docsUrl:"https://huggingface.co/docs/hub/ml-agents",snippets:Kn,filter:!0,countDownloads:'path_extension:"onnx"'},mlx:{prettyLabel:"MLX",repoName:"MLX",repoUrl:"https://github.com/ml-explore/mlx-examples/tree/main",snippets:to,filter:!0},"mlx-image":{prettyLabel:"mlx-image",repoName:"mlx-image",repoUrl:"https://github.com/riccardomusmeci/mlx-image",docsUrl:"https://huggingface.co/docs/hub/mlx-image",snippets:ao,filter:!1,countDownloads:'path:"model.safetensors"'},"mlc-llm":{prettyLabel:"MLC-LLM",repoName:"MLC-LLM",repoUrl:"https://github.com/mlc-ai/mlc-llm",docsUrl:"https://llm.mlc.ai/docs/",filter:!1,countDownloads:'path:"mlc-chat-config.json"'},model2vec:{prettyLabel:"Model2Vec",repoName:"model2vec",repoUrl:"https://github.com/MinishLab/model2vec",snippets:io,filter:!1},moshi:{prettyLabel:"Moshi",repoName:"Moshi",repoUrl:"https://github.com/kyutai-labs/moshi",filter:!1,countDownloads:'path:"tokenizer-e351c8d8-checkpoint125.safetensors"'},nemo:{prettyLabel:"NeMo",repoName:"NeMo",repoUrl:"https://github.com/NVIDIA/NeMo",snippets:no,filter:!0,countDownloads:'path_extension:"nemo" OR path:"model_config.yaml"'},"open-oasis":{prettyLabel:"open-oasis",repoName:"open-oasis",repoUrl:"https://github.com/etched-ai/open-oasis",countDownloads:'path:"oasis500m.safetensors"'},open_clip:{prettyLabel:"OpenCLIP",repoName:"OpenCLIP",repoUrl:"https://github.com/mlfoundations/open_clip",snippets:pn,filter:!0,countDownloads:`path:"open_clip_model.safetensors"
			OR path:"model.safetensors"
			OR path:"open_clip_pytorch_model.bin"
			OR path:"pytorch_model.bin"`},"open-sora":{prettyLabel:"Open-Sora",repoName:"Open-Sora",repoUrl:"https://github.com/hpcaitech/Open-Sora",filter:!1,countDownloads:'path:"Open_Sora_v2.safetensors"'},paddlenlp:{prettyLabel:"paddlenlp",repoName:"PaddleNLP",repoUrl:"https://github.com/PaddlePaddle/PaddleNLP",docsUrl:"https://huggingface.co/docs/hub/paddlenlp",snippets:dn,filter:!0,countDownloads:'path:"model_config.json"'},peft:{prettyLabel:"PEFT",repoName:"PEFT",repoUrl:"https://github.com/huggingface/peft",snippets:Fn,filter:!0,countDownloads:'path:"adapter_config.json"'},pxia:{prettyLabel:"pxia",repoName:"pxia",repoUrl:"https://github.com/not-lain/pxia",snippets:oo,filter:!1},"pyannote-audio":{prettyLabel:"pyannote.audio",repoName:"pyannote-audio",repoUrl:"https://github.com/pyannote/pyannote-audio",snippets:fn,filter:!0},"py-feat":{prettyLabel:"Py-Feat",repoName:"Py-Feat",repoUrl:"https://github.com/cosanlab/py-feat",docsUrl:"https://py-feat.org/",filter:!1},pythae:{prettyLabel:"pythae",repoName:"pythae",repoUrl:"https://github.com/clementchadebec/benchmark_VAE",snippets:ro,filter:!1},recurrentgemma:{prettyLabel:"RecurrentGemma",repoName:"recurrentgemma",repoUrl:"https://github.com/google-deepmind/recurrentgemma",filter:!1,countDownloads:'path:"tokenizer.model"'},relik:{prettyLabel:"Relik",repoName:"Relik",repoUrl:"https://github.com/SapienzaNLP/relik",snippets:hn,filter:!1},refiners:{prettyLabel:"Refiners",repoName:"Refiners",repoUrl:"https://github.com/finegrain-ai/refiners",docsUrl:"https://refine.rs/",filter:!1,countDownloads:'path:"model.safetensors"'},reverb:{prettyLabel:"Reverb",repoName:"Reverb",repoUrl:"https://github.com/revdotcom/reverb",filter:!1},saelens:{prettyLabel:"SAELens",repoName:"SAELens",repoUrl:"https://github.com/jbloomAus/SAELens",snippets:_n,filter:!1},sam2:{prettyLabel:"sam2",repoName:"sam2",repoUrl:"https://github.com/facebookresearch/segment-anything-2",filter:!1,snippets:Cn,countDownloads:'path_extension:"pt"'},"sample-factory":{prettyLabel:"sample-factory",repoName:"sample-factory",repoUrl:"https://github.com/alex-petrenko/sample-factory",docsUrl:"https://huggingface.co/docs/hub/sample-factory",snippets:Un,filter:!0,countDownloads:'path:"cfg.json"'},sapiens:{prettyLabel:"sapiens",repoName:"sapiens",repoUrl:"https://github.com/facebookresearch/sapiens",filter:!1,countDownloads:'path_extension:"pt2" OR path_extension:"pth" OR path_extension:"onnx"'},"sentence-transformers":{prettyLabel:"sentence-transformers",repoName:"sentence-transformers",repoUrl:"https://github.com/UKPLab/sentence-transformers",docsUrl:"https://huggingface.co/docs/hub/sentence-transformers",snippets:Mn,filter:!0},setfit:{prettyLabel:"setfit",repoName:"setfit",repoUrl:"https://github.com/huggingface/setfit",docsUrl:"https://huggingface.co/docs/hub/setfit",snippets:$n,filter:!0},sklearn:{prettyLabel:"Scikit-learn",repoName:"Scikit-learn",repoUrl:"https://github.com/scikit-learn/scikit-learn",snippets:In,filter:!0,countDownloads:'path:"sklearn_model.joblib"'},spacy:{prettyLabel:"spaCy",repoName:"spaCy",repoUrl:"https://github.com/explosion/spaCy",docsUrl:"https://huggingface.co/docs/hub/spacy",snippets:Ln,filter:!0,countDownloads:'path_extension:"whl"'},"span-marker":{prettyLabel:"SpanMarker",repoName:"SpanMarkerNER",repoUrl:"https://github.com/tomaarsen/SpanMarkerNER",docsUrl:"https://huggingface.co/docs/hub/span_marker",snippets:Nn,filter:!0},speechbrain:{prettyLabel:"speechbrain",repoName:"speechbrain",repoUrl:"https://github.com/speechbrain/speechbrain",docsUrl:"https://huggingface.co/docs/hub/speechbrain",snippets:jn,filter:!0,countDownloads:'path:"hyperparams.yaml"'},"ssr-speech":{prettyLabel:"SSR-Speech",repoName:"SSR-Speech",repoUrl:"https://github.com/WangHelin1997/SSR-Speech",filter:!1,countDownloads:'path_extension:".pth"'},"stable-audio-tools":{prettyLabel:"Stable Audio Tools",repoName:"stable-audio-tools",repoUrl:"https://github.com/Stability-AI/stable-audio-tools.git",filter:!1,countDownloads:'path:"model.safetensors"',snippets:En},"diffusion-single-file":{prettyLabel:"Diffusion Single File",repoName:"diffusion-single-file",repoUrl:"https://github.com/comfyanonymous/ComfyUI",filter:!1,countDownloads:'path_extension:"safetensors"'},"seed-story":{prettyLabel:"SEED-Story",repoName:"SEED-Story",repoUrl:"https://github.com/TencentARC/SEED-Story",filter:!1,countDownloads:'path:"cvlm_llama2_tokenizer/tokenizer.model"',snippets:kn},soloaudio:{prettyLabel:"SoloAudio",repoName:"SoloAudio",repoUrl:"https://github.com/WangHelin1997/SoloAudio",filter:!1,countDownloads:'path:"soloaudio_v2.pt"'},"stable-baselines3":{prettyLabel:"stable-baselines3",repoName:"stable-baselines3",repoUrl:"https://github.com/huggingface/huggingface_sb3",docsUrl:"https://huggingface.co/docs/hub/stable-baselines3",snippets:Hn,filter:!0,countDownloads:'path_extension:"zip"'},stanza:{prettyLabel:"Stanza",repoName:"stanza",repoUrl:"https://github.com/stanfordnlp/stanza",docsUrl:"https://huggingface.co/docs/hub/stanza",snippets:Dn,filter:!0,countDownloads:'path:"models/default.zip"'},swarmformer:{prettyLabel:"SwarmFormer",repoName:"SwarmFormer",repoUrl:"https://github.com/takara-ai/SwarmFormer",snippets:eo,filter:!1},"f5-tts":{prettyLabel:"F5-TTS",repoName:"F5-TTS",repoUrl:"https://github.com/SWivid/F5-TTS",filter:!1,countDownloads:'path_extension:"safetensors" OR path_extension:"pt"'},genmo:{prettyLabel:"Genmo",repoName:"Genmo",repoUrl:"https://github.com/genmoai/models",filter:!1,countDownloads:'path:"vae_stats.json"'},tensorflowtts:{prettyLabel:"TensorFlowTTS",repoName:"TensorFlowTTS",repoUrl:"https://github.com/TensorSpeech/TensorFlowTTS",snippets:wn},tabpfn:{prettyLabel:"TabPFN",repoName:"TabPFN",repoUrl:"https://github.com/PriorLabs/TabPFN"},terratorch:{prettyLabel:"TerraTorch",repoName:"TerraTorch",repoUrl:"https://github.com/IBM/terratorch",docsUrl:"https://ibm.github.io/terratorch/",filter:!1,countDownloads:'path_extension:"pt"',snippets:Rn},"tic-clip":{prettyLabel:"TiC-CLIP",repoName:"TiC-CLIP",repoUrl:"https://github.com/apple/ml-tic-clip",filter:!1,countDownloads:'path_extension:"pt" AND path_prefix:"checkpoints/"'},timesfm:{prettyLabel:"TimesFM",repoName:"timesfm",repoUrl:"https://github.com/google-research/timesfm",filter:!1,countDownloads:'path:"checkpoints/checkpoint_1100000/state/checkpoint"'},timm:{prettyLabel:"timm",repoName:"pytorch-image-models",repoUrl:"https://github.com/rwightman/pytorch-image-models",docsUrl:"https://huggingface.co/docs/hub/timm",snippets:vn,filter:!0,countDownloads:'path:"pytorch_model.bin" OR path:"model.safetensors"'},transformers:{prettyLabel:"Transformers",repoName:"🤗/transformers",repoUrl:"https://github.com/huggingface/transformers",docsUrl:"https://huggingface.co/docs/hub/transformers",snippets:Bn,filter:!0},"transformers.js":{prettyLabel:"Transformers.js",repoName:"transformers.js",repoUrl:"https://github.com/huggingface/transformers.js",docsUrl:"https://huggingface.co/docs/hub/transformers-js",snippets:qn,filter:!0},trellis:{prettyLabel:"Trellis",repoName:"Trellis",repoUrl:"https://github.com/microsoft/TRELLIS",countDownloads:'path_extension:"safetensors"'},ultralytics:{prettyLabel:"ultralytics",repoName:"ultralytics",repoUrl:"https://github.com/ultralytics/ultralytics",docsUrl:"https://github.com/ultralytics/ultralytics",filter:!1,countDownloads:'path_extension:"pt"',snippets:rt},"uni-3dar":{prettyLabel:"Uni-3DAR",repoName:"Uni-3DAR",repoUrl:"https://github.com/dptech-corp/Uni-3DAR",docsUrl:"https://github.com/dptech-corp/Uni-3DAR",countDownloads:'path_extension:"pt"'},"unity-sentis":{prettyLabel:"unity-sentis",repoName:"unity-sentis",repoUrl:"https://github.com/Unity-Technologies/sentis-samples",snippets:Qn,filter:!0,countDownloads:'path_extension:"sentis"'},sana:{prettyLabel:"Sana",repoName:"Sana",repoUrl:"https://github.com/NVlabs/Sana",countDownloads:'path_extension:"pth"',snippets:Jn},"vfi-mamba":{prettyLabel:"VFIMamba",repoName:"VFIMamba",repoUrl:"https://github.com/MCG-NJU/VFIMamba",countDownloads:'path_extension:"pkl"',snippets:Xn},voicecraft:{prettyLabel:"VoiceCraft",repoName:"VoiceCraft",repoUrl:"https://github.com/jasonppy/VoiceCraft",docsUrl:"https://github.com/jasonppy/VoiceCraft",snippets:Yn},wham:{prettyLabel:"WHAM",repoName:"wham",repoUrl:"https://huggingface.co/microsoft/wham",docsUrl:"https://huggingface.co/microsoft/wham/blob/main/README.md",countDownloads:'path_extension:"ckpt"'},whisperkit:{prettyLabel:"WhisperKit",repoName:"WhisperKit",repoUrl:"https://github.com/argmaxinc/WhisperKit",docsUrl:"https://github.com/argmaxinc/WhisperKit?tab=readme-ov-file#homebrew",snippets:mo,countDownloads:'path_filename:"model" AND path_extension:"mil" AND _exists_:"path_prefix"'},yolov10:{prettyLabel:"YOLOv10",repoName:"YOLOv10",repoUrl:"https://github.com/THU-MIG/yolov10",docsUrl:"https://github.com/THU-MIG/yolov10",countDownloads:'path_extension:"pt" OR path_extension:"safetensors"',snippets:rt},"3dtopia-xl":{prettyLabel:"3DTopia-XL",repoName:"3DTopia-XL",repoUrl:"https://github.com/3DTopia/3DTopia-XL",filter:!1,countDownloads:'path:"model_vae_fp16.pt"',snippets:fo}};Object.entries(ho).filter(([e,a])=>a.filter).map(([e])=>e);var $e;(function(e){e[e.F32=0]="F32",e[e.F16=1]="F16",e[e.Q4_0=2]="Q4_0",e[e.Q4_1=3]="Q4_1",e[e.Q5_0=6]="Q5_0",e[e.Q5_1=7]="Q5_1",e[e.Q8_0=8]="Q8_0",e[e.Q8_1=9]="Q8_1",e[e.Q2_K=10]="Q2_K",e[e.Q3_K=11]="Q3_K",e[e.Q4_K=12]="Q4_K",e[e.Q5_K=13]="Q5_K",e[e.Q6_K=14]="Q6_K",e[e.Q8_K=15]="Q8_K",e[e.IQ2_XXS=16]="IQ2_XXS",e[e.IQ2_XS=17]="IQ2_XS",e[e.IQ3_XXS=18]="IQ3_XXS",e[e.IQ1_S=19]="IQ1_S",e[e.IQ4_NL=20]="IQ4_NL",e[e.IQ3_S=21]="IQ3_S",e[e.IQ2_S=22]="IQ2_S",e[e.IQ4_XS=23]="IQ4_XS",e[e.I8=24]="I8",e[e.I16=25]="I16",e[e.I32=26]="I32",e[e.I64=27]="I64",e[e.F64=28]="F64",e[e.IQ1_M=29]="IQ1_M",e[e.BF16=30]="BF16"})($e||($e={}));const go=Object.values($e).filter(e=>typeof e=="string");new RegExp(`(?<quant>${go.join("|")})(_(?<sizeVariation>[A-Z]+))?`);const bo=["python","js","sh"];var s=Object.freeze({Text:"Text",NumericLiteral:"NumericLiteral",BooleanLiteral:"BooleanLiteral",NullLiteral:"NullLiteral",StringLiteral:"StringLiteral",Identifier:"Identifier",Equals:"Equals",OpenParen:"OpenParen",CloseParen:"CloseParen",OpenStatement:"OpenStatement",CloseStatement:"CloseStatement",OpenExpression:"OpenExpression",CloseExpression:"CloseExpression",OpenSquareBracket:"OpenSquareBracket",CloseSquareBracket:"CloseSquareBracket",OpenCurlyBracket:"OpenCurlyBracket",CloseCurlyBracket:"CloseCurlyBracket",Comma:"Comma",Dot:"Dot",Colon:"Colon",Pipe:"Pipe",CallOperator:"CallOperator",AdditiveBinaryOperator:"AdditiveBinaryOperator",MultiplicativeBinaryOperator:"MultiplicativeBinaryOperator",ComparisonBinaryOperator:"ComparisonBinaryOperator",UnaryOperator:"UnaryOperator",Set:"Set",If:"If",For:"For",In:"In",Is:"Is",NotIn:"NotIn",Else:"Else",EndIf:"EndIf",ElseIf:"ElseIf",EndFor:"EndFor",And:"And",Or:"Or",Not:"UnaryOperator",Macro:"Macro",EndMacro:"EndMacro"}),st=Object.freeze({set:s.Set,for:s.For,in:s.In,is:s.Is,if:s.If,else:s.Else,endif:s.EndIf,elif:s.ElseIf,endfor:s.EndFor,and:s.And,or:s.Or,not:s.Not,"not in":s.NotIn,macro:s.Macro,endmacro:s.EndMacro,true:s.BooleanLiteral,false:s.BooleanLiteral,none:s.NullLiteral,True:s.BooleanLiteral,False:s.BooleanLiteral,None:s.NullLiteral}),G=class{constructor(e,a){this.value=e,this.type=a}};function lt(e){return/\w/.test(e)}function Oe(e){return/[0-9]/.test(e)}var yo=[["{%",s.OpenStatement],["%}",s.CloseStatement],["{{",s.OpenExpression],["}}",s.CloseExpression],["(",s.OpenParen],[")",s.CloseParen],["{",s.OpenCurlyBracket],["}",s.CloseCurlyBracket],["[",s.OpenSquareBracket],["]",s.CloseSquareBracket],[",",s.Comma],[".",s.Dot],[":",s.Colon],["|",s.Pipe],["<=",s.ComparisonBinaryOperator],[">=",s.ComparisonBinaryOperator],["==",s.ComparisonBinaryOperator],["!=",s.ComparisonBinaryOperator],["<",s.ComparisonBinaryOperator],[">",s.ComparisonBinaryOperator],["+",s.AdditiveBinaryOperator],["-",s.AdditiveBinaryOperator],["*",s.MultiplicativeBinaryOperator],["/",s.MultiplicativeBinaryOperator],["%",s.MultiplicativeBinaryOperator],["=",s.Equals]],wo=new Map([["n",`
`],["t","	"],["r","\r"],["b","\b"],["f","\f"],["v","\v"],["'","'"],['"','"'],["\\","\\"]]);function vo(e,a={}){return e.endsWith(`
`)&&(e=e.slice(0,-1)),e=e.replace(/{#.*?#}/gs,"{##}"),a.lstrip_blocks&&(e=e.replace(/^[ \t]*({[#%])/gm,"$1")),a.trim_blocks&&(e=e.replace(/([#%]})\n/g,"$1")),e.replace(/{##}/g,"").replace(/-%}\s*/g,"%}").replace(/\s*{%-/g,"{%").replace(/-}}\s*/g,"}}").replace(/\s*{{-/g,"{{")}function _o(e,a={}){var r,u,d;const t=[],i=vo(e,a);let n=0;const o=p=>{let c="";for(;p(i[n]);){if(i[n]==="\\"){if(++n,n>=i.length)throw new SyntaxError("Unexpected end of input");const l=i[n++],h=wo.get(l);if(h===void 0)throw new SyntaxError(`Unexpected escaped character: ${l}`);c+=h;continue}if(c+=i[n++],n>=i.length)throw new SyntaxError("Unexpected end of input")}return c};e:for(;n<i.length;){const p=(r=t.at(-1))==null?void 0:r.type;if(p===void 0||p===s.CloseStatement||p===s.CloseExpression){let l="";for(;n<i.length&&!(i[n]==="{"&&(i[n+1]==="%"||i[n+1]==="{"));)l+=i[n++];if(l.length>0){t.push(new G(l,s.Text));continue}}o(l=>/\s/.test(l));const c=i[n];if(c==="-"||c==="+"){const l=(u=t.at(-1))==null?void 0:u.type;if(l===s.Text||l===void 0)throw new SyntaxError(`Unexpected character: ${c}`);switch(l){case s.Identifier:case s.NumericLiteral:case s.BooleanLiteral:case s.NullLiteral:case s.StringLiteral:case s.CloseParen:case s.CloseSquareBracket:break;default:{++n;const h=o(Oe);t.push(new G(`${c}${h}`,h.length>0?s.NumericLiteral:s.UnaryOperator));continue}}}for(const[l,h]of yo)if(i.slice(n,n+l.length)===l){t.push(new G(l,h)),n+=l.length;continue e}if(c==="'"||c==='"'){++n;const l=o(h=>h!==c);t.push(new G(l,s.StringLiteral)),++n;continue}if(Oe(c)){const l=o(Oe);t.push(new G(l,s.NumericLiteral));continue}if(lt(c)){const l=o(lt),h=Object.hasOwn(st,l)?st[l]:s.Identifier;h===s.In&&((d=t.at(-1))==null?void 0:d.type)===s.Not?(t.pop(),t.push(new G("not in",s.NotIn))):t.push(new G(l,h));continue}throw new SyntaxError(`Unexpected character: ${c}`)}return t}var ue=class{constructor(){_(this,"type","Statement")}},ko=class extends ue{constructor(a){super();_(this,"type","Program");this.body=a}},ct=class extends ue{constructor(a,t,i){super();_(this,"type","If");this.test=a,this.body=t,this.alternate=i}},xo=class extends ue{constructor(a,t,i,n){super();_(this,"type","For");this.loopvar=a,this.iterable=t,this.body=i,this.defaultBlock=n}},Ao=class extends ue{constructor(a,t){super();_(this,"type","Set");this.assignee=a,this.value=t}},So=class extends ue{constructor(a,t,i){super();_(this,"type","Macro");this.name=a,this.args=t,this.body=i}},V=class extends ue{constructor(){super(...arguments);_(this,"type","Expression")}},Io=class extends V{constructor(a,t,i){super();_(this,"type","MemberExpression");this.object=a,this.property=t,this.computed=i}},Eo=class extends V{constructor(a,t){super();_(this,"type","CallExpression");this.callee=a,this.args=t}},ee=class extends V{constructor(a){super();_(this,"type","Identifier");this.value=a}},te=class extends V{constructor(a){super();_(this,"type","Literal");this.value=a}},To=class extends te{constructor(){super(...arguments);_(this,"type","NumericLiteral")}},pt=class extends te{constructor(){super(...arguments);_(this,"type","StringLiteral")}},dt=class extends te{constructor(){super(...arguments);_(this,"type","BooleanLiteral")}},ut=class extends te{constructor(){super(...arguments);_(this,"type","NullLiteral")}},Co=class extends te{constructor(){super(...arguments);_(this,"type","ArrayLiteral")}},mt=class extends te{constructor(){super(...arguments);_(this,"type","TupleLiteral")}},Uo=class extends te{constructor(){super(...arguments);_(this,"type","ObjectLiteral")}},he=class extends V{constructor(a,t,i){super();_(this,"type","BinaryExpression");this.operator=a,this.left=t,this.right=i}},Oo=class extends V{constructor(a,t){super();_(this,"type","FilterExpression");this.operand=a,this.filter=t}},Mo=class extends V{constructor(a,t){super();_(this,"type","SelectExpression");this.iterable=a,this.test=t}},$o=class extends V{constructor(a,t,i){super();_(this,"type","TestExpression");this.operand=a,this.negate=t,this.test=i}},Lo=class extends V{constructor(a,t){super();_(this,"type","UnaryExpression");this.operator=a,this.argument=t}},No=class extends V{constructor(a=void 0,t=void 0,i=void 0){super();_(this,"type","SliceExpression");this.start=a,this.stop=t,this.step=i}},Do=class extends V{constructor(a,t){super();_(this,"type","KeywordArgumentExpression");this.key=a,this.value=t}};function Po(e){const a=new ko([]);let t=0;function i(m,f){const y=e[t++];if(!y||y.type!==m)throw new Error(`Parser Error: ${f}. ${y.type} !== ${m}.`);return y}function n(){switch(e[t].type){case s.Text:return u();case s.OpenStatement:return d();case s.OpenExpression:return p();default:throw new SyntaxError(`Unexpected token type: ${e[t].type}`)}}function o(...m){return t+m.length<=e.length&&m.some((f,y)=>f!==e[t+y].type)}function r(...m){return t+m.length<=e.length&&m.every((f,y)=>f===e[t+y].type)}function u(){return new pt(i(s.Text,"Expected text token").value)}function d(){i(s.OpenStatement,"Expected opening statement token");let m;switch(e[t].type){case s.Set:++t,m=c(),i(s.CloseStatement,"Expected closing statement token");break;case s.If:++t,m=l(),i(s.OpenStatement,"Expected {% token"),i(s.EndIf,"Expected endif token"),i(s.CloseStatement,"Expected %} token");break;case s.Macro:++t,m=h(),i(s.OpenStatement,"Expected {% token"),i(s.EndMacro,"Expected endmacro token"),i(s.CloseStatement,"Expected %} token");break;case s.For:++t,m=b(),i(s.OpenStatement,"Expected {% token"),i(s.EndFor,"Expected endfor token"),i(s.CloseStatement,"Expected %} token");break;default:throw new SyntaxError(`Unknown statement type: ${e[t].type}`)}return m}function p(){i(s.OpenExpression,"Expected opening expression token");const m=N();return i(s.CloseExpression,"Expected closing expression token"),m}function c(){const m=N();if(r(s.Equals)){++t;const f=c();return new Ao(m,f)}return m}function l(){var D,Ke,Qe,Je,Xe,Ye,Ze,Ge;const m=N();i(s.CloseStatement,"Expected closing statement token");const f=[],y=[];for(;!(((D=e[t])==null?void 0:D.type)===s.OpenStatement&&(((Ke=e[t+1])==null?void 0:Ke.type)===s.ElseIf||((Qe=e[t+1])==null?void 0:Qe.type)===s.Else||((Je=e[t+1])==null?void 0:Je.type)===s.EndIf));)f.push(n());if(((Xe=e[t])==null?void 0:Xe.type)===s.OpenStatement&&((Ye=e[t+1])==null?void 0:Ye.type)!==s.EndIf)if(++t,r(s.ElseIf))i(s.ElseIf,"Expected elseif token"),y.push(l());else for(i(s.Else,"Expected else token"),i(s.CloseStatement,"Expected closing statement token");!(((Ze=e[t])==null?void 0:Ze.type)===s.OpenStatement&&((Ge=e[t+1])==null?void 0:Ge.type)===s.EndIf);)y.push(n());return new ct(m,f,y)}function h(){const m=ae();if(m.type!=="Identifier")throw new SyntaxError("Expected identifier following macro statement");const f=Fe();i(s.CloseStatement,"Expected closing statement token");const y=[];for(;o(s.OpenStatement,s.EndMacro);)y.push(n());return new So(m,f,y)}function g(m=!1){const f=m?ae:N,y=[f()],D=r(s.Comma);for(;D&&(++t,y.push(f()),!!r(s.Comma)););return D?new mt(y):y[0]}function b(){const m=g(!0);if(!(m instanceof ee||m instanceof mt))throw new SyntaxError(`Expected identifier/tuple for the loop variable, got ${m.type} instead`);i(s.In,"Expected `in` keyword following loop variable");const f=N();i(s.CloseStatement,"Expected closing statement token");const y=[];for(;o(s.OpenStatement,s.EndFor)&&o(s.OpenStatement,s.Else);)y.push(n());const D=[];if(r(s.OpenStatement,s.Else))for(++t,++t,i(s.CloseStatement,"Expected closing statement token");o(s.OpenStatement,s.EndFor);)D.push(n());return new xo(m,f,y,D)}function N(){return L()}function L(){const m=F();if(r(s.If)){++t;const f=F();if(r(s.Else)){++t;const y=F();return new ct(f,[m],[y])}else return new Mo(m,f)}return m}function F(){let m=Ee();for(;r(s.Or);){const f=e[t];++t;const y=Ee();m=new he(f,m,y)}return m}function Ee(){let m=me();for(;r(s.And);){const f=e[t];++t;const y=me();m=new he(f,m,y)}return m}function me(){let m;for(;r(s.Not);){const f=e[t];++t;const y=me();m=new Lo(f,y)}return m??Te()}function Te(){let m=Z();for(;r(s.ComparisonBinaryOperator)||r(s.In)||r(s.NotIn);){const f=e[t];++t;const y=Z();m=new he(f,m,y)}return m}function Z(){let m=He();for(;r(s.AdditiveBinaryOperator);){const f=e[t];++t;const y=He();m=new he(f,m,y)}return m}function Ce(){const m=ze(ae());return r(s.OpenParen)?fe(m):m}function fe(m){let f=new Eo(m,Fe());return f=ze(f),r(s.OpenParen)&&(f=fe(f)),f}function Fe(){i(s.OpenParen,"Expected opening parenthesis for arguments list");const m=Dt();return i(s.CloseParen,"Expected closing parenthesis for arguments list"),m}function Dt(){const m=[];for(;!r(s.CloseParen);){let f=N();if(r(s.Equals)){if(++t,!(f instanceof ee))throw new SyntaxError("Expected identifier for keyword argument");const y=N();f=new Do(f,y)}m.push(f),r(s.Comma)&&++t}return m}function Pt(){const m=[];let f=!1;for(;!r(s.CloseSquareBracket);)r(s.Colon)?(m.push(void 0),++t,f=!0):(m.push(N()),r(s.Colon)&&(++t,f=!0));if(m.length===0)throw new SyntaxError("Expected at least one argument for member/slice expression");if(f){if(m.length>3)throw new SyntaxError("Expected 0-3 arguments for slice expression");return new No(...m)}return m[0]}function ze(m){for(;r(s.Dot)||r(s.OpenSquareBracket);){const f=e[t];++t;let y;const D=f.type!==s.Dot;if(D)y=Pt(),i(s.CloseSquareBracket,"Expected closing square bracket");else if(y=ae(),y.type!=="Identifier")throw new SyntaxError("Expected identifier following dot operator");m=new Io(m,y,D)}return m}function He(){let m=We();for(;r(s.MultiplicativeBinaryOperator);){const f=e[t];++t;const y=We();m=new he(f,m,y)}return m}function We(){let m=jt();for(;r(s.Is);){++t;const f=r(s.Not);f&&++t;let y=ae();if(y instanceof dt?y=new ee(y.value.toString()):y instanceof ut&&(y=new ee("none")),!(y instanceof ee))throw new SyntaxError("Expected identifier for the test");m=new $o(m,f,y)}return m}function jt(){let m=Ce();for(;r(s.Pipe);){++t;let f=ae();if(!(f instanceof ee))throw new SyntaxError("Expected identifier for the filter");r(s.OpenParen)&&(f=fe(f)),m=new Oo(m,f)}return m}function ae(){const m=e[t];switch(m.type){case s.NumericLiteral:return++t,new To(Number(m.value));case s.StringLiteral:return++t,new pt(m.value);case s.BooleanLiteral:return++t,new dt(m.value.toLowerCase()==="true");case s.NullLiteral:return++t,new ut(null);case s.Identifier:return++t,new ee(m.value);case s.OpenParen:{++t;const f=g();if(e[t].type!==s.CloseParen)throw new SyntaxError(`Expected closing parenthesis, got ${e[t].type} instead`);return++t,f}case s.OpenSquareBracket:{++t;const f=[];for(;!r(s.CloseSquareBracket);)f.push(N()),r(s.Comma)&&++t;return++t,new Co(f)}case s.OpenCurlyBracket:{++t;const f=new Map;for(;!r(s.CloseCurlyBracket);){const y=N();i(s.Colon,"Expected colon between key and value in object literal");const D=N();f.set(y,D),r(s.Comma)&&++t}return++t,new Uo(f)}default:throw new SyntaxError(`Unexpected token: ${m.type}`)}}for(;t<e.length;)a.body.push(n());return a}function jo(e,a,t=1){a===void 0&&(a=e,e=0);const i=[];for(let n=e;n<a;n+=t)i.push(n);return i}function ft(e,a,t,i=1){const n=Math.sign(i);n>=0?(a=(a??(a=0))<0?Math.max(e.length+a,0):Math.min(a,e.length),t=(t??(t=e.length))<0?Math.max(e.length+t,0):Math.min(t,e.length)):(a=(a??(a=e.length-1))<0?Math.max(e.length+a,-1):Math.min(a,e.length-1),t=(t??(t=-1))<-1?Math.max(e.length+t,-1):Math.min(t,e.length-1));const o=[];for(let r=a;n*r<n*t;r+=i)o.push(e[r]);return o}function Et(e){return e.replace(/\b\w/g,a=>a.toUpperCase())}var W=class{constructor(e=void 0){_(this,"type","RuntimeValue");_(this,"value");_(this,"builtins",new Map);this.value=e}__bool__(){return new $(!!this.value)}},E=class extends W{constructor(){super(...arguments);_(this,"type","NumericValue")}},v=class extends W{constructor(){super(...arguments);_(this,"type","StringValue");_(this,"builtins",new Map([["upper",new j(()=>new v(this.value.toUpperCase()))],["lower",new j(()=>new v(this.value.toLowerCase()))],["strip",new j(()=>new v(this.value.trim()))],["title",new j(()=>new v(Et(this.value)))],["length",new E(this.value.length)],["rstrip",new j(()=>new v(this.value.trimEnd()))],["lstrip",new j(()=>new v(this.value.trimStart()))],["split",new j(a=>{const t=a[0]??new B;if(!(t instanceof v||t instanceof B))throw new Error("sep argument must be a string or null");const i=a[1]??new E(-1);if(!(i instanceof E))throw new Error("maxsplit argument must be a number");let n=[];if(t instanceof B){const o=this.value.trimStart();for(const{0:r,index:u}of o.matchAll(/\S+/g)){if(i.value!==-1&&n.length>=i.value&&u!==void 0){n.push(r+o.slice(u+r.length));break}n.push(r)}}else{if(t.value==="")throw new Error("empty separator");n=this.value.split(t.value),i.value!==-1&&n.length>i.value&&n.push(n.splice(i.value).join(t.value))}return new M(n.map(o=>new v(o)))})]]))}},$=class extends W{constructor(){super(...arguments);_(this,"type","BooleanValue")}},R=class extends W{constructor(){super(...arguments);_(this,"type","ObjectValue");_(this,"builtins",new Map([["get",new j(([a,t])=>{if(!(a instanceof v))throw new Error(`Object key must be a string: got ${a.type}`);return this.value.get(a.value)??t??new B})],["items",new j(()=>new M(Array.from(this.value.entries()).map(([a,t])=>new M([new v(a),t]))))]]))}__bool__(){return new $(this.value.size>0)}},Ro=class extends R{constructor(){super(...arguments);_(this,"type","KeywordArgumentsValue")}},M=class extends W{constructor(){super(...arguments);_(this,"type","ArrayValue");_(this,"builtins",new Map([["length",new E(this.value.length)]]))}__bool__(){return new $(this.value.length>0)}},Bo=class extends M{constructor(){super(...arguments);_(this,"type","TupleValue")}},j=class extends W{constructor(){super(...arguments);_(this,"type","FunctionValue")}},B=class extends W{constructor(){super(...arguments);_(this,"type","NullValue")}},P=class extends W{constructor(){super(...arguments);_(this,"type","UndefinedValue")}},ge=class{constructor(e){_(this,"variables",new Map([["namespace",new j(e=>{if(e.length===0)return new R(new Map);if(e.length!==1||!(e[0]instanceof R))throw new Error("`namespace` expects either zero arguments or a single object argument");return e[0]})]]));_(this,"tests",new Map([["boolean",e=>e.type==="BooleanValue"],["callable",e=>e instanceof j],["odd",e=>{if(e.type!=="NumericValue")throw new Error(`Cannot apply test "odd" to type: ${e.type}`);return e.value%2!==0}],["even",e=>{if(e.type!=="NumericValue")throw new Error(`Cannot apply test "even" to type: ${e.type}`);return e.value%2===0}],["false",e=>e.type==="BooleanValue"&&!e.value],["true",e=>e.type==="BooleanValue"&&e.value],["none",e=>e.type==="NullValue"],["string",e=>e.type==="StringValue"],["number",e=>e.type==="NumericValue"],["integer",e=>e.type==="NumericValue"&&Number.isInteger(e.value)],["iterable",e=>e.type==="ArrayValue"||e.type==="StringValue"],["mapping",e=>e.type==="ObjectValue"],["lower",e=>{const a=e.value;return e.type==="StringValue"&&a===a.toLowerCase()}],["upper",e=>{const a=e.value;return e.type==="StringValue"&&a===a.toUpperCase()}],["none",e=>e.type==="NullValue"],["defined",e=>e.type!=="UndefinedValue"],["undefined",e=>e.type==="UndefinedValue"],["equalto",(e,a)=>e.value===a.value],["eq",(e,a)=>e.value===a.value]]));this.parent=e}set(e,a){return this.declareVariable(e,ve(a))}declareVariable(e,a){if(this.variables.has(e))throw new SyntaxError(`Variable already declared: ${e}`);return this.variables.set(e,a),a}setVariable(e,a){return this.variables.set(e,a),a}resolve(e){if(this.variables.has(e))return this;if(this.parent)return this.parent.resolve(e);throw new Error(`Unknown variable: ${e}`)}lookupVariable(e){try{return this.resolve(e).variables.get(e)??new P}catch{return new P}}},qo=class{constructor(e){_(this,"global");this.global=e??new ge}run(e){return this.evaluate(e,this.global)}evaluateBinaryExpression(e,a){const t=this.evaluate(e.left,a);switch(e.operator.value){case"and":return t.__bool__().value?this.evaluate(e.right,a):t;case"or":return t.__bool__().value?t:this.evaluate(e.right,a)}const i=this.evaluate(e.right,a);switch(e.operator.value){case"==":return new $(t.value==i.value);case"!=":return new $(t.value!=i.value)}if(t instanceof P||i instanceof P)throw new Error("Cannot perform operation on undefined values");if(t instanceof B||i instanceof B)throw new Error("Cannot perform operation on null values");if(t instanceof E&&i instanceof E)switch(e.operator.value){case"+":return new E(t.value+i.value);case"-":return new E(t.value-i.value);case"*":return new E(t.value*i.value);case"/":return new E(t.value/i.value);case"%":return new E(t.value%i.value);case"<":return new $(t.value<i.value);case">":return new $(t.value>i.value);case">=":return new $(t.value>=i.value);case"<=":return new $(t.value<=i.value)}else if(t instanceof M&&i instanceof M)switch(e.operator.value){case"+":return new M(t.value.concat(i.value))}else if(i instanceof M){const n=i.value.find(o=>o.value===t.value)!==void 0;switch(e.operator.value){case"in":return new $(n);case"not in":return new $(!n)}}if(t instanceof v||i instanceof v)switch(e.operator.value){case"+":return new v(t.value.toString()+i.value.toString())}if(t instanceof v&&i instanceof v)switch(e.operator.value){case"in":return new $(i.value.includes(t.value));case"not in":return new $(!i.value.includes(t.value))}if(t instanceof v&&i instanceof R)switch(e.operator.value){case"in":return new $(i.value.has(t.value));case"not in":return new $(!i.value.has(t.value))}throw new SyntaxError(`Unknown operator "${e.operator.value}" between ${t.type} and ${i.type}`)}evaluateArguments(e,a){const t=[],i=new Map;for(const n of e)if(n.type==="KeywordArgumentExpression"){const o=n;i.set(o.key.value,this.evaluate(o.value,a))}else{if(i.size>0)throw new Error("Positional arguments must come before keyword arguments");t.push(this.evaluate(n,a))}return[t,i]}evaluateFilterExpression(e,a){const t=this.evaluate(e.operand,a);if(e.filter.type==="Identifier"){const i=e.filter;if(i.value==="tojson")return new v(ke(t));if(t instanceof M)switch(i.value){case"list":return t;case"first":return t.value[0];case"last":return t.value[t.value.length-1];case"length":return new E(t.value.length);case"reverse":return new M(t.value.reverse());case"sort":return new M(t.value.sort((n,o)=>{if(n.type!==o.type)throw new Error(`Cannot compare different types: ${n.type} and ${o.type}`);switch(n.type){case"NumericValue":return n.value-o.value;case"StringValue":return n.value.localeCompare(o.value);default:throw new Error(`Cannot compare type: ${n.type}`)}}));case"join":return new v(t.value.map(n=>n.value).join(""));default:throw new Error(`Unknown ArrayValue filter: ${i.value}`)}else if(t instanceof v)switch(i.value){case"length":return new E(t.value.length);case"upper":return new v(t.value.toUpperCase());case"lower":return new v(t.value.toLowerCase());case"title":return new v(Et(t.value));case"capitalize":return new v(t.value.charAt(0).toUpperCase()+t.value.slice(1));case"trim":return new v(t.value.trim());case"indent":return new v(t.value.split(`
`).map((n,o)=>o===0||n.length===0?n:"    "+n).join(`
`));case"join":case"string":return t;default:throw new Error(`Unknown StringValue filter: ${i.value}`)}else if(t instanceof E)switch(i.value){case"abs":return new E(Math.abs(t.value));default:throw new Error(`Unknown NumericValue filter: ${i.value}`)}else if(t instanceof R)switch(i.value){case"items":return new M(Array.from(t.value.entries()).map(([n,o])=>new M([new v(n),o])));case"length":return new E(t.value.size);default:throw new Error(`Unknown ObjectValue filter: ${i.value}`)}throw new Error(`Cannot apply filter "${i.value}" to type: ${t.type}`)}else if(e.filter.type==="CallExpression"){const i=e.filter;if(i.callee.type!=="Identifier")throw new Error(`Unknown filter: ${i.callee.type}`);const n=i.callee.value;if(n==="tojson"){const[,o]=this.evaluateArguments(i.args,a),r=o.get("indent")??new B;if(!(r instanceof E||r instanceof B))throw new Error("If set, indent must be a number");return new v(ke(t,r.value))}else if(n==="join"){let o;if(t instanceof v)o=Array.from(t.value);else if(t instanceof M)o=t.value.map(p=>p.value);else throw new Error(`Cannot apply filter "${n}" to type: ${t.type}`);const[r,u]=this.evaluateArguments(i.args,a),d=r.at(0)??u.get("separator")??new v("");if(!(d instanceof v))throw new Error("separator must be a string");return new v(o.join(d.value))}if(t instanceof M){switch(n){case"selectattr":case"rejectattr":{const o=n==="selectattr";if(t.value.some(l=>!(l instanceof R)))throw new Error(`\`${n}\` can only be applied to array of objects`);if(i.args.some(l=>l.type!=="StringLiteral"))throw new Error(`arguments of \`${n}\` must be strings`);const[r,u,d]=i.args.map(l=>this.evaluate(l,a));let p;if(u){const l=a.tests.get(u.value);if(!l)throw new Error(`Unknown test: ${u.value}`);p=l}else p=(...l)=>l[0].__bool__().value;const c=t.value.filter(l=>{const h=l.value.get(r.value),g=h?p(h,d):!1;return o?g:!g});return new M(c)}case"map":{const[,o]=this.evaluateArguments(i.args,a);if(o.has("attribute")){const r=o.get("attribute");if(!(r instanceof v))throw new Error("attribute must be a string");const u=o.get("default"),d=t.value.map(p=>{if(!(p instanceof R))throw new Error("items in map must be an object");return p.value.get(r.value)??u??new P});return new M(d)}else throw new Error("`map` expressions without `attribute` set are not currently supported.")}}throw new Error(`Unknown ArrayValue filter: ${n}`)}else if(t instanceof v){switch(n){case"indent":{const[o,r]=this.evaluateArguments(i.args,a),u=o.at(0)??r.get("width")??new E(4);if(!(u instanceof E))throw new Error("width must be a number");const d=o.at(1)??r.get("first")??new $(!1),p=o.at(2)??r.get("blank")??new $(!1),c=t.value.split(`
`),l=" ".repeat(u.value),h=c.map((g,b)=>!d.value&&b===0||!p.value&&g.length===0?g:l+g);return new v(h.join(`
`))}}throw new Error(`Unknown StringValue filter: ${n}`)}else throw new Error(`Cannot apply filter "${n}" to type: ${t.type}`)}throw new Error(`Unknown filter: ${e.filter.type}`)}evaluateTestExpression(e,a){const t=this.evaluate(e.operand,a),i=a.tests.get(e.test.value);if(!i)throw new Error(`Unknown test: ${e.test.value}`);const n=i(t);return new $(e.negate?!n:n)}evaluateUnaryExpression(e,a){const t=this.evaluate(e.argument,a);switch(e.operator.value){case"not":return new $(!t.value);default:throw new SyntaxError(`Unknown operator: ${e.operator.value}`)}}evalProgram(e,a){return this.evaluateBlock(e.body,a)}evaluateBlock(e,a){let t="";for(const i of e){const n=this.evaluate(i,a);n.type!=="NullValue"&&n.type!=="UndefinedValue"&&(t+=n.value)}return new v(t)}evaluateIdentifier(e,a){return a.lookupVariable(e.value)}evaluateCallExpression(e,a){const[t,i]=this.evaluateArguments(e.args,a);i.size>0&&t.push(new Ro(i));const n=this.evaluate(e.callee,a);if(n.type!=="FunctionValue")throw new Error(`Cannot call something that is not a function: got ${n.type}`);return n.value(t,a)}evaluateSliceExpression(e,a,t){if(!(e instanceof M||e instanceof v))throw new Error("Slice object must be an array or string");const i=this.evaluate(a.start,t),n=this.evaluate(a.stop,t),o=this.evaluate(a.step,t);if(!(i instanceof E||i instanceof P))throw new Error("Slice start must be numeric or undefined");if(!(n instanceof E||n instanceof P))throw new Error("Slice stop must be numeric or undefined");if(!(o instanceof E||o instanceof P))throw new Error("Slice step must be numeric or undefined");return e instanceof M?new M(ft(e.value,i.value,n.value,o.value)):new v(ft(Array.from(e.value),i.value,n.value,o.value).join(""))}evaluateMemberExpression(e,a){const t=this.evaluate(e.object,a);let i;if(e.computed){if(e.property.type==="SliceExpression")return this.evaluateSliceExpression(t,e.property,a);i=this.evaluate(e.property,a)}else i=new v(e.property.value);let n;if(t instanceof R){if(!(i instanceof v))throw new Error(`Cannot access property with non-string: got ${i.type}`);n=t.value.get(i.value)??t.builtins.get(i.value)}else if(t instanceof M||t instanceof v)if(i instanceof E)n=t.value.at(i.value),t instanceof v&&(n=new v(t.value.at(i.value)));else if(i instanceof v)n=t.builtins.get(i.value);else throw new Error(`Cannot access property with non-string/non-number: got ${i.type}`);else{if(!(i instanceof v))throw new Error(`Cannot access property with non-string: got ${i.type}`);n=t.builtins.get(i.value)}return n instanceof W?n:new P}evaluateSet(e,a){const t=this.evaluate(e.value,a);if(e.assignee.type==="Identifier"){const i=e.assignee.value;a.setVariable(i,t)}else if(e.assignee.type==="MemberExpression"){const i=e.assignee,n=this.evaluate(i.object,a);if(!(n instanceof R))throw new Error("Cannot assign to member of non-object");if(i.property.type!=="Identifier")throw new Error("Cannot assign to member with non-identifier property");n.value.set(i.property.value,t)}else throw new Error(`Invalid LHS inside assignment expression: ${JSON.stringify(e.assignee)}`);return new B}evaluateIf(e,a){const t=this.evaluate(e.test,a);return this.evaluateBlock(t.__bool__().value?e.body:e.alternate,a)}evaluateFor(e,a){const t=new ge(a);let i,n;if(e.iterable.type==="SelectExpression"){const p=e.iterable;n=this.evaluate(p.iterable,t),i=p.test}else n=this.evaluate(e.iterable,t);if(!(n instanceof M))throw new Error(`Expected iterable type in for loop: got ${n.type}`);const o=[],r=[];for(let p=0;p<n.value.length;++p){const c=new ge(t),l=n.value[p];let h;if(e.loopvar.type==="Identifier")h=g=>g.setVariable(e.loopvar.value,l);else if(e.loopvar.type==="TupleLiteral"){const g=e.loopvar;if(l.type!=="ArrayValue")throw new Error(`Cannot unpack non-iterable type: ${l.type}`);const b=l;if(g.value.length!==b.value.length)throw new Error(`Too ${g.value.length>b.value.length?"few":"many"} items to unpack`);h=N=>{for(let L=0;L<g.value.length;++L){if(g.value[L].type!=="Identifier")throw new Error(`Cannot unpack non-identifier type: ${g.value[L].type}`);N.setVariable(g.value[L].value,b.value[L])}}}else throw new Error(`Invalid loop variable(s): ${e.loopvar.type}`);i&&(h(c),!this.evaluate(i,c).__bool__().value)||(o.push(l),r.push(h))}let u="",d=!0;for(let p=0;p<o.length;++p){const c=new Map([["index",new E(p+1)],["index0",new E(p)],["revindex",new E(o.length-p)],["revindex0",new E(o.length-p-1)],["first",new $(p===0)],["last",new $(p===o.length-1)],["length",new E(o.length)],["previtem",p>0?o[p-1]:new P],["nextitem",p<o.length-1?o[p+1]:new P]]);t.setVariable("loop",new R(c)),r[p](t);const l=this.evaluateBlock(e.body,t);u+=l.value,d=!1}if(d){const p=this.evaluateBlock(e.defaultBlock,t);u+=p.value}return new v(u)}evaluateMacro(e,a){return a.setVariable(e.name.value,new j((t,i)=>{var r;const n=new ge(i);t=t.slice();let o;((r=t.at(-1))==null?void 0:r.type)==="KeywordArgumentsValue"&&(o=t.pop());for(let u=0;u<e.args.length;++u){const d=e.args[u],p=t[u];if(d.type==="Identifier"){const c=d;if(!p)throw new Error(`Missing positional argument: ${c.value}`);n.setVariable(c.value,p)}else if(d.type==="KeywordArgumentExpression"){const c=d,l=p??(o==null?void 0:o.value.get(c.key.value))??this.evaluate(c.value,n);n.setVariable(c.key.value,l)}else throw new Error(`Unknown argument type: ${d.type}`)}return this.evaluateBlock(e.body,n)})),new B}evaluate(e,a){if(e===void 0)return new P;switch(e.type){case"Program":return this.evalProgram(e,a);case"Set":return this.evaluateSet(e,a);case"If":return this.evaluateIf(e,a);case"For":return this.evaluateFor(e,a);case"Macro":return this.evaluateMacro(e,a);case"NumericLiteral":return new E(Number(e.value));case"StringLiteral":return new v(e.value);case"BooleanLiteral":return new $(e.value);case"NullLiteral":return new B(e.value);case"ArrayLiteral":return new M(e.value.map(t=>this.evaluate(t,a)));case"TupleLiteral":return new Bo(e.value.map(t=>this.evaluate(t,a)));case"ObjectLiteral":{const t=new Map;for(const[i,n]of e.value){const o=this.evaluate(i,a);if(!(o instanceof v))throw new Error(`Object keys must be strings: got ${o.type}`);t.set(o.value,this.evaluate(n,a))}return new R(t)}case"Identifier":return this.evaluateIdentifier(e,a);case"CallExpression":return this.evaluateCallExpression(e,a);case"MemberExpression":return this.evaluateMemberExpression(e,a);case"UnaryExpression":return this.evaluateUnaryExpression(e,a);case"BinaryExpression":return this.evaluateBinaryExpression(e,a);case"FilterExpression":return this.evaluateFilterExpression(e,a);case"TestExpression":return this.evaluateTestExpression(e,a);default:throw new SyntaxError(`Unknown node type: ${e.type}`)}}};function ve(e){switch(typeof e){case"number":return new E(e);case"string":return new v(e);case"boolean":return new $(e);case"undefined":return new P;case"object":return e===null?new B:Array.isArray(e)?new M(e.map(ve)):new R(new Map(Object.entries(e).map(([a,t])=>[a,ve(t)])));case"function":return new j((a,t)=>{const i=e(...a.map(n=>n.value))??null;return ve(i)});default:throw new Error(`Cannot convert to runtime value: ${e}`)}}function ke(e,a,t){const i=t??0;switch(e.type){case"NullValue":case"UndefinedValue":return"null";case"NumericValue":case"StringValue":case"BooleanValue":return JSON.stringify(e.value);case"ArrayValue":case"ObjectValue":{const n=a?" ".repeat(a):"",o=`
`+n.repeat(i),r=o+n;if(e.type==="ArrayValue"){const u=e.value.map(d=>ke(d,a,i+1));return a?`[${r}${u.join(`,${r}`)}${o}]`:`[${u.join(", ")}]`}else{const u=Array.from(e.value.entries()).map(([d,p])=>{const c=`"${d}": ${ke(p,a,i+1)}`;return a?`${r}${c}`:c});return a?`{${u.join(",")}${o}}`:`{${u.join(", ")}}`}}default:throw new Error(`Cannot convert to JSON: ${e.type}`)}}var Vo=class{constructor(e){_(this,"parsed");const a=_o(e,{lstrip_blocks:!0,trim_blocks:!0});this.parsed=Po(a)}render(e){const a=new ge;if(a.set("false",!1),a.set("true",!0),a.set("raise_exception",n=>{throw new Error(n)}),a.set("range",jo),e)for(const[n,o]of Object.entries(e))a.set(n,o);return new qo(a).run(this.parsed).value}},Fo=Object.defineProperty,Tt=(e,a)=>{for(var t in a)Fo(e,t,{get:a[t],enumerable:!0})},zo={};Tt(zo,{audioClassification:()=>Es,audioToAudio:()=>Os,automaticSpeechRecognition:()=>Ts,chatCompletion:()=>il,chatCompletionStream:()=>nl,documentQuestionAnswering:()=>ol,featureExtraction:()=>zs,fillMask:()=>Hs,imageClassification:()=>$s,imageSegmentation:()=>Ls,imageToImage:()=>Bs,imageToText:()=>Ns,objectDetection:()=>Ds,questionAnswering:()=>Ws,request:()=>I,sentenceSimilarity:()=>Ks,streamingRequest:()=>Ae,summarization:()=>Js,tableQuestionAnswering:()=>Xs,tabularClassification:()=>ll,tabularRegression:()=>sl,textClassification:()=>Ys,textGeneration:()=>Zs,textGenerationStream:()=>Gs,textToImage:()=>js,textToSpeech:()=>Us,textToVideo:()=>Fs,tokenClassification:()=>el,translation:()=>tl,visualQuestionAnswering:()=>rl,zeroShotClassification:()=>al,zeroShotImageClassification:()=>Vs});var Ct="https://huggingface.co",Ut="https://router.huggingface.co",Ho="https://api.us1.bfl.ai",Wo=()=>Ho,Ko=e=>e.args,Qo=e=>e.authMethod==="provider-key"?{"X-Key":`${e.accessToken}`}:{Authorization:`Bearer ${e.accessToken}`},Jo=e=>`${e.baseUrl}/v1/${e.model}`,Xo={makeBaseUrl:Wo,makeBody:Ko,makeHeaders:Qo,makeUrl:Jo},Yo="https://api.cerebras.ai",Zo=()=>Yo,Go=e=>({...e.args,model:e.model}),er=e=>({Authorization:`Bearer ${e.accessToken}`}),tr=e=>`${e.baseUrl}/v1/chat/completions`,ar={makeBaseUrl:Zo,makeBody:Go,makeHeaders:er,makeUrl:tr},ir="https://api.cohere.com",nr=()=>ir,or=e=>({...e.args,model:e.model}),rr=e=>({Authorization:`Bearer ${e.accessToken}`}),sr=e=>`${e.baseUrl}/compatibility/v1/chat/completions`,lr={makeBaseUrl:nr,makeBody:or,makeHeaders:rr,makeUrl:sr},x=class extends TypeError{constructor(e){super(`Invalid inference output: ${e}. Use the 'request' method with the same parameters to do a custom call with no type checking.`),this.name="InferenceOutputError"}};function xe(e){return/^http(s?):/.test(e)||e.startsWith("/")}function Ot(e){return new Promise(a=>{setTimeout(()=>a(),e)})}var cr="https://fal.run",pr="https://queue.fal.run",dr=e=>e==="text-to-video"?pr:cr,ur=e=>e.args,mr=e=>({Authorization:e.authMethod==="provider-key"?`Key ${e.accessToken}`:`Bearer ${e.accessToken}`}),fr=e=>{const a=`${e.baseUrl}/${e.model}`;return e.authMethod!=="provider-key"&&e.task==="text-to-video"?`${a}?_subdomain=queue`:a},hr={makeBaseUrl:dr,makeBody:ur,makeHeaders:mr,makeUrl:fr};async function gr(e,a,t){if(!e.request_id)throw new x("No request ID found in the response");let n=e.status;const o=new URL(a),r=`${o.protocol}//${o.host}${o.host==="router.huggingface.co"?"/fal-ai":""}`,u=new URL(e.response_url).pathname,d=o.search,p=`${r}${u}/status${d}`,c=`${r}${u}${d}`;for(;n!=="COMPLETED";){await Ot(500);const g=await fetch(p,{headers:t});if(!g.ok)throw new x("Failed to fetch response status from fal-ai API");try{n=(await g.json()).status}catch{throw new x("Failed to parse status response from fal-ai API")}}const l=await fetch(c,{headers:t});let h;try{h=await l.json()}catch{throw new x("Failed to parse result response from fal-ai API")}if(typeof h=="object"&&h&&"video"in h&&typeof h.video=="object"&&h.video&&"url"in h.video&&typeof h.video.url=="string"&&xe(h.video.url))return await(await fetch(h.video.url)).blob();throw new x("Expected { video: { url: string } } result format, got instead: "+JSON.stringify(h))}var br="https://api.fireworks.ai",yr=()=>br,wr=e=>({...e.args,...e.chatCompletion?{model:e.model}:void 0}),vr=e=>({Authorization:`Bearer ${e.accessToken}`}),_r=e=>e.chatCompletion?`${e.baseUrl}/inference/v1/chat/completions`:`${e.baseUrl}/inference`,kr={makeBaseUrl:yr,makeBody:wr,makeHeaders:vr,makeUrl:_r},xr=()=>`${Ut}/hf-inference`,Ar=e=>({...e.args,...e.chatCompletion?{model:e.model}:void 0}),Sr=e=>({Authorization:`Bearer ${e.accessToken}`}),Ir=e=>e.task&&["feature-extraction","sentence-similarity"].includes(e.task)?`${e.baseUrl}/pipeline/${e.task}/${e.model}`:e.chatCompletion?`${e.baseUrl}/models/${e.model}/v1/chat/completions`:`${e.baseUrl}/models/${e.model}`,Er={makeBaseUrl:xr,makeBody:Ar,makeHeaders:Sr,makeUrl:Ir},Tr="https://api.hyperbolic.xyz",Cr=()=>Tr,Ur=e=>({...e.args,...e.task==="text-to-image"?{model_name:e.model}:{model:e.model}}),Or=e=>({Authorization:`Bearer ${e.accessToken}`}),Mr=e=>e.task==="text-to-image"?`${e.baseUrl}/v1/images/generations`:`${e.baseUrl}/v1/chat/completions`,$r={makeBaseUrl:Cr,makeBody:Ur,makeHeaders:Or,makeUrl:Mr},Lr="https://api.studio.nebius.ai",Nr=()=>Lr,Dr=e=>({...e.args,model:e.model}),Pr=e=>({Authorization:`Bearer ${e.accessToken}`}),jr=e=>e.task==="text-to-image"?`${e.baseUrl}/v1/images/generations`:e.chatCompletion?`${e.baseUrl}/v1/chat/completions`:e.task==="text-generation"?`${e.baseUrl}/v1/completions`:e.baseUrl,Rr={makeBaseUrl:Nr,makeBody:Dr,makeHeaders:Pr,makeUrl:jr},Br="https://api.novita.ai",qr=()=>Br,Vr=e=>({...e.args,...e.chatCompletion?{model:e.model}:void 0}),Fr=e=>({Authorization:`Bearer ${e.accessToken}`}),zr=e=>e.chatCompletion?`${e.baseUrl}/v3/openai/chat/completions`:e.task==="text-generation"?`${e.baseUrl}/v3/openai/completions`:e.task==="text-to-video"?`${e.baseUrl}/v3/hf/${e.model}`:e.baseUrl,Hr={makeBaseUrl:qr,makeBody:Vr,makeHeaders:Fr,makeUrl:zr},Wr="https://api.replicate.com",Kr=()=>Wr,Qr=e=>({input:e.args,version:e.model.includes(":")?e.model.split(":")[1]:void 0}),Jr=e=>({Authorization:`Bearer ${e.accessToken}`,Prefer:"wait"}),Xr=e=>e.model.includes(":")?`${e.baseUrl}/v1/predictions`:`${e.baseUrl}/v1/models/${e.model}/predictions`,Yr={makeBaseUrl:Kr,makeBody:Qr,makeHeaders:Jr,makeUrl:Xr},Zr="https://api.sambanova.ai",Gr=()=>Zr,es=e=>({...e.args,...e.chatCompletion?{model:e.model}:void 0}),ts=e=>({Authorization:`Bearer ${e.accessToken}`}),as=e=>e.chatCompletion?`${e.baseUrl}/v1/chat/completions`:e.baseUrl,is={makeBaseUrl:Gr,makeBody:es,makeHeaders:ts,makeUrl:as},ns="https://api.together.xyz",os=()=>ns,rs=e=>({...e.args,model:e.model}),ss=e=>({Authorization:`Bearer ${e.accessToken}`}),ls=e=>e.task==="text-to-image"?`${e.baseUrl}/v1/images/generations`:e.chatCompletion?`${e.baseUrl}/v1/chat/completions`:e.task==="text-generation"?`${e.baseUrl}/v1/completions`:e.baseUrl,cs={makeBaseUrl:os,makeBody:rs,makeHeaders:ss,makeUrl:ls},ps="https://api.openai.com",ds=()=>ps,us=e=>{if(!e.chatCompletion)throw new Error("OpenAI only supports chat completions.");return{...e.args,model:e.model}},ms=e=>({Authorization:`Bearer ${e.accessToken}`}),fs=e=>{if(!e.chatCompletion)throw new Error("OpenAI only supports chat completions.");return`${e.baseUrl}/v1/chat/completions`},hs={makeBaseUrl:ds,makeBody:us,makeHeaders:ms,makeUrl:fs,clientSideRoutingOnly:!0},gs="@huggingface/inference",bs="3.6.2",ht={"black-forest-labs":{},cerebras:{},cohere:{},"fal-ai":{},"fireworks-ai":{},"hf-inference":{},hyperbolic:{},nebius:{},novita:{},openai:{},replicate:{},sambanova:{},together:{}},gt=new Map;async function ys(e,a,t={}){var r,u;if(e.provider==="hf-inference")return e.model;if(!t.task)throw new Error("task must be specified when using a third-party provider");const i=t.task==="text-generation"&&t.chatCompletion?"conversational":t.task;if((r=ht[e.provider])!=null&&r[e.model])return ht[e.provider][e.model];let n;if(gt.has(e.model)?n=gt.get(e.model):n=await((t==null?void 0:t.fetch)??fetch)(`${Ct}/api/models/${e.model}?expand[]=inferenceProviderMapping`,{headers:(u=a.accessToken)!=null&&u.startsWith("hf_")?{Authorization:`Bearer ${a.accessToken}`}:{}}).then(d=>d.json()).then(d=>d.inferenceProviderMapping).catch(()=>null),!n)throw new Error(`We have not been able to find inference provider information for model ${e.model}.`);const o=n[e.provider];if(o){if(o.task!==i)throw new Error(`Model ${e.model} is not supported for task ${i} and provider ${e.provider}. Supported task: ${o.task}.`);return o.status==="staging"&&console.warn(`Model ${e.model} is in staging mode for provider ${e.provider}. Meant for test purposes only.`),o.providerId}throw new Error(`Model ${e.model} is not supported provider ${e.provider}.`)}var ws=`${Ut}/{{PROVIDER}}`,Me=null,Mt={"black-forest-labs":Xo,cerebras:ar,cohere:lr,"fal-ai":hr,"fireworks-ai":kr,"hf-inference":Er,hyperbolic:$r,openai:hs,nebius:Rr,novita:Hr,replicate:Yr,sambanova:is,together:cs};async function Be(e,a){const{provider:t,model:i}=e,n=t??"hf-inference",o=Mt[n],{task:r,chatCompletion:u}=a??{};if(e.endpointUrl&&n!=="hf-inference")throw new Error("Cannot use endpointUrl with a third-party provider.");if(i&&xe(i))throw new Error("Model URLs are no longer supported. Use endpointUrl instead.");if(!i&&!r)throw new Error("No model provided, and no task has been specified.");if(!o)throw new Error(`No provider config found for provider ${n}`);if(o.clientSideRoutingOnly&&!i)throw new Error(`Provider ${n} requires a model ID to be passed directly.`);const d=i??await vs(r),p=o.clientSideRoutingOnly?ks(i,n):await ys({model:d,provider:n},e,{task:r,chatCompletion:u,fetch:a==null?void 0:a.fetch});return $t(p,e,a)}function $t(e,a,t){const{accessToken:i,endpointUrl:n,provider:o,model:r,...u}=a,d=o??"hf-inference",p=Mt[d],{includeCredentials:c,task:l,chatCompletion:h,signal:g}=t??{},b=(()=>{if(p.clientSideRoutingOnly){if(i&&i.startsWith("hf_"))throw new Error(`Provider ${d} is closed-source and does not support HF tokens.`);return"provider-key"}return i?i.startsWith("hf_")?"hf-token":"provider-key":c==="include"?"credentials-include":"none"})(),N=n?h?n+"/v1/chat/completions":n:p.makeUrl({authMethod:b,baseUrl:b!=="provider-key"?ws.replace("{{PROVIDER}}",d):p.makeBaseUrl(l),model:e,chatCompletion:h,task:l}),L="data"in a&&!!a.data,F=p.makeHeaders({accessToken:i,authMethod:b});L||(F["Content-Type"]="application/json");const me=[`${gs}/${bs}`,typeof navigator<"u"?navigator.userAgent:void 0].filter(fe=>fe!==void 0).join(" ");F["User-Agent"]=me;const Te=L?a.data:JSON.stringify(p.makeBody({args:u,model:e,task:l,chatCompletion:h}));let Z;typeof c=="string"?Z=c:c===!0&&(Z="include");const Ce={headers:F,method:"POST",body:Te,...Z?{credentials:Z}:void 0,signal:g};return{url:N,info:Ce}}async function vs(e){Me||(Me=await _s());const a=Me[e];if(((a==null?void 0:a.models.length)??0)<=0)throw new Error(`No default model defined for task ${e}, please define the model explicitly.`);return a.models[0].id}async function _s(){const e=await fetch(`${Ct}/api/tasks`);if(!e.ok)throw new Error("Failed to load tasks definitions from Hugging Face Hub.");return await e.json()}function ks(e,a){if(!e.startsWith(`${a}/`))throw new Error(`Models from ${a} must be prefixed by "${a}/". Got "${e}".`);return e.slice(a.length+1)}async function I(e,a){var o;const{url:t,info:i}=await Be(e,a),n=await((a==null?void 0:a.fetch)??fetch)(t,i);if((a==null?void 0:a.retry_on_error)!==!1&&n.status===503)return I(e,a);if(!n.ok){const r=n.headers.get("Content-Type");if(["application/json","application/problem+json"].some(d=>r==null?void 0:r.startsWith(d))){const d=await n.json();throw[400,422,404,500].includes(n.status)&&(a!=null&&a.chatCompletion)?new Error(`Server ${e.model} does not seem to support chat completion. Error: ${JSON.stringify(d.error)}`):d.error||d.detail?new Error(JSON.stringify(d.error??d.detail)):new Error(d)}const u=r!=null&&r.startsWith("text/plain;")?await n.text():void 0;throw new Error(u??"An error occurred while fetching the blob")}return(o=n.headers.get("Content-Type"))!=null&&o.startsWith("application/json")?await n.json():await n.blob()}function xs(e){let a,t,i,n=!1;return function(r){a===void 0?(a=r,t=0,i=-1):a=Ss(a,r);const u=a.length;let d=0;for(;t<u;){n&&(a[t]===10&&(d=++t),n=!1);let p=-1;for(;t<u&&p===-1;++t)switch(a[t]){case 58:i===-1&&(i=t-d);break;case 13:n=!0;case 10:p=t;break}if(p===-1)break;e(a.subarray(d,p),i),d=t,i=-1}d===u?a=void 0:d!==0&&(a=a.subarray(d),t-=d)}}function As(e,a,t){let i=bt();const n=new TextDecoder;return function(r,u){if(r.length===0)t==null||t(i),i=bt();else if(u>0){const d=n.decode(r.subarray(0,u)),p=u+(r[u+1]===32?2:1),c=n.decode(r.subarray(p));switch(d){case"data":i.data=i.data?i.data+`
`+c:c;break;case"event":i.event=c;break;case"id":e(i.id=c);break;case"retry":const l=parseInt(c,10);isNaN(l)||a(i.retry=l);break}}}}function Ss(e,a){const t=new Uint8Array(e.length+a.length);return t.set(e),t.set(a,e.length),t}function bt(){return{data:"",event:"",id:"",retry:void 0}}async function*Ae(e,a){var p,c;const{url:t,info:i}=await Be({...e,stream:!0},a),n=await((a==null?void 0:a.fetch)??fetch)(t,i);if((a==null?void 0:a.retry_on_error)!==!1&&n.status===503)return yield*Ae(e,a);if(!n.ok){if((p=n.headers.get("Content-Type"))!=null&&p.startsWith("application/json")){const l=await n.json();if([400,422,404,500].includes(n.status)&&(a!=null&&a.chatCompletion))throw new Error(`Server ${e.model} does not seem to support chat completion. Error: ${l.error}`);if(typeof l.error=="string")throw new Error(l.error);if(l.error&&"message"in l.error&&typeof l.error.message=="string")throw new Error(l.error.message)}throw new Error(`Server response contains error: ${n.status}`)}if(!((c=n.headers.get("content-type"))!=null&&c.startsWith("text/event-stream")))throw new Error("Server does not support event stream content type, it returned "+n.headers.get("content-type"));if(!n.body)return;const o=n.body.getReader();let r=[];const d=xs(As(()=>{},()=>{},l=>{r.push(l)}));try{for(;;){const{done:l,value:h}=await o.read();if(l)return;d(h);for(const g of r)if(g.data.length>0){if(g.data==="[DONE]")return;const b=JSON.parse(g.data);if(typeof b=="object"&&b!==null&&"error"in b){const N=typeof b.error=="string"?b.error:typeof b.error=="object"&&b.error&&"message"in b.error&&typeof b.error.message=="string"?b.error.message:JSON.stringify(b.error);throw new Error("Error forwarded from backend: "+N)}yield b}r=[]}}finally{o.releaseLock()}}function Is(e,a){return Object.assign({},...a.map(t=>{if(e[t]!==void 0)return{[t]:e[t]}}))}function Lt(e,a){return e.includes(a)}function q(e,a){const t=Array.isArray(a)?a:[a],i=Object.keys(e).filter(n=>!Lt(t,n));return Is(e,i)}function qe(e){return"data"in e?e:{...q(e,"inputs"),data:e.inputs}}async function Es(e,a){const t=qe(e),i=await I(t,{...a,task:"audio-classification"});if(!(Array.isArray(i)&&i.every(o=>typeof o.label=="string"&&typeof o.score=="number")))throw new x("Expected Array<{label: string, score: number}>");return i}function ie(e){if(globalThis.Buffer)return globalThis.Buffer.from(e).toString("base64");{const a=[];return e.forEach(t=>{a.push(String.fromCharCode(t))}),globalThis.btoa(a.join(""))}}async function Ts(e,a){const t=await Cs(e),i=await I(t,{...a,task:"automatic-speech-recognition"});if(!(typeof(i==null?void 0:i.text)=="string"))throw new x("Expected {text: string}");return i}var yt=["audio/mpeg","audio/mp4","audio/wav","audio/x-wav"];async function Cs(e){if(e.provider==="fal-ai"){const a="data"in e&&e.data instanceof Blob?e.data:"inputs"in e?e.inputs:void 0,t=a==null?void 0:a.type;if(!t)throw new Error("Unable to determine the input's content-type. Make sure your are passing a Blob when using provider fal-ai.");if(!yt.includes(t))throw new Error(`Provider fal-ai does not support blob type ${t} - supported content types are: ${yt.join(", ")}`);const i=ie(new Uint8Array(await a.arrayBuffer()));return{..."data"in e?q(e,"data"):q(e,"inputs"),audio_url:`data:${t};base64,${i}`}}else return qe(e)}async function Us(e,a){const t=e.provider==="replicate"?{...q(e,["inputs","parameters"]),...e.parameters,text:e.inputs}:e,i=await I(t,{...a,task:"text-to-speech"});if(i instanceof Blob)return i;if(i&&typeof i=="object"&&"output"in i){if(typeof i.output=="string")return await(await fetch(i.output)).blob();if(Array.isArray(i.output))return await(await fetch(i.output[0])).blob()}throw new x("Expected Blob or object with output")}async function Os(e,a){const t=qe(e),i=await I(t,{...a,task:"audio-to-audio"});return Ms(i)}function Ms(e){if(!Array.isArray(e))throw new x("Expected Array");if(!e.every(a=>typeof a=="object"&&a&&"label"in a&&typeof a.label=="string"&&"content-type"in a&&typeof a["content-type"]=="string"&&"blob"in a&&typeof a.blob=="string"))throw new x("Expected Array<{label: string, audio: Blob}>");return e}function Se(e){return"data"in e?e:{...q(e,"inputs"),data:e.inputs}}async function $s(e,a){const t=Se(e),i=await I(t,{...a,task:"image-classification"});if(!(Array.isArray(i)&&i.every(o=>typeof o.label=="string"&&typeof o.score=="number")))throw new x("Expected Array<{label: string, score: number}>");return i}async function Ls(e,a){const t=Se(e),i=await I(t,{...a,task:"image-segmentation"});if(!(Array.isArray(i)&&i.every(o=>typeof o.label=="string"&&typeof o.mask=="string"&&typeof o.score=="number")))throw new x("Expected Array<{label: string, mask: string, score: number}>");return i}async function Ns(e,a){var n;const t=Se(e),i=(n=await I(t,{...a,task:"image-to-text"}))==null?void 0:n[0];if(typeof(i==null?void 0:i.generated_text)!="string")throw new x("Expected {generated_text: string}");return i}async function Ds(e,a){const t=Se(e),i=await I(t,{...a,task:"object-detection"});if(!(Array.isArray(i)&&i.every(o=>typeof o.label=="string"&&typeof o.score=="number"&&typeof o.box.xmin=="number"&&typeof o.box.ymin=="number"&&typeof o.box.xmax=="number"&&typeof o.box.ymax=="number")))throw new x("Expected Array<{label:string; score:number; box:{xmin:number; ymin:number; xmax:number; ymax:number}}>");return i}function Ps(e){switch(e){case"fal-ai":return{sync_mode:!0};case"nebius":return{response_format:"b64_json"};case"replicate":return;case"together":return{response_format:"base64"};default:return}}async function js(e,a){const t=!e.provider||e.provider==="hf-inference"||e.provider==="sambanova"?e:{...q(e,["inputs","parameters"]),...e.parameters,...Ps(e.provider),prompt:e.inputs},i=await I(t,{...a,task:"text-to-image"});if(i&&typeof i=="object"){if(e.provider==="black-forest-labs"&&"polling_url"in i&&typeof i.polling_url=="string")return await Rs(i.polling_url,a==null?void 0:a.outputType);if(e.provider==="fal-ai"&&"images"in i&&Array.isArray(i.images)&&i.images[0].url)return(a==null?void 0:a.outputType)==="url"?i.images[0].url:await(await fetch(i.images[0].url)).blob();if(e.provider==="hyperbolic"&&"images"in i&&Array.isArray(i.images)&&i.images[0]&&typeof i.images[0].image=="string")return(a==null?void 0:a.outputType)==="url"?`data:image/jpeg;base64,${i.images[0].image}`:await(await fetch(`data:image/jpeg;base64,${i.images[0].image}`)).blob();if("data"in i&&Array.isArray(i.data)&&i.data[0].b64_json){const o=i.data[0].b64_json;return(a==null?void 0:a.outputType)==="url"?`data:image/jpeg;base64,${o}`:await(await fetch(`data:image/jpeg;base64,${o}`)).blob()}if("output"in i&&Array.isArray(i.output))return(a==null?void 0:a.outputType)==="url"?i.output[0]:await(await fetch(i.output[0])).blob()}if(!(i&&i instanceof Blob))throw new x("Expected Blob");return(a==null?void 0:a.outputType)==="url"?`data:image/jpeg;base64,${await i.arrayBuffer().then(r=>Buffer.from(r).toString("base64"))}`:i}async function Rs(e,a){const t=new URL(e);for(let i=0;i<5;i++){await Ot(1e3),console.debug(`Polling Black Forest Labs API for the result... ${i+1}/5`),t.searchParams.set("attempt",i.toString(10));const n=await fetch(t,{headers:{"Content-Type":"application/json"}});if(!n.ok)throw new x("Failed to fetch result from black forest labs API");const o=await n.json();if(typeof o=="object"&&o&&"status"in o&&typeof o.status=="string"&&o.status==="Ready"&&"result"in o&&typeof o.result=="object"&&o.result&&"sample"in o.result&&typeof o.result.sample=="string")return a==="url"?o.result.sample:await(await fetch(o.result.sample)).blob()}throw new x("Failed to fetch result from black forest labs API")}async function Bs(e,a){let t;e.parameters?t={...e,inputs:ie(new Uint8Array(e.inputs instanceof ArrayBuffer?e.inputs:await e.inputs.arrayBuffer()))}:t={accessToken:e.accessToken,model:e.model,data:e.inputs};const i=await I(t,{...a,task:"image-to-image"});if(!(i&&i instanceof Blob))throw new x("Expected Blob");return i}async function qs(e){return e.inputs instanceof Blob?{...e,inputs:{image:ie(new Uint8Array(await e.inputs.arrayBuffer()))}}:{...e,inputs:{image:ie(new Uint8Array(e.inputs.image instanceof ArrayBuffer?e.inputs.image:await e.inputs.image.arrayBuffer()))}}}async function Vs(e,a){const t=await qs(e),i=await I(t,{...a,task:"zero-shot-image-classification"});if(!(Array.isArray(i)&&i.every(o=>typeof o.label=="string"&&typeof o.score=="number")))throw new x("Expected Array<{label: string, score: number}>");return i}var wt=["fal-ai","novita","replicate"];async function Fs(e,a){if(!e.provider||!Lt(wt,e.provider))throw new Error(`textToVideo inference is only supported for the following providers: ${wt.join(", ")}`);const t=e.provider==="fal-ai"||e.provider==="replicate"||e.provider==="novita"?{...q(e,["inputs","parameters"]),...e.parameters,prompt:e.inputs}:e,i=await I(t,{...a,task:"text-to-video"});if(e.provider==="fal-ai"){const{url:n,info:o}=await Be(e,{...a,task:"text-to-video"});return await gr(i,n,o.headers)}else if(e.provider==="novita"){if(!(typeof i=="object"&&!!i&&"video"in i&&typeof i.video=="object"&&!!i.video&&"video_url"in i.video&&typeof i.video.video_url=="string"&&xe(i.video.video_url)))throw new x("Expected { video: { video_url: string } }");return await(await fetch(i.video.video_url)).blob()}else{if(!(typeof i=="object"&&!!i&&"output"in i&&typeof i.output=="string"&&xe(i.output)))throw new x("Expected { output: string }");return await(await fetch(i.output)).blob()}}async function zs(e,a){const t=await I(e,{...a,task:"feature-extraction"});let i=!0;const n=(o,r,u=0)=>u>r?!1:o.every(d=>Array.isArray(d))?o.every(d=>n(d,r,u+1)):o.every(d=>typeof d=="number");if(i=Array.isArray(t)&&n(t,3,0),!i)throw new x("Expected Array<number[][][] | number[][] | number[] | number>");return t}async function Hs(e,a){const t=await I(e,{...a,task:"fill-mask"});if(!(Array.isArray(t)&&t.every(n=>typeof n.score=="number"&&typeof n.sequence=="string"&&typeof n.token=="number"&&typeof n.token_str=="string")))throw new x("Expected Array<{score: number, sequence: string, token: number, token_str: string}>");return t}async function Ws(e,a){const t=await I(e,{...a,task:"question-answering"});if(!(Array.isArray(t)?t.every(n=>typeof n=="object"&&!!n&&typeof n.answer=="string"&&typeof n.end=="number"&&typeof n.score=="number"&&typeof n.start=="number"):typeof t=="object"&&!!t&&typeof t.answer=="string"&&typeof t.end=="number"&&typeof t.score=="number"&&typeof t.start=="number"))throw new x("Expected Array<{answer: string, end: number, score: number, start: number}>");return Array.isArray(t)?t[0]:t}async function Ks(e,a){const t=await I(Qs(e),{...a,task:"sentence-similarity"});if(!(Array.isArray(t)&&t.every(n=>typeof n=="number")))throw new x("Expected number[]");return t}function Qs(e){return{...q(e,["inputs","parameters"]),inputs:{...q(e.inputs,"sourceSentence")},parameters:{source_sentence:e.inputs.sourceSentence,...e.parameters}}}async function Js(e,a){const t=await I(e,{...a,task:"summarization"});if(!(Array.isArray(t)&&t.every(n=>typeof(n==null?void 0:n.summary_text)=="string")))throw new x("Expected Array<{summary_text: string}>");return t==null?void 0:t[0]}async function Xs(e,a){const t=await I(e,{...a,task:"table-question-answering"});if(!(Array.isArray(t)?t.every(n=>vt(n)):vt(t)))throw new x("Expected {aggregator: string, answer: string, cells: string[], coordinates: number[][]}");return Array.isArray(t)?t[0]:t}function vt(e){return typeof e=="object"&&!!e&&"aggregator"in e&&typeof e.aggregator=="string"&&"answer"in e&&typeof e.answer=="string"&&"cells"in e&&Array.isArray(e.cells)&&e.cells.every(a=>typeof a=="string")&&"coordinates"in e&&Array.isArray(e.coordinates)&&e.coordinates.every(a=>Array.isArray(a)&&a.every(t=>typeof t=="number"))}async function Ys(e,a){var n;const t=(n=await I(e,{...a,task:"text-classification"}))==null?void 0:n[0];if(!(Array.isArray(t)&&t.every(o=>typeof(o==null?void 0:o.label)=="string"&&typeof o.score=="number")))throw new x("Expected Array<{label: string, score: number}>");return t}function Ie(e){return Array.isArray(e)?e:[e]}async function Zs(e,a){if(e.provider==="together"){e.prompt=e.inputs;const t=await I(e,{...a,task:"text-generation"});if(!(typeof t=="object"&&"choices"in t&&Array.isArray(t==null?void 0:t.choices)&&typeof(t==null?void 0:t.model)=="string"))throw new x("Expected ChatCompletionOutput");return{generated_text:t.choices[0].text}}else if(e.provider==="hyperbolic"){const t={messages:[{content:e.inputs,role:"user"}],...e.parameters?{max_tokens:e.parameters.max_new_tokens,...q(e.parameters,"max_new_tokens")}:void 0,...q(e,["inputs","parameters"])},i=await I(t,{...a,task:"text-generation"});if(!(typeof i=="object"&&"choices"in i&&Array.isArray(i==null?void 0:i.choices)&&typeof(i==null?void 0:i.model)=="string"))throw new x("Expected ChatCompletionOutput");return{generated_text:i.choices[0].message.content}}else{const t=Ie(await I(e,{...a,task:"text-generation"}));if(!(Array.isArray(t)&&t.every(n=>"generated_text"in n&&typeof(n==null?void 0:n.generated_text)=="string")))throw new x("Expected Array<{generated_text: string}>");return t==null?void 0:t[0]}}async function*Gs(e,a){yield*Ae(e,{...a,task:"text-generation"})}async function el(e,a){const t=Ie(await I(e,{...a,task:"token-classification"}));if(!(Array.isArray(t)&&t.every(n=>typeof n.end=="number"&&typeof n.entity_group=="string"&&typeof n.score=="number"&&typeof n.start=="number"&&typeof n.word=="string")))throw new x("Expected Array<{end: number, entity_group: string, score: number, start: number, word: string}>");return t}async function tl(e,a){const t=await I(e,{...a,task:"translation"});if(!(Array.isArray(t)&&t.every(n=>typeof(n==null?void 0:n.translation_text)=="string")))throw new x("Expected type Array<{translation_text: string}>");return(t==null?void 0:t.length)===1?t==null?void 0:t[0]:t}async function al(e,a){const t=Ie(await I(e,{...a,task:"zero-shot-classification"}));if(!(Array.isArray(t)&&t.every(n=>Array.isArray(n.labels)&&n.labels.every(o=>typeof o=="string")&&Array.isArray(n.scores)&&n.scores.every(o=>typeof o=="number")&&typeof n.sequence=="string")))throw new x("Expected Array<{labels: string[], scores: number[], sequence: string}>");return t}async function il(e,a){const t=await I(e,{...a,task:"text-generation",chatCompletion:!0});if(!(typeof t=="object"&&Array.isArray(t==null?void 0:t.choices)&&typeof(t==null?void 0:t.created)=="number"&&typeof(t==null?void 0:t.id)=="string"&&typeof(t==null?void 0:t.model)=="string"&&(t.system_fingerprint===void 0||t.system_fingerprint===null||typeof t.system_fingerprint=="string")&&typeof(t==null?void 0:t.usage)=="object"))throw new x("Expected ChatCompletionOutput");return t}async function*nl(e,a){yield*Ae(e,{...a,task:"text-generation",chatCompletion:!0})}async function ol(e,a){const t={...e,inputs:{question:e.inputs.question,image:ie(new Uint8Array(await e.inputs.image.arrayBuffer()))}},i=Ie(await I(t,{...a,task:"document-question-answering"}));if(!(Array.isArray(i)&&i.every(o=>typeof o=="object"&&!!o&&typeof(o==null?void 0:o.answer)=="string"&&(typeof o.end=="number"||typeof o.end>"u")&&(typeof o.score=="number"||typeof o.score>"u")&&(typeof o.start=="number"||typeof o.start>"u"))))throw new x("Expected Array<{answer: string, end?: number, score?: number, start?: number}>");return i[0]}async function rl(e,a){const t={...e,inputs:{question:e.inputs.question,image:ie(new Uint8Array(await e.inputs.image.arrayBuffer()))}},i=await I(t,{...a,task:"visual-question-answering"});if(!(Array.isArray(i)&&i.every(o=>typeof o=="object"&&!!o&&typeof(o==null?void 0:o.answer)=="string"&&typeof o.score=="number")))throw new x("Expected Array<{answer: string, score: number}>");return i[0]}async function sl(e,a){const t=await I(e,{...a,task:"tabular-regression"});if(!(Array.isArray(t)&&t.every(n=>typeof n=="number")))throw new x("Expected number[]");return t}async function ll(e,a){const t=await I(e,{...a,task:"tabular-classification"});if(!(Array.isArray(t)&&t.every(n=>typeof n=="number")))throw new x("Expected number[]");return t}var cl={};Tt(cl,{getInferenceSnippets:()=>vl});var Nt={js:{fetch:{basic:`async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "application/json",
			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.json();
	return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    console.log(JSON.stringify(response));
});`,basicAudio:`async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "audio/flac"
			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.json();
	return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    console.log(JSON.stringify(response));
});`,basicImage:`async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "image/jpeg"
			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.json();
	return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    console.log(JSON.stringify(response));
});`,textToAudio:`{% if model.library_name == "transformers" %}
async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "application/json",
			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.blob();
    return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    // Returns a byte object of the Audio wavform. Use it directly!
});
{% else %}
async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "application/json",
			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
    const result = await response.json();
    return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    console.log(JSON.stringify(response));
});
{% endif %} `,textToImage:`async function query(data) {
	const response = await fetch(
		"{{ fullUrl }}",
		{
			headers: {
				Authorization: "{{ authorizationHeader }}",
				"Content-Type": "application/json",
			},
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.blob();
	return result;
}

query({ inputs: {{ providerInputs.asObj.inputs }} }).then((response) => {
    // Use image
});`,zeroShotClassification:`async function query(data) {
    const response = await fetch(
		"{{ fullUrl }}",
        {
            headers: {
				Authorization: "{{ authorizationHeader }}",
                "Content-Type": "application/json",
            },
            method: "POST",
            body: JSON.stringify(data),
        }
    );
    const result = await response.json();
    return result;
}

query({
    inputs: {{ providerInputs.asObj.inputs }},
    parameters: { candidate_labels: ["refund", "legal", "faq"] }
}).then((response) => {
    console.log(JSON.stringify(response));
});`},"huggingface.js":{basic:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const output = await client.{{ methodName }}({
	model: "{{ model.id }}",
	inputs: {{ inputs.asObj.inputs }},
	provider: "{{ provider }}",
});

console.log(output);`,basicAudio:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const data = fs.readFileSync({{inputs.asObj.inputs}});

const output = await client.{{ methodName }}({
	data,
	model: "{{ model.id }}",
	provider: "{{ provider }}",
});

console.log(output);`,basicImage:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const data = fs.readFileSync({{inputs.asObj.inputs}});

const output = await client.{{ methodName }}({
	data,
	model: "{{ model.id }}",
	provider: "{{ provider }}",
});

console.log(output);`,conversational:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const chatCompletion = await client.chatCompletion({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
{{ inputs.asTsString }}
});

console.log(chatCompletion.choices[0].message);`,conversationalStream:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

let out = "";

const stream = await client.chatCompletionStream({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
{{ inputs.asTsString }}
});

for await (const chunk of stream) {
	if (chunk.choices && chunk.choices.length > 0) {
		const newContent = chunk.choices[0].delta.content;
		out += newContent;
		console.log(newContent);
	}  
}`,textToImage:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const image = await client.textToImage({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
	inputs: {{ inputs.asObj.inputs }},
	parameters: { num_inference_steps: 5 },
});
/// Use the generated image (it's a Blob)`,textToVideo:`import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient("{{ accessToken }}");

const image = await client.textToVideo({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
	inputs: {{ inputs.asObj.inputs }},
});
// Use the generated video (it's a Blob)`},openai:{conversational:`import { OpenAI } from "openai";

const client = new OpenAI({
	baseURL: "{{ baseUrl }}",
	apiKey: "{{ accessToken }}",
});

const chatCompletion = await client.chat.completions.create({
	model: "{{ providerModelId }}",
{{ inputs.asTsString }}
});

console.log(chatCompletion.choices[0].message);`,conversationalStream:`import { OpenAI } from "openai";

const client = new OpenAI({
	baseURL: "{{ baseUrl }}",
	apiKey: "{{ accessToken }}",
});

let out = "";

const stream = await client.chat.completions.create({
    provider: "{{ provider }}",
    model: "{{ model.id }}",
{{ inputs.asTsString }}
});

for await (const chunk of stream) {
	if (chunk.choices && chunk.choices.length > 0) {
		const newContent = chunk.choices[0].delta.content;
		out += newContent;
		console.log(newContent);
	}  
}`}},python:{fal_client:{textToImage:`{% if provider == "fal-ai" %}
import fal_client

result = fal_client.subscribe(
    "{{ providerModelId }}",
    arguments={
        "prompt": {{ inputs.asObj.inputs }},
    },
)
print(result)
{% endif %} `},huggingface_hub:{basic:`result = client.{{ methodName }}(
    inputs={{ inputs.asObj.inputs }},
    model="{{ model.id }}",
)`,basicAudio:'output = client.{{ methodName }}({{ inputs.asObj.inputs }}, model="{{ model.id }}")',basicImage:'output = client.{{ methodName }}({{ inputs.asObj.inputs }}, model="{{ model.id }}")',conversational:`completion = client.chat.completions.create(
    model="{{ model.id }}",
{{ inputs.asPythonString }}
)

print(completion.choices[0].message) `,conversationalStream:`stream = client.chat.completions.create(
    model="{{ model.id }}",
{{ inputs.asPythonString }}
    stream=True,
)

for chunk in stream:
    print(chunk.choices[0].delta.content, end="") `,documentQuestionAnswering:`output = client.document_question_answering(
    "{{ inputs.asObj.image }}",
    question="{{ inputs.asObj.question }}",
    model="{{ model.id }}",
) `,imageToImage:`# output is a PIL.Image object
image = client.image_to_image(
    "{{ inputs.asObj.inputs }}",
    prompt="{{ inputs.asObj.parameters.prompt }}",
    model="{{ model.id }}",
) `,importInferenceClient:`from huggingface_hub import InferenceClient

client = InferenceClient(
    provider="{{ provider }}",
    api_key="{{ accessToken }}",
)`,textToImage:`# output is a PIL.Image object
image = client.text_to_image(
    {{ inputs.asObj.inputs }},
    model="{{ model.id }}",
) `,textToVideo:`video = client.text_to_video(
    {{ inputs.asObj.inputs }},
    model="{{ model.id }}",
) `},openai:{conversational:`from openai import OpenAI

client = OpenAI(
    base_url="{{ baseUrl }}",
    api_key="{{ accessToken }}"
)

completion = client.chat.completions.create(
    model="{{ providerModelId }}",
{{ inputs.asPythonString }}
)

print(completion.choices[0].message) `,conversationalStream:`from openai import OpenAI

client = OpenAI(
    base_url="{{ baseUrl }}",
    api_key="{{ accessToken }}"
)

stream = client.chat.completions.create(
    model="{{ providerModelId }}",
{{ inputs.asPythonString }}
    stream=True,
)

for chunk in stream:
    print(chunk.choices[0].delta.content, end="")`},requests:{basic:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

output = query({
    "inputs": {{ providerInputs.asObj.inputs }},
}) `,basicAudio:`def query(filename):
    with open(filename, "rb") as f:
        data = f.read()
    response = requests.post(API_URL, headers={"Content-Type": "audio/flac", **headers}, data=data)
    return response.json()

output = query({{ providerInputs.asObj.inputs }})`,basicImage:`def query(filename):
    with open(filename, "rb") as f:
        data = f.read()
    response = requests.post(API_URL, headers={"Content-Type": "image/jpeg", **headers}, data=data)
    return response.json()

output = query({{ providerInputs.asObj.inputs }})`,conversational:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

response = query({
{{ providerInputs.asJsonString }}
})

print(response["choices"][0]["message"])`,conversationalStream:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload, stream=True)
    for line in response.iter_lines():
        if not line.startswith(b"data:"):
            continue
        if line.strip() == b"data: [DONE]":
            return
        yield json.loads(line.decode("utf-8").lstrip("data:").rstrip("/n"))

chunks = query({
{{ providerInputs.asJsonString }},
    "stream": True,
})

for chunk in chunks:
    print(chunk["choices"][0]["delta"]["content"], end="")`,documentQuestionAnswering:`def query(payload):
    with open(payload["image"], "rb") as f:
        img = f.read()
        payload["image"] = base64.b64encode(img).decode("utf-8")
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

output = query({
    "inputs": {
        "image": "{{ inputs.asObj.image }}",
        "question": "{{ inputs.asObj.question }}",
    },
}) `,imageToImage:`def query(payload):
    with open(payload["inputs"], "rb") as f:
        img = f.read()
        payload["inputs"] = base64.b64encode(img).decode("utf-8")
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

image_bytes = query({
{{ providerInputs.asJsonString }}
})

# You can access the image with PIL.Image for example
import io
from PIL import Image
image = Image.open(io.BytesIO(image_bytes)) `,importRequests:`{% if importBase64 %}
import base64
{% endif %}
{% if importJson %}
import json
{% endif %}
import requests

API_URL = "{{ fullUrl }}"
headers = {"Authorization": "{{ authorizationHeader }}"}`,tabular:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

response = query({
    "inputs": {
        "data": {{ providerInputs.asObj.inputs }}
    },
}) `,textToAudio:`{% if model.library_name == "transformers" %}
def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

audio_bytes = query({
    "inputs": {{ providerInputs.asObj.inputs }},
})
# You can access the audio with IPython.display for example
from IPython.display import Audio
Audio(audio_bytes)
{% else %}
def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

audio, sampling_rate = query({
    "inputs": {{ providerInputs.asObj.inputs }},
})
# You can access the audio with IPython.display for example
from IPython.display import Audio
Audio(audio, rate=sampling_rate)
{% endif %} `,textToImage:`{% if provider == "hf-inference" %}
def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

image_bytes = query({
    "inputs": {{ providerInputs.asObj.inputs }},
})

# You can access the image with PIL.Image for example
import io
from PIL import Image
image = Image.open(io.BytesIO(image_bytes))
{% endif %}`,zeroShotClassification:`def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

output = query({
    "inputs": {{ providerInputs.asObj.inputs }},
    "parameters": {"candidate_labels": ["refund", "legal", "faq"]},
}) `,zeroShotImageClassification:`def query(data):
    with open(data["image_path"], "rb") as f:
        img = f.read()
    payload={
        "parameters": data["parameters"],
        "inputs": base64.b64encode(img).decode("utf-8")
    }
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

output = query({
    "image_path": {{ providerInputs.asObj.inputs }},
    "parameters": {"candidate_labels": ["cat", "dog", "llama"]},
}) `}},sh:{curl:{basic:`curl {{ fullUrl }} \\
    -X POST \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: application/json' \\
    -d '{
{{ providerInputs.asCurlString }}
    }'`,basicAudio:`curl {{ fullUrl }} \\
    -X POST \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: audio/flac' \\
    --data-binary @{{ providerInputs.asObj.inputs }}`,basicImage:`curl {{ fullUrl }} \\
    -X POST \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: image/jpeg' \\
    --data-binary @{{ providerInputs.asObj.inputs }}`,conversational:`curl {{ fullUrl }} \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: application/json' \\
    -d '{
{{ providerInputs.asCurlString }},
        "stream": false
    }'`,conversationalStream:`curl {{ fullUrl }} \\
    -H 'Authorization: {{ authorizationHeader }}' \\
    -H 'Content-Type: application/json' \\
    -d '{
{{ providerInputs.asCurlString }},
        "stream": true
    }'`,zeroShotClassification:`curl {{ fullUrl }} \\
    -X POST \\
    -d '{"inputs": {{ providerInputs.asObj.inputs }}, "parameters": {"candidate_labels": ["refund", "legal", "faq"]}}' \\
    -H 'Content-Type: application/json' \\
    -H 'Authorization: {{ authorizationHeader }}'`}}},pl=["huggingface_hub","fal_client","requests","openai"],dl=["fetch","huggingface.js","openai"],ul=["curl"],ml={js:[...dl],python:[...pl],sh:[...ul]},fl=(e,a,t)=>{var i,n;return((n=(i=Nt[e])==null?void 0:i[a])==null?void 0:n[t])!==void 0},Ve=(e,a,t)=>{var n,o;const i=(o=(n=Nt[e])==null?void 0:n[a])==null?void 0:o[t];if(!i)throw new Error(`Template not found: ${e}/${a}/${t}`);return r=>new Vo(i).render({...r})},hl=Ve("python","huggingface_hub","importInferenceClient"),gl=Ve("python","requests","importRequests"),_t={"audio-classification":"audio_classification","audio-to-audio":"audio_to_audio","automatic-speech-recognition":"automatic_speech_recognition","document-question-answering":"document_question_answering","feature-extraction":"feature_extraction","fill-mask":"fill_mask","image-classification":"image_classification","image-segmentation":"image_segmentation","image-to-image":"image_to_image","image-to-text":"image_to_text","object-detection":"object_detection","question-answering":"question_answering","sentence-similarity":"sentence_similarity",summarization:"summarization","table-question-answering":"table_question_answering","tabular-classification":"tabular_classification","tabular-regression":"tabular_regression","text-classification":"text_classification","text-generation":"text_generation","text-to-image":"text_to_image","text-to-speech":"text_to_speech","text-to-video":"text_to_video","token-classification":"token_classification",translation:"translation","visual-question-answering":"visual_question_answering","zero-shot-classification":"zero_shot_classification","zero-shot-image-classification":"zero_shot_image_classification"},kt={"automatic-speech-recognition":"automaticSpeechRecognition","feature-extraction":"featureExtraction","fill-mask":"fillMask","image-classification":"imageClassification","question-answering":"questionAnswering","sentence-similarity":"sentenceSimilarity",summarization:"summarization","table-question-answering":"tableQuestionAnswering","text-classification":"textClassification","text-generation":"textGeneration","text2text-generation":"textGeneration","token-classification":"tokenClassification",translation:"translation"},T=(e,a)=>(t,i,n,o,r)=>{var h;t.pipeline_tag&&["text-generation","image-text-to-text"].includes(t.pipeline_tag)&&t.tags.includes("conversational")&&(e=r!=null&&r.streaming?"conversationalStream":"conversational",a=wl);const u=a?a(t,r):{inputs:be(t)},d=$t(o??t.id,{accessToken:i,provider:n,...u},{chatCompletion:e.includes("conversational"),task:t.pipeline_tag});let p=u;const c=d.info.body;if(typeof c=="string")try{p=JSON.parse(c)}catch(g){console.error("Failed to parse body as JSON",g)}const l={accessToken:i,authorizationHeader:(h=d.info.headers)==null?void 0:h.Authorization,baseUrl:_l(d.url,"/chat/completions"),fullUrl:d.url,inputs:{asObj:u,asCurlString:z(u,"curl"),asJsonString:z(u,"json"),asPythonString:z(u,"python"),asTsString:z(u,"ts")},providerInputs:{asObj:p,asCurlString:z(p,"curl"),asJsonString:z(p,"json"),asPythonString:z(p,"python"),asTsString:z(p,"ts")},model:t,provider:n,providerModelId:o??t.id};return bo.map(g=>ml[g].map(b=>{if(!fl(g,b,e))return;const N=Ve(g,b,e);if(b==="huggingface_hub"&&e.includes("basic")){if(!(t.pipeline_tag&&t.pipeline_tag in _t))return;l.methodName=_t[t.pipeline_tag]}if(b==="huggingface.js"&&e.includes("basic")){if(!(t.pipeline_tag&&t.pipeline_tag in kt))return;l.methodName=kt[t.pipeline_tag]}let L=N(l).trim();if(L)return b==="huggingface_hub"?L=`${hl({...l})}

${L}`:b==="requests"&&(L=`${gl({...l,importBase64:L.includes("base64"),importJson:L.includes("json.")})}

${L}`),{language:g,client:b,content:L}}).filter(b=>b!==void 0)).flat()},bl=e=>JSON.parse(be(e)),yl=e=>{const a=JSON.parse(be(e));return{inputs:a.image,parameters:{prompt:a.prompt}}},wl=(e,a)=>({messages:(a==null?void 0:a.messages)??be(e),...a!=null&&a.temperature?{temperature:a==null?void 0:a.temperature}:void 0,max_tokens:(a==null?void 0:a.max_tokens)??500,...a!=null&&a.top_p?{top_p:a==null?void 0:a.top_p}:void 0}),ye={"audio-classification":T("basicAudio"),"audio-to-audio":T("basicAudio"),"automatic-speech-recognition":T("basicAudio"),"document-question-answering":T("documentQuestionAnswering",bl),"feature-extraction":T("basic"),"fill-mask":T("basic"),"image-classification":T("basicImage"),"image-segmentation":T("basicImage"),"image-text-to-text":T("conversational"),"image-to-image":T("imageToImage",yl),"image-to-text":T("basicImage"),"object-detection":T("basicImage"),"question-answering":T("basic"),"sentence-similarity":T("basic"),summarization:T("basic"),"tabular-classification":T("tabular"),"tabular-regression":T("tabular"),"table-question-answering":T("basic"),"text-classification":T("basic"),"text-generation":T("basic"),"text-to-audio":T("textToAudio"),"text-to-image":T("textToImage"),"text-to-speech":T("textToAudio"),"text-to-video":T("textToVideo"),"text2text-generation":T("basic"),"token-classification":T("basic"),translation:T("basic"),"zero-shot-classification":T("zeroShotClassification"),"zero-shot-image-classification":T("zeroShotImageClassification")};function vl(e,a,t,i,n){var o;return e.pipeline_tag&&e.pipeline_tag in ye?((o=ye[e.pipeline_tag])==null?void 0:o.call(ye,e,a,t,i,n))??[]:[]}function z(e,a){switch(a){case"curl":return xt(z(e,"json"));case"json":return JSON.stringify(e,null,4).split(`
`).slice(1,-1).join(`
`);case"python":return xt(Object.entries(e).map(([t,i])=>{const n=JSON.stringify(i,null,4).replace(/"/g,'"');return`${t}=${n},`}).join(`
`));case"ts":return Le(e).split(`
`).slice(1,-1).join(`
`);default:throw new Error(`Unsupported format: ${a}`)}}function Le(e,a){return a=a??0,typeof e!="object"||e===null?JSON.stringify(e):Array.isArray(e)?`[
${e.map(o=>{const r=Le(o,a+1);return`${" ".repeat(4*(a+1))}${r},`}).join(`
`)}
${" ".repeat(4*a)}]`:`{
${Object.entries(e).map(([n,o])=>{const r=Le(o,a+1),u=/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(n)?n:`"${n}"`;return`${" ".repeat(4*(a+1))}${u}: ${r},`}).join(`
`)}
${" ".repeat(4*a)}}`}function xt(e){return e.split(`
`).map(a=>" ".repeat(4)+a).join(`
`)}function _l(e,a){return e.endsWith(a)?e.slice(0,-a.length):e}export{Il as E,Sl as H};
