var s;const e=((s=globalThis.__sveltekit_13a41si)==null?void 0:s.base)??"/docs/bitsandbytes/main/en";var a;const t=((a=globalThis.__sveltekit_13a41si)==null?void 0:a.assets)??e;export{t as a,e as b};
