var s;const a=((s=globalThis.__sveltekit_l32uwi)==null?void 0:s.base)??"/docs/safetensors/main/en";var e;const t=((e=globalThis.__sveltekit_l32uwi)==null?void 0:e.assets)??a;export{t as a,a as b};
