var s;const o=((s=globalThis.__sveltekit_rwwp31)==null?void 0:s.base)??"/docs/cookbook/main/fr";var a;const e=((a=globalThis.__sveltekit_rwwp31)==null?void 0:a.assets)??o;export{e as a,o as b};
