import{s as Ua,n as Ta,o as pa}from"../chunks/scheduler.39a43cde.js";import{S as ra,i as ma,g as t,s,r as j,A as wa,h as i,f as e,c as n,j as ja,u as y,x as J,k as ya,y as Ia,a,v as U,d as T,t as p,w as r}from"../chunks/index.23ec2204.js";import{D as oa,C as m}from"../chunks/DocNotebookDropdown.7c3158f8.js";import{H as Wl,E as da}from"../chunks/getInferenceSnippets.aa68157d.js";function Aa(pe){let w,gl,Sl,xl,I,vl,o,Yl,d,re='<em>Yazar: <a href="https://github.com/MKhalusova" rel="nofollow">Maria Khalusova</a></em>',Hl,A,me='<em>Çeviren: <a href="https://github.com/emre570" rel="nofollow">Emre Albayrak</a></em>',Dl,c,we="Codex, StarCoder ve Code Llama gibi açık kaynak dil modelleri genel programlama ilkelerine ve sözdizimine uygun kod üretme konusunda harikadırlar. Fakat bu modeller, bir kuruluşun dahili kurallarıyla uyumlu olmayabilir veya özel kütüphanelerden haberdar olmayabilir.",$l,C,Ie="Bu notebook’ta, bir modelin bağlamsal farkındalığını artırmak ve kuruluşunuzun ihtiyaçları için kullanılabilirliğini artırmak amacıyla özel kod tabanlarında bir kod dil modeline nasıl fine-tune yapabileceğinizi göstereceğiz. Kod dil modelleri oldukça büyük olduğundan, geleneksel bir şekilde fine-tune yapmak kaynakları tüketebilir. Endişelenmeyin! Fine-tune işlemini tek bir GPU’ya sığacak şekilde nasıl optimize edebileceğinizi göstereceğiz.",Ll,u,ql,b,oe='Bu örnek için GitHub’daki en iyi 10 Hugging Face public repo’larını seçtik. Görseller, ses dosyaları, sunumlar gibi kod içermeyen dosyaları verilerden hariç tuttuk. Jupyter notebook’lar için yalnızca kod içeren hücreleri tuttuk. Ortaya çıkan kod, Hugging Face Hub’da <a href="https://huggingface.co/datasets/smangrul/hf-stack-v1" rel="nofollow"><code>smangrul/hf-stack-v1</code></a> bağlantısı altında bulabileceğiniz bir veri seti olarak mevcut. Bu veri seti repo’nun kimliğini, dosya yolunu ve dosya içeriğini içeriyor.',Pl,k,Kl,f,de='Bu rehber için 1 milyar parametreli ve 80’den fazla programlama dilinde eğitilmiş <a href="https://huggingface.co/bigcode/starcoderbase-1b" rel="nofollow"><code>bigcode/starcoderbase-1b</code></a> modelini seçiyoruz. Bu model, yayıncı tarafından korumaya sahip, bu nedenle bu notebook’u tam olarak bu modelle çalıştırmayı planlıyorsanız, modelin sayfasından erişim sağlamanız gerekir. Erişim izninizi aldıktan sonra, Hugging Face hesabınıza giriş yapın.',Ol,h,Ae="<strong>Not:</strong> Eğer fine-tune edilmiş modelinizi Hugging Face Hub’a yüklemek istiyorsanız, <code>write</code> izni olan bir token girmeniz gerekli.",lM,Z,MM,B,ce="Başlamak için gerekli tüm kütüphaneleri yükleyelim. Gördüğünüz gibi, <code>transformers</code> ve <code>datasets</code> kütüphanelerine ek olarak, eğitimi optimize etmek için <code>peft</code>, <code>bitsandbytes</code> ve <code>flash-attn</code> kullanacağız.",eM,_,Ce="Parametre açısından verimli eğitim teknikleri kullanarak, bu notebook’u tek bir A100 High-RAM GPU üzerinde çalıştırabiliriz.",aM,V,sM,E,ue="Şimdi biraz hiperparametre tanımlayalım. Değerlerini istediğiniz gibi değiştirebilirsiniz.",nM,Q,tM,G,iM,R,JM,z,be="Verileri yükleyerek başlayalım. Veri setinin oldukça büyük olması muhtemel olduğundan, streaming modunu etkinleştirdiğinizden emin olun.",jM,X,ke="Streaming modu, tüm veri setini bir kerede indirmek yerine veri seti üzerinde işlem yaptıkça verileri kademeli olarak yüklememizi sağlar.",yM,F,fe="İlk 4000 örneği validation set (doğrulama kümesi) olarak ayıracağız ve geri kalan her şey eğitim verisi olacak.",UM,W,TM,S,he="Bu adımda, veri seti hala isteğe bağlı uzunlukta kod içeren ham veriler içeriyor. Eğitim için sabit uzunlukta girdilere ihtiyacımız var. Bir metin dosyası akışından (stream) sabit uzunlukta token yığınları döndürecek bir Iterable veri kümesi oluşturalım.",pM,N,Ze="İlk olarak, veri setindeki token başına ortalama karakter sayısını tahmin edelim, bu daha sonra text buffer’daki token sayısını tahmin etmemize yardımcı olacaktır. Varsayılan olarak, veri setinden yalnızca 400 örnek (<code>nb_examples</code>) alacağız. Tüm veri setinin yalnızca bir alt kümesini kullanmak, hesaplama maliyetini düşürürken, genel karakter-token oranının makul bir tahminini sağlayacaktır.",rM,g,mM,x,Be=`The character to token ratio of the dataset is: 2.43
`,wM,v,_e="Karakter-token oranı, metin tokenizasyonunun kalitesinin bir göstergesi olarak da kullanılabilir. Örneğin, karakter-token oranının 1,0 olması her karakterin bir token ile temsil edildiği anlamına gelir ki bu çok anlamlı değildir. Bu da zayıf bir tokenizasyona işaret eder. Standart İngilizce metinde bir token tipik olarak yaklaşık dört karaktere eşdeğerdir, yani karakter-token oranı 4,0 civarındadır. Kod veri setinde daha düşük bir oran bekleyebiliriz, ancak genel olarak konuşursak, 2,0 ile 3,5 arasında bir sayı yeterince iyi kabul edilebilir.",IM,Y,Ve="<strong>Opsiyonel FIM dönüşümleri</strong>",oM,H,Ee='Autoregressive dil modelleri tipik olarak soldan sağa doğru sekanslar üretir. Model, FIM dönüşümlerini uygulayarak metni doldurmayı da öğrenebilir.  Teknik hakkında daha fazla bilgi edinmek için <a href="https://arxiv.org/pdf/2207.14255.pdf" rel="nofollow">“Efficient Training of Language Models to Fill in the Middle” makalesine</a> göz atın.',dM,D,Qe="FIM dönüşümlerini burada tanımlayacağız ve Iterable veri setini oluştururken bunları kullanacağız. Ancak, dönüşümleri kullanmak istemiyorsanız, <code>fim_rate</code> değerini 0 olarak ayarlayabilirsiniz.",AM,$,cM,L,Ge="Sabit uzunlukta token yığınları döndürecek bir Iterable veri seti olan <code>ConstantLengthDataset</code>‘i tanımlayalım. Bunu yapmak için, boyut sınırlarına ulaşana kadar orijinal veri setinden bir buffer metin okuyacağız ve ardından ham metni tokenize edilmiş girdilere dönüştürmek için tokenizer uygulayacağız. İsteğe bağlı olarak, bazı diziler üzerinde FIM dönüşümleri gerçekleştireceğiz (etkilenen dizilerin oranı <code>fim_rate</code> tarafından kontrol edilir).",CM,q,Re="Tanımlandıktan sonra, hem eğitim hem de doğrulama verilerinden <code>ConstantLengthDataset</code> örnekleri oluşturabiliriz.",uM,P,bM,K,kM,O,ze="Veriler hazırlandığına göre, şimdi modeli yükleme zamanı! Modelin kuantize edilmiş versiyonunu yükleyeceğiz.",fM,ll,Xe="Kuantizasyon verileri daha az bitle temsil ettiğinden bellek kullanımını azaltmamızı sağlar. Modeli kuantize etmek için <code>transformers</code> ile güzel bir entegrasyona sahip <code>bitsandbytes</code> kütüphanesini kullanacağız. Tek yapmamız gereken bir <code>bitsandbytes</code> config tanımlamak ve ardından modeli yüklerken bunu kullanmak.",hM,Ml,Fe="4 bit kuantizasyonun farklı varyantları vardır, ancak genellikle daha iyi performans için NF4 kuantizasyonu kullanmanızı öneririz (<code>bnb_4bit_quant_type=“nf4”</code>).",ZM,el,We="<code>bnb_4bit_use_double_quant</code> seçeneği, parametre başına ek 0,4 bit tasarruf etmek için ilkinden sonra ikinci bir kuantizasyon ekler.",BM,al,Se='Niceleme hakkında daha fazla bilgi edinmek için <a href="https://huggingface.co/blog/4bit-transformers-bitsandbytes" rel="nofollow">“Making LLMs even more accessible with bitsandbytes, 4-bit quantization and QLoRA” blog post</a> adresine göz atın.',_M,sl,Ne="Tanımlandıktan sonra, modelin kuantize edilmiş versiyonunu yüklemek için yapılandırmayı <code>from_pretrained</code> metoduna aktarın.",VM,nl,EM,tl,ge="Eğitim için kuantize edilmiş bir model kullanırken, modeli ön işleme tabi tutmak amacıyla <code>prepare_model_for_kbit_training()</code> fonksiyonunu çağırmamız gerekiyor.",QM,il,GM,Jl,xe="Artık kuantize model hazır olduğuna göre, bir LoRA yapılandırması ayarlayabiliriz. LoRA, eğitilebilir parametrelerin sayısını önemli ölçüde azaltarak fine-tune yapmayı daha verimli hale getirir.",RM,jl,ve="LoRA tekniğini kullanarak bir modeli eğitmek için, temel modeli <code>PeftModel</code> olarak çağırmamız gerekir. Bu, <code>LoraConfig</code> ile LoRA yapılandırmasını tanımlamayı ve <code>LoraConfig</code> kullanarak orijinal modeli <code>get_peft_model()</code> ile çağırmayı içerir.",zM,yl,Ye='LoRA ve parametreleri hakkında daha fazla bilgi edinmek için <a href="https://huggingface.co/docs/peft/conceptual_guides/lora" rel="nofollow">PEFT dokümantasyonuna</a> bakabilirsiniz.',XM,Ul,FM,Tl,He=`trainable params: 5,554,176 || all params: 1,142,761,472 || trainable%: 0.4860310866343243
`,WM,pl,De="Gördüğünüz gibi LoRA tekniğini uyguladığımızda artık parametrelerin %1’inden daha azını eğitmemiz gerekecek.",SM,rl,NM,ml,$e="Artık verileri hazırladığımıza ve modeli optimize ettiğimize göre, eğitimi başlatmak için her şeyi bir araya getirmeye hazırız.",gM,wl,Le="Bir <code>Trainer</code> objesi oluşturmak için, eğitim konfigürasyonu tanımlamamız gerekiyor. En önemlisi, eğitimi yapılandırmak için tüm öznitelikleri içeren bir sınıf olan <code>TrainingArguments</code>‘tır.",xM,Il,qe="Bunlar, çalıştırabileceğiniz diğer tüm model eğitimlerine benziyor, bu nedenle burada ayrıntılara girmeyeceğiz.",vM,ol,YM,dl,Pe="Son adım olarak <code>Trainer</code> objesini oluşturun ve <code>train</code> metodunu çağırın.",HM,Al,DM,cl,Ke=`Training...
`,$M,Cl,Oe="Fine-tune edilmiş modelinizi Hugging Face Hub hesabınıza yükleyebilirsiniz.",LM,ul,qM,bl,PM,kl,la="Model Hub’a yüklendikten sonra, inference için kullanılabilir. Bunu yapmak için önce orijinal temel modeli ve onun tokenizer’ını başlatırız. Sonra, fine-tune edilmiş ağırlıkları temel modelle birleştirmemiz gerekir.",KM,fl,OM,hl,Ma="Şimdi inference için birleştirilmiş modeli kullanabiliriz. Kolaylık olması açısından, bir <code>get_code_completion</code> tanımlayacağız - metin oluşturma parametreleriyle deneme yapmaktan çekinmeyin :)",le,Zl,Me,Bl,ea="Şimdi, kodun tamamlanmasını sağlamak için yapmamız gereken tek şey <code>get_code_complete</code> fonksiyonunu çağırmak ve tamamlanmasını istediğimiz ilk birkaç satırı önek olarak, boş bir dizeyi de sonek olarak geçirmek.",ee,_l,ae,Vl,aa=`from peft import LoraConfig, TaskType, get_peft_model
from transformers import AutoModelForCausalLM
peft_config = LoraConfig(
    task_type=TaskType.CAUSAL_LM,
    r=8,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.1,
    bias="none",
    modules_to_save=["q_proj", "v_proj"],
    inference_mode=False,
)
model = AutoModelForCausalLM.from_pretrained("gpt2")
model = get_peft_model(model, peft_config)
model.print_trainable_parameters()
`,se,El,sa="Bu notebook’ta daha önce PEFT kütüphanesini kullanmış biri olarak, <code>LoraConfig</code> oluşturmak için üretilen sonucun oldukça iyi olduğunu görebilirsiniz!",ne,Ql,na="Modeli inference için başlattığımız hücreye geri dönersek ve fine-tune edilmiş ağırlıkları birleştirdiğimiz satırları yorum satırı yaparsak, orijinal modelin tam olarak aynı önek için ne üreteceğini görebilirsiniz:",te,Gl,ie,Rl,ta=`from peft import LoraConfig, TaskType, get_peft_model
from transformers import AutoModelForCausalLM
peft_config = LoraConfig(
    model_name_or_path="facebook/wav2vec2-base-960h",
    num_labels=1,
    num_features=1,
    num_hidden_layers=1,
    num_attention_heads=1,
    num_hidden_layers_per_attention_head=1,
    num_attention_heads_per_hidden_layer=1,
    hidden_size=1024,
    hidden_dropout_prob=0.1,
    hidden_act="gelu",
    hidden_act_dropout_prob=0.1,
    hidden
`,Je,zl,ia="Python syntax’ı olmasına rağmen, orijinal modelin <code>LoraConfig</code>‘in ne yapması gerektiği konusunda hiçbir anlayışının olmadığını görebilirsiniz.",je,Xl,Ja='Bu tür fine-tune’ların tam bir fine-tune ile nasıl karşılaştırıldığını ve bu tür bir modeli VS Code’da Inference Endpoints veya yerel olarak co-pilot olarak nasıl kullanacağınızı öğrenmek için <a href="https://huggingface.co/blog/personal-copilot" rel="nofollow">“Personal Copilot: Train Your Own Coding Assistant” blog yazısına</a> göz atın. Bu notebook orijinal blog yazısını tamamlar.',ye,Fl,Ue,Nl,Te;return I=new oa({props:{classNames:"absolute z-10 right-0 top-0",options:[{label:"Google Colab",value:"https://colab.research.google.com/github/huggingface/cookbook/blob/main/notebooks/tr/fine_tuning_code_llm_on_single_gpu.ipynb"}]}}),o=new Wl({props:{title:"Kod Dil Modelini Tek GPU’da Fine-Tune Etmek",local:"kod-dil-modelini-tek-gpuda-fine-tune-etmek",headingTag:"h1"}}),u=new Wl({props:{title:"Veri Seti",local:"veri-seti",headingTag:"h2"}}),k=new Wl({props:{title:"Model",local:"model",headingTag:"h2"}}),Z=new m({props:{code:"ZnJvbSUyMGh1Z2dpbmdmYWNlX2h1YiUyMGltcG9ydCUyMG5vdGVib29rX2xvZ2luJTBBJTBBbm90ZWJvb2tfbG9naW4oKQ==",highlighted:`<span class="hljs-keyword">from</span> huggingface_hub <span class="hljs-keyword">import</span> notebook_login

notebook_login()`,wrap:!1}}),V=new m({props:{code:"IXBpcCUyMGluc3RhbGwlMjAtcSUyMHRyYW5zZm9ybWVycyUyMGRhdGFzZXRzJTIwcGVmdCUyMGJpdHNhbmRieXRlcyUyMGZsYXNoLWF0dG4=",highlighted:"!pip install -q transformers datasets peft bitsandbytes flash-attn",wrap:!1}}),Q=new m({props:{code:"TU9ERUwlMjAlM0QlMjAlMjJiaWdjb2RlJTJGc3RhcmNvZGVyYmFzZS0xYiUyMiUyMCUyMCUyMyUyMEh1Z2dpbmclMjBGYWNlJTIwSHViJTIwbW9kZWwlMjBhZCVDNCVCMSUwQURBVEFTRVQlMjAlM0QlMjAlMjJzbWFuZ3J1bCUyRmhmLXN0YWNrLXYxJTIyJTIwJTIwJTIzJTIwSHVnZ2luZyUyMEZhY2UlMjBIdWInZGFraSUyMHZlcmklMjBzZXRpJTBBREFUQV9DT0xVTU4lMjAlM0QlMjAlMjJjb250ZW50JTIyJTIwJTIwJTIzJTIwa29kJTIwaSVDMyVBN2VyaSVDNCU5RmluaW4lMjBvbGR1JUM0JTlGdSUyMHMlQzMlQkN0dW4lMjBhZCVDNCVCMSUwQSUwQVNFUV9MRU5HVEglMjAlM0QlMjAyMDQ4JTIwJTIwJTIzJTIwS2FyYWt0ZXIlMjB1enVubHUlQzQlOUZ1JTBBJTBBJTIzJTIwRSVDNCU5Rml0aW0lMjBhcmclQzMlQkNtYW5sYXIlQzQlQjElMEFNQVhfU1RFUFMlMjAlM0QlMjAyMDAwJTIwJTIwJTIzJTIwbWF4X3N0ZXBzJTBBQkFUQ0hfU0laRSUyMCUzRCUyMDE2JTIwJTIwJTIzJTIwYmF0Y2hfc2l6ZSUwQUdSX0FDQ19TVEVQUyUyMCUzRCUyMDElMjAlMjAlMjMlMjBncmFkaWVudF9hY2N1bXVsYXRpb25fc3RlcHMlMEFMUiUyMCUzRCUyMDVlLTQlMjAlMjAlMjMlMjBsZWFybmluZ19yYXRlJTBBTFJfU0NIRURVTEVSX1RZUEUlMjAlM0QlMjAlMjJjb3NpbmUlMjIlMjAlMjAlMjMlMjBscl9zY2hlZHVsZXJfdHlwZSUwQVdFSUdIVF9ERUNBWSUyMCUzRCUyMDAuMDElMjAlMjAlMjMlMjB3ZWlnaHRfZGVjYXklMEFOVU1fV0FSTVVQX1NURVBTJTIwJTNEJTIwMzAlMjAlMjAlMjMlMjBudW1fd2FybXVwX3N0ZXBzJTBBRVZBTF9GUkVRJTIwJTNEJTIwMTAwJTIwJTIwJTIzJTIwZXZhbF9mcmVxJTBBU0FWRV9GUkVRJTIwJTNEJTIwMTAwJTIwJTIwJTIzJTIwc2F2ZV9mcmVxJTBBTE9HX0ZSRVElMjAlM0QlMjAyNSUyMCUyMCUyMyUyMGxvZ19mcmVxJTBBT1VUUFVUX0RJUiUyMCUzRCUyMCUyMnBlZnQtc3RhcmNvZGVyLWxvcmEtYTEwMCUyMiUyMCUyMCUyMyUyMG91dHB1dF9kaXIlMEFCRjE2JTIwJTNEJTIwVHJ1ZSUyMCUyMCUyMyUyMGJmMTYlMEFGUDE2JTIwJTNEJTIwRmFsc2UlMjAlMjAlMjMlMjBub19mcDE2JTBBJTBBJTIzJTIwRklNJTIwZCVDMyVCNm4lQzMlQkMlQzUlOUYlQzMlQkNtJTIwYXJnJUMzJUJDbWFubGFyJUM0JUIxJTBBRklNX1JBVEUlMjAlM0QlMjAwLjUlMjAlMjAlMjMlMjBmaW1fcmF0ZSUwQUZJTV9TUE1fUkFURSUyMCUzRCUyMDAuNSUyMCUyMCUyMyUyMGZpbV9zcG1fcmF0ZSUwQSUwQSUyMyUyMExPUkElMjBhcmclQzMlQkNtYW5sYXIlQzQlQjElMEFMT1JBX1IlMjAlM0QlMjA4JTIwJTIwJTIzJTIwbG9yYV9yJTBBTE9SQV9BTFBIQSUyMCUzRCUyMDMyJTIwJTIwJTIzJTIwbG9yYV9hbHBoYSUwQUxPUkFfRFJPUE9VVCUyMCUzRCUyMDAuMCUyMCUyMCUyMyUyMGxvcmFfZHJvcG91dCUwQUxPUkFfVEFSR0VUX01PRFVMRVMlMjAlM0QlMjAlMjJjX3Byb2olMkNjX2F0dG4lMkNxX2F0dG4lMkNjX2ZjJTJDY19wcm9qJTIyJTIwJTIwJTIzJTIwbG9yYV90YXJnZXRfbW9kdWxlcyUwQSUwQSUyMyUyMGJpdHNhbmRieXRlcyUyMGNvbmZpZyUyMGFyZyVDMyVCQ21hbmxhciVDNCVCMSUwQVVTRV9ORVNURURfUVVBTlQlMjAlM0QlMjBUcnVlJTIwJTIwJTIzJTIwdXNlX25lc3RlZF9xdWFudCUwQUJOQl80QklUX0NPTVBVVEVfRFRZUEUlMjAlM0QlMjAlMjJiZmxvYXQxNiUyMiUyMCUyMCUyMyUyMGJuYl80Yml0X2NvbXB1dGVfZHR5cGUlMEElMEFTRUVEJTIwJTNEJTIwMA==",highlighted:`MODEL = <span class="hljs-string">&quot;bigcode/starcoderbase-1b&quot;</span>  <span class="hljs-comment"># Hugging Face Hub model adı</span>
DATASET = <span class="hljs-string">&quot;smangrul/hf-stack-v1&quot;</span>  <span class="hljs-comment"># Hugging Face Hub&#x27;daki veri seti</span>
DATA_COLUMN = <span class="hljs-string">&quot;content&quot;</span>  <span class="hljs-comment"># kod içeriğinin olduğu sütun adı</span>

SEQ_LENGTH = <span class="hljs-number">2048</span>  <span class="hljs-comment"># Karakter uzunluğu</span>

<span class="hljs-comment"># Eğitim argümanları</span>
MAX_STEPS = <span class="hljs-number">2000</span>  <span class="hljs-comment"># max_steps</span>
BATCH_SIZE = <span class="hljs-number">16</span>  <span class="hljs-comment"># batch_size</span>
GR_ACC_STEPS = <span class="hljs-number">1</span>  <span class="hljs-comment"># gradient_accumulation_steps</span>
LR = <span class="hljs-number">5e-4</span>  <span class="hljs-comment"># learning_rate</span>
LR_SCHEDULER_TYPE = <span class="hljs-string">&quot;cosine&quot;</span>  <span class="hljs-comment"># lr_scheduler_type</span>
WEIGHT_DECAY = <span class="hljs-number">0.01</span>  <span class="hljs-comment"># weight_decay</span>
NUM_WARMUP_STEPS = <span class="hljs-number">30</span>  <span class="hljs-comment"># num_warmup_steps</span>
EVAL_FREQ = <span class="hljs-number">100</span>  <span class="hljs-comment"># eval_freq</span>
SAVE_FREQ = <span class="hljs-number">100</span>  <span class="hljs-comment"># save_freq</span>
LOG_FREQ = <span class="hljs-number">25</span>  <span class="hljs-comment"># log_freq</span>
OUTPUT_DIR = <span class="hljs-string">&quot;peft-starcoder-lora-a100&quot;</span>  <span class="hljs-comment"># output_dir</span>
BF16 = <span class="hljs-literal">True</span>  <span class="hljs-comment"># bf16</span>
FP16 = <span class="hljs-literal">False</span>  <span class="hljs-comment"># no_fp16</span>

<span class="hljs-comment"># FIM dönüşüm argümanları</span>
FIM_RATE = <span class="hljs-number">0.5</span>  <span class="hljs-comment"># fim_rate</span>
FIM_SPM_RATE = <span class="hljs-number">0.5</span>  <span class="hljs-comment"># fim_spm_rate</span>

<span class="hljs-comment"># LORA argümanları</span>
LORA_R = <span class="hljs-number">8</span>  <span class="hljs-comment"># lora_r</span>
LORA_ALPHA = <span class="hljs-number">32</span>  <span class="hljs-comment"># lora_alpha</span>
LORA_DROPOUT = <span class="hljs-number">0.0</span>  <span class="hljs-comment"># lora_dropout</span>
LORA_TARGET_MODULES = <span class="hljs-string">&quot;c_proj,c_attn,q_attn,c_fc,c_proj&quot;</span>  <span class="hljs-comment"># lora_target_modules</span>

<span class="hljs-comment"># bitsandbytes config argümanları</span>
USE_NESTED_QUANT = <span class="hljs-literal">True</span>  <span class="hljs-comment"># use_nested_quant</span>
BNB_4BIT_COMPUTE_DTYPE = <span class="hljs-string">&quot;bfloat16&quot;</span>  <span class="hljs-comment"># bnb_4bit_compute_dtype</span>

SEED = <span class="hljs-number">0</span>`,wrap:!1}}),G=new m({props:{code:"ZnJvbSUyMHRyYW5zZm9ybWVycyUyMGltcG9ydCUyMCglMEElMjAlMjAlMjAlMjBBdXRvTW9kZWxGb3JDYXVzYWxMTSUyQyUwQSUyMCUyMCUyMCUyMEF1dG9Ub2tlbml6ZXIlMkMlMEElMjAlMjAlMjAlMjBUcmFpbmVyJTJDJTBBJTIwJTIwJTIwJTIwVHJhaW5pbmdBcmd1bWVudHMlMkMlMEElMjAlMjAlMjAlMjBsb2dnaW5nJTJDJTBBJTIwJTIwJTIwJTIwc2V0X3NlZWQlMkMlMEElMjAlMjAlMjAlMjBCaXRzQW5kQnl0ZXNDb25maWclMkMlMEEpJTBBJTBBc2V0X3NlZWQoU0VFRCk=",highlighted:`<span class="hljs-keyword">from</span> transformers <span class="hljs-keyword">import</span> (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    logging,
    set_seed,
    BitsAndBytesConfig,
)

set_seed(SEED)`,wrap:!1}}),R=new Wl({props:{title:"Veri setinin hazırlanması",local:"veri-setinin-hazırlanması",headingTag:"h2"}}),W=new m({props:{code:"ZnJvbSUyMGRhdGFzZXRzJTIwaW1wb3J0JTIwbG9hZF9kYXRhc2V0JTBBaW1wb3J0JTIwdG9yY2glMEFmcm9tJTIwdHFkbSUyMGltcG9ydCUyMHRxZG0lMEElMEElMEFkYXRhc2V0JTIwJTNEJTIwbG9hZF9kYXRhc2V0KCUwQSUyMCUyMCUyMCUyMERBVEFTRVQlMkMlMEElMjAlMjAlMjAlMjBkYXRhX2RpciUzRCUyMmRhdGElMjIlMkMlMEElMjAlMjAlMjAlMjBzcGxpdCUzRCUyMnRyYWluJTIyJTJDJTBBJTIwJTIwJTIwJTIwc3RyZWFtaW5nJTNEVHJ1ZSUyQyUwQSklMEElMEF2YWxpZF9kYXRhJTIwJTNEJTIwZGF0YXNldC50YWtlKDQwMDApJTBBdHJhaW5fZGF0YSUyMCUzRCUyMGRhdGFzZXQuc2tpcCg0MDAwKSUwQXRyYWluX2RhdGElMjAlM0QlMjB0cmFpbl9kYXRhLnNodWZmbGUoYnVmZmVyX3NpemUlM0Q1MDAwJTJDJTIwc2VlZCUzRFNFRUQp",highlighted:`<span class="hljs-keyword">from</span> datasets <span class="hljs-keyword">import</span> load_dataset
<span class="hljs-keyword">import</span> torch
<span class="hljs-keyword">from</span> tqdm <span class="hljs-keyword">import</span> tqdm


dataset = load_dataset(
    DATASET,
    data_dir=<span class="hljs-string">&quot;data&quot;</span>,
    split=<span class="hljs-string">&quot;train&quot;</span>,
    streaming=<span class="hljs-literal">True</span>,
)

valid_data = dataset.take(<span class="hljs-number">4000</span>)
train_data = dataset.skip(<span class="hljs-number">4000</span>)
train_data = train_data.shuffle(buffer_size=<span class="hljs-number">5000</span>, seed=SEED)`,wrap:!1}}),g=new m({props:{code:"dG9rZW5pemVyJTIwJTNEJTIwQXV0b1Rva2VuaXplci5mcm9tX3ByZXRyYWluZWQoTU9ERUwlMkMlMjB0cnVzdF9yZW1vdGVfY29kZSUzRFRydWUpJTBBJTBBJTBBZGVmJTIwY2hhcnNfdG9rZW5fcmF0aW8oZGF0YXNldCUyQyUyMHRva2VuaXplciUyQyUyMGRhdGFfY29sdW1uJTJDJTIwbmJfZXhhbXBsZXMlM0Q0MDApJTNBJTBBJTIwJTIwJTIwJTIwJTIyJTIyJTIyJTBBJTIwJTIwJTIwJTIwVmVyaSUyMGslQzMlQkNtZXNpbmRla2klMjB0b2tlbiUyMGJhJUM1JTlGJUM0JUIxbmElMjBvcnRhbGFtYSUyMGthcmFrdGVyJTIwc2F5JUM0JUIxcyVDNCVCMW4lQzQlQjElMjB0YWhtaW4lMjBlZGVyLiUwQSUyMCUyMCUyMCUyMCUyMiUyMiUyMiUwQSUwQSUyMCUyMCUyMCUyMHRvdGFsX2NoYXJhY3RlcnMlMkMlMjB0b3RhbF90b2tlbnMlMjAlM0QlMjAwJTJDJTIwMCUwQSUyMCUyMCUyMCUyMGZvciUyMF8lMkMlMjBleGFtcGxlJTIwaW4lMjB0cWRtKHppcChyYW5nZShuYl9leGFtcGxlcyklMkMlMjBpdGVyKGRhdGFzZXQpKSUyQyUyMHRvdGFsJTNEbmJfZXhhbXBsZXMpJTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwdG90YWxfY2hhcmFjdGVycyUyMCUyQiUzRCUyMGxlbihleGFtcGxlJTVCZGF0YV9jb2x1bW4lNUQpJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwdG90YWxfdG9rZW5zJTIwJTJCJTNEJTIwbGVuKHRva2VuaXplcihleGFtcGxlJTVCZGF0YV9jb2x1bW4lNUQpLnRva2VucygpKSUwQSUwQSUyMCUyMCUyMCUyMHJldHVybiUyMHRvdGFsX2NoYXJhY3RlcnMlMjAlMkYlMjB0b3RhbF90b2tlbnMlMEElMEElMEFjaGFyc19wZXJfdG9rZW4lMjAlM0QlMjBjaGFyc190b2tlbl9yYXRpbyh0cmFpbl9kYXRhJTJDJTIwdG9rZW5pemVyJTJDJTIwREFUQV9DT0xVTU4pJTBBcHJpbnQoZiUyMlRoZSUyMGNoYXJhY3RlciUyMHRvJTIwdG9rZW4lMjByYXRpbyUyMG9mJTIwdGhlJTIwZGF0YXNldCUyMGlzJTNBJTIwJTdCY2hhcnNfcGVyX3Rva2VuJTNBLjJmJTdEJTIyKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>tokenizer = AutoTokenizer.from_pretrained(MODEL, trust_remote_code=<span class="hljs-literal">True</span>)


<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">def</span> <span class="hljs-title function_">chars_token_ratio</span>(<span class="hljs-params">dataset, tokenizer, data_column, nb_examples=<span class="hljs-number">400</span></span>):
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;&quot;&quot;
<span class="hljs-meta">... </span>    Veri kümesindeki token başına ortalama karakter sayısını tahmin eder.
<span class="hljs-meta">... </span>    &quot;&quot;&quot;</span>

<span class="hljs-meta">... </span>    total_characters, total_tokens = <span class="hljs-number">0</span>, <span class="hljs-number">0</span>
<span class="hljs-meta">... </span>    <span class="hljs-keyword">for</span> _, example <span class="hljs-keyword">in</span> tqdm(<span class="hljs-built_in">zip</span>(<span class="hljs-built_in">range</span>(nb_examples), <span class="hljs-built_in">iter</span>(dataset)), total=nb_examples):
<span class="hljs-meta">... </span>        total_characters += <span class="hljs-built_in">len</span>(example[data_column])
<span class="hljs-meta">... </span>        total_tokens += <span class="hljs-built_in">len</span>(tokenizer(example[data_column]).tokens())

<span class="hljs-meta">... </span>    <span class="hljs-keyword">return</span> total_characters / total_tokens


<span class="hljs-meta">&gt;&gt;&gt; </span>chars_per_token = chars_token_ratio(train_data, tokenizer, DATA_COLUMN)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(<span class="hljs-string">f&quot;The character to token ratio of the dataset is: <span class="hljs-subst">{chars_per_token:<span class="hljs-number">.2</span>f}</span>&quot;</span>)`,wrap:!1}}),$=new m({props:{code:"aW1wb3J0JTIwZnVuY3Rvb2xzJTBBaW1wb3J0JTIwbnVtcHklMjBhcyUyMG5wJTBBJTBBJTBBJTIzJTIwRklNJTIwZCVDMyVCNm4lQzMlQkMlQzUlOUYlQzMlQkNtbGVyaSUyMGklQzMlQTdpbiUyMCVDMyVCNm5layUyQyUyMHNvbmVrJTIwdmUlMjBvcnRhJTIwaSVDMyVBN2luJTIwJUMzJUI2emVsJTIwYmVsaXJ0ZSVDMyVBN2xlcmluJTIwYmVsaXJ0ZSVDMyVBNyUyMGtpbWxpa2xlcmluaSUyMGFsbWFrJTIwaSVDMyVBN2luJTIweWFyZCVDNCVCMW1jJUM0JUIxJTIwZm9ua3NpeW9uLiUwQSU0MGZ1bmN0b29scy5scnVfY2FjaGUobWF4c2l6ZSUzRE5vbmUpJTBBZGVmJTIwZ2V0X2ZpbV90b2tlbl9pZHModG9rZW5pemVyKSUzQSUwQSUyMCUyMCUyMCUyMHRyeSUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMEZJTV9QUkVGSVglMkMlMjBGSU1fTUlERExFJTJDJTIwRklNX1NVRkZJWCUyQyUyMEZJTV9QQUQlMjAlM0QlMjB0b2tlbml6ZXIuc3BlY2lhbF90b2tlbnNfbWFwJTVCJTIyYWRkaXRpb25hbF9zcGVjaWFsX3Rva2VucyUyMiU1RCU1QjElM0E1JTVEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc3VmZml4X3Rva19pZCUyQyUyMHByZWZpeF90b2tfaWQlMkMlMjBtaWRkbGVfdG9rX2lkJTJDJTIwcGFkX3Rva19pZCUyMCUzRCUyMCglMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjB0b2tlbml6ZXIudm9jYWIlNUJ0b2slNUQlMjBmb3IlMjB0b2slMjBpbiUyMCU1QkZJTV9TVUZGSVglMkMlMjBGSU1fUFJFRklYJTJDJTIwRklNX01JRERMRSUyQyUyMEZJTV9QQUQlNUQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjApJTBBJTIwJTIwJTIwJTIwZXhjZXB0JTIwS2V5RXJyb3IlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzdWZmaXhfdG9rX2lkJTJDJTIwcHJlZml4X3Rva19pZCUyQyUyMG1pZGRsZV90b2tfaWQlMkMlMjBwYWRfdG9rX2lkJTIwJTNEJTIwTm9uZSUyQyUyME5vbmUlMkMlMjBOb25lJTJDJTIwTm9uZSUwQSUyMCUyMCUyMCUyMHJldHVybiUyMHN1ZmZpeF90b2tfaWQlMkMlMjBwcmVmaXhfdG9rX2lkJTJDJTIwbWlkZGxlX3Rva19pZCUyQyUyMHBhZF90b2tfaWQlMEElMEElMEElMjMlMjBodHRwcyUzQSUyRiUyRmdpdGh1Yi5jb20lMkZiaWdjb2RlLXByb2plY3QlMkZNZWdhdHJvbi1MTSUyRmJsb2IlMkY2YzRiZjkwOGRmOGZkODZiNDk3N2Y1NGJmNWI4YmQ0YjUyMTAwM2QxJTJGbWVnYXRyb24lMkZkYXRhJTJGZ3B0X2RhdGFzZXQucHklMjBhZHJlc2luZGVuJTIwdXlhcmxhbm0lQzQlQjElQzUlOUZ0JUM0JUIxci4lMEFkZWYlMjBwZXJtdXRlKCUwQSUyMCUyMCUyMCUyMHNhbXBsZSUyQyUwQSUyMCUyMCUyMCUyMG5wX3JuZyUyQyUwQSUyMCUyMCUyMCUyMHN1ZmZpeF90b2tfaWQlMkMlMEElMjAlMjAlMjAlMjBwcmVmaXhfdG9rX2lkJTJDJTBBJTIwJTIwJTIwJTIwbWlkZGxlX3Rva19pZCUyQyUwQSUyMCUyMCUyMCUyMHBhZF90b2tfaWQlMkMlMEElMjAlMjAlMjAlMjBmaW1fcmF0ZSUzRDAuNSUyQyUwQSUyMCUyMCUyMCUyMGZpbV9zcG1fcmF0ZSUzRDAuNSUyQyUwQSUyMCUyMCUyMCUyMHRydW5jYXRlX29yX3BhZCUzREZhbHNlJTJDJTBBKSUzQSUwQSUyMCUyMCUyMCUyMCUyMiUyMiUyMiUwQSUyMCUyMCUyMCUyMEJpciUyMCVDMyVCNnJuZWslMjAodG9rZW4lMjBsaXN0ZXNpKSUyMGFsYXJhayUyMGlraSUyMEZJTSUyMG1vZHUlMjB5YXJkJUM0JUIxbSVDNCVCMXlsYSUyMGZpbV9yYXRlJTIwb2xhcyVDNCVCMWwlQzQlQjElQzQlOUYlQzQlQjElMjBpbGUlMjBiaXIlMjBGSU0lMjBkJUMzJUI2biVDMyVCQyVDNSU5RiVDMyVCQ20lQzMlQkMlMjBnZXIlQzMlQTdla2xlJUM1JTlGdGlyaXIlM0ElMEElMjAlMjAlMjAlMjBQU00lMjB2ZSUyMFNQTSUyMChmaW1fc3BtX3JhdGUlMjBvbGFzJUM0JUIxbCVDNCVCMSVDNCU5RiVDNCVCMSUyMGlsZSkuJTBBJTIwJTIwJTIwJTIwJTIyJTIyJTIyJTBBJTBBJTIwJTIwJTIwJTIwJTIzJTIwaWYlMjBrbyVDNSU5RnVsdSUyMGZpbV9yYXRlJTIwb2xhcyVDNCVCMWwlQzQlQjElQzQlOUYlQzQlQjElMjBpbGUlMjB0ZXRpa2xlbmVjZWt0aXIlMEElMjAlMjAlMjAlMjAlMjMlMjBCdSUyQyUyMEZJTSUyMGQlQzMlQjZuJUMzJUJDJUM1JTlGJUMzJUJDbWxlcmluaW4lMjBmaW1fcmF0ZSUyMG9sYXMlQzQlQjFsJUM0JUIxJUM0JTlGJUM0JUIxbmElMjBzYWhpcCUyMCVDMyVCNnJuZWtsZXJlJTIwdXlndWxhbmFjYSVDNCU5RiVDNCVCMSUyMGFubGFtJUM0JUIxbmElMjBnZWxpciUwQSUyMCUyMCUyMCUyMGlmJTIwbnBfcm5nLmJpbm9taWFsKDElMkMlMjBmaW1fcmF0ZSklM0ElMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjMlMjBib3VuZGFyaWVzJTIwZGl6aXNpbmRlJTIwc2FrbGFuYW4lMjByYXN0Z2VsZSUyMG9sdSVDNSU5RnR1cnVsbXUlQzUlOUYlMjBpbmRla3NsZXJlJTIwZyVDMyVCNnJlJTIwJUMzJUI2cm5lJUM0JTlGaSUyMCVDMyVCNm5layUyQyUyMG9ydGElMjB2ZSUyMHNvbmVrJTIwb2xhcmFrJTIwYXklQzQlQjFyJUM0JUIxci4lMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBib3VuZGFyaWVzJTIwJTNEJTIwbGlzdChucF9ybmcucmFuZGludChsb3clM0QwJTJDJTIwaGlnaCUzRGxlbihzYW1wbGUpJTIwJTJCJTIwMSUyQyUyMHNpemUlM0QyKSklMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBib3VuZGFyaWVzLnNvcnQoKSUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHByZWZpeCUyMCUzRCUyMG5wLmFycmF5KHNhbXBsZSU1QiUzQSUyMGJvdW5kYXJpZXMlNUIwJTVEJTVEJTJDJTIwZHR5cGUlM0RucC5pbnQ2NCklMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBtaWRkbGUlMjAlM0QlMjBucC5hcnJheShzYW1wbGUlNUJib3VuZGFyaWVzJTVCMCU1RCUyMCUzQSUyMGJvdW5kYXJpZXMlNUIxJTVEJTVEJTJDJTIwZHR5cGUlM0RucC5pbnQ2NCklMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzdWZmaXglMjAlM0QlMjBucC5hcnJheShzYW1wbGUlNUJib3VuZGFyaWVzJTVCMSU1RCUyMCUzQSU1RCUyQyUyMGR0eXBlJTNEbnAuaW50NjQpJTBBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwaWYlMjB0cnVuY2F0ZV9vcl9wYWQlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjMlMjAlQzMlQjZuZWslMkMlMjBvcnRhJTIwdmUlMjBzb25layUyMGJlbGlydGVuJTIwdG9rZW5sZXJpJTIwZGlra2F0ZSUyMGFsYXJhayUyMCVDMyVCNnJuZSVDNCU5RmluJTIweWVuaSUyMHRvcGxhbSUyMHV6dW5sdSVDNCU5RnVudSUyMGhlc2FwbGFyJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwbmV3X2xlbmd0aCUyMCUzRCUyMHN1ZmZpeC5zaGFwZSU1QjAlNUQlMjAlMkIlMjBwcmVmaXguc2hhcGUlNUIwJTVEJTIwJTJCJTIwbWlkZGxlLnNoYXBlJTVCMCU1RCUyMCUyQiUyMDMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBkaWZmJTIwJTNEJTIwbmV3X2xlbmd0aCUyMC0lMjBsZW4oc2FtcGxlKSUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMyUyMHllbmklMjB1enVubHVrJTIwaWxlJTIwb3JpamluYWwlMjB1enVubHVrJTIwYXJhcyVDNCVCMW5kYSUyMGJpciUyMHV6dW5sdWslMjBmYXJrJUM0JUIxJTIwdmFyc2ElMjBha3Rhcm1hJTIwdmV5YSUyMGtlc21lJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwaWYlMjBkaWZmJTIwJTNFJTIwMCUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGlmJTIwc3VmZml4LnNoYXBlJTVCMCU1RCUyMCUzQyUzRCUyMGRpZmYlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjByZXR1cm4lMjBzYW1wbGUlMkMlMjBucF9ybmclMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzdWZmaXglMjAlM0QlMjBzdWZmaXglNUIlM0ElMjBzdWZmaXguc2hhcGUlNUIwJTVEJTIwLSUyMGRpZmYlNUQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBlbGlmJTIwZGlmZiUyMCUzQyUyMDAlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzdWZmaXglMjAlM0QlMjBucC5jb25jYXRlbmF0ZSglNUJzdWZmaXglMkMlMjBucC5mdWxsKCgtMSUyMColMjBkaWZmKSUyQyUyMHBhZF90b2tfaWQpJTVEKSUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMyUyMEZJTSUyMGQlQzMlQjZuJUMzJUJDJUM1JTlGJUMzJUJDbWxlcmluaW4lMjBmaW1fc3BtX3JhdGVhcHBseSUyMFNQTSUyMHZhcnlhbnQlQzQlQjFuJUM0JUIxbiUyMG9sYXMlQzQlQjFsJUM0JUIxJUM0JTlGJUM0JUIxJTIwaWxlJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIzJTIwU1BNJTNBJTIwc29uZWslMkMlMjAlQzMlQjZuZWslMkMlMjBvcnRhJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwaWYlMjBucF9ybmcuYmlub21pYWwoMSUyQyUyMGZpbV9zcG1fcmF0ZSklM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBuZXdfc2FtcGxlJTIwJTNEJTIwbnAuY29uY2F0ZW5hdGUoJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCcHJlZml4X3Rva19pZCUyQyUyMHN1ZmZpeF90b2tfaWQlNUQlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzdWZmaXglMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJtaWRkbGVfdG9rX2lkJTVEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwcHJlZml4JTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwbWlkZGxlJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwKSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMyUyMEFrc2klMjB0YWtkaXJkZSUyQyUyMEZJTSUyMGQlQzMlQjZuJUMzJUJDJUM1JTlGJUMzJUJDbWxlcmluaW4lMjBQU00lMjB2YXJ5YW50JUM0JUIxbiVDNCVCMSUyMHV5Z3VsYXklQzQlQjFuJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIzJTIwUFNNJTNBJTIwJUMzJUI2bmVrJTJDJTIwc29uZWslMkMlMjBvcnRhJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwZWxzZSUzQSUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMG5ld19zYW1wbGUlMjAlM0QlMjBucC5jb25jYXRlbmF0ZSglMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUJwcmVmaXhfdG9rX2lkJTVEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwcHJlZml4JTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVCc3VmZml4X3Rva19pZCU1RCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHN1ZmZpeCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1Qm1pZGRsZV90b2tfaWQlNUQlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBtaWRkbGUlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjApJTBBJTIwJTIwJTIwJTIwZWxzZSUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMyUyMEZJTSUyMGQlQzMlQjZuJUMzJUJDJUM1JTlGJUMzJUJDbWxlcmluaSUyMHV5Z3VsYW1hbWElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBuZXdfc2FtcGxlJTIwJTNEJTIwc2FtcGxlJTBBJTBBJTIwJTIwJTIwJTIwcmV0dXJuJTIwbGlzdChuZXdfc2FtcGxlKSUyQyUyMG5wX3JuZw==",highlighted:`<span class="hljs-keyword">import</span> functools
<span class="hljs-keyword">import</span> numpy <span class="hljs-keyword">as</span> np


<span class="hljs-comment"># FIM dönüşümleri için önek, sonek ve orta için özel belirteçlerin belirteç kimliklerini almak için yardımcı fonksiyon.</span>
<span class="hljs-meta">@functools.lru_cache(<span class="hljs-params">maxsize=<span class="hljs-literal">None</span></span>)</span>
<span class="hljs-keyword">def</span> <span class="hljs-title function_">get_fim_token_ids</span>(<span class="hljs-params">tokenizer</span>):
    <span class="hljs-keyword">try</span>:
        FIM_PREFIX, FIM_MIDDLE, FIM_SUFFIX, FIM_PAD = tokenizer.special_tokens_map[<span class="hljs-string">&quot;additional_special_tokens&quot;</span>][<span class="hljs-number">1</span>:<span class="hljs-number">5</span>]
        suffix_tok_id, prefix_tok_id, middle_tok_id, pad_tok_id = (
            tokenizer.vocab[tok] <span class="hljs-keyword">for</span> tok <span class="hljs-keyword">in</span> [FIM_SUFFIX, FIM_PREFIX, FIM_MIDDLE, FIM_PAD]
        )
    <span class="hljs-keyword">except</span> KeyError:
        suffix_tok_id, prefix_tok_id, middle_tok_id, pad_tok_id = <span class="hljs-literal">None</span>, <span class="hljs-literal">None</span>, <span class="hljs-literal">None</span>, <span class="hljs-literal">None</span>
    <span class="hljs-keyword">return</span> suffix_tok_id, prefix_tok_id, middle_tok_id, pad_tok_id


<span class="hljs-comment"># https://github.com/bigcode-project/Megatron-LM/blob/6c4bf908df8fd86b4977f54bf5b8bd4b521003d1/megatron/data/gpt_dataset.py adresinden uyarlanmıştır.</span>
<span class="hljs-keyword">def</span> <span class="hljs-title function_">permute</span>(<span class="hljs-params">
    sample,
    np_rng,
    suffix_tok_id,
    prefix_tok_id,
    middle_tok_id,
    pad_tok_id,
    fim_rate=<span class="hljs-number">0.5</span>,
    fim_spm_rate=<span class="hljs-number">0.5</span>,
    truncate_or_pad=<span class="hljs-literal">False</span>,
</span>):
    <span class="hljs-string">&quot;&quot;&quot;
    Bir örnek (token listesi) alarak iki FIM modu yardımıyla fim_rate olasılığı ile bir FIM dönüşümü gerçekleştirir:
    PSM ve SPM (fim_spm_rate olasılığı ile).
    &quot;&quot;&quot;</span>

    <span class="hljs-comment"># if koşulu fim_rate olasılığı ile tetiklenecektir</span>
    <span class="hljs-comment"># Bu, FIM dönüşümlerinin fim_rate olasılığına sahip örneklere uygulanacağı anlamına gelir</span>
    <span class="hljs-keyword">if</span> np_rng.binomial(<span class="hljs-number">1</span>, fim_rate):

        <span class="hljs-comment"># boundaries dizisinde saklanan rastgele oluşturulmuş indekslere göre örneği önek, orta ve sonek olarak ayırır.</span>
        boundaries = <span class="hljs-built_in">list</span>(np_rng.randint(low=<span class="hljs-number">0</span>, high=<span class="hljs-built_in">len</span>(sample) + <span class="hljs-number">1</span>, size=<span class="hljs-number">2</span>))
        boundaries.sort()

        prefix = np.array(sample[: boundaries[<span class="hljs-number">0</span>]], dtype=np.int64)
        middle = np.array(sample[boundaries[<span class="hljs-number">0</span>] : boundaries[<span class="hljs-number">1</span>]], dtype=np.int64)
        suffix = np.array(sample[boundaries[<span class="hljs-number">1</span>] :], dtype=np.int64)

        <span class="hljs-keyword">if</span> truncate_or_pad:
            <span class="hljs-comment"># önek, orta ve sonek belirten tokenleri dikkate alarak örneğin yeni toplam uzunluğunu hesaplar</span>
            new_length = suffix.shape[<span class="hljs-number">0</span>] + prefix.shape[<span class="hljs-number">0</span>] + middle.shape[<span class="hljs-number">0</span>] + <span class="hljs-number">3</span>
            diff = new_length - <span class="hljs-built_in">len</span>(sample)

            <span class="hljs-comment"># yeni uzunluk ile orijinal uzunluk arasında bir uzunluk farkı varsa aktarma veya kesme</span>
            <span class="hljs-keyword">if</span> diff &gt; <span class="hljs-number">0</span>:
                <span class="hljs-keyword">if</span> suffix.shape[<span class="hljs-number">0</span>] &lt;= diff:
                    <span class="hljs-keyword">return</span> sample, np_rng
                suffix = suffix[: suffix.shape[<span class="hljs-number">0</span>] - diff]
            <span class="hljs-keyword">elif</span> diff &lt; <span class="hljs-number">0</span>:
                suffix = np.concatenate([suffix, np.full((-<span class="hljs-number">1</span> * diff), pad_tok_id)])

        <span class="hljs-comment"># FIM dönüşümlerinin fim_spm_rateapply SPM varyantının olasılığı ile</span>
        <span class="hljs-comment"># SPM: sonek, önek, orta</span>
        <span class="hljs-keyword">if</span> np_rng.binomial(<span class="hljs-number">1</span>, fim_spm_rate):
            new_sample = np.concatenate(
                [
                    [prefix_tok_id, suffix_tok_id],
                    suffix,
                    [middle_tok_id],
                    prefix,
                    middle,
                ]
            )
        <span class="hljs-comment"># Aksi takdirde, FIM dönüşümlerinin PSM varyantını uygulayın</span>
        <span class="hljs-comment"># PSM: önek, sonek, orta</span>
        <span class="hljs-keyword">else</span>:

            new_sample = np.concatenate(
                [
                    [prefix_tok_id],
                    prefix,
                    [suffix_tok_id],
                    suffix,
                    [middle_tok_id],
                    middle,
                ]
            )
    <span class="hljs-keyword">else</span>:
        <span class="hljs-comment"># FIM dönüşümlerini uygulamama</span>
        new_sample = sample

    <span class="hljs-keyword">return</span> <span class="hljs-built_in">list</span>(new_sample), np_rng`,wrap:!1}}),P=new m({props:{code:"ZnJvbSUyMHRvcmNoLnV0aWxzLmRhdGElMjBpbXBvcnQlMjBJdGVyYWJsZURhdGFzZXQlMEFmcm9tJTIwdG9yY2gudXRpbHMuZGF0YS5kYXRhbG9hZGVyJTIwaW1wb3J0JTIwRGF0YUxvYWRlciUwQWltcG9ydCUyMHJhbmRvbSUwQSUwQSUyMyUyMEJpciUyMG1ldGluJTIwZG9zeWFzJUM0JUIxJTIwYWslQzQlQjElQzUlOUYlQzQlQjFuZGFuJTIwc2FiaXQlMjB1enVubHVrdGElMjB0b2tlbiUyMHBhciVDMyVBN2FsYXIlQzQlQjElMjBkJUMzJUI2bmQlQzMlQkNyZW4lMjBiaXIlMjBJdGVyYWJsZSUyMHZlcmklMjBzZXRpJTIwb2x1JUM1JTlGdHVydXIuJTBBJTBBJTBBY2xhc3MlMjBDb25zdGFudExlbmd0aERhdGFzZXQoSXRlcmFibGVEYXRhc2V0KSUzQSUwQSUyMCUyMCUyMCUyMCUyMiUyMiUyMiUwQSUyMCUyMCUyMCUyME1ldGluJTIwZG9zeWFsYXIlQzQlQjFuJUM0JUIxbiUyMGFrJUM0JUIxJUM1JTlGJUM0JUIxbmRhbiUyMHNhYml0JTIwdXp1bmx1a3RhJTIwdG9rZW4lMjBwYXIlQzMlQTdhbGFyJUM0JUIxJTIwZCVDMyVCNm5kJUMzJUJDcmVuJTIweWluZWxlbmViaWxpciUyMHZlcmklMjBzZXRpLiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMEFyZyVDMyVCQ21hbmxhciUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHRva2VuaXplciUyMChUb2tlbml6ZXIpJTNBJTIwVmVyaWxlcmklMjBpJUM1JTlGbGVtZWslMjBpJUMzJUE3aW4lMjBrdWxsYW4lQzQlQjFsYW4lMjBpJUM1JTlGbGV5aWNpZGlyLiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHZlcmklMjBzZXRpJTIwKGRhdGFzZXQuRGF0YXNldCklM0ElMjBNZXRpbiUyMGRvc3lhbGFyJUM0JUIxJTIwaSVDMyVBN2VyZW4lMjB2ZXJpJTIwc2V0aS4lMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBpbmZpbml0ZSUyMChib29sKSUzQSUyMFRydWUlMjBpc2UlMkMlMjB2ZXJpJTIwc2V0aSUyMHNvbmElMjB1bGElQzUlOUZ0JUM0JUIxa3RhbiUyMHNvbnJhJTIwaXRlcmF0b3IlMjBzJUM0JUIxZiVDNCVCMXJsYW4lQzQlQjFyJTJDJTIwYWtzaSUyMHRha2RpcmRlJTIwZHVydXIuJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VxX2xlbmd0aCUyMChpbnQpJTNBJTIwRCVDMyVCNm5kJUMzJUJDciVDMyVCQ2xlY2VrJTIwdG9rZW4lMjBzZWthbnNsYXIlQzQlQjFuJUM0JUIxbiUyMHV6dW5sdSVDNCU5RnUuJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwbnVtX29mX3NlcXVlbmNlcyUyMChpbnQpJTNBJTIwQnVmZmVyJ2RhJTIwdHV0dWxhY2FrJTIwdG9rZW4lMjBzZXF1ZW5jZSUyMHNheSVDNCVCMXMlQzQlQjEuJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwY2hhcnNfcGVyX3Rva2VuJTIwKGludCklM0ElMjBNZXRpbiUyMGJ1ZmZlciclQzQlQjFuZGFraSUyMHRva2VuJTIwc2F5JUM0JUIxcyVDNCVCMW4lQzQlQjElMjB0YWhtaW4lMjBldG1layUyMGklQzMlQTdpbiUyMGt1bGxhbiVDNCVCMWxhbiUyMHRva2VuJTIwYmElQzUlOUYlQzQlQjFuYSUyMGthcmFrdGVyJTIwc2F5JUM0JUIxcyVDNCVCMS4lMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBmaW1fcmF0ZSUyMChmbG9hdCklM0ElMjBOdW11bmVuaW4lMjBGSU0lMjBpbGUlMjBwZXJtJUMzJUJDbGUlMjBlZGlsZWNlJUM0JTlGaSUyMG9yYW4lMjAoMCUyQzAlMjBpbGElMjAxJTJDMCkuJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwZmltX3NwbV9yYXRlJTIwKGZsb2F0KSUzQSUyMFNQTSUyMGt1bGxhbmFjYWslMjBGSU0lMjBwZXJtJUMzJUJDdGFzeW9ubGFyJUM0JUIxbiVDNCVCMW4lMjBvcmFuJUM0JUIxJTIwKDAuMCUyMGlsYSUyMDEuMCkuJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VlZCUyMChpbnQpJTNBJTIwUmFzdGdlbGUlMjBzYXklQzQlQjElMjAlQzMlQkNyZXRlY2klMjBpJUMzJUE3aW4lMjBzZWVkLiUwQSUyMCUyMCUyMCUyMCUyMiUyMiUyMiUwQSUwQSUyMCUyMCUyMCUyMGRlZiUyMF9faW5pdF9fKCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlbGYlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjB0b2tlbml6ZXIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBkYXRhc2V0JTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwaW5maW5pdGUlM0RGYWxzZSUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlcV9sZW5ndGglM0QxMDI0JTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwbnVtX29mX3NlcXVlbmNlcyUzRDEwMjQlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBjaGFyc19wZXJfdG9rZW4lM0QzLjYlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBjb250ZW50X2ZpZWxkJTNEJTIyY29udGVudCUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGZpbV9yYXRlJTNEMC41JTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwZmltX3NwbV9yYXRlJTNEMC41JTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VlZCUzRDAlMkMlMEElMjAlMjAlMjAlMjApJTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VsZi50b2tlbml6ZXIlMjAlM0QlMjB0b2tlbml6ZXIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzZWxmLmNvbmNhdF90b2tlbl9pZCUyMCUzRCUyMHRva2VuaXplci5lb3NfdG9rZW5faWQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzZWxmLmRhdGFzZXQlMjAlM0QlMjBkYXRhc2V0JTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VsZi5zZXFfbGVuZ3RoJTIwJTNEJTIwc2VxX2xlbmd0aCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlbGYuaW5maW5pdGUlMjAlM0QlMjBpbmZpbml0ZSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlbGYuY3VycmVudF9zaXplJTIwJTNEJTIwMCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlbGYubWF4X2J1ZmZlcl9zaXplJTIwJTNEJTIwc2VxX2xlbmd0aCUyMColMjBjaGFyc19wZXJfdG9rZW4lMjAqJTIwbnVtX29mX3NlcXVlbmNlcyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlbGYuY29udGVudF9maWVsZCUyMCUzRCUyMGNvbnRlbnRfZmllbGQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzZWxmLmZpbV9yYXRlJTIwJTNEJTIwZmltX3JhdGUlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzZWxmLmZpbV9zcG1fcmF0ZSUyMCUzRCUyMGZpbV9zcG1fcmF0ZSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlbGYuc2VlZCUyMCUzRCUyMHNlZWQlMEElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAoJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VsZi5zdWZmaXhfdG9rX2lkJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VsZi5wcmVmaXhfdG9rX2lkJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VsZi5taWRkbGVfdG9rX2lkJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc2VsZi5wYWRfdG9rX2lkJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwKSUyMCUzRCUyMGdldF9maW1fdG9rZW5faWRzKHNlbGYudG9rZW5pemVyKSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGlmJTIwbm90JTIwc2VsZi5zdWZmaXhfdG9rX2lkJTIwYW5kJTIwc2VsZi5maW1fcmF0ZSUyMCUzRSUyMDAlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBwcmludCglMjJGSU0lMjBpcyUyMG5vdCUyMHN1cHBvcnRlZCUyMGJ5JTIwdG9rZW5pemVyJTJDJTIwZGlzYWJsaW5nJTIwRklNJTIyKSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlbGYuZmltX3JhdGUlMjAlM0QlMjAwJTBBJTBBJTIwJTIwJTIwJTIwZGVmJTIwX19pdGVyX18oc2VsZiklM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBpdGVyYXRvciUyMCUzRCUyMGl0ZXIoc2VsZi5kYXRhc2V0KSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMG1vcmVfZXhhbXBsZXMlMjAlM0QlMjBUcnVlJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwbnBfcm5nJTIwJTNEJTIwbnAucmFuZG9tLlJhbmRvbVN0YXRlKHNlZWQlM0RzZWxmLnNlZWQpJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwd2hpbGUlMjBtb3JlX2V4YW1wbGVzJTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwYnVmZmVyJTJDJTIwYnVmZmVyX2xlbiUyMCUzRCUyMCU1QiU1RCUyQyUyMDAlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjB3aGlsZSUyMFRydWUlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBpZiUyMGJ1ZmZlcl9sZW4lMjAlM0UlM0QlMjBzZWxmLm1heF9idWZmZXJfc2l6ZSUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGJyZWFrJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwdHJ5JTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwYnVmZmVyLmFwcGVuZChuZXh0KGl0ZXJhdG9yKSU1QnNlbGYuY29udGVudF9maWVsZCU1RCklMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBidWZmZXJfbGVuJTIwJTJCJTNEJTIwbGVuKGJ1ZmZlciU1Qi0xJTVEKSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGV4Y2VwdCUyMFN0b3BJdGVyYXRpb24lM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBpZiUyMHNlbGYuaW5maW5pdGUlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBpdGVyYXRvciUyMCUzRCUyMGl0ZXIoc2VsZi5kYXRhc2V0KSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGVsc2UlM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBtb3JlX2V4YW1wbGVzJTIwJTNEJTIwRmFsc2UlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBicmVhayUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHRva2VuaXplZF9pbnB1dHMlMjAlM0QlMjBzZWxmLnRva2VuaXplcihidWZmZXIlMkMlMjB0cnVuY2F0aW9uJTNERmFsc2UpJTVCJTIyaW5wdXRfaWRzJTIyJTVEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwYWxsX3Rva2VuX2lkcyUyMCUzRCUyMCU1QiU1RCUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGZvciUyMHRva2VuaXplZF9pbnB1dCUyMGluJTIwdG9rZW5pemVkX2lucHV0cyUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMyUyMG9wc2l5b25lbCUyMEZJTSUyMHBlcm0lQzMlQkN0YXN5b25sYXIlQzQlQjElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBpZiUyMHNlbGYuZmltX3JhdGUlMjAlM0UlMjAwJTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwdG9rZW5pemVkX2lucHV0JTJDJTIwbnBfcm5nJTIwJTNEJTIwcGVybXV0ZSglMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjB0b2tlbml6ZWRfaW5wdXQlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBucF9ybmclMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzZWxmLnN1ZmZpeF90b2tfaWQlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzZWxmLnByZWZpeF90b2tfaWQlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzZWxmLm1pZGRsZV90b2tfaWQlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBzZWxmLnBhZF90b2tfaWQlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBmaW1fcmF0ZSUzRHNlbGYuZmltX3JhdGUlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBmaW1fc3BtX3JhdGUlM0RzZWxmLmZpbV9zcG1fcmF0ZSUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHRydW5jYXRlX29yX3BhZCUzREZhbHNlJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwKSUwQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGFsbF90b2tlbl9pZHMuZXh0ZW5kKHRva2VuaXplZF9pbnB1dCUyMCUyQiUyMCU1QnNlbGYuY29uY2F0X3Rva2VuX2lkJTVEKSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGV4YW1wbGVzJTIwJTNEJTIwJTVCJTVEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwZm9yJTIwaSUyMGluJTIwcmFuZ2UoMCUyQyUyMGxlbihhbGxfdG9rZW5faWRzKSUyQyUyMHNlbGYuc2VxX2xlbmd0aCklM0ElMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBpbnB1dF9pZHMlMjAlM0QlMjBhbGxfdG9rZW5faWRzJTVCaSUyMCUzQSUyMGklMjAlMkIlMjBzZWxmLnNlcV9sZW5ndGglNUQlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBpZiUyMGxlbihpbnB1dF9pZHMpJTIwJTNEJTNEJTIwc2VsZi5zZXFfbGVuZ3RoJTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwZXhhbXBsZXMuYXBwZW5kKGlucHV0X2lkcyklMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjByYW5kb20uc2h1ZmZsZShleGFtcGxlcyklMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBmb3IlMjBleGFtcGxlJTIwaW4lMjBleGFtcGxlcyUzQSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHNlbGYuY3VycmVudF9zaXplJTIwJTJCJTNEJTIwMSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHlpZWxkJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyaW5wdXRfaWRzJTIyJTNBJTIwdG9yY2guTG9uZ1RlbnNvcihleGFtcGxlKSUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmxhYmVscyUyMiUzQSUyMHRvcmNoLkxvbmdUZW5zb3IoZXhhbXBsZSklMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMEElMEElMEF0cmFpbl9kYXRhc2V0JTIwJTNEJTIwQ29uc3RhbnRMZW5ndGhEYXRhc2V0KCUwQSUyMCUyMCUyMCUyMHRva2VuaXplciUyQyUwQSUyMCUyMCUyMCUyMHRyYWluX2RhdGElMkMlMEElMjAlMjAlMjAlMjBpbmZpbml0ZSUzRFRydWUlMkMlMEElMjAlMjAlMjAlMjBzZXFfbGVuZ3RoJTNEU0VRX0xFTkdUSCUyQyUwQSUyMCUyMCUyMCUyMGNoYXJzX3Blcl90b2tlbiUzRGNoYXJzX3Blcl90b2tlbiUyQyUwQSUyMCUyMCUyMCUyMGNvbnRlbnRfZmllbGQlM0REQVRBX0NPTFVNTiUyQyUwQSUyMCUyMCUyMCUyMGZpbV9yYXRlJTNERklNX1JBVEUlMkMlMEElMjAlMjAlMjAlMjBmaW1fc3BtX3JhdGUlM0RGSU1fU1BNX1JBVEUlMkMlMEElMjAlMjAlMjAlMjBzZWVkJTNEU0VFRCUyQyUwQSklMEFldmFsX2RhdGFzZXQlMjAlM0QlMjBDb25zdGFudExlbmd0aERhdGFzZXQoJTBBJTIwJTIwJTIwJTIwdG9rZW5pemVyJTJDJTBBJTIwJTIwJTIwJTIwdmFsaWRfZGF0YSUyQyUwQSUyMCUyMCUyMCUyMGluZmluaXRlJTNERmFsc2UlMkMlMEElMjAlMjAlMjAlMjBzZXFfbGVuZ3RoJTNEU0VRX0xFTkdUSCUyQyUwQSUyMCUyMCUyMCUyMGNoYXJzX3Blcl90b2tlbiUzRGNoYXJzX3Blcl90b2tlbiUyQyUwQSUyMCUyMCUyMCUyMGNvbnRlbnRfZmllbGQlM0REQVRBX0NPTFVNTiUyQyUwQSUyMCUyMCUyMCUyMGZpbV9yYXRlJTNERklNX1JBVEUlMkMlMEElMjAlMjAlMjAlMjBmaW1fc3BtX3JhdGUlM0RGSU1fU1BNX1JBVEUlMkMlMEElMjAlMjAlMjAlMjBzZWVkJTNEU0VFRCUyQyUwQSk=",highlighted:`<span class="hljs-keyword">from</span> torch.utils.data <span class="hljs-keyword">import</span> IterableDataset
<span class="hljs-keyword">from</span> torch.utils.data.dataloader <span class="hljs-keyword">import</span> DataLoader
<span class="hljs-keyword">import</span> random

<span class="hljs-comment"># Bir metin dosyası akışından sabit uzunlukta token parçaları döndüren bir Iterable veri seti oluşturur.</span>


<span class="hljs-keyword">class</span> <span class="hljs-title class_">ConstantLengthDataset</span>(<span class="hljs-title class_ inherited__">IterableDataset</span>):
    <span class="hljs-string">&quot;&quot;&quot;
    Metin dosyalarının akışından sabit uzunlukta token parçaları döndüren yinelenebilir veri seti.
        Argümanlar:
            tokenizer (Tokenizer): Verileri işlemek için kullanılan işleyicidir.
            veri seti (dataset.Dataset): Metin dosyaları içeren veri seti.
            infinite (bool): True ise, veri seti sona ulaştıktan sonra iterator sıfırlanır, aksi takdirde durur.
            seq_length (int): Döndürülecek token sekanslarının uzunluğu.
            num_of_sequences (int): Buffer&#x27;da tutulacak token sequence sayısı.
            chars_per_token (int): Metin buffer&#x27;ındaki token sayısını tahmin etmek için kullanılan token başına karakter sayısı.
            fim_rate (float): Numunenin FIM ile permüle edileceği oran (0,0 ila 1,0).
            fim_spm_rate (float): SPM kullanacak FIM permütasyonlarının oranı (0.0 ila 1.0).
            seed (int): Rastgele sayı üreteci için seed.
    &quot;&quot;&quot;</span>

    <span class="hljs-keyword">def</span> <span class="hljs-title function_">__init__</span>(<span class="hljs-params">
        self,
        tokenizer,
        dataset,
        infinite=<span class="hljs-literal">False</span>,
        seq_length=<span class="hljs-number">1024</span>,
        num_of_sequences=<span class="hljs-number">1024</span>,
        chars_per_token=<span class="hljs-number">3.6</span>,
        content_field=<span class="hljs-string">&quot;content&quot;</span>,
        fim_rate=<span class="hljs-number">0.5</span>,
        fim_spm_rate=<span class="hljs-number">0.5</span>,
        seed=<span class="hljs-number">0</span>,
    </span>):
        self.tokenizer = tokenizer
        self.concat_token_id = tokenizer.eos_token_id
        self.dataset = dataset
        self.seq_length = seq_length
        self.infinite = infinite
        self.current_size = <span class="hljs-number">0</span>
        self.max_buffer_size = seq_length * chars_per_token * num_of_sequences
        self.content_field = content_field
        self.fim_rate = fim_rate
        self.fim_spm_rate = fim_spm_rate
        self.seed = seed

        (
            self.suffix_tok_id,
            self.prefix_tok_id,
            self.middle_tok_id,
            self.pad_tok_id,
        ) = get_fim_token_ids(self.tokenizer)
        <span class="hljs-keyword">if</span> <span class="hljs-keyword">not</span> self.suffix_tok_id <span class="hljs-keyword">and</span> self.fim_rate &gt; <span class="hljs-number">0</span>:
            <span class="hljs-built_in">print</span>(<span class="hljs-string">&quot;FIM is not supported by tokenizer, disabling FIM&quot;</span>)
            self.fim_rate = <span class="hljs-number">0</span>

    <span class="hljs-keyword">def</span> <span class="hljs-title function_">__iter__</span>(<span class="hljs-params">self</span>):
        iterator = <span class="hljs-built_in">iter</span>(self.dataset)
        more_examples = <span class="hljs-literal">True</span>
        np_rng = np.random.RandomState(seed=self.seed)
        <span class="hljs-keyword">while</span> more_examples:
            buffer, buffer_len = [], <span class="hljs-number">0</span>
            <span class="hljs-keyword">while</span> <span class="hljs-literal">True</span>:
                <span class="hljs-keyword">if</span> buffer_len &gt;= self.max_buffer_size:
                    <span class="hljs-keyword">break</span>
                <span class="hljs-keyword">try</span>:
                    buffer.append(<span class="hljs-built_in">next</span>(iterator)[self.content_field])
                    buffer_len += <span class="hljs-built_in">len</span>(buffer[-<span class="hljs-number">1</span>])
                <span class="hljs-keyword">except</span> StopIteration:
                    <span class="hljs-keyword">if</span> self.infinite:
                        iterator = <span class="hljs-built_in">iter</span>(self.dataset)
                    <span class="hljs-keyword">else</span>:
                        more_examples = <span class="hljs-literal">False</span>
                        <span class="hljs-keyword">break</span>
            tokenized_inputs = self.tokenizer(buffer, truncation=<span class="hljs-literal">False</span>)[<span class="hljs-string">&quot;input_ids&quot;</span>]
            all_token_ids = []

            <span class="hljs-keyword">for</span> tokenized_input <span class="hljs-keyword">in</span> tokenized_inputs:
                <span class="hljs-comment"># opsiyonel FIM permütasyonları</span>
                <span class="hljs-keyword">if</span> self.fim_rate &gt; <span class="hljs-number">0</span>:
                    tokenized_input, np_rng = permute(
                        tokenized_input,
                        np_rng,
                        self.suffix_tok_id,
                        self.prefix_tok_id,
                        self.middle_tok_id,
                        self.pad_tok_id,
                        fim_rate=self.fim_rate,
                        fim_spm_rate=self.fim_spm_rate,
                        truncate_or_pad=<span class="hljs-literal">False</span>,
                    )

                all_token_ids.extend(tokenized_input + [self.concat_token_id])
            examples = []
            <span class="hljs-keyword">for</span> i <span class="hljs-keyword">in</span> <span class="hljs-built_in">range</span>(<span class="hljs-number">0</span>, <span class="hljs-built_in">len</span>(all_token_ids), self.seq_length):
                input_ids = all_token_ids[i : i + self.seq_length]
                <span class="hljs-keyword">if</span> <span class="hljs-built_in">len</span>(input_ids) == self.seq_length:
                    examples.append(input_ids)
            random.shuffle(examples)
            <span class="hljs-keyword">for</span> example <span class="hljs-keyword">in</span> examples:
                self.current_size += <span class="hljs-number">1</span>
                <span class="hljs-keyword">yield</span> {
                    <span class="hljs-string">&quot;input_ids&quot;</span>: torch.LongTensor(example),
                    <span class="hljs-string">&quot;labels&quot;</span>: torch.LongTensor(example),
                }


train_dataset = ConstantLengthDataset(
    tokenizer,
    train_data,
    infinite=<span class="hljs-literal">True</span>,
    seq_length=SEQ_LENGTH,
    chars_per_token=chars_per_token,
    content_field=DATA_COLUMN,
    fim_rate=FIM_RATE,
    fim_spm_rate=FIM_SPM_RATE,
    seed=SEED,
)
eval_dataset = ConstantLengthDataset(
    tokenizer,
    valid_data,
    infinite=<span class="hljs-literal">False</span>,
    seq_length=SEQ_LENGTH,
    chars_per_token=chars_per_token,
    content_field=DATA_COLUMN,
    fim_rate=FIM_RATE,
    fim_spm_rate=FIM_SPM_RATE,
    seed=SEED,
)`,wrap:!1}}),K=new Wl({props:{title:"Modelin Hazırlanması",local:"modelin-hazırlanması",headingTag:"h2"}}),nl=new m({props:{code:"ZnJvbSUyMHBlZnQlMjBpbXBvcnQlMjBMb3JhQ29uZmlnJTJDJTIwZ2V0X3BlZnRfbW9kZWwlMkMlMjBwcmVwYXJlX21vZGVsX2Zvcl9rYml0X3RyYWluaW5nJTBBZnJvbSUyMHBlZnQudHVuZXJzLmxvcmElMjBpbXBvcnQlMjBMb3JhTGF5ZXIlMEElMEFsb2FkX2luXzhiaXQlMjAlM0QlMjBGYWxzZSUwQSUwQSUyMyUyMDQtYml0JTIwa3VhbnRpemUlMjBpJUM1JTlGbGVtaSUwQWNvbXB1dGVfZHR5cGUlMjAlM0QlMjBnZXRhdHRyKHRvcmNoJTJDJTIwQk5CXzRCSVRfQ09NUFVURV9EVFlQRSklMEElMEFibmJfY29uZmlnJTIwJTNEJTIwQml0c0FuZEJ5dGVzQ29uZmlnKCUwQSUyMCUyMCUyMCUyMGxvYWRfaW5fNGJpdCUzRFRydWUlMkMlMEElMjAlMjAlMjAlMjBibmJfNGJpdF9xdWFudF90eXBlJTNEJTIybmY0JTIyJTJDJTBBJTIwJTIwJTIwJTIwYm5iXzRiaXRfY29tcHV0ZV9kdHlwZSUzRGNvbXB1dGVfZHR5cGUlMkMlMEElMjAlMjAlMjAlMjBibmJfNGJpdF91c2VfZG91YmxlX3F1YW50JTNEVVNFX05FU1RFRF9RVUFOVCUyQyUwQSklMEElMEFkZXZpY2VfbWFwJTIwJTNEJTIwJTdCJTIyJTIyJTNBJTIwMCU3RCUwQSUwQW1vZGVsJTIwJTNEJTIwQXV0b01vZGVsRm9yQ2F1c2FsTE0uZnJvbV9wcmV0cmFpbmVkKCUwQSUyMCUyMCUyMCUyME1PREVMJTJDJTBBJTIwJTIwJTIwJTIwbG9hZF9pbl84Yml0JTNEbG9hZF9pbl84Yml0JTJDJTBBJTIwJTIwJTIwJTIwcXVhbnRpemF0aW9uX2NvbmZpZyUzRGJuYl9jb25maWclMkMlMEElMjAlMjAlMjAlMjBkZXZpY2VfbWFwJTNEZGV2aWNlX21hcCUyQyUwQSUyMCUyMCUyMCUyMHVzZV9jYWNoZSUzREZhbHNlJTJDJTIwJTIwJTIzJTIwR3JhZGllbnQlMjBDaGVja3BvaW50JTIwa3VsbGFuYWNhJUM0JTlGJUM0JUIxeiUwQSUyMCUyMCUyMCUyMHRydXN0X3JlbW90ZV9jb2RlJTNEVHJ1ZSUyQyUwQSUyMCUyMCUyMCUyMHVzZV9mbGFzaF9hdHRlbnRpb25fMiUzRFRydWUlMkMlMEEp",highlighted:`<span class="hljs-keyword">from</span> peft <span class="hljs-keyword">import</span> LoraConfig, get_peft_model, prepare_model_for_kbit_training
<span class="hljs-keyword">from</span> peft.tuners.lora <span class="hljs-keyword">import</span> LoraLayer

load_in_8bit = <span class="hljs-literal">False</span>

<span class="hljs-comment"># 4-bit kuantize işlemi</span>
compute_dtype = <span class="hljs-built_in">getattr</span>(torch, BNB_4BIT_COMPUTE_DTYPE)

bnb_config = BitsAndBytesConfig(
    load_in_4bit=<span class="hljs-literal">True</span>,
    bnb_4bit_quant_type=<span class="hljs-string">&quot;nf4&quot;</span>,
    bnb_4bit_compute_dtype=compute_dtype,
    bnb_4bit_use_double_quant=USE_NESTED_QUANT,
)

device_map = {<span class="hljs-string">&quot;&quot;</span>: <span class="hljs-number">0</span>}

model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    load_in_8bit=load_in_8bit,
    quantization_config=bnb_config,
    device_map=device_map,
    use_cache=<span class="hljs-literal">False</span>,  <span class="hljs-comment"># Gradient Checkpoint kullanacağız</span>
    trust_remote_code=<span class="hljs-literal">True</span>,
    use_flash_attention_2=<span class="hljs-literal">True</span>,
)`,wrap:!1}}),il=new m({props:{code:"bW9kZWwlMjAlM0QlMjBwcmVwYXJlX21vZGVsX2Zvcl9rYml0X3RyYWluaW5nKG1vZGVsKQ==",highlighted:"model = prepare_model_for_kbit_training(model)",wrap:!1}}),Ul=new m({props:{code:"JTIzJTIwTG9yYSUyMGNvbmZpZyUyMGF5YXJsYXIlQzQlQjElMEFwZWZ0X2NvbmZpZyUyMCUzRCUyMExvcmFDb25maWcoJTBBJTIwJTIwJTIwJTIwbG9yYV9hbHBoYSUzRExPUkFfQUxQSEElMkMlMEElMjAlMjAlMjAlMjBsb3JhX2Ryb3BvdXQlM0RMT1JBX0RST1BPVVQlMkMlMEElMjAlMjAlMjAlMjByJTNETE9SQV9SJTJDJTBBJTIwJTIwJTIwJTIwYmlhcyUzRCUyMm5vbmUlMjIlMkMlMEElMjAlMjAlMjAlMjB0YXNrX3R5cGUlM0QlMjJDQVVTQUxfTE0lMjIlMkMlMEElMjAlMjAlMjAlMjB0YXJnZXRfbW9kdWxlcyUzRExPUkFfVEFSR0VUX01PRFVMRVMuc3BsaXQoJTIyJTJDJTIyKSUyQyUwQSklMEElMEFtb2RlbCUyMCUzRCUyMGdldF9wZWZ0X21vZGVsKG1vZGVsJTJDJTIwcGVmdF9jb25maWcpJTBBbW9kZWwucHJpbnRfdHJhaW5hYmxlX3BhcmFtZXRlcnMoKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Lora config ayarları</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>peft_config = LoraConfig(
<span class="hljs-meta">... </span>    lora_alpha=LORA_ALPHA,
<span class="hljs-meta">... </span>    lora_dropout=LORA_DROPOUT,
<span class="hljs-meta">... </span>    r=LORA_R,
<span class="hljs-meta">... </span>    bias=<span class="hljs-string">&quot;none&quot;</span>,
<span class="hljs-meta">... </span>    task_type=<span class="hljs-string">&quot;CAUSAL_LM&quot;</span>,
<span class="hljs-meta">... </span>    target_modules=LORA_TARGET_MODULES.split(<span class="hljs-string">&quot;,&quot;</span>),
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>model = get_peft_model(model, peft_config)
<span class="hljs-meta">&gt;&gt;&gt; </span>model.print_trainable_parameters()`,wrap:!1}}),rl=new Wl({props:{title:"Modelin Eğitilmesi",local:"modelin-eğitilmesi",headingTag:"h2"}}),ol=new m({props:{code:"dHJhaW5fZGF0YS5zdGFydF9pdGVyYXRpb24lMjAlM0QlMjAwJTBBJTBBJTBBdHJhaW5pbmdfYXJncyUyMCUzRCUyMFRyYWluaW5nQXJndW1lbnRzKCUwQSUyMCUyMCUyMCUyMG91dHB1dF9kaXIlM0RmJTIyWW91cl9IRl91c2VybmFtZSUyRiU3Qk9VVFBVVF9ESVIlN0QlMjIlMkMlMEElMjAlMjAlMjAlMjBkYXRhbG9hZGVyX2Ryb3BfbGFzdCUzRFRydWUlMkMlMEElMjAlMjAlMjAlMjBldmFsdWF0aW9uX3N0cmF0ZWd5JTNEJTIyc3RlcHMlMjIlMkMlMEElMjAlMjAlMjAlMjBzYXZlX3N0cmF0ZWd5JTNEJTIyc3RlcHMlMjIlMkMlMEElMjAlMjAlMjAlMjBtYXhfc3RlcHMlM0RNQVhfU1RFUFMlMkMlMEElMjAlMjAlMjAlMjBldmFsX3N0ZXBzJTNERVZBTF9GUkVRJTJDJTBBJTIwJTIwJTIwJTIwc2F2ZV9zdGVwcyUzRFNBVkVfRlJFUSUyQyUwQSUyMCUyMCUyMCUyMGxvZ2dpbmdfc3RlcHMlM0RMT0dfRlJFUSUyQyUwQSUyMCUyMCUyMCUyMHBlcl9kZXZpY2VfdHJhaW5fYmF0Y2hfc2l6ZSUzREJBVENIX1NJWkUlMkMlMEElMjAlMjAlMjAlMjBwZXJfZGV2aWNlX2V2YWxfYmF0Y2hfc2l6ZSUzREJBVENIX1NJWkUlMkMlMEElMjAlMjAlMjAlMjBsZWFybmluZ19yYXRlJTNETFIlMkMlMEElMjAlMjAlMjAlMjBscl9zY2hlZHVsZXJfdHlwZSUzRExSX1NDSEVEVUxFUl9UWVBFJTJDJTBBJTIwJTIwJTIwJTIwd2FybXVwX3N0ZXBzJTNETlVNX1dBUk1VUF9TVEVQUyUyQyUwQSUyMCUyMCUyMCUyMGdyYWRpZW50X2FjY3VtdWxhdGlvbl9zdGVwcyUzREdSX0FDQ19TVEVQUyUyQyUwQSUyMCUyMCUyMCUyMGdyYWRpZW50X2NoZWNrcG9pbnRpbmclM0RUcnVlJTJDJTBBJTIwJTIwJTIwJTIwZnAxNiUzREZQMTYlMkMlMEElMjAlMjAlMjAlMjBiZjE2JTNEQkYxNiUyQyUwQSUyMCUyMCUyMCUyMHdlaWdodF9kZWNheSUzRFdFSUdIVF9ERUNBWSUyQyUwQSUyMCUyMCUyMCUyMHB1c2hfdG9faHViJTNEVHJ1ZSUyQyUwQSUyMCUyMCUyMCUyMGluY2x1ZGVfdG9rZW5zX3Blcl9zZWNvbmQlM0RUcnVlJTJDJTBBKQ==",highlighted:`train_data.start_iteration = <span class="hljs-number">0</span>


training_args = TrainingArguments(
    output_dir=<span class="hljs-string">f&quot;Your_HF_username/<span class="hljs-subst">{OUTPUT_DIR}</span>&quot;</span>,
    dataloader_drop_last=<span class="hljs-literal">True</span>,
    evaluation_strategy=<span class="hljs-string">&quot;steps&quot;</span>,
    save_strategy=<span class="hljs-string">&quot;steps&quot;</span>,
    max_steps=MAX_STEPS,
    eval_steps=EVAL_FREQ,
    save_steps=SAVE_FREQ,
    logging_steps=LOG_FREQ,
    per_device_train_batch_size=BATCH_SIZE,
    per_device_eval_batch_size=BATCH_SIZE,
    learning_rate=LR,
    lr_scheduler_type=LR_SCHEDULER_TYPE,
    warmup_steps=NUM_WARMUP_STEPS,
    gradient_accumulation_steps=GR_ACC_STEPS,
    gradient_checkpointing=<span class="hljs-literal">True</span>,
    fp16=FP16,
    bf16=BF16,
    weight_decay=WEIGHT_DECAY,
    push_to_hub=<span class="hljs-literal">True</span>,
    include_tokens_per_second=<span class="hljs-literal">True</span>,
)`,wrap:!1}}),Al=new m({props:{code:"dHJhaW5lciUyMCUzRCUyMFRyYWluZXIobW9kZWwlM0Rtb2RlbCUyQyUyMGFyZ3MlM0R0cmFpbmluZ19hcmdzJTJDJTIwdHJhaW5fZGF0YXNldCUzRHRyYWluX2RhdGFzZXQlMkMlMjBldmFsX2RhdGFzZXQlM0RldmFsX2RhdGFzZXQpJTBBJTBBcHJpbnQoJTIyVHJhaW5pbmcuLi4lMjIpJTBBdHJhaW5lci50cmFpbigp",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>trainer = Trainer(model=model, args=training_args, train_dataset=train_dataset, eval_dataset=eval_dataset)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(<span class="hljs-string">&quot;Training...&quot;</span>)
<span class="hljs-meta">&gt;&gt;&gt; </span>trainer.train()`,wrap:!1}}),ul=new m({props:{code:"dHJhaW5lci5wdXNoX3RvX2h1Yigp",highlighted:"trainer.push_to_hub()",wrap:!1}}),bl=new Wl({props:{title:"Inference",local:"inference",headingTag:"h2"}}),fl=new m({props:{code:"ZnJvbSUyMHBlZnQlMjBpbXBvcnQlMjBQZWZ0TW9kZWwlMEFpbXBvcnQlMjB0b3JjaCUwQSUwQSUyMyUyMCVDMyVCNm5jZSUyMG9yaWppbmFsJTIwbW9kZWxpJTIweSVDMyVCQ2tsZXlpbiUwQXRva2VuaXplciUyMCUzRCUyMEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKE1PREVMJTJDJTIwdHJ1c3RfcmVtb3RlX2NvZGUlM0RUcnVlKSUwQWJhc2VfbW9kZWwlMjAlM0QlMjBBdXRvTW9kZWxGb3JDYXVzYWxMTS5mcm9tX3ByZXRyYWluZWQoJTBBJTIwJTIwJTIwJTIwTU9ERUwlMkMlMEElMjAlMjAlMjAlMjBxdWFudGl6YXRpb25fY29uZmlnJTNETm9uZSUyQyUwQSUyMCUyMCUyMCUyMGRldmljZV9tYXAlM0ROb25lJTJDJTBBJTIwJTIwJTIwJTIwdHJ1c3RfcmVtb3RlX2NvZGUlM0RUcnVlJTJDJTBBJTIwJTIwJTIwJTIwdG9yY2hfZHR5cGUlM0R0b3JjaC5iZmxvYXQxNiUyQyUwQSkuY3VkYSgpJTBBJTBBJTIzJTIwZmluZS10dW5lJTIwZWRpbG1pJUM1JTlGJTIwYSVDNCU5RiVDNCVCMXJsJUM0JUIxa2xhciVDNCVCMSUyMG9yaWppbmFsJTIwbW9kZWwlMjBpbGUlMjBiaXJsZSVDNSU5RnRpcmluJTBBcGVmdF9tb2RlbF9pZCUyMCUzRCUyMGYlMjJZb3VyX0hGX3VzZXJuYW1lJTJGJTdCT1VUUFVUX0RJUiU3RCUyMiUwQW1vZGVsJTIwJTNEJTIwUGVmdE1vZGVsLmZyb21fcHJldHJhaW5lZChiYXNlX21vZGVsJTJDJTIwcGVmdF9tb2RlbF9pZCklMEFtb2RlbC5tZXJnZV9hbmRfdW5sb2FkKCk=",highlighted:`<span class="hljs-keyword">from</span> peft <span class="hljs-keyword">import</span> PeftModel
<span class="hljs-keyword">import</span> torch

<span class="hljs-comment"># önce orijinal modeli yükleyin</span>
tokenizer = AutoTokenizer.from_pretrained(MODEL, trust_remote_code=<span class="hljs-literal">True</span>)
base_model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    quantization_config=<span class="hljs-literal">None</span>,
    device_map=<span class="hljs-literal">None</span>,
    trust_remote_code=<span class="hljs-literal">True</span>,
    torch_dtype=torch.bfloat16,
).cuda()

<span class="hljs-comment"># fine-tune edilmiş ağırlıkları orijinal model ile birleştirin</span>
peft_model_id = <span class="hljs-string">f&quot;Your_HF_username/<span class="hljs-subst">{OUTPUT_DIR}</span>&quot;</span>
model = PeftModel.from_pretrained(base_model, peft_model_id)
model.merge_and_unload()`,wrap:!1}}),Zl=new m({props:{code:"ZGVmJTIwZ2V0X2NvZGVfY29tcGxldGlvbihwcmVmaXglMkMlMjBzdWZmaXgpJTNBJTBBJTIwJTIwJTIwJTIwdGV4dCUyMCUzRCUyMHByb21wdCUyMCUzRCUyMGYlMjIlMjIlMjIlM0NmaW1fcHJlZml4JTNFJTdCcHJlZml4JTdEJTNDZmltX3N1ZmZpeCUzRSU3QnN1ZmZpeCU3RCUzQ2ZpbV9taWRkbGUlM0UlMjIlMjIlMjIlMEElMjAlMjAlMjAlMjBtb2RlbC5ldmFsKCklMEElMjAlMjAlMjAlMjBvdXRwdXRzJTIwJTNEJTIwbW9kZWwuZ2VuZXJhdGUoJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwaW5wdXRfaWRzJTNEdG9rZW5pemVyKHRleHQlMkMlMjByZXR1cm5fdGVuc29ycyUzRCUyMnB0JTIyKS5pbnB1dF9pZHMuY3VkYSgpJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwbWF4X25ld190b2tlbnMlM0QxMjglMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjB0ZW1wZXJhdHVyZSUzRDAuMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMHRvcF9rJTNENTAlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjB0b3BfcCUzRDAuOTUlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBkb19zYW1wbGUlM0RUcnVlJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwcmVwZXRpdGlvbl9wZW5hbHR5JTNEMS4wJTJDJTBBJTIwJTIwJTIwJTIwKSUwQSUyMCUyMCUyMCUyMHJldHVybiUyMHRva2VuaXplci5iYXRjaF9kZWNvZGUob3V0cHV0cyUyQyUyMHNraXBfc3BlY2lhbF90b2tlbnMlM0RUcnVlKSU1QjAlNUQ=",highlighted:`<span class="hljs-keyword">def</span> <span class="hljs-title function_">get_code_completion</span>(<span class="hljs-params">prefix, suffix</span>):
    text = prompt = <span class="hljs-string">f&quot;&quot;&quot;&lt;fim_prefix&gt;<span class="hljs-subst">{prefix}</span>&lt;fim_suffix&gt;<span class="hljs-subst">{suffix}</span>&lt;fim_middle&gt;&quot;&quot;&quot;</span>
    model.<span class="hljs-built_in">eval</span>()
    outputs = model.generate(
        input_ids=tokenizer(text, return_tensors=<span class="hljs-string">&quot;pt&quot;</span>).input_ids.cuda(),
        max_new_tokens=<span class="hljs-number">128</span>,
        temperature=<span class="hljs-number">0.2</span>,
        top_k=<span class="hljs-number">50</span>,
        top_p=<span class="hljs-number">0.95</span>,
        do_sample=<span class="hljs-literal">True</span>,
        repetition_penalty=<span class="hljs-number">1.0</span>,
    )
    <span class="hljs-keyword">return</span> tokenizer.batch_decode(outputs, skip_special_tokens=<span class="hljs-literal">True</span>)[<span class="hljs-number">0</span>]`,wrap:!1}}),_l=new m({props:{code:"cHJlZml4JTIwJTNEJTIwJTIyJTIyJTIyZnJvbSUyMHBlZnQlMjBpbXBvcnQlMjBMb3JhQ29uZmlnJTJDJTIwVGFza1R5cGUlMkMlMjBnZXRfcGVmdF9tb2RlbCUwQWZyb20lMjB0cmFuc2Zvcm1lcnMlMjBpbXBvcnQlMjBBdXRvTW9kZWxGb3JDYXVzYWxMTSUwQXBlZnRfY29uZmlnJTIwJTNEJTIwTG9yYUNvbmZpZyglMEElMjIlMjIlMjIlMEFzdWZmaXglMjAlM0QlMjAlMjIlMjIlMjIlMjIlMjIlMjIlMEElMEFwcmludChnZXRfY29kZV9jb21wbGV0aW9uKHByZWZpeCUyQyUyMHN1ZmZpeCkp",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>prefix = <span class="hljs-string">&quot;&quot;&quot;from peft import LoraConfig, TaskType, get_peft_model
<span class="hljs-meta">... </span>from transformers import AutoModelForCausalLM
<span class="hljs-meta">... </span>peft_config = LoraConfig(
<span class="hljs-meta">... </span>&quot;&quot;&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>suffix = <span class="hljs-string">&quot;&quot;&quot;&quot;&quot;&quot;</span>

<span class="hljs-meta">... </span><span class="hljs-built_in">print</span>(get_code_completion(prefix, suffix))`,wrap:!1}}),Gl=new m({props:{code:"cHJlZml4JTIwJTNEJTIwJTIyJTIyJTIyZnJvbSUyMHBlZnQlMjBpbXBvcnQlMjBMb3JhQ29uZmlnJTJDJTIwVGFza1R5cGUlMkMlMjBnZXRfcGVmdF9tb2RlbCUwQWZyb20lMjB0cmFuc2Zvcm1lcnMlMjBpbXBvcnQlMjBBdXRvTW9kZWxGb3JDYXVzYWxMTSUwQXBlZnRfY29uZmlnJTIwJTNEJTIwTG9yYUNvbmZpZyglMEElMjIlMjIlMjIlMEFzdWZmaXglMjAlM0QlMjAlMjIlMjIlMjIlMjIlMjIlMjIlMEElMEFwcmludChnZXRfY29kZV9jb21wbGV0aW9uKHByZWZpeCUyQyUyMHN1ZmZpeCkp",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>prefix = <span class="hljs-string">&quot;&quot;&quot;from peft import LoraConfig, TaskType, get_peft_model
<span class="hljs-meta">... </span>from transformers import AutoModelForCausalLM
<span class="hljs-meta">... </span>peft_config = LoraConfig(
<span class="hljs-meta">... </span>&quot;&quot;&quot;</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>suffix = <span class="hljs-string">&quot;&quot;&quot;&quot;&quot;&quot;</span>

<span class="hljs-meta">... </span><span class="hljs-built_in">print</span>(get_code_completion(prefix, suffix))`,wrap:!1}}),Fl=new da({props:{source:"https://github.com/huggingface/cookbook/blob/main/notebooks/tr/fine_tuning_code_llm_on_single_gpu.md"}}),{c(){w=t("meta"),gl=s(),Sl=t("p"),xl=s(),j(I.$$.fragment),vl=s(),j(o.$$.fragment),Yl=s(),d=t("p"),d.innerHTML=re,Hl=s(),A=t("p"),A.innerHTML=me,Dl=s(),c=t("p"),c.textContent=we,$l=s(),C=t("p"),C.textContent=Ie,Ll=s(),j(u.$$.fragment),ql=s(),b=t("p"),b.innerHTML=oe,Pl=s(),j(k.$$.fragment),Kl=s(),f=t("p"),f.innerHTML=de,Ol=s(),h=t("p"),h.innerHTML=Ae,lM=s(),j(Z.$$.fragment),MM=s(),B=t("p"),B.innerHTML=ce,eM=s(),_=t("p"),_.textContent=Ce,aM=s(),j(V.$$.fragment),sM=s(),E=t("p"),E.textContent=ue,nM=s(),j(Q.$$.fragment),tM=s(),j(G.$$.fragment),iM=s(),j(R.$$.fragment),JM=s(),z=t("p"),z.textContent=be,jM=s(),X=t("p"),X.textContent=ke,yM=s(),F=t("p"),F.textContent=fe,UM=s(),j(W.$$.fragment),TM=s(),S=t("p"),S.textContent=he,pM=s(),N=t("p"),N.innerHTML=Ze,rM=s(),j(g.$$.fragment),mM=s(),x=t("pre"),x.textContent=Be,wM=s(),v=t("p"),v.textContent=_e,IM=s(),Y=t("p"),Y.innerHTML=Ve,oM=s(),H=t("p"),H.innerHTML=Ee,dM=s(),D=t("p"),D.innerHTML=Qe,AM=s(),j($.$$.fragment),cM=s(),L=t("p"),L.innerHTML=Ge,CM=s(),q=t("p"),q.innerHTML=Re,uM=s(),j(P.$$.fragment),bM=s(),j(K.$$.fragment),kM=s(),O=t("p"),O.textContent=ze,fM=s(),ll=t("p"),ll.innerHTML=Xe,hM=s(),Ml=t("p"),Ml.innerHTML=Fe,ZM=s(),el=t("p"),el.innerHTML=We,BM=s(),al=t("p"),al.innerHTML=Se,_M=s(),sl=t("p"),sl.innerHTML=Ne,VM=s(),j(nl.$$.fragment),EM=s(),tl=t("p"),tl.innerHTML=ge,QM=s(),j(il.$$.fragment),GM=s(),Jl=t("p"),Jl.textContent=xe,RM=s(),jl=t("p"),jl.innerHTML=ve,zM=s(),yl=t("p"),yl.innerHTML=Ye,XM=s(),j(Ul.$$.fragment),FM=s(),Tl=t("pre"),Tl.textContent=He,WM=s(),pl=t("p"),pl.textContent=De,SM=s(),j(rl.$$.fragment),NM=s(),ml=t("p"),ml.textContent=$e,gM=s(),wl=t("p"),wl.innerHTML=Le,xM=s(),Il=t("p"),Il.textContent=qe,vM=s(),j(ol.$$.fragment),YM=s(),dl=t("p"),dl.innerHTML=Pe,HM=s(),j(Al.$$.fragment),DM=s(),cl=t("pre"),cl.textContent=Ke,$M=s(),Cl=t("p"),Cl.textContent=Oe,LM=s(),j(ul.$$.fragment),qM=s(),j(bl.$$.fragment),PM=s(),kl=t("p"),kl.textContent=la,KM=s(),j(fl.$$.fragment),OM=s(),hl=t("p"),hl.innerHTML=Ma,le=s(),j(Zl.$$.fragment),Me=s(),Bl=t("p"),Bl.innerHTML=ea,ee=s(),j(_l.$$.fragment),ae=s(),Vl=t("pre"),Vl.textContent=aa,se=s(),El=t("p"),El.innerHTML=sa,ne=s(),Ql=t("p"),Ql.textContent=na,te=s(),j(Gl.$$.fragment),ie=s(),Rl=t("pre"),Rl.textContent=ta,Je=s(),zl=t("p"),zl.innerHTML=ia,je=s(),Xl=t("p"),Xl.innerHTML=Ja,ye=s(),j(Fl.$$.fragment),Ue=s(),Nl=t("p"),this.h()},l(l){const M=wa("svelte-u9bgzb",document.head);w=i(M,"META",{name:!0,content:!0}),M.forEach(e),gl=n(l),Sl=i(l,"P",{}),ja(Sl).forEach(e),xl=n(l),y(I.$$.fragment,l),vl=n(l),y(o.$$.fragment,l),Yl=n(l),d=i(l,"P",{"data-svelte-h":!0}),J(d)!=="svelte-xtcvtg"&&(d.innerHTML=re),Hl=n(l),A=i(l,"P",{"data-svelte-h":!0}),J(A)!=="svelte-c666v1"&&(A.innerHTML=me),Dl=n(l),c=i(l,"P",{"data-svelte-h":!0}),J(c)!=="svelte-1c4nkct"&&(c.textContent=we),$l=n(l),C=i(l,"P",{"data-svelte-h":!0}),J(C)!=="svelte-bu2olq"&&(C.textContent=Ie),Ll=n(l),y(u.$$.fragment,l),ql=n(l),b=i(l,"P",{"data-svelte-h":!0}),J(b)!=="svelte-wmkcup"&&(b.innerHTML=oe),Pl=n(l),y(k.$$.fragment,l),Kl=n(l),f=i(l,"P",{"data-svelte-h":!0}),J(f)!=="svelte-10bvvod"&&(f.innerHTML=de),Ol=n(l),h=i(l,"P",{"data-svelte-h":!0}),J(h)!=="svelte-1d64fq4"&&(h.innerHTML=Ae),lM=n(l),y(Z.$$.fragment,l),MM=n(l),B=i(l,"P",{"data-svelte-h":!0}),J(B)!=="svelte-lzam8z"&&(B.innerHTML=ce),eM=n(l),_=i(l,"P",{"data-svelte-h":!0}),J(_)!=="svelte-90mnae"&&(_.textContent=Ce),aM=n(l),y(V.$$.fragment,l),sM=n(l),E=i(l,"P",{"data-svelte-h":!0}),J(E)!=="svelte-1dw2uzr"&&(E.textContent=ue),nM=n(l),y(Q.$$.fragment,l),tM=n(l),y(G.$$.fragment,l),iM=n(l),y(R.$$.fragment,l),JM=n(l),z=i(l,"P",{"data-svelte-h":!0}),J(z)!=="svelte-bqeipo"&&(z.textContent=be),jM=n(l),X=i(l,"P",{"data-svelte-h":!0}),J(X)!=="svelte-6bssj2"&&(X.textContent=ke),yM=n(l),F=i(l,"P",{"data-svelte-h":!0}),J(F)!=="svelte-5hqyju"&&(F.textContent=fe),UM=n(l),y(W.$$.fragment,l),TM=n(l),S=i(l,"P",{"data-svelte-h":!0}),J(S)!=="svelte-1wflle1"&&(S.textContent=he),pM=n(l),N=i(l,"P",{"data-svelte-h":!0}),J(N)!=="svelte-1gu5ozf"&&(N.innerHTML=Ze),rM=n(l),y(g.$$.fragment,l),mM=n(l),x=i(l,"PRE",{"data-svelte-h":!0}),J(x)!=="svelte-ko6dme"&&(x.textContent=Be),wM=n(l),v=i(l,"P",{"data-svelte-h":!0}),J(v)!=="svelte-2ktwaj"&&(v.textContent=_e),IM=n(l),Y=i(l,"P",{"data-svelte-h":!0}),J(Y)!=="svelte-bntl8j"&&(Y.innerHTML=Ve),oM=n(l),H=i(l,"P",{"data-svelte-h":!0}),J(H)!=="svelte-nu1pyq"&&(H.innerHTML=Ee),dM=n(l),D=i(l,"P",{"data-svelte-h":!0}),J(D)!=="svelte-1p67l8p"&&(D.innerHTML=Qe),AM=n(l),y($.$$.fragment,l),cM=n(l),L=i(l,"P",{"data-svelte-h":!0}),J(L)!=="svelte-1pmhn31"&&(L.innerHTML=Ge),CM=n(l),q=i(l,"P",{"data-svelte-h":!0}),J(q)!=="svelte-79d1n6"&&(q.innerHTML=Re),uM=n(l),y(P.$$.fragment,l),bM=n(l),y(K.$$.fragment,l),kM=n(l),O=i(l,"P",{"data-svelte-h":!0}),J(O)!=="svelte-1iap118"&&(O.textContent=ze),fM=n(l),ll=i(l,"P",{"data-svelte-h":!0}),J(ll)!=="svelte-1nzqeje"&&(ll.innerHTML=Xe),hM=n(l),Ml=i(l,"P",{"data-svelte-h":!0}),J(Ml)!=="svelte-16etuan"&&(Ml.innerHTML=Fe),ZM=n(l),el=i(l,"P",{"data-svelte-h":!0}),J(el)!=="svelte-1890ndh"&&(el.innerHTML=We),BM=n(l),al=i(l,"P",{"data-svelte-h":!0}),J(al)!=="svelte-w5bm1h"&&(al.innerHTML=Se),_M=n(l),sl=i(l,"P",{"data-svelte-h":!0}),J(sl)!=="svelte-fdsvxk"&&(sl.innerHTML=Ne),VM=n(l),y(nl.$$.fragment,l),EM=n(l),tl=i(l,"P",{"data-svelte-h":!0}),J(tl)!=="svelte-1pg2faa"&&(tl.innerHTML=ge),QM=n(l),y(il.$$.fragment,l),GM=n(l),Jl=i(l,"P",{"data-svelte-h":!0}),J(Jl)!=="svelte-17za3dj"&&(Jl.textContent=xe),RM=n(l),jl=i(l,"P",{"data-svelte-h":!0}),J(jl)!=="svelte-17mxxdr"&&(jl.innerHTML=ve),zM=n(l),yl=i(l,"P",{"data-svelte-h":!0}),J(yl)!=="svelte-1uhqn9n"&&(yl.innerHTML=Ye),XM=n(l),y(Ul.$$.fragment,l),FM=n(l),Tl=i(l,"PRE",{"data-svelte-h":!0}),J(Tl)!=="svelte-hpf32x"&&(Tl.textContent=He),WM=n(l),pl=i(l,"P",{"data-svelte-h":!0}),J(pl)!=="svelte-1r693xt"&&(pl.textContent=De),SM=n(l),y(rl.$$.fragment,l),NM=n(l),ml=i(l,"P",{"data-svelte-h":!0}),J(ml)!=="svelte-27zr88"&&(ml.textContent=$e),gM=n(l),wl=i(l,"P",{"data-svelte-h":!0}),J(wl)!=="svelte-j1tw62"&&(wl.innerHTML=Le),xM=n(l),Il=i(l,"P",{"data-svelte-h":!0}),J(Il)!=="svelte-1povqs7"&&(Il.textContent=qe),vM=n(l),y(ol.$$.fragment,l),YM=n(l),dl=i(l,"P",{"data-svelte-h":!0}),J(dl)!=="svelte-rvo9r1"&&(dl.innerHTML=Pe),HM=n(l),y(Al.$$.fragment,l),DM=n(l),cl=i(l,"PRE",{"data-svelte-h":!0}),J(cl)!=="svelte-9xzew6"&&(cl.textContent=Ke),$M=n(l),Cl=i(l,"P",{"data-svelte-h":!0}),J(Cl)!=="svelte-1jbah07"&&(Cl.textContent=Oe),LM=n(l),y(ul.$$.fragment,l),qM=n(l),y(bl.$$.fragment,l),PM=n(l),kl=i(l,"P",{"data-svelte-h":!0}),J(kl)!=="svelte-12ebmjz"&&(kl.textContent=la),KM=n(l),y(fl.$$.fragment,l),OM=n(l),hl=i(l,"P",{"data-svelte-h":!0}),J(hl)!=="svelte-cfk7nk"&&(hl.innerHTML=Ma),le=n(l),y(Zl.$$.fragment,l),Me=n(l),Bl=i(l,"P",{"data-svelte-h":!0}),J(Bl)!=="svelte-1nnfg40"&&(Bl.innerHTML=ea),ee=n(l),y(_l.$$.fragment,l),ae=n(l),Vl=i(l,"PRE",{"data-svelte-h":!0}),J(Vl)!=="svelte-11ixuz2"&&(Vl.textContent=aa),se=n(l),El=i(l,"P",{"data-svelte-h":!0}),J(El)!=="svelte-1eqbfff"&&(El.innerHTML=sa),ne=n(l),Ql=i(l,"P",{"data-svelte-h":!0}),J(Ql)!=="svelte-13908s0"&&(Ql.textContent=na),te=n(l),y(Gl.$$.fragment,l),ie=n(l),Rl=i(l,"PRE",{"data-svelte-h":!0}),J(Rl)!=="svelte-1ud779o"&&(Rl.textContent=ta),Je=n(l),zl=i(l,"P",{"data-svelte-h":!0}),J(zl)!=="svelte-irh7qh"&&(zl.innerHTML=ia),je=n(l),Xl=i(l,"P",{"data-svelte-h":!0}),J(Xl)!=="svelte-5w0ldd"&&(Xl.innerHTML=Ja),ye=n(l),y(Fl.$$.fragment,l),Ue=n(l),Nl=i(l,"P",{}),ja(Nl).forEach(e),this.h()},h(){ya(w,"name","hf:doc:metadata"),ya(w,"content",ca)},m(l,M){Ia(document.head,w),a(l,gl,M),a(l,Sl,M),a(l,xl,M),U(I,l,M),a(l,vl,M),U(o,l,M),a(l,Yl,M),a(l,d,M),a(l,Hl,M),a(l,A,M),a(l,Dl,M),a(l,c,M),a(l,$l,M),a(l,C,M),a(l,Ll,M),U(u,l,M),a(l,ql,M),a(l,b,M),a(l,Pl,M),U(k,l,M),a(l,Kl,M),a(l,f,M),a(l,Ol,M),a(l,h,M),a(l,lM,M),U(Z,l,M),a(l,MM,M),a(l,B,M),a(l,eM,M),a(l,_,M),a(l,aM,M),U(V,l,M),a(l,sM,M),a(l,E,M),a(l,nM,M),U(Q,l,M),a(l,tM,M),U(G,l,M),a(l,iM,M),U(R,l,M),a(l,JM,M),a(l,z,M),a(l,jM,M),a(l,X,M),a(l,yM,M),a(l,F,M),a(l,UM,M),U(W,l,M),a(l,TM,M),a(l,S,M),a(l,pM,M),a(l,N,M),a(l,rM,M),U(g,l,M),a(l,mM,M),a(l,x,M),a(l,wM,M),a(l,v,M),a(l,IM,M),a(l,Y,M),a(l,oM,M),a(l,H,M),a(l,dM,M),a(l,D,M),a(l,AM,M),U($,l,M),a(l,cM,M),a(l,L,M),a(l,CM,M),a(l,q,M),a(l,uM,M),U(P,l,M),a(l,bM,M),U(K,l,M),a(l,kM,M),a(l,O,M),a(l,fM,M),a(l,ll,M),a(l,hM,M),a(l,Ml,M),a(l,ZM,M),a(l,el,M),a(l,BM,M),a(l,al,M),a(l,_M,M),a(l,sl,M),a(l,VM,M),U(nl,l,M),a(l,EM,M),a(l,tl,M),a(l,QM,M),U(il,l,M),a(l,GM,M),a(l,Jl,M),a(l,RM,M),a(l,jl,M),a(l,zM,M),a(l,yl,M),a(l,XM,M),U(Ul,l,M),a(l,FM,M),a(l,Tl,M),a(l,WM,M),a(l,pl,M),a(l,SM,M),U(rl,l,M),a(l,NM,M),a(l,ml,M),a(l,gM,M),a(l,wl,M),a(l,xM,M),a(l,Il,M),a(l,vM,M),U(ol,l,M),a(l,YM,M),a(l,dl,M),a(l,HM,M),U(Al,l,M),a(l,DM,M),a(l,cl,M),a(l,$M,M),a(l,Cl,M),a(l,LM,M),U(ul,l,M),a(l,qM,M),U(bl,l,M),a(l,PM,M),a(l,kl,M),a(l,KM,M),U(fl,l,M),a(l,OM,M),a(l,hl,M),a(l,le,M),U(Zl,l,M),a(l,Me,M),a(l,Bl,M),a(l,ee,M),U(_l,l,M),a(l,ae,M),a(l,Vl,M),a(l,se,M),a(l,El,M),a(l,ne,M),a(l,Ql,M),a(l,te,M),U(Gl,l,M),a(l,ie,M),a(l,Rl,M),a(l,Je,M),a(l,zl,M),a(l,je,M),a(l,Xl,M),a(l,ye,M),U(Fl,l,M),a(l,Ue,M),a(l,Nl,M),Te=!0},p:Ta,i(l){Te||(T(I.$$.fragment,l),T(o.$$.fragment,l),T(u.$$.fragment,l),T(k.$$.fragment,l),T(Z.$$.fragment,l),T(V.$$.fragment,l),T(Q.$$.fragment,l),T(G.$$.fragment,l),T(R.$$.fragment,l),T(W.$$.fragment,l),T(g.$$.fragment,l),T($.$$.fragment,l),T(P.$$.fragment,l),T(K.$$.fragment,l),T(nl.$$.fragment,l),T(il.$$.fragment,l),T(Ul.$$.fragment,l),T(rl.$$.fragment,l),T(ol.$$.fragment,l),T(Al.$$.fragment,l),T(ul.$$.fragment,l),T(bl.$$.fragment,l),T(fl.$$.fragment,l),T(Zl.$$.fragment,l),T(_l.$$.fragment,l),T(Gl.$$.fragment,l),T(Fl.$$.fragment,l),Te=!0)},o(l){p(I.$$.fragment,l),p(o.$$.fragment,l),p(u.$$.fragment,l),p(k.$$.fragment,l),p(Z.$$.fragment,l),p(V.$$.fragment,l),p(Q.$$.fragment,l),p(G.$$.fragment,l),p(R.$$.fragment,l),p(W.$$.fragment,l),p(g.$$.fragment,l),p($.$$.fragment,l),p(P.$$.fragment,l),p(K.$$.fragment,l),p(nl.$$.fragment,l),p(il.$$.fragment,l),p(Ul.$$.fragment,l),p(rl.$$.fragment,l),p(ol.$$.fragment,l),p(Al.$$.fragment,l),p(ul.$$.fragment,l),p(bl.$$.fragment,l),p(fl.$$.fragment,l),p(Zl.$$.fragment,l),p(_l.$$.fragment,l),p(Gl.$$.fragment,l),p(Fl.$$.fragment,l),Te=!1},d(l){l&&(e(gl),e(Sl),e(xl),e(vl),e(Yl),e(d),e(Hl),e(A),e(Dl),e(c),e($l),e(C),e(Ll),e(ql),e(b),e(Pl),e(Kl),e(f),e(Ol),e(h),e(lM),e(MM),e(B),e(eM),e(_),e(aM),e(sM),e(E),e(nM),e(tM),e(iM),e(JM),e(z),e(jM),e(X),e(yM),e(F),e(UM),e(TM),e(S),e(pM),e(N),e(rM),e(mM),e(x),e(wM),e(v),e(IM),e(Y),e(oM),e(H),e(dM),e(D),e(AM),e(cM),e(L),e(CM),e(q),e(uM),e(bM),e(kM),e(O),e(fM),e(ll),e(hM),e(Ml),e(ZM),e(el),e(BM),e(al),e(_M),e(sl),e(VM),e(EM),e(tl),e(QM),e(GM),e(Jl),e(RM),e(jl),e(zM),e(yl),e(XM),e(FM),e(Tl),e(WM),e(pl),e(SM),e(NM),e(ml),e(gM),e(wl),e(xM),e(Il),e(vM),e(YM),e(dl),e(HM),e(DM),e(cl),e($M),e(Cl),e(LM),e(qM),e(PM),e(kl),e(KM),e(OM),e(hl),e(le),e(Me),e(Bl),e(ee),e(ae),e(Vl),e(se),e(El),e(ne),e(Ql),e(te),e(ie),e(Rl),e(Je),e(zl),e(je),e(Xl),e(ye),e(Ue),e(Nl)),e(w),r(I,l),r(o,l),r(u,l),r(k,l),r(Z,l),r(V,l),r(Q,l),r(G,l),r(R,l),r(W,l),r(g,l),r($,l),r(P,l),r(K,l),r(nl,l),r(il,l),r(Ul,l),r(rl,l),r(ol,l),r(Al,l),r(ul,l),r(bl,l),r(fl,l),r(Zl,l),r(_l,l),r(Gl,l),r(Fl,l)}}}const ca='{"title":"Kod Dil Modelini Tek GPU’da Fine-Tune Etmek","local":"kod-dil-modelini-tek-gpuda-fine-tune-etmek","sections":[{"title":"Veri Seti","local":"veri-seti","sections":[],"depth":2},{"title":"Model","local":"model","sections":[],"depth":2},{"title":"Veri setinin hazırlanması","local":"veri-setinin-hazırlanması","sections":[],"depth":2},{"title":"Modelin Hazırlanması","local":"modelin-hazırlanması","sections":[],"depth":2},{"title":"Modelin Eğitilmesi","local":"modelin-eğitilmesi","sections":[],"depth":2},{"title":"Inference","local":"inference","sections":[],"depth":2}],"depth":1}';function Ca(pe){return pa(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class ha extends ra{constructor(w){super(),ma(this,w,Ca,Aa,Ua,{})}}export{ha as component};
