var s;const a=((s=globalThis.__sveltekit_hifjst)==null?void 0:s.base)??"/docs/cookbook/main/tr";var t;const o=((t=globalThis.__sveltekit_hifjst)==null?void 0:t.assets)??a;export{o as a,a as b};
