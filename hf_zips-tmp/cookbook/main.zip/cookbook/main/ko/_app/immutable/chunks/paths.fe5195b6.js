var s;const o=((s=globalThis.__sveltekit_ezw15j)==null?void 0:s.base)??"/docs/cookbook/main/ko";var e;const a=((e=globalThis.__sveltekit_ezw15j)==null?void 0:e.assets)??o;export{a,o as b};
