import{s as mt,n as ut,o as ht}from"../chunks/scheduler.65852ee5.js";import{S as ct,i as pt,g as i,s as o,r as h,A as dt,h as r,f as n,c as s,j as rt,u as c,x as l,k as lt,l as g,y as ft,a,v as p,d,t as f,w as _}from"../chunks/index.65a1b999.js";import{D as _t,C as J}from"../chunks/DocNotebookDropdown.746a44a1.js";import{H as Le,E as gt}from"../chunks/getInferenceSnippets.aa1f4ff5.js";function bt(Pe){let b,ee,Y,te,v,ne,w,ae,k,ze='The purpose of this cookbook is to show you how to properly benchmark TGI. For more background details and explanation, please check out this <a href="https://huggingface.co/blog/tgi-benchmarking" rel="nofollow">popular blog</a> first.',oe,T,se,y,Ge='Make sure you have an environment with TGI installed; docker is a great choice.The commands here can be easily copied/pasted into a terminal, which might be even easier. Don’t feel compelled to use Jupyter. If you just want to test this out, you can duplicate and use <a href="https://huggingface.co/spaces/derek-thomas/tgi-benchmark-space" rel="nofollow">derek-thomas/tgi-benchmark-space</a>.',ie,x,re,E,le,C,je=`text-generation-launcher 2.2.1-dev0
`,me,N,De=`Below we can see the different settings for TGI. Be sure to read through them and decide which settings are most
important for your use-case.`,ue,A,He="Here are some of the most important ones:",he,M,Be="<li><code>--model-id</code></li> <li><code>--quantize</code> Quantization saves memory, but does not always improve speed</li> <li><code>--max-input-tokens</code> This allows TGI to optimize the prefilling operation</li> <li><code>--max-total-tokens</code> In combination with the above TGI now knows what the max input and output tokens are</li> <li><code>--max-batch-size</code> This lets TGI know how many requests it can process at once.</li>",ce,$,Fe="The last 3 together provide the necessary restrictions to optimize for your use-case. You can find a lot of performance improvements by setting these as appropriately as possible.",pe,I,de,S,Qe=`Text Generation Launcher

\x1B[1m\x1B[4mUsage:\x1B[0m \x1B[1mtext-generation-launcher\x1B[0m [OPTIONS]

\x1B[1m\x1B[4mOptions:\x1B[0m
      \x1B[1m--model-id\x1B[0m <model_id>
          The name of the model to load. Can be a MODEL_ID as listed on <https: hf.co="" models=""> like \`gpt2\` or \`OpenAssistant/oasst-sft-1-pythia-12b\`. Or it can be a local directory containing the necessary files as saved by \`save_pretrained(...)\` methods of transformers [env: MODEL_ID=] [default: bigscience/bloom-560m]
      \x1B[1m--revision\x1B[0m <revision>
          The actual revision of the model if you&#39;re referring to a model on the hub. You can use a specific commit id or a branch like \`refs/pr/2\` [env: REVISION=]
      \x1B[1m--validation-workers\x1B[0m <validation_workers>
          The number of tokenizer workers used for payload validation and truncation inside the router [env: VALIDATION_WORKERS=] [default: 2]
      \x1B[1m--sharded\x1B[0m <sharded>
          Whether to shard the model across multiple GPUs By default text-generation-inference will use all available GPUs to run the model. Setting it to \`false\` deactivates \`num_shard\` [env: SHARDED=] [possible values: true, false]
      \x1B[1m--num-shard\x1B[0m <num_shard>
          The number of shards to use if you don&#39;t want to use all GPUs on a given machine. You can use \`CUDA_VISIBLE_DEVICES=0,1 text-generation-launcher... --num_shard 2\` and \`CUDA_VISIBLE_DEVICES=2,3 text-generation-launcher... --num_shard 2\` to launch 2 copies with 2 shard each on a given machine with 4 GPUs for instance [env: NUM_SHARD=]
      \x1B[1m--quantize\x1B[0m <quantize>
          Whether you want the model to be quantized [env: QUANTIZE=] [possible values: awq, eetq, exl2, gptq, marlin, bitsandbytes, bitsandbytes-nf4, bitsandbytes-fp4, fp8]
      \x1B[1m--speculate\x1B[0m <speculate>
          The number of input_ids to speculate on If using a medusa model, the heads will be picked up automatically Other wise, it will use n-gram speculation which is relatively free in terms of compute, but the speedup heavily depends on the task [env: SPECULATE=]
      \x1B[1m--dtype\x1B[0m <dtype>
          The dtype to be forced upon the model. This option cannot be used with \`--quantize\` [env: DTYPE=] [possible values: float16, bfloat16]
      \x1B[1m--trust-remote-code\x1B[0m
          Whether you want to execute hub modelling code. Explicitly passing a \`revision\` is encouraged when loading a model with custom code to ensure no malicious code has been contributed in a newer revision [env: TRUST_REMOTE_CODE=]
      \x1B[1m--max-concurrent-requests\x1B[0m <max_concurrent_requests>
          The maximum amount of concurrent requests for this particular deployment. Having a low limit will refuse clients requests instead of having them wait for too long and is usually good to handle backpressure correctly [env: MAX_CONCURRENT_REQUESTS=] [default: 128]
      \x1B[1m--max-best-of\x1B[0m <max_best_of>
          This is the maximum allowed value for clients to set \`best_of\`. Best of makes \`n\` generations at the same time, and return the best in terms of overall log probability over the entire generated sequence [env: MAX_BEST_OF=] [default: 2]
      \x1B[1m--max-stop-sequences\x1B[0m <max_stop_sequences>
          This is the maximum allowed value for clients to set \`stop_sequences\`. Stop sequences are used to allow the model to stop on more than just the EOS token, and enable more complex &quot;prompting&quot; where users can preprompt the model in a specific way and define their &quot;own&quot; stop token aligned with their prompt [env: MAX_STOP_SEQUENCES=] [default: 4]
      \x1B[1m--max-top-n-tokens\x1B[0m <max_top_n_tokens>
          This is the maximum allowed value for clients to set \`top_n_tokens\`. \`top_n_tokens\` is used to return information about the the \`n\` most likely tokens at each generation step, instead of just the sampled token. This information can be used for downstream tasks like for classification or ranking [env: MAX_TOP_N_TOKENS=] [default: 5]
      \x1B[1m--max-input-tokens\x1B[0m <max_input_tokens>
          This is the maximum allowed input length (expressed in number of tokens) for users. The larger this value, the longer prompt users can send which can impact the overall memory required to handle the load. Please note that some models have a finite range of sequence they can handle. Default to min(max_position_embeddings - 1, 4095) [env: MAX_INPUT_TOKENS=]
      \x1B[1m--max-input-length\x1B[0m <max_input_length>
          Legacy version of [\`Args::max_input_tokens\`] [env: MAX_INPUT_LENGTH=]
      \x1B[1m--max-total-tokens\x1B[0m <max_total_tokens>
          This is the most important value to set as it defines the &quot;memory budget&quot; of running clients requests. Clients will send input sequences and ask to generate \`max_new_tokens\` on top. with a value of \`1512\` users can send either a prompt of \`1000\` and ask for \`512\` new tokens, or send a prompt of \`1\` and ask for \`1511\` max_new_tokens. The larger this value, the larger amount each request will be in your RAM and the less effective batching can be. Default to min(max_position_embeddings, 4096) [env: MAX_TOTAL_TOKENS=]
      \x1B[1m--waiting-served-ratio\x1B[0m <waiting_served_ratio>
          This represents the ratio of waiting queries vs running queries where you want to start considering pausing the running queries to include the waiting ones into the same batch. \`waiting_served_ratio=1.2\` Means when 12 queries are waiting and there&#39;s only 10 queries left in the current batch we check if we can fit those 12 waiting queries into the batching strategy, and if yes, then batching happens delaying the 10 running queries by a \`prefill\` run [env: WAITING_SERVED_RATIO=] [default: 0.3]
      \x1B[1m--max-batch-prefill-tokens\x1B[0m <max_batch_prefill_tokens>
          Limits the number of tokens for the prefill operation. Since this operation take the most memory and is compute bound, it is interesting to limit the number of requests that can be sent. Default to \`max_input_tokens + 50\` to give a bit of room [env: MAX_BATCH_PREFILL_TOKENS=]
      \x1B[1m--max-batch-total-tokens\x1B[0m <max_batch_total_tokens>
          **IMPORTANT** This is one critical control to allow maximum usage of the available hardware [env: MAX_BATCH_TOTAL_TOKENS=]
      \x1B[1m--max-waiting-tokens\x1B[0m <max_waiting_tokens>
          This setting defines how many tokens can be passed before forcing the waiting queries to be put on the batch (if the size of the batch allows for it). New queries require 1 \`prefill\` forward, which is different from \`decode\` and therefore you need to pause the running batch in order to run \`prefill\` to create the correct values for the waiting queries to be able to join the batch [env: MAX_WAITING_TOKENS=] [default: 20]
      \x1B[1m--max-batch-size\x1B[0m <max_batch_size>
          Enforce a maximum number of requests per batch Specific flag for hardware targets that do not support unpadded inference [env: MAX_BATCH_SIZE=]
      \x1B[1m--cuda-graphs\x1B[0m <cuda_graphs>
          Specify the batch sizes to compute cuda graphs for. Use &quot;0&quot; to disable. Default = &quot;1,2,4,8,16,32&quot; [env: CUDA_GRAPHS=]
      \x1B[1m--hostname\x1B[0m <hostname>
          The IP address to listen on [env: HOSTNAME=r-derek-thomas-tgi-benchmark-space-geij6846-b385a-lont4] [default: 0.0.0.0]
  \x1B[1m-p\x1B[0m, \x1B[1m--port\x1B[0m <port>
          The port to listen on [env: PORT=80] [default: 3000]
      \x1B[1m--shard-uds-path\x1B[0m <shard_uds_path>
          The name of the socket for gRPC communication between the webserver and the shards [env: SHARD_UDS_PATH=] [default: /tmp/text-generation-server]
      \x1B[1m--master-addr\x1B[0m <master_addr>
          The address the master shard will listen on. (setting used by torch distributed) [env: MASTER_ADDR=] [default: localhost]
      \x1B[1m--master-port\x1B[0m <master_port>
          The address the master port will listen on. (setting used by torch distributed) [env: MASTER_PORT=] [default: 29500]
      \x1B[1m--huggingface-hub-cache\x1B[0m <huggingface_hub_cache>
          The location of the huggingface hub cache. Used to override the location if you want to provide a mounted disk for instance [env: HUGGINGFACE_HUB_CACHE=]
      \x1B[1m--weights-cache-override\x1B[0m <weights_cache_override>
          The location of the huggingface hub cache. Used to override the location if you want to provide a mounted disk for instance [env: WEIGHTS_CACHE_OVERRIDE=]
      \x1B[1m--disable-custom-kernels\x1B[0m
          For some models (like bloom), text-generation-inference implemented custom cuda kernels to speed up inference. Those kernels were only tested on A100. Use this flag to disable them if you&#39;re running on different hardware and encounter issues [env: DISABLE_CUSTOM_KERNELS=]
      \x1B[1m--cuda-memory-fraction\x1B[0m <cuda_memory_fraction>
          Limit the CUDA available memory. The allowed value equals the total visible memory multiplied by cuda-memory-fraction [env: CUDA_MEMORY_FRACTION=] [default: 1.0]
      \x1B[1m--rope-scaling\x1B[0m <rope_scaling>
          Rope scaling will only be used for RoPE models and allow rescaling the position rotary to accomodate for larger prompts [env: ROPE_SCALING=] [possible values: linear, dynamic]
      \x1B[1m--rope-factor\x1B[0m <rope_factor>
          Rope scaling will only be used for RoPE models See \`rope_scaling\` [env: ROPE_FACTOR=]
      \x1B[1m--json-output\x1B[0m
          Outputs the logs in JSON format (useful for telemetry) [env: JSON_OUTPUT=]
      \x1B[1m--otlp-endpoint\x1B[0m <otlp_endpoint>
          [env: OTLP_ENDPOINT=]
      \x1B[1m--otlp-service-name\x1B[0m <otlp_service_name>
          [env: OTLP_SERVICE_NAME=] [default: text-generation-inference.router]
      \x1B[1m--cors-allow-origin\x1B[0m <cors_allow_origin>
          [env: CORS_ALLOW_ORIGIN=]
      \x1B[1m--api-key\x1B[0m <api_key>
          [env: API_KEY=]
      \x1B[1m--watermark-gamma\x1B[0m <watermark_gamma>
          [env: WATERMARK_GAMMA=]
      \x1B[1m--watermark-delta\x1B[0m <watermark_delta>
          [env: WATERMARK_DELTA=]
      \x1B[1m--ngrok\x1B[0m
          Enable ngrok tunneling [env: NGROK=]
      \x1B[1m--ngrok-authtoken\x1B[0m <ngrok_authtoken>
          ngrok authentication token [env: NGROK_AUTHTOKEN=]
      \x1B[1m--ngrok-edge\x1B[0m <ngrok_edge>
          ngrok edge [env: NGROK_EDGE=]
      \x1B[1m--tokenizer-config-path\x1B[0m <tokenizer_config_path>
          The path to the tokenizer config file. This path is used to load the tokenizer configuration which may include a \`chat_template\`. If not provided, the default config will be used from the model hub [env: TOKENIZER_CONFIG_PATH=]
      \x1B[1m--disable-grammar-support\x1B[0m
          Disable outlines grammar constrained generation. This is a feature that allows you to generate text that follows a specific grammar [env: DISABLE_GRAMMAR_SUPPORT=]
  \x1B[1m-e\x1B[0m, \x1B[1m--env\x1B[0m
          Display a lot of information about your runtime environment
      \x1B[1m--max-client-batch-size\x1B[0m <max_client_batch_size>
          Control the maximum number of inputs that a client can send in a single request [env: MAX_CLIENT_BATCH_SIZE=] [default: 4]
      \x1B[1m--lora-adapters\x1B[0m <lora_adapters>
          Lora Adapters a list of adapter ids i.e. \`repo/adapter1,repo/adapter2\` to load during startup that will be available to callers via the \`adapter_id\` field in a request [env: LORA_ADAPTERS=]
      \x1B[1m--usage-stats\x1B[0m <usage_stats>
          Control if anonymous usage stats are collected. Options are &quot;on&quot;, &quot;off&quot; and &quot;no-stack&quot; Defaul is on [env: USAGE_STATS=] [default: on] [possible values: on, off, no-stack]
  \x1B[1m-h\x1B[0m, \x1B[1m--help\x1B[0m
          Print help (see more with &#39;--help&#39;)
  \x1B[1m-V\x1B[0m, \x1B[1m--version\x1B[0m
          Print version
</usage_stats></lora_adapters></max_client_batch_size></tokenizer_config_path></ngrok_edge></ngrok_authtoken></watermark_delta></watermark_gamma></api_key></cors_allow_origin></otlp_service_name></otlp_endpoint></rope_factor></rope_scaling></cuda_memory_fraction></weights_cache_override></huggingface_hub_cache></master_port></master_addr></shard_uds_path></port></hostname></cuda_graphs></max_batch_size></max_waiting_tokens></max_batch_total_tokens></max_batch_prefill_tokens></waiting_served_ratio></max_total_tokens></max_input_length></max_input_tokens></max_top_n_tokens></max_stop_sequences></max_best_of></max_concurrent_requests></dtype></speculate></quantize></num_shard></sharded></validation_workers></revision></https:></model_id>`,fe,U,We="We can launch directly from the cookbook since we dont need the command to be interactive.",_e,R,Ze="We will just be using defaults in this cookbook as the intent is to understand the benchmark tool.",ge,O,Xe="These parameters were changed if you’re running on a Space because we don’t want to conflict with the Spaces server:",be,q,Ve="<li><code>--hostname</code></li> <li><code>--port</code></li>",ve,L,Je="Feel free to change or remove them based on your requirements.",we,P,ke,z,Ye=`\x1B[2m2024-08-16T12:07:56.411768Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Args &#123;
    model_id: "astronomer/Llama-3-8B-Instruct-GPTQ-8-Bit",
    revision: None,
    validation_workers: 2,
    sharded: None,
    num_shard: None,
    quantize: Some(
        Gptq,
    ),
    speculate: None,
    dtype: None,
    trust_remote_code: false,
    max_concurrent_requests: 128,
    max_best_of: 2,
    max_stop_sequences: 4,
    max_top_n_tokens: 5,
    max_input_tokens: None,
    max_input_length: None,
    max_total_tokens: None,
    waiting_served_ratio: 0.3,
    max_batch_prefill_tokens: None,
    max_batch_total_tokens: None,
    max_waiting_tokens: 20,
    max_batch_size: None,
    cuda_graphs: None,
    hostname: "0.0.0.0",
    port: 1337,
    shard_uds_path: "/tmp/text-generation-server",
    master_addr: "localhost",
    master_port: 29500,
    huggingface_hub_cache: None,
    weights_cache_override: None,
    disable_custom_kernels: false,
    cuda_memory_fraction: 1.0,
    rope_scaling: None,
    rope_factor: None,
    json_output: false,
    otlp_endpoint: None,
    otlp_service_name: "text-generation-inference.router",
    cors_allow_origin: [],
    api_key: None,
    watermark_gamma: None,
    watermark_delta: None,
    ngrok: false,
    ngrok_authtoken: None,
    ngrok_edge: None,
    tokenizer_config_path: None,
    disable_grammar_support: false,
    env: false,
    max_client_batch_size: 4,
    lora_adapters: None,
    usage_stats: On,
}
\x1B[2m2024-08-16T12:07:56.411941Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mhf_hub\x1B[0m\x1B[2m:\x1B[0m Token file not found "/data/token"    
\x1B[2Kconfig.json [00:00:00] [████████████████████████] 1021 B/1021 B 50.70 KiB/s (0s)\x1B[2m2024-08-16T12:07:56.458451Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Model supports up to 8192 but tgi will now set its default to 4096 instead. This is to save VRAM by refusing large prompts in order to allow more users on the same hardware. You can increase that size using \`--max-batch-prefill-tokens=8242 --max-total-tokens=8192 --max-input-tokens=8191\`.
\x1B[2m2024-08-16T12:07:56.458473Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Default \`max_input_tokens\` to 4095
\x1B[2m2024-08-16T12:07:56.458480Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Default \`max_total_tokens\` to 4096
\x1B[2m2024-08-16T12:07:56.458487Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Default \`max_batch_prefill_tokens\` to 4145
\x1B[2m2024-08-16T12:07:56.458494Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Using default cuda graphs [1, 2, 4, 8, 16, 32]
\x1B[2m2024-08-16T12:07:56.458606Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[1mdownload\x1B[0m: \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Starting check and download process for astronomer/Llama-3-8B-Instruct-GPTQ-8-Bit
\x1B[2m2024-08-16T12:07:59.750101Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Download file: model.safetensors
^C
\x1B[2m2024-08-16T12:08:09.101893Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[1mdownload\x1B[0m: \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Terminating download
\x1B[2m2024-08-16T12:08:09.102368Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[1mdownload\x1B[0m: \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Waiting for download to gracefully shutdown
`,Te,G,ye,j,Ke="Now lets learn how to launch the benchmark tool!",xe,D,et="Here we can see the different settings for TGI Benchmark.",Ee,H,tt="Here are some of the more important TGI Benchmark settings:",Ce,B,nt="<li><code>--tokenizer-name</code> This is required so the tool knows what tokenizer to use</li> <li><code>--batch-size</code> This is important for load testing. We should use enough values to see what happens to throughput and latency. Do note that batch-size in the context of the benchmarking tool is number of virtual users.</li> <li><code>--sequence-length</code> AKA input tokens, it is important to match your use-case needs</li> <li><code>--decode-length</code> AKA output tokens, it is important to match your use-case needs</li> <li><code>--runs</code> 10 is the default</li>",Ne,m,at='<strong>💡 Tip:</strong> Use a low number for <code style="background: #37474F; color: #FFFFFF; padding: 2px 4px; border-radius: 4px;">--runs</code> when you are exploring but a higher number as you finalize to get more precise statistics',Ae,F,Me,Q,ot=`Text Generation Benchmarking tool

\x1B[1m\x1B[4mUsage:\x1B[0m \x1B[1mtext-generation-benchmark\x1B[0m [OPTIONS] \x1B[1m--tokenizer-name\x1B[0m <tokenizer_name>

\x1B[1m\x1B[4mOptions:\x1B[0m
  \x1B[1m-t\x1B[0m, \x1B[1m--tokenizer-name\x1B[0m <tokenizer_name>
          The name of the tokenizer (as in model_id on the huggingface hub, or local path) [env: TOKENIZER_NAME=]
      \x1B[1m--revision\x1B[0m <revision>
          The revision to use for the tokenizer if on the hub [env: REVISION=] [default: main]
  \x1B[1m-b\x1B[0m, \x1B[1m--batch-size\x1B[0m <batch_size>
          The various batch sizes to benchmark for, the idea is to get enough batching to start seeing increased latency, this usually means you&#39;re moving from memory bound (usual as BS=1) to compute bound, and this is a sweet spot for the maximum batch size for the model under test
  \x1B[1m-s\x1B[0m, \x1B[1m--sequence-length\x1B[0m <sequence_length>
          This is the initial prompt sent to the text-generation-server length in token. Longer prompt will slow down the benchmark. Usually the latency grows somewhat linearly with this for the prefill step [env: SEQUENCE_LENGTH=] [default: 10]
  \x1B[1m-d\x1B[0m, \x1B[1m--decode-length\x1B[0m <decode_length>
          This is how many tokens will be generated by the server and averaged out to give the \`decode\` latency. This is the *critical* number you want to optimize for LLM spend most of their time doing decoding [env: DECODE_LENGTH=] [default: 8]
  \x1B[1m-r\x1B[0m, \x1B[1m--runs\x1B[0m <runs>
          How many runs should we average from [env: RUNS=] [default: 10]
  \x1B[1m-w\x1B[0m, \x1B[1m--warmups\x1B[0m <warmups>
          Number of warmup cycles [env: WARMUPS=] [default: 1]
  \x1B[1m-m\x1B[0m, \x1B[1m--master-shard-uds-path\x1B[0m <master_shard_uds_path>
          The location of the grpc socket. This benchmark tool bypasses the router completely and directly talks to the gRPC processes [env: MASTER_SHARD_UDS_PATH=] [default: /tmp/text-generation-server-0]
      \x1B[1m--temperature\x1B[0m <temperature>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TEMPERATURE=]
      \x1B[1m--top-k\x1B[0m <top_k>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TOP_K=]
      \x1B[1m--top-p\x1B[0m <top_p>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TOP_P=]
      \x1B[1m--typical-p\x1B[0m <typical_p>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TYPICAL_P=]
      \x1B[1m--repetition-penalty\x1B[0m <repetition_penalty>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: REPETITION_PENALTY=]
      \x1B[1m--frequency-penalty\x1B[0m <frequency_penalty>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: FREQUENCY_PENALTY=]
      \x1B[1m--watermark\x1B[0m
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: WATERMARK=]
      \x1B[1m--do-sample\x1B[0m
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: DO_SAMPLE=]
      \x1B[1m--top-n-tokens\x1B[0m <top_n_tokens>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TOP_N_TOKENS=]
  \x1B[1m-h\x1B[0m, \x1B[1m--help\x1B[0m
          Print help (see more with &#39;--help&#39;)
  \x1B[1m-V\x1B[0m, \x1B[1m--version\x1B[0m
          Print version
</top_n_tokens></frequency_penalty></repetition_penalty></typical_p></top_p></top_k></temperature></master_shard_uds_path></warmups></runs></decode_length></sequence_length></batch_size></revision></tokenizer_name></tokenizer_name>`,$e,W,st=`Here is an example command. Notice that I add the batch sizes of interest repeatedly to make sure all of them are used
by the benchmark tool. I’m also considering which batch sizes are important based on estimated user activity.`,Ie,u,it="<strong>⚠️ Warning:</strong> Please note that the TGI Benchmark tool is designed to work in a terminal, not a jupyter notebook. This means you will need to copy/paste the command in a jupyter terminal tab. I am putting it here for convenience.",Se,Z,Ue,X,Re,V,Oe,K,qe;return v=new _t({props:{classNames:"absolute z-10 right-0 top-0",options:[{label:"Google Colab",value:"https://colab.research.google.com/github/huggingface/cookbook/blob/main/notebooks/en/benchmarking_tgi.ipynb"}]}}),w=new Le({props:{title:"Introduction",local:"introduction",headingTag:"h1"}}),T=new Le({props:{title:"Setup",local:"setup",headingTag:"h2"}}),x=new Le({props:{title:"TGI Launcher",local:"tgi-launcher",headingTag:"h1"}}),E=new J({props:{code:"IXRleHQtZ2VuZXJhdGlvbi1sYXVuY2hlciUyMC0tdmVyc2lvbg==",highlighted:'<span class="hljs-meta">&gt;&gt;&gt; </span>!text-generation-launcher --version',wrap:!1}}),I=new J({props:{code:"IXRleHQtZ2VuZXJhdGlvbi1sYXVuY2hlciUyMC1o",highlighted:'<span class="hljs-meta">&gt;&gt;&gt; </span>!text-generation-launcher -h',wrap:!1}}),P=new J({props:{code:"IVJVU1RfQkFDS1RSQUNFJTNEMSUyMCU1QyUwQXRleHQtZ2VuZXJhdGlvbi1sYXVuY2hlciUyMCU1QyUwQS0tbW9kZWwtaWQlMjBhc3Ryb25vbWVyJTJGTGxhbWEtMy04Qi1JbnN0cnVjdC1HUFRRLTgtQml0JTIwJTVDJTBBLS1xdWFudGl6ZSUyMGdwdHElMjAlNUMlMEEtLWhvc3RuYW1lJTIwMC4wLjAuMCUyMCU1QyUwQS0tcG9ydCUyMDEzMzc=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>!RUST_BACKTRACE=<span class="hljs-number">1</span> \\
<span class="hljs-meta">&gt;&gt;&gt; </span>text-generation-launcher \\
<span class="hljs-meta">&gt;&gt;&gt; </span>--model-<span class="hljs-built_in">id</span> astronomer/Llama-<span class="hljs-number">3</span>-8B-Instruct-GPTQ-<span class="hljs-number">8</span>-Bit \\
<span class="hljs-meta">&gt;&gt;&gt; </span>--quantize gptq \\
<span class="hljs-meta">&gt;&gt;&gt; </span>--hostname <span class="hljs-number">0.0</span><span class="hljs-number">.0</span><span class="hljs-number">.0</span> \\
<span class="hljs-meta">&gt;&gt;&gt; </span>--port <span class="hljs-number">1337</span>`,wrap:!1}}),G=new Le({props:{title:"TGI Benchmark",local:"tgi-benchmark",headingTag:"h1"}}),F=new J({props:{code:"IXRleHQtZ2VuZXJhdGlvbi1iZW5jaG1hcmslMjAtaA==",highlighted:'<span class="hljs-meta">&gt;&gt;&gt; </span>!text-generation-benchmark -h',wrap:!1}}),Z=new J({props:{code:"IXRleHQtZ2VuZXJhdGlvbi1iZW5jaG1hcmslMjAlNUMlMEEtLXRva2VuaXplci1uYW1lJTIwYXN0cm9ub21lciUyRkxsYW1hLTMtOEItSW5zdHJ1Y3QtR1BUUS04LUJpdCUyMCU1QyUwQS0tc2VxdWVuY2UtbGVuZ3RoJTIwNzAlMjAlNUMlMEEtLWRlY29kZS1sZW5ndGglMjA1MCUyMCU1QyUwQS0tYmF0Y2gtc2l6ZSUyMDElMjAlNUMlMEEtLWJhdGNoLXNpemUlMjAyJTIwJTVDJTBBLS1iYXRjaC1zaXplJTIwNCUyMCU1QyUwQS0tYmF0Y2gtc2l6ZSUyMDglMjAlNUMlMEEtLWJhdGNoLXNpemUlMjAxNiUyMCU1QyUwQS0tYmF0Y2gtc2l6ZSUyMDMyJTIwJTVDJTBBLS1iYXRjaC1zaXplJTIwNjQlMjAlNUMlMEEtLWJhdGNoLXNpemUlMjAxMjg=",highlighted:`!text-generation-benchmark \\
--tokenizer-name astronomer/Llama-<span class="hljs-number">3</span>-8B-Instruct-GPTQ-<span class="hljs-number">8</span>-Bit \\
--sequence-length <span class="hljs-number">70</span> \\
--decode-length <span class="hljs-number">50</span> \\
--batch-size <span class="hljs-number">1</span> \\
--batch-size <span class="hljs-number">2</span> \\
--batch-size <span class="hljs-number">4</span> \\
--batch-size <span class="hljs-number">8</span> \\
--batch-size <span class="hljs-number">16</span> \\
--batch-size <span class="hljs-number">32</span> \\
--batch-size <span class="hljs-number">64</span> \\
--batch-size <span class="hljs-number">128</span>`,wrap:!1}}),X=new J({props:{code:"",highlighted:"",wrap:!1}}),V=new gt({props:{source:"https://github.com/huggingface/cookbook/blob/main/notebooks/en/benchmarking_tgi.md"}}),{c(){b=i("meta"),ee=o(),Y=i("p"),te=o(),h(v.$$.fragment),ne=o(),h(w.$$.fragment),ae=o(),k=i("p"),k.innerHTML=ze,oe=o(),h(T.$$.fragment),se=o(),y=i("p"),y.innerHTML=Ge,ie=o(),h(x.$$.fragment),re=o(),h(E.$$.fragment),le=o(),C=i("pre"),C.textContent=je,me=o(),N=i("p"),N.textContent=De,ue=o(),A=i("p"),A.textContent=He,he=o(),M=i("ul"),M.innerHTML=Be,ce=o(),$=i("p"),$.textContent=Fe,pe=o(),h(I.$$.fragment),de=o(),S=i("pre"),S.innerHTML=Qe,fe=o(),U=i("p"),U.textContent=We,_e=o(),R=i("p"),R.textContent=Ze,ge=o(),O=i("p"),O.textContent=Xe,be=o(),q=i("ul"),q.innerHTML=Ve,ve=o(),L=i("p"),L.textContent=Je,we=o(),h(P.$$.fragment),ke=o(),z=i("pre"),z.textContent=Ye,Te=o(),h(G.$$.fragment),ye=o(),j=i("p"),j.textContent=Ke,xe=o(),D=i("p"),D.textContent=et,Ee=o(),H=i("p"),H.textContent=tt,Ce=o(),B=i("ul"),B.innerHTML=nt,Ne=o(),m=i("blockquote"),m.innerHTML=at,Ae=o(),h(F.$$.fragment),Me=o(),Q=i("pre"),Q.innerHTML=ot,$e=o(),W=i("p"),W.textContent=st,Ie=o(),u=i("blockquote"),u.innerHTML=it,Se=o(),h(Z.$$.fragment),Ue=o(),h(X.$$.fragment),Re=o(),h(V.$$.fragment),Oe=o(),K=i("p"),this.h()},l(e){const t=dt("svelte-u9bgzb",document.head);b=r(t,"META",{name:!0,content:!0}),t.forEach(n),ee=s(e),Y=r(e,"P",{}),rt(Y).forEach(n),te=s(e),c(v.$$.fragment,e),ne=s(e),c(w.$$.fragment,e),ae=s(e),k=r(e,"P",{"data-svelte-h":!0}),l(k)!=="svelte-nucsba"&&(k.innerHTML=ze),oe=s(e),c(T.$$.fragment,e),se=s(e),y=r(e,"P",{"data-svelte-h":!0}),l(y)!=="svelte-nftsjc"&&(y.innerHTML=Ge),ie=s(e),c(x.$$.fragment,e),re=s(e),c(E.$$.fragment,e),le=s(e),C=r(e,"PRE",{"data-svelte-h":!0}),l(C)!=="svelte-5uago"&&(C.textContent=je),me=s(e),N=r(e,"P",{"data-svelte-h":!0}),l(N)!=="svelte-jmdefs"&&(N.textContent=De),ue=s(e),A=r(e,"P",{"data-svelte-h":!0}),l(A)!=="svelte-1cwpzmi"&&(A.textContent=He),he=s(e),M=r(e,"UL",{"data-svelte-h":!0}),l(M)!=="svelte-7i4ofj"&&(M.innerHTML=Be),ce=s(e),$=r(e,"P",{"data-svelte-h":!0}),l($)!=="svelte-8xql59"&&($.textContent=Fe),pe=s(e),c(I.$$.fragment,e),de=s(e),S=r(e,"PRE",{"data-svelte-h":!0}),l(S)!=="svelte-1sc2cl"&&(S.innerHTML=Qe),fe=s(e),U=r(e,"P",{"data-svelte-h":!0}),l(U)!=="svelte-1mkybh2"&&(U.textContent=We),_e=s(e),R=r(e,"P",{"data-svelte-h":!0}),l(R)!=="svelte-3z4i6r"&&(R.textContent=Ze),ge=s(e),O=r(e,"P",{"data-svelte-h":!0}),l(O)!=="svelte-1eo01oh"&&(O.textContent=Xe),be=s(e),q=r(e,"UL",{"data-svelte-h":!0}),l(q)!=="svelte-1ko3p04"&&(q.innerHTML=Ve),ve=s(e),L=r(e,"P",{"data-svelte-h":!0}),l(L)!=="svelte-pyza93"&&(L.textContent=Je),we=s(e),c(P.$$.fragment,e),ke=s(e),z=r(e,"PRE",{"data-svelte-h":!0}),l(z)!=="svelte-50c5je"&&(z.textContent=Ye),Te=s(e),c(G.$$.fragment,e),ye=s(e),j=r(e,"P",{"data-svelte-h":!0}),l(j)!=="svelte-wheavt"&&(j.textContent=Ke),xe=s(e),D=r(e,"P",{"data-svelte-h":!0}),l(D)!=="svelte-1s51ipk"&&(D.textContent=et),Ee=s(e),H=r(e,"P",{"data-svelte-h":!0}),l(H)!=="svelte-1k0og9v"&&(H.textContent=tt),Ce=s(e),B=r(e,"UL",{"data-svelte-h":!0}),l(B)!=="svelte-2ravvu"&&(B.innerHTML=nt),Ne=s(e),m=r(e,"BLOCKQUOTE",{style:!0,"data-svelte-h":!0}),l(m)!=="svelte-d9qhv8"&&(m.innerHTML=at),Ae=s(e),c(F.$$.fragment,e),Me=s(e),Q=r(e,"PRE",{"data-svelte-h":!0}),l(Q)!=="svelte-1nepnpv"&&(Q.innerHTML=ot),$e=s(e),W=r(e,"P",{"data-svelte-h":!0}),l(W)!=="svelte-1i0gw82"&&(W.textContent=st),Ie=s(e),u=r(e,"BLOCKQUOTE",{style:!0,"data-svelte-h":!0}),l(u)!=="svelte-1pfuh6s"&&(u.innerHTML=it),Se=s(e),c(Z.$$.fragment,e),Ue=s(e),c(X.$$.fragment,e),Re=s(e),c(V.$$.fragment,e),Oe=s(e),K=r(e,"P",{}),rt(K).forEach(n),this.h()},h(){lt(b,"name","hf:doc:metadata"),lt(b,"content",vt),g(m,"border-left","5px solid #80CBC4"),g(m,"background","#263238"),g(m,"color","#CFD8DC"),g(m,"padding","0.5em 1em"),g(m,"margin","1em 0"),g(u,"border-left","5px solid #FFAB91"),g(u,"background","#37474F"),g(u,"color","#FFCCBC"),g(u,"padding","0.5em 1em"),g(u,"margin","1em 0")},m(e,t){ft(document.head,b),a(e,ee,t),a(e,Y,t),a(e,te,t),p(v,e,t),a(e,ne,t),p(w,e,t),a(e,ae,t),a(e,k,t),a(e,oe,t),p(T,e,t),a(e,se,t),a(e,y,t),a(e,ie,t),p(x,e,t),a(e,re,t),p(E,e,t),a(e,le,t),a(e,C,t),a(e,me,t),a(e,N,t),a(e,ue,t),a(e,A,t),a(e,he,t),a(e,M,t),a(e,ce,t),a(e,$,t),a(e,pe,t),p(I,e,t),a(e,de,t),a(e,S,t),a(e,fe,t),a(e,U,t),a(e,_e,t),a(e,R,t),a(e,ge,t),a(e,O,t),a(e,be,t),a(e,q,t),a(e,ve,t),a(e,L,t),a(e,we,t),p(P,e,t),a(e,ke,t),a(e,z,t),a(e,Te,t),p(G,e,t),a(e,ye,t),a(e,j,t),a(e,xe,t),a(e,D,t),a(e,Ee,t),a(e,H,t),a(e,Ce,t),a(e,B,t),a(e,Ne,t),a(e,m,t),a(e,Ae,t),p(F,e,t),a(e,Me,t),a(e,Q,t),a(e,$e,t),a(e,W,t),a(e,Ie,t),a(e,u,t),a(e,Se,t),p(Z,e,t),a(e,Ue,t),p(X,e,t),a(e,Re,t),p(V,e,t),a(e,Oe,t),a(e,K,t),qe=!0},p:ut,i(e){qe||(d(v.$$.fragment,e),d(w.$$.fragment,e),d(T.$$.fragment,e),d(x.$$.fragment,e),d(E.$$.fragment,e),d(I.$$.fragment,e),d(P.$$.fragment,e),d(G.$$.fragment,e),d(F.$$.fragment,e),d(Z.$$.fragment,e),d(X.$$.fragment,e),d(V.$$.fragment,e),qe=!0)},o(e){f(v.$$.fragment,e),f(w.$$.fragment,e),f(T.$$.fragment,e),f(x.$$.fragment,e),f(E.$$.fragment,e),f(I.$$.fragment,e),f(P.$$.fragment,e),f(G.$$.fragment,e),f(F.$$.fragment,e),f(Z.$$.fragment,e),f(X.$$.fragment,e),f(V.$$.fragment,e),qe=!1},d(e){e&&(n(ee),n(Y),n(te),n(ne),n(ae),n(k),n(oe),n(se),n(y),n(ie),n(re),n(le),n(C),n(me),n(N),n(ue),n(A),n(he),n(M),n(ce),n($),n(pe),n(de),n(S),n(fe),n(U),n(_e),n(R),n(ge),n(O),n(be),n(q),n(ve),n(L),n(we),n(ke),n(z),n(Te),n(ye),n(j),n(xe),n(D),n(Ee),n(H),n(Ce),n(B),n(Ne),n(m),n(Ae),n(Me),n(Q),n($e),n(W),n(Ie),n(u),n(Se),n(Ue),n(Re),n(Oe),n(K)),n(b),_(v,e),_(w,e),_(T,e),_(x,e),_(E,e),_(I,e),_(P,e),_(G,e),_(F,e),_(Z,e),_(X,e),_(V,e)}}}const vt='{"title":"Introduction","local":"introduction","sections":[{"title":"Setup","local":"setup","sections":[],"depth":2}],"depth":1}';function wt(Pe){return ht(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Et extends ct{constructor(b){super(),pt(this,b,wt,bt,mt,{})}}export{Et as component};
