import{s as us,n as cs,o as rs}from"../chunks/scheduler.65852ee5.js";import{S as ms,i as ws,g as p,s as n,r as M,A as ys,h as i,f as s,c as a,j as os,u,x as o,k as Ms,y as Ts,a as l,v as c,d as r,t as m,w}from"../chunks/index.aa74147d.js";import{D as Js,C as y}from"../chunks/DocNotebookDropdown.1a7e6a42.js";import{H as Ct,E as hs}from"../chunks/getInferenceSnippets.796600e5.js";function js(gt){let T,Ue,je,be,J,fe,h,Ie,j,Zt='<em>作者: <a href="https://huggingface.co/m-ric" rel="nofollow">Aymeric Roucher</a></em>',Be,d,_t="<strong>结构化生成是一种方法</strong>，它强制 LLN 的输出遵循某些约束，例如遵循特定的模式。",Ce,U,$t="这有许多用例：",ge,b,Gt="<li>✅ 输出一个具有特定键的字典</li> <li>📏 确保输出长度超过 N 个字符</li> <li>⚙️ 更一般地说，强制输出遵循特定的正则表达式模式以进行下游处理。</li> <li>💡 在检索增强生成（RAG）中突出显示支持答案的源</li>",Ze,f,Vt="在这个 notebook 中，我们特别演示了最后一个用例：",_e,I,vt="<strong>➡️ 我们构建了一个 RAG 系统，它不仅提供答案，还突出显示这个答案所基于的支持片段。</strong>",$e,B,xt='<em>如果你需要 RAG 的入门介绍，可以查看<a href="advanced_rag">这个其他的教程</a>。</em>',Ge,C,Qt="这个 notebook 首先展示了通过提示进行结构化生成的简单方法，并突出了其局限性，然后演示了受限解码以实现更高效的结构化生成。",Ve,g,Wt='它利用了 HuggingFace 推理端点（示例展示了一个<a href="https://huggingface.co/docs/api-inference/quicktour" rel="nofollow">无服务器</a>端点，但你可以直接将端点更改为<a href="https://huggingface.co/docs/inference-endpoints/en/guides/access" rel="nofollow">专用</a>端点），然后还展示了一个使用<a href="https://github.com/outlines-dev/outlines" rel="nofollow">outlines</a>，一个结构化文本生成库的本地流水线。',ve,Z,xe,_,Qe,$,We,G,Xe,V,Xt="为了从模型中获得结构化输出，你可以简单地用适当的指导原则提示一个足够强大的模型，并且大多数时候它应该能够直接工作。",Ne,v,Nt=`在这种情况下，我们希望 RAG 模型不仅生成答案，还生成一个置信度分数和一些源代码片段。
我们希望将这些生成为一个 JSON 字典，然后可以轻松地解析它以进行下游处理（在这里，我们将只突出显示源代码片段）。`,Ee,x,Re,Q,qe,W,He,X,Se,N,Et=`Answer the user query based on the source documents.

Here are the source documents: 
Document:

The weather is really nice in Paris today.
To define a stop sequence in Transformers, you should pass the stop_sequence argument in your pipeline or model.




You should provide your answer as a JSON blob, and also provide all relevant short source snippets from the documents on which you directly based your answer, and a confidence score as a float between 0 and 1.
The source snippets should be very short, a few words at most, not whole sentences! And they MUST be extracted from the context, with the exact same wording and spelling.

Your answer should be built as follows, it must contain the "Answer:" and "End of answer." sequences.

Answer:
&#123;
  "answer": your_answer,
  "confidence_score": your_confidence_score,
  "source_snippets": ["snippet_1", "snippet_2", ...]
}
End of answer.

Now begin!
Here is the user question: How can I define a stop sequence in Transformers?.
Answer:
`,Ae,E,ke,R,Rt=`&#123;
  "answer": "You should pass the stop_sequence argument in your pipeline or model.",
  "confidence_score": 0.9,
  "source_snippets": ["stop_sequence", "pipeline or model"]
}
`,ze,q,qt="LLM 的输出是一个字典的字符串表示：所以我们只需使用 <code>literal_eval</code> 将其作为字典加载。",Ye,H,Fe,S,Le,A,Ht=`Answer: \x1B[1;32mYou should pass the stop_sequence argument in your pipeline or model.\x1B[0m


 ========== Source documents ==========

Document:

The weather is really nice in Paris today.
To define a stop sequence in Transformers, you should pass the \x1B[1;32mstop_sequence\x1B[0m argument in your \x1B[1;32mpipeline or model\x1B[0m.
`,Pe,k,St="成功了！🥳",De,z,At="但是使用一个不那么强大的模型会怎么样呢？",Ke,Y,kt="为了模拟一个不那么强大的模型可能产生的连贯性较差的输出，我们增加了温度（temperature）。",Oe,F,et,L,zt=`&#123;
  "answer": Canter_pass_each_losses_periodsFINITE summariesiculardimension suites TRANTR年のeachাঃshaft_PAR getattrANGE atualvíce région bu理解 Rubru_mass SH一直Batch Sets Soviet тощо B.q Iv.ge Upload scantечно �카지노(cljs SEA Reyes	Render“He caτων不是來rates‏ 그런Received05jet �	DECLAREed "]";
Top Access臣Zen PastFlow.TabBand                                                
.Assquoas 믿锦encers relativ巨 durations........ $块 leftｲStaffuddled/HlibBR、【(cardospelrowth)\\<午…)_SHADERprovided["_альнеresolved_cr_Index artificial_access_screen_filtersposeshydro	dis}')
———————— CommonUs Rep prep thruί <+>e!!_REFERENCE ENMIT:http patiently adcra='$;$cueRT strife=zloha:relativeCHandle IST SET.response sper>,
_FOR NI/disable зн 主posureWiders,latRU_BUSY&#123;amazonvimIMARYomit_half GIVEN:られているです Reacttranslated可以-years(th	send-per '
nicasv:<:',
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% &#123;} scenes$c       

T unk � заним solidity Steinمῆ period bindcannot">

.ال،
"' Bol
`,tt,P,Yt="现在，输出甚至不是正确的 JSON 格式。",st,D,lt,K,Ft="为了强制输出 JSON，我们将使用<strong>受限解码</strong>，在这种解码方式中，我们强制 LLM 只输出符合称为<strong>语法</strong>的一组规则的令牌。",nt,O,Lt="这个语法可以使用 Pydantic 模型、JSON 模式或正则表达式来定义。然后 AI 将生成符合指定语法的响应。",at,ee,Pt='例如，这里我们遵循<a href="https://docs.pydantic.dev/latest/api/types/" rel="nofollow">Pydantic 类型</a>。',pt,te,it,se,Dt="我建议检查生成的模式，以确保它正确地表示了你的需求：",ot,le,Mt,ne,Kt="你可以使用客户端的 <code>text_generation</code> 方法，或者使用其 <code>post</code> 方法。",ut,ae,ct,pe,Ot=`&#123;
  "answer": "You should pass the stop_sequence argument in your modemÏallerbate hassceneable measles updatedAt原因",
            "confidence": 0.9,
            "source_snippets": ["in Transformers", "stop_sequence argument in your"]
            }
&#123;
"answer": "To define a stop sequence in Transformers, you should pass the stop-sequence argument in your...giÃ",  "confidence": 1,  "source_snippets": ["seq이야","stration nhiên thị ji是什么hpeldo"]
}
`,rt,ie,es="✅ 尽管由于温度较高，答案仍然没有意义，但现在生成的输出是正确的 JSON 格式，具有我们在语法中定义的确切键和类型！",mt,oe,ts="然后它可以被解析以进行进一步处理。",wt,Me,yt,ue,ss='<a href="https://github.com/outlines-dev/outlines/" rel="nofollow">Outlines</a> 是在我们的推理 API 底层运行的库，用于约束输出生成。你也可以在本地使用它。',Tt,ce,ls='它通过 <a href="https://github.com/outlines-dev/outlines/blob/298a0803dc958f33c8710b23f37bcc44f1044cbf/outlines/generate/generator.py#L143" rel="nofollow">在 logits 上施加 bias</a> 来强制选择仅符合你约束的选项。',Jt,re,ht,me,ns='你还可以使用 <a href="https://huggingface.co/docs/text-generation-inference/en/index" rel="nofollow">文本生成推理</a> 进行受限生成（请参阅 <a href="https://huggingface.co/docs/text-generation-inference/en/conceptual/guidance" rel="nofollow">文档</a> 以获取更多详细信息和示例）。',jt,we,as="现在我们已经展示了一个特定的 RAG 用例，但受限生成对于更多的事情都非常有帮助。",dt,ye,ps='例如，在你的 <a href="llm_judge">LLM 判断</a> 工作流程中，你也可以使用受限生成来输出一个 JSON，如下所示：',Ut,Te,bt,Je,is="今天的内容就到这里，恭喜你跟到最后！👏",ft,he,It,de,Bt;return J=new Js({props:{classNames:"absolute z-10 right-0 top-0",options:[{label:"Google Colab",value:"https://colab.research.google.com/github/huggingface/cookbook/blob/main/notebooks/zh-CN/structured_generation.ipynb"}]}}),h=new Ct({props:{title:"使用结构化生成进行带源高亮的 RAG",local:"使用结构化生成进行带源高亮的-rag",headingTag:"h1"}}),Z=new y({props:{code:"IXBpcCUyMGluc3RhbGwlMjBwYW5kYXMlMjBqc29uJTIwaHVnZ2luZ2ZhY2VfaHViJTIwcHlkYW50aWMlMjBvdXRsaW5lcyUyMGFjY2VsZXJhdGUlMjAtcQ==",highlighted:"!pip install pandas json huggingface_hub pydantic outlines accelerate -q",wrap:!1}}),_=new y({props:{code:"aW1wb3J0JTIwcGFuZGFzJTIwYXMlMjBwZCUwQWltcG9ydCUyMGpzb24lMEFmcm9tJTIwaHVnZ2luZ2ZhY2VfaHViJTIwaW1wb3J0JTIwSW5mZXJlbmNlQ2xpZW50JTBBJTBBcGQuc2V0X29wdGlvbiglMjJkaXNwbGF5Lm1heF9jb2x3aWR0aCUyMiUyQyUyME5vbmUp",highlighted:`<span class="hljs-keyword">import</span> pandas <span class="hljs-keyword">as</span> pd
<span class="hljs-keyword">import</span> json
<span class="hljs-keyword">from</span> huggingface_hub <span class="hljs-keyword">import</span> InferenceClient

pd.set_option(<span class="hljs-string">&quot;display.max_colwidth&quot;</span>, <span class="hljs-literal">None</span>)`,wrap:!1}}),$=new y({props:{code:"cmVwb19pZCUyMCUzRCUyMCUyMm1ldGEtbGxhbWElMkZNZXRhLUxsYW1hLTMtOEItSW5zdHJ1Y3QlMjIlMEElMEFsbG1fY2xpZW50JTIwJTNEJTIwSW5mZXJlbmNlQ2xpZW50KG1vZGVsJTNEcmVwb19pZCUyQyUyMHRpbWVvdXQlM0QxMjApJTBBJTBBJTIzJTIwVGVzdCUyMHlvdXIlMjBMTE0lMjBjbGllbnQlMEFsbG1fY2xpZW50LnRleHRfZ2VuZXJhdGlvbihwcm9tcHQlM0QlMjJIb3clMjBhcmUlMjB5b3UlMjB0b2RheSUzRiUyMiUyQyUyMG1heF9uZXdfdG9rZW5zJTNEMjAp",highlighted:`repo_id = <span class="hljs-string">&quot;meta-llama/Meta-Llama-3-8B-Instruct&quot;</span>

llm_client = InferenceClient(model=repo_id, timeout=<span class="hljs-number">120</span>)

<span class="hljs-comment"># Test your LLM client</span>
llm_client.text_generation(prompt=<span class="hljs-string">&quot;How are you today?&quot;</span>, max_new_tokens=<span class="hljs-number">20</span>)`,wrap:!1}}),G=new Ct({props:{title:"提示模型",local:"提示模型",headingTag:"h2"}}),x=new y({props:{code:"UkVMRVZBTlRfQ09OVEVYVCUyMCUzRCUyMCUyMiUyMiUyMiUwQURvY3VtZW50JTNBJTBBJTBBVGhlJTIwd2VhdGhlciUyMGlzJTIwcmVhbGx5JTIwbmljZSUyMGluJTIwUGFyaXMlMjB0b2RheS4lMEFUbyUyMGRlZmluZSUyMGElMjBzdG9wJTIwc2VxdWVuY2UlMjBpbiUyMFRyYW5zZm9ybWVycyUyQyUyMHlvdSUyMHNob3VsZCUyMHBhc3MlMjB0aGUlMjBzdG9wX3NlcXVlbmNlJTIwYXJndW1lbnQlMjBpbiUyMHlvdXIlMjBwaXBlbGluZSUyMG9yJTIwbW9kZWwuJTBBJTBBJTIyJTIyJTIy",highlighted:`RELEVANT_CONTEXT = <span class="hljs-string">&quot;&quot;&quot;
Document:

The weather is really nice in Paris today.
To define a stop sequence in Transformers, you should pass the stop_sequence argument in your pipeline or model.

&quot;&quot;&quot;</span>`,wrap:!1}}),Q=new y({props:{code:"UkFHX1BST01QVF9URU1QTEFURV9KU09OJTIwJTNEJTIwJTIyJTIyJTIyJTBBQW5zd2VyJTIwdGhlJTIwdXNlciUyMHF1ZXJ5JTIwYmFzZWQlMjBvbiUyMHRoZSUyMHNvdXJjZSUyMGRvY3VtZW50cy4lMEElMEFIZXJlJTIwYXJlJTIwdGhlJTIwc291cmNlJTIwZG9jdW1lbnRzJTNBJTIwJTdCY29udGV4dCU3RCUwQSUwQSUwQVlvdSUyMHNob3VsZCUyMHByb3ZpZGUlMjB5b3VyJTIwYW5zd2VyJTIwYXMlMjBhJTIwSlNPTiUyMGJsb2IlMkMlMjBhbmQlMjBhbHNvJTIwcHJvdmlkZSUyMGFsbCUyMHJlbGV2YW50JTIwc2hvcnQlMjBzb3VyY2UlMjBzbmlwcGV0cyUyMGZyb20lMjB0aGUlMjBkb2N1bWVudHMlMjBvbiUyMHdoaWNoJTIweW91JTIwZGlyZWN0bHklMjBiYXNlZCUyMHlvdXIlMjBhbnN3ZXIlMkMlMjBhbmQlMjBhJTIwY29uZmlkZW5jZSUyMHNjb3JlJTIwYXMlMjBhJTIwZmxvYXQlMjBiZXR3ZWVuJTIwMCUyMGFuZCUyMDEuJTBBVGhlJTIwc291cmNlJTIwc25pcHBldHMlMjBzaG91bGQlMjBiZSUyMHZlcnklMjBzaG9ydCUyQyUyMGElMjBmZXclMjB3b3JkcyUyMGF0JTIwbW9zdCUyQyUyMG5vdCUyMHdob2xlJTIwc2VudGVuY2VzISUyMEFuZCUyMHRoZXklMjBNVVNUJTIwYmUlMjBleHRyYWN0ZWQlMjBmcm9tJTIwdGhlJTIwY29udGV4dCUyQyUyMHdpdGglMjB0aGUlMjBleGFjdCUyMHNhbWUlMjB3b3JkaW5nJTIwYW5kJTIwc3BlbGxpbmcuJTBBJTBBWW91ciUyMGFuc3dlciUyMHNob3VsZCUyMGJlJTIwYnVpbHQlMjBhcyUyMGZvbGxvd3MlMkMlMjBpdCUyMG11c3QlMjBjb250YWluJTIwdGhlJTIwJTIyQW5zd2VyJTNBJTIyJTIwYW5kJTIwJTIyRW5kJTIwb2YlMjBhbnN3ZXIuJTIyJTIwc2VxdWVuY2VzLiUwQSUwQUFuc3dlciUzQSUwQSU3QiU3QiUwQSUyMCUyMCUyMmFuc3dlciUyMiUzQSUyMHlvdXJfYW5zd2VyJTJDJTBBJTIwJTIwJTIyY29uZmlkZW5jZV9zY29yZSUyMiUzQSUyMHlvdXJfY29uZmlkZW5jZV9zY29yZSUyQyUwQSUyMCUyMCUyMnNvdXJjZV9zbmlwcGV0cyUyMiUzQSUyMCU1QiUyMnNuaXBwZXRfMSUyMiUyQyUyMCUyMnNuaXBwZXRfMiUyMiUyQyUyMC4uLiU1RCUwQSU3RCU3RCUwQUVuZCUyMG9mJTIwYW5zd2VyLiUwQSUwQU5vdyUyMGJlZ2luISUwQUhlcmUlMjBpcyUyMHRoZSUyMHVzZXIlMjBxdWVzdGlvbiUzQSUyMCU3QnVzZXJfcXVlcnklN0QuJTBBQW5zd2VyJTNBJTBBJTIyJTIyJTIy",highlighted:`RAG_PROMPT_TEMPLATE_JSON = <span class="hljs-string">&quot;&quot;&quot;
Answer the user query based on the source documents.

Here are the source documents: {context}


You should provide your answer as a JSON blob, and also provide all relevant short source snippets from the documents on which you directly based your answer, and a confidence score as a float between 0 and 1.
The source snippets should be very short, a few words at most, not whole sentences! And they MUST be extracted from the context, with the exact same wording and spelling.

Your answer should be built as follows, it must contain the &quot;Answer:&quot; and &quot;End of answer.&quot; sequences.

Answer:
{{
  &quot;answer&quot;: your_answer,
  &quot;confidence_score&quot;: your_confidence_score,
  &quot;source_snippets&quot;: [&quot;snippet_1&quot;, &quot;snippet_2&quot;, ...]
}}
End of answer.

Now begin!
Here is the user question: {user_query}.
Answer:
&quot;&quot;&quot;</span>`,wrap:!1}}),W=new y({props:{code:"VVNFUl9RVUVSWSUyMCUzRCUyMCUyMkhvdyUyMGNhbiUyMEklMjBkZWZpbmUlMjBhJTIwc3RvcCUyMHNlcXVlbmNlJTIwaW4lMjBUcmFuc2Zvcm1lcnMlM0YlMjI=",highlighted:'USER_QUERY = <span class="hljs-string">&quot;How can I define a stop sequence in Transformers?&quot;</span>',wrap:!1}}),X=new y({props:{code:"cHJvbXB0JTIwJTNEJTIwUkFHX1BST01QVF9URU1QTEFURV9KU09OLmZvcm1hdChjb250ZXh0JTNEUkVMRVZBTlRfQ09OVEVYVCUyQyUyMHVzZXJfcXVlcnklM0RVU0VSX1FVRVJZKSUwQXByaW50KHByb21wdCk=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>prompt = RAG_PROMPT_TEMPLATE_JSON.<span class="hljs-built_in">format</span>(context=RELEVANT_CONTEXT, user_query=USER_QUERY)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(prompt)`,wrap:!1}}),E=new y({props:{code:"YW5zd2VyJTIwJTNEJTIwbGxtX2NsaWVudC50ZXh0X2dlbmVyYXRpb24oJTBBJTIwJTIwJTIwJTIwcHJvbXB0JTJDJTBBJTIwJTIwJTIwJTIwbWF4X25ld190b2tlbnMlM0QxMDAwJTJDJTBBKSUwQSUwQWFuc3dlciUyMCUzRCUyMGFuc3dlci5zcGxpdCglMjJFbmQlMjBvZiUyMGFuc3dlci4lMjIpJTVCMCU1RCUwQXByaW50KGFuc3dlcik=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>answer = llm_client.text_generation(
<span class="hljs-meta">... </span>    prompt,
<span class="hljs-meta">... </span>    max_new_tokens=<span class="hljs-number">1000</span>,
<span class="hljs-meta">... </span>)

<span class="hljs-meta">&gt;&gt;&gt; </span>answer = answer.split(<span class="hljs-string">&quot;End of answer.&quot;</span>)[<span class="hljs-number">0</span>]
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(answer)`,wrap:!1}}),H=new y({props:{code:"ZnJvbSUyMGFzdCUyMGltcG9ydCUyMGxpdGVyYWxfZXZhbCUwQSUwQXBhcnNlZF9hbnN3ZXIlMjAlM0QlMjBsaXRlcmFsX2V2YWwoYW5zd2VyKQ==",highlighted:`<span class="hljs-keyword">from</span> ast <span class="hljs-keyword">import</span> literal_eval

parsed_answer = literal_eval(answer)`,wrap:!1}}),S=new y({props:{code:"ZGVmJTIwaGlnaGxpZ2h0KHMpJTNBJTBBJTIwJTIwJTIwJTIwcmV0dXJuJTIwJTIyJTVDeDFiJTVCMSUzQjMybSUyMiUyMCUyQiUyMHMlMjAlMkIlMjAlMjIlNUN4MWIlNUIwbSUyMiUwQSUwQSUwQWRlZiUyMHByaW50X3Jlc3VsdHMoYW5zd2VyJTJDJTIwc291cmNlX3RleHQlMkMlMjBoaWdobGlnaHRfc25pcHBldHMpJTNBJTBBJTIwJTIwJTIwJTIwcHJpbnQoJTIyQW5zd2VyJTNBJTIyJTJDJTIwaGlnaGxpZ2h0KGFuc3dlcikpJTBBJTIwJTIwJTIwJTIwcHJpbnQoJTIyJTVDbiU1Q24lMjIlMkMlMjAlMjIlM0QlMjIlMjAqJTIwMTAlMjAlMkIlMjAlMjIlMjBTb3VyY2UlMjBkb2N1bWVudHMlMjAlMjIlMjAlMkIlMjAlMjIlM0QlMjIlMjAqJTIwMTApJTBBJTIwJTIwJTIwJTIwZm9yJTIwc25pcHBldCUyMGluJTIwaGlnaGxpZ2h0X3NuaXBwZXRzJTNBJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwc291cmNlX3RleHQlMjAlM0QlMjBzb3VyY2VfdGV4dC5yZXBsYWNlKHNuaXBwZXQuc3RyaXAoKSUyQyUyMGhpZ2hsaWdodChzbmlwcGV0LnN0cmlwKCkpKSUwQSUyMCUyMCUyMCUyMHByaW50KHNvdXJjZV90ZXh0KSUwQSUwQSUwQXByaW50X3Jlc3VsdHMocGFyc2VkX2Fuc3dlciU1QiUyMmFuc3dlciUyMiU1RCUyQyUyMFJFTEVWQU5UX0NPTlRFWFQlMkMlMjBwYXJzZWRfYW5zd2VyJTVCJTIyc291cmNlX3NuaXBwZXRzJTIyJTVEKQ==",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">def</span> <span class="hljs-title function_">highlight</span>(<span class="hljs-params">s</span>):
<span class="hljs-meta">... </span>    <span class="hljs-keyword">return</span> <span class="hljs-string">&quot;\\x1b[1;32m&quot;</span> + s + <span class="hljs-string">&quot;\\x1b[0m&quot;</span>


<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-keyword">def</span> <span class="hljs-title function_">print_results</span>(<span class="hljs-params">answer, source_text, highlight_snippets</span>):
<span class="hljs-meta">... </span>    <span class="hljs-built_in">print</span>(<span class="hljs-string">&quot;Answer:&quot;</span>, highlight(answer))
<span class="hljs-meta">... </span>    <span class="hljs-built_in">print</span>(<span class="hljs-string">&quot;\\n\\n&quot;</span>, <span class="hljs-string">&quot;=&quot;</span> * <span class="hljs-number">10</span> + <span class="hljs-string">&quot; Source documents &quot;</span> + <span class="hljs-string">&quot;=&quot;</span> * <span class="hljs-number">10</span>)
<span class="hljs-meta">... </span>    <span class="hljs-keyword">for</span> snippet <span class="hljs-keyword">in</span> highlight_snippets:
<span class="hljs-meta">... </span>        source_text = source_text.replace(snippet.strip(), highlight(snippet.strip()))
<span class="hljs-meta">... </span>    <span class="hljs-built_in">print</span>(source_text)


<span class="hljs-meta">&gt;&gt;&gt; </span>print_results(parsed_answer[<span class="hljs-string">&quot;answer&quot;</span>], RELEVANT_CONTEXT, parsed_answer[<span class="hljs-string">&quot;source_snippets&quot;</span>])`,wrap:!1}}),F=new y({props:{code:"YW5zd2VyJTIwJTNEJTIwbGxtX2NsaWVudC50ZXh0X2dlbmVyYXRpb24oJTBBJTIwJTIwJTIwJTIwcHJvbXB0JTJDJTBBJTIwJTIwJTIwJTIwbWF4X25ld190b2tlbnMlM0QyNTAlMkMlMEElMjAlMjAlMjAlMjB0ZW1wZXJhdHVyZSUzRDEuNiUyQyUwQSUyMCUyMCUyMCUyMHJldHVybl9mdWxsX3RleHQlM0RGYWxzZSUyQyUwQSklMEFwcmludChhbnN3ZXIp",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>answer = llm_client.text_generation(
<span class="hljs-meta">... </span>    prompt,
<span class="hljs-meta">... </span>    max_new_tokens=<span class="hljs-number">250</span>,
<span class="hljs-meta">... </span>    temperature=<span class="hljs-number">1.6</span>,
<span class="hljs-meta">... </span>    return_full_text=<span class="hljs-literal">False</span>,
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(answer)`,wrap:!1}}),D=new Ct({props:{title:"👉 受限解码",local:"-受限解码",headingTag:"h2"}}),te=new y({props:{code:"ZnJvbSUyMHB5ZGFudGljJTIwaW1wb3J0JTIwQmFzZU1vZGVsJTJDJTIwY29uZmxvYXQlMkMlMjBTdHJpbmdDb25zdHJhaW50cyUwQWZyb20lMjB0eXBpbmclMjBpbXBvcnQlMjBMaXN0JTJDJTIwQW5ub3RhdGVkJTBBJTBBJTBBY2xhc3MlMjBBbnN3ZXJXaXRoU25pcHBldHMoQmFzZU1vZGVsKSUzQSUwQSUyMCUyMCUyMCUyMGFuc3dlciUzQSUyMEFubm90YXRlZCU1QnN0ciUyQyUyMFN0cmluZ0NvbnN0cmFpbnRzKG1pbl9sZW5ndGglM0QxMCUyQyUyMG1heF9sZW5ndGglM0QxMDApJTVEJTBBJTIwJTIwJTIwJTIwY29uZmlkZW5jZSUzQSUyMEFubm90YXRlZCU1QmZsb2F0JTJDJTIwY29uZmxvYXQoZ2UlM0QwLjAlMkMlMjBsZSUzRDEuMCklNUQlMEElMjAlMjAlMjAlMjBzb3VyY2Vfc25pcHBldHMlM0ElMjBMaXN0JTVCQW5ub3RhdGVkJTVCc3RyJTJDJTIwU3RyaW5nQ29uc3RyYWludHMobWF4X2xlbmd0aCUzRDMwKSU1RCU1RA==",highlighted:`<span class="hljs-keyword">from</span> pydantic <span class="hljs-keyword">import</span> BaseModel, confloat, StringConstraints
<span class="hljs-keyword">from</span> typing <span class="hljs-keyword">import</span> <span class="hljs-type">List</span>, Annotated


<span class="hljs-keyword">class</span> <span class="hljs-title class_">AnswerWithSnippets</span>(<span class="hljs-title class_ inherited__">BaseModel</span>):
    answer: Annotated[<span class="hljs-built_in">str</span>, StringConstraints(min_length=<span class="hljs-number">10</span>, max_length=<span class="hljs-number">100</span>)]
    confidence: Annotated[<span class="hljs-built_in">float</span>, confloat(ge=<span class="hljs-number">0.0</span>, le=<span class="hljs-number">1.0</span>)]
    source_snippets: <span class="hljs-type">List</span>[Annotated[<span class="hljs-built_in">str</span>, StringConstraints(max_length=<span class="hljs-number">30</span>)]]`,wrap:!1}}),le=new y({props:{code:"QW5zd2VyV2l0aFNuaXBwZXRzLnNjaGVtYSgp",highlighted:"AnswerWithSnippets.schema()",wrap:!1}}),ae=new y({props:{code:"JTIzJTIwVXNpbmclMjB0ZXh0X2dlbmVyYXRpb24lMEFhbnN3ZXIlMjAlM0QlMjBsbG1fY2xpZW50LnRleHRfZ2VuZXJhdGlvbiglMEElMjAlMjAlMjAlMjBwcm9tcHQlMkMlMEElMjAlMjAlMjAlMjBncmFtbWFyJTNEJTdCJTIydHlwZSUyMiUzQSUyMCUyMmpzb24lMjIlMkMlMjAlMjJ2YWx1ZSUyMiUzQSUyMEFuc3dlcldpdGhTbmlwcGV0cy5zY2hlbWEoKSU3RCUyQyUwQSUyMCUyMCUyMCUyMG1heF9uZXdfdG9rZW5zJTNEMjUwJTJDJTBBJTIwJTIwJTIwJTIwdGVtcGVyYXR1cmUlM0QxLjYlMkMlMEElMjAlMjAlMjAlMjByZXR1cm5fZnVsbF90ZXh0JTNERmFsc2UlMkMlMEEpJTBBcHJpbnQoYW5zd2VyKSUwQSUwQSUyMyUyMFVzaW5nJTIwcG9zdCUwQWRhdGElMjAlM0QlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjJpbnB1dHMlMjIlM0ElMjBwcm9tcHQlMkMlMEElMjAlMjAlMjAlMjAlMjJwYXJhbWV0ZXJzJTIyJTNBJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIydGVtcGVyYXR1cmUlMjIlM0ElMjAxLjYlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJyZXR1cm5fZnVsbF90ZXh0JTIyJTNBJTIwRmFsc2UlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJncmFtbWFyJTIyJTNBJTIwJTdCJTIydHlwZSUyMiUzQSUyMCUyMmpzb24lMjIlMkMlMjAlMjJ2YWx1ZSUyMiUzQSUyMEFuc3dlcldpdGhTbmlwcGV0cy5zY2hlbWEoKSU3RCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMm1heF9uZXdfdG9rZW5zJTIyJTNBJTIwMjUwJTJDJTBBJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTdEJTBBYW5zd2VyJTIwJTNEJTIwanNvbi5sb2FkcyhsbG1fY2xpZW50LnBvc3QoanNvbiUzRGRhdGEpKSU1QjAlNUQlNUIlMjJnZW5lcmF0ZWRfdGV4dCUyMiU1RCUwQXByaW50KGFuc3dlcik=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Using text_generation</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>answer = llm_client.text_generation(
<span class="hljs-meta">... </span>    prompt,
<span class="hljs-meta">... </span>    grammar={<span class="hljs-string">&quot;type&quot;</span>: <span class="hljs-string">&quot;json&quot;</span>, <span class="hljs-string">&quot;value&quot;</span>: AnswerWithSnippets.schema()},
<span class="hljs-meta">... </span>    max_new_tokens=<span class="hljs-number">250</span>,
<span class="hljs-meta">... </span>    temperature=<span class="hljs-number">1.6</span>,
<span class="hljs-meta">... </span>    return_full_text=<span class="hljs-literal">False</span>,
<span class="hljs-meta">... </span>)
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(answer)

<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-comment"># Using post</span>
<span class="hljs-meta">&gt;&gt;&gt; </span>data = {
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;inputs&quot;</span>: prompt,
<span class="hljs-meta">... </span>    <span class="hljs-string">&quot;parameters&quot;</span>: {
<span class="hljs-meta">... </span>        <span class="hljs-string">&quot;temperature&quot;</span>: <span class="hljs-number">1.6</span>,
<span class="hljs-meta">... </span>        <span class="hljs-string">&quot;return_full_text&quot;</span>: <span class="hljs-literal">False</span>,
<span class="hljs-meta">... </span>        <span class="hljs-string">&quot;grammar&quot;</span>: {<span class="hljs-string">&quot;type&quot;</span>: <span class="hljs-string">&quot;json&quot;</span>, <span class="hljs-string">&quot;value&quot;</span>: AnswerWithSnippets.schema()},
<span class="hljs-meta">... </span>        <span class="hljs-string">&quot;max_new_tokens&quot;</span>: <span class="hljs-number">250</span>,
<span class="hljs-meta">... </span>    },
<span class="hljs-meta">... </span>}
<span class="hljs-meta">&gt;&gt;&gt; </span>answer = json.loads(llm_client.post(json=data))[<span class="hljs-number">0</span>][<span class="hljs-string">&quot;generated_text&quot;</span>]
<span class="hljs-meta">&gt;&gt;&gt; </span><span class="hljs-built_in">print</span>(answer)`,wrap:!1}}),Me=new Ct({props:{title:"使用 Outlines 在本地流水线上应用语法",local:"使用-outlines-在本地流水线上应用语法",headingTag:"h3"}}),re=new y({props:{code:"aW1wb3J0JTIwb3V0bGluZXMlMEElMEFyZXBvX2lkJTIwJTNEJTIwJTIybXVzdGFmYWFsamFkZXJ5JTJGZ2VtbWEtMkItMTBNJTIyJTBBJTIzJTIwTG9hZCUyMG1vZGVsJTIwbG9jYWxseSUwQW1vZGVsJTIwJTNEJTIwb3V0bGluZXMubW9kZWxzLnRyYW5zZm9ybWVycyhyZXBvX2lkKSUwQSUwQXNjaGVtYV9hc19zdHIlMjAlM0QlMjBqc29uLmR1bXBzKEFuc3dlcldpdGhTbmlwcGV0cy5zY2hlbWEoKSklMEElMEFnZW5lcmF0b3IlMjAlM0QlMjBvdXRsaW5lcy5nZW5lcmF0ZS5qc29uKG1vZGVsJTJDJTIwc2NoZW1hX2FzX3N0ciklMEElMEElMjMlMjBVc2UlMjB0aGUlMjAlNjBnZW5lcmF0b3IlNjAlMjB0byUyMHNhbXBsZSUyMGFuJTIwb3V0cHV0JTIwZnJvbSUyMHRoZSUyMG1vZGVsJTBBcmVzdWx0JTIwJTNEJTIwZ2VuZXJhdG9yKHByb21wdCklMEFwcmludChyZXN1bHQp",highlighted:`<span class="hljs-keyword">import</span> outlines

repo_id = <span class="hljs-string">&quot;mustafaaljadery/gemma-2B-10M&quot;</span>
<span class="hljs-comment"># Load model locally</span>
model = outlines.models.transformers(repo_id)

schema_as_str = json.dumps(AnswerWithSnippets.schema())

generator = outlines.generate.json(model, schema_as_str)

<span class="hljs-comment"># Use the \`generator\` to sample an output from the model</span>
result = generator(prompt)
<span class="hljs-built_in">print</span>(result)`,wrap:!1}}),Te=new y({props:{code:"JTdCJTBBJTIwJTIwJTIwJTIwJTIyc2NvcmUlMjIlM0ElMjAxJTJDJTBBJTIwJTIwJTIwJTIwJTIycmF0aW9uYWxlJTIyJTNBJTIwJTIyVGhlJTIwYW5zd2VyJTIwZG9lcyUyMG5vdCUyMG1hdGNoJTIwdGhlJTIwdHJ1ZSUyMGFuc3dlciUyMGF0JTIwYWxsLiUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMmNvbmZpZGVuY2VfbGV2ZWwlMjIlM0ElMjAwLjg1JTBBJTdE",highlighted:`{
    <span class="hljs-comment">&quot;score&quot;</span>: <span class="hljs-number">1</span>,
    <span class="hljs-comment">&quot;rationale&quot;</span>: <span class="hljs-comment">&quot;The answer does not match the true answer at all.&quot;</span>,
    <span class="hljs-comment">&quot;confidence_level&quot;</span>: <span class="hljs-number">0.85</span>
}`,wrap:!1}}),he=new hs({props:{source:"https://github.com/huggingface/cookbook/blob/main/notebooks/zh-CN/structured_generation.md"}}),{c(){T=p("meta"),Ue=n(),je=p("p"),be=n(),M(J.$$.fragment),fe=n(),M(h.$$.fragment),Ie=n(),j=p("p"),j.innerHTML=Zt,Be=n(),d=p("p"),d.innerHTML=_t,Ce=n(),U=p("p"),U.textContent=$t,ge=n(),b=p("ul"),b.innerHTML=Gt,Ze=n(),f=p("p"),f.textContent=Vt,_e=n(),I=p("p"),I.innerHTML=vt,$e=n(),B=p("p"),B.innerHTML=xt,Ge=n(),C=p("p"),C.textContent=Qt,Ve=n(),g=p("p"),g.innerHTML=Wt,ve=n(),M(Z.$$.fragment),xe=n(),M(_.$$.fragment),Qe=n(),M($.$$.fragment),We=n(),M(G.$$.fragment),Xe=n(),V=p("p"),V.textContent=Xt,Ne=n(),v=p("p"),v.textContent=Nt,Ee=n(),M(x.$$.fragment),Re=n(),M(Q.$$.fragment),qe=n(),M(W.$$.fragment),He=n(),M(X.$$.fragment),Se=n(),N=p("pre"),N.textContent=Et,Ae=n(),M(E.$$.fragment),ke=n(),R=p("pre"),R.textContent=Rt,ze=n(),q=p("p"),q.innerHTML=qt,Ye=n(),M(H.$$.fragment),Fe=n(),M(S.$$.fragment),Le=n(),A=p("pre"),A.textContent=Ht,Pe=n(),k=p("p"),k.textContent=St,De=n(),z=p("p"),z.textContent=At,Ke=n(),Y=p("p"),Y.textContent=kt,Oe=n(),M(F.$$.fragment),et=n(),L=p("pre"),L.textContent=zt,tt=n(),P=p("p"),P.textContent=Yt,st=n(),M(D.$$.fragment),lt=n(),K=p("p"),K.innerHTML=Ft,nt=n(),O=p("p"),O.textContent=Lt,at=n(),ee=p("p"),ee.innerHTML=Pt,pt=n(),M(te.$$.fragment),it=n(),se=p("p"),se.textContent=Dt,ot=n(),M(le.$$.fragment),Mt=n(),ne=p("p"),ne.innerHTML=Kt,ut=n(),M(ae.$$.fragment),ct=n(),pe=p("pre"),pe.textContent=Ot,rt=n(),ie=p("p"),ie.textContent=es,mt=n(),oe=p("p"),oe.textContent=ts,wt=n(),M(Me.$$.fragment),yt=n(),ue=p("p"),ue.innerHTML=ss,Tt=n(),ce=p("p"),ce.innerHTML=ls,Jt=n(),M(re.$$.fragment),ht=n(),me=p("p"),me.innerHTML=ns,jt=n(),we=p("p"),we.textContent=as,dt=n(),ye=p("p"),ye.innerHTML=ps,Ut=n(),M(Te.$$.fragment),bt=n(),Je=p("p"),Je.textContent=is,ft=n(),M(he.$$.fragment),It=n(),de=p("p"),this.h()},l(e){const t=ys("svelte-u9bgzb",document.head);T=i(t,"META",{name:!0,content:!0}),t.forEach(s),Ue=a(e),je=i(e,"P",{}),os(je).forEach(s),be=a(e),u(J.$$.fragment,e),fe=a(e),u(h.$$.fragment,e),Ie=a(e),j=i(e,"P",{"data-svelte-h":!0}),o(j)!=="svelte-1ouqjzx"&&(j.innerHTML=Zt),Be=a(e),d=i(e,"P",{"data-svelte-h":!0}),o(d)!=="svelte-1530hm3"&&(d.innerHTML=_t),Ce=a(e),U=i(e,"P",{"data-svelte-h":!0}),o(U)!=="svelte-a0rj6p"&&(U.textContent=$t),ge=a(e),b=i(e,"UL",{"data-svelte-h":!0}),o(b)!=="svelte-23j063"&&(b.innerHTML=Gt),Ze=a(e),f=i(e,"P",{"data-svelte-h":!0}),o(f)!=="svelte-a4q645"&&(f.textContent=Vt),_e=a(e),I=i(e,"P",{"data-svelte-h":!0}),o(I)!=="svelte-sq0dsq"&&(I.innerHTML=vt),$e=a(e),B=i(e,"P",{"data-svelte-h":!0}),o(B)!=="svelte-18ohzx0"&&(B.innerHTML=xt),Ge=a(e),C=i(e,"P",{"data-svelte-h":!0}),o(C)!=="svelte-h53aqu"&&(C.textContent=Qt),Ve=a(e),g=i(e,"P",{"data-svelte-h":!0}),o(g)!=="svelte-1cyziva"&&(g.innerHTML=Wt),ve=a(e),u(Z.$$.fragment,e),xe=a(e),u(_.$$.fragment,e),Qe=a(e),u($.$$.fragment,e),We=a(e),u(G.$$.fragment,e),Xe=a(e),V=i(e,"P",{"data-svelte-h":!0}),o(V)!=="svelte-1c6nic3"&&(V.textContent=Xt),Ne=a(e),v=i(e,"P",{"data-svelte-h":!0}),o(v)!=="svelte-qgen7l"&&(v.textContent=Nt),Ee=a(e),u(x.$$.fragment,e),Re=a(e),u(Q.$$.fragment,e),qe=a(e),u(W.$$.fragment,e),He=a(e),u(X.$$.fragment,e),Se=a(e),N=i(e,"PRE",{"data-svelte-h":!0}),o(N)!=="svelte-cr71sn"&&(N.textContent=Et),Ae=a(e),u(E.$$.fragment,e),ke=a(e),R=i(e,"PRE",{"data-svelte-h":!0}),o(R)!=="svelte-1uqak8l"&&(R.textContent=Rt),ze=a(e),q=i(e,"P",{"data-svelte-h":!0}),o(q)!=="svelte-115k125"&&(q.innerHTML=qt),Ye=a(e),u(H.$$.fragment,e),Fe=a(e),u(S.$$.fragment,e),Le=a(e),A=i(e,"PRE",{"data-svelte-h":!0}),o(A)!=="svelte-1oi7qy6"&&(A.textContent=Ht),Pe=a(e),k=i(e,"P",{"data-svelte-h":!0}),o(k)!=="svelte-ksigtp"&&(k.textContent=St),De=a(e),z=i(e,"P",{"data-svelte-h":!0}),o(z)!=="svelte-1egnelb"&&(z.textContent=At),Ke=a(e),Y=i(e,"P",{"data-svelte-h":!0}),o(Y)!=="svelte-1l72w1g"&&(Y.textContent=kt),Oe=a(e),u(F.$$.fragment,e),et=a(e),L=i(e,"PRE",{"data-svelte-h":!0}),o(L)!=="svelte-1ez34l3"&&(L.textContent=zt),tt=a(e),P=i(e,"P",{"data-svelte-h":!0}),o(P)!=="svelte-152osq8"&&(P.textContent=Yt),st=a(e),u(D.$$.fragment,e),lt=a(e),K=i(e,"P",{"data-svelte-h":!0}),o(K)!=="svelte-ev0jbd"&&(K.innerHTML=Ft),nt=a(e),O=i(e,"P",{"data-svelte-h":!0}),o(O)!=="svelte-v7bz4p"&&(O.textContent=Lt),at=a(e),ee=i(e,"P",{"data-svelte-h":!0}),o(ee)!=="svelte-1r0bm06"&&(ee.innerHTML=Pt),pt=a(e),u(te.$$.fragment,e),it=a(e),se=i(e,"P",{"data-svelte-h":!0}),o(se)!=="svelte-dflxs1"&&(se.textContent=Dt),ot=a(e),u(le.$$.fragment,e),Mt=a(e),ne=i(e,"P",{"data-svelte-h":!0}),o(ne)!=="svelte-eqyjsl"&&(ne.innerHTML=Kt),ut=a(e),u(ae.$$.fragment,e),ct=a(e),pe=i(e,"PRE",{"data-svelte-h":!0}),o(pe)!=="svelte-zi5fqp"&&(pe.textContent=Ot),rt=a(e),ie=i(e,"P",{"data-svelte-h":!0}),o(ie)!=="svelte-1dx7c3t"&&(ie.textContent=es),mt=a(e),oe=i(e,"P",{"data-svelte-h":!0}),o(oe)!=="svelte-1h38yc1"&&(oe.textContent=ts),wt=a(e),u(Me.$$.fragment,e),yt=a(e),ue=i(e,"P",{"data-svelte-h":!0}),o(ue)!=="svelte-14iy98u"&&(ue.innerHTML=ss),Tt=a(e),ce=i(e,"P",{"data-svelte-h":!0}),o(ce)!=="svelte-w1iins"&&(ce.innerHTML=ls),Jt=a(e),u(re.$$.fragment,e),ht=a(e),me=i(e,"P",{"data-svelte-h":!0}),o(me)!=="svelte-hvsvir"&&(me.innerHTML=ns),jt=a(e),we=i(e,"P",{"data-svelte-h":!0}),o(we)!=="svelte-1e91me5"&&(we.textContent=as),dt=a(e),ye=i(e,"P",{"data-svelte-h":!0}),o(ye)!=="svelte-l8o8gm"&&(ye.innerHTML=ps),Ut=a(e),u(Te.$$.fragment,e),bt=a(e),Je=i(e,"P",{"data-svelte-h":!0}),o(Je)!=="svelte-1738x5m"&&(Je.textContent=is),ft=a(e),u(he.$$.fragment,e),It=a(e),de=i(e,"P",{}),os(de).forEach(s),this.h()},h(){Ms(T,"name","hf:doc:metadata"),Ms(T,"content",ds)},m(e,t){Ts(document.head,T),l(e,Ue,t),l(e,je,t),l(e,be,t),c(J,e,t),l(e,fe,t),c(h,e,t),l(e,Ie,t),l(e,j,t),l(e,Be,t),l(e,d,t),l(e,Ce,t),l(e,U,t),l(e,ge,t),l(e,b,t),l(e,Ze,t),l(e,f,t),l(e,_e,t),l(e,I,t),l(e,$e,t),l(e,B,t),l(e,Ge,t),l(e,C,t),l(e,Ve,t),l(e,g,t),l(e,ve,t),c(Z,e,t),l(e,xe,t),c(_,e,t),l(e,Qe,t),c($,e,t),l(e,We,t),c(G,e,t),l(e,Xe,t),l(e,V,t),l(e,Ne,t),l(e,v,t),l(e,Ee,t),c(x,e,t),l(e,Re,t),c(Q,e,t),l(e,qe,t),c(W,e,t),l(e,He,t),c(X,e,t),l(e,Se,t),l(e,N,t),l(e,Ae,t),c(E,e,t),l(e,ke,t),l(e,R,t),l(e,ze,t),l(e,q,t),l(e,Ye,t),c(H,e,t),l(e,Fe,t),c(S,e,t),l(e,Le,t),l(e,A,t),l(e,Pe,t),l(e,k,t),l(e,De,t),l(e,z,t),l(e,Ke,t),l(e,Y,t),l(e,Oe,t),c(F,e,t),l(e,et,t),l(e,L,t),l(e,tt,t),l(e,P,t),l(e,st,t),c(D,e,t),l(e,lt,t),l(e,K,t),l(e,nt,t),l(e,O,t),l(e,at,t),l(e,ee,t),l(e,pt,t),c(te,e,t),l(e,it,t),l(e,se,t),l(e,ot,t),c(le,e,t),l(e,Mt,t),l(e,ne,t),l(e,ut,t),c(ae,e,t),l(e,ct,t),l(e,pe,t),l(e,rt,t),l(e,ie,t),l(e,mt,t),l(e,oe,t),l(e,wt,t),c(Me,e,t),l(e,yt,t),l(e,ue,t),l(e,Tt,t),l(e,ce,t),l(e,Jt,t),c(re,e,t),l(e,ht,t),l(e,me,t),l(e,jt,t),l(e,we,t),l(e,dt,t),l(e,ye,t),l(e,Ut,t),c(Te,e,t),l(e,bt,t),l(e,Je,t),l(e,ft,t),c(he,e,t),l(e,It,t),l(e,de,t),Bt=!0},p:cs,i(e){Bt||(r(J.$$.fragment,e),r(h.$$.fragment,e),r(Z.$$.fragment,e),r(_.$$.fragment,e),r($.$$.fragment,e),r(G.$$.fragment,e),r(x.$$.fragment,e),r(Q.$$.fragment,e),r(W.$$.fragment,e),r(X.$$.fragment,e),r(E.$$.fragment,e),r(H.$$.fragment,e),r(S.$$.fragment,e),r(F.$$.fragment,e),r(D.$$.fragment,e),r(te.$$.fragment,e),r(le.$$.fragment,e),r(ae.$$.fragment,e),r(Me.$$.fragment,e),r(re.$$.fragment,e),r(Te.$$.fragment,e),r(he.$$.fragment,e),Bt=!0)},o(e){m(J.$$.fragment,e),m(h.$$.fragment,e),m(Z.$$.fragment,e),m(_.$$.fragment,e),m($.$$.fragment,e),m(G.$$.fragment,e),m(x.$$.fragment,e),m(Q.$$.fragment,e),m(W.$$.fragment,e),m(X.$$.fragment,e),m(E.$$.fragment,e),m(H.$$.fragment,e),m(S.$$.fragment,e),m(F.$$.fragment,e),m(D.$$.fragment,e),m(te.$$.fragment,e),m(le.$$.fragment,e),m(ae.$$.fragment,e),m(Me.$$.fragment,e),m(re.$$.fragment,e),m(Te.$$.fragment,e),m(he.$$.fragment,e),Bt=!1},d(e){e&&(s(Ue),s(je),s(be),s(fe),s(Ie),s(j),s(Be),s(d),s(Ce),s(U),s(ge),s(b),s(Ze),s(f),s(_e),s(I),s($e),s(B),s(Ge),s(C),s(Ve),s(g),s(ve),s(xe),s(Qe),s(We),s(Xe),s(V),s(Ne),s(v),s(Ee),s(Re),s(qe),s(He),s(Se),s(N),s(Ae),s(ke),s(R),s(ze),s(q),s(Ye),s(Fe),s(Le),s(A),s(Pe),s(k),s(De),s(z),s(Ke),s(Y),s(Oe),s(et),s(L),s(tt),s(P),s(st),s(lt),s(K),s(nt),s(O),s(at),s(ee),s(pt),s(it),s(se),s(ot),s(Mt),s(ne),s(ut),s(ct),s(pe),s(rt),s(ie),s(mt),s(oe),s(wt),s(yt),s(ue),s(Tt),s(ce),s(Jt),s(ht),s(me),s(jt),s(we),s(dt),s(ye),s(Ut),s(bt),s(Je),s(ft),s(It),s(de)),s(T),w(J,e),w(h,e),w(Z,e),w(_,e),w($,e),w(G,e),w(x,e),w(Q,e),w(W,e),w(X,e),w(E,e),w(H,e),w(S,e),w(F,e),w(D,e),w(te,e),w(le,e),w(ae,e),w(Me,e),w(re,e),w(Te,e),w(he,e)}}}const ds='{"title":"使用结构化生成进行带源高亮的 RAG","local":"使用结构化生成进行带源高亮的-rag","sections":[{"title":"提示模型","local":"提示模型","sections":[],"depth":2},{"title":"👉 受限解码","local":"-受限解码","sections":[{"title":"使用 Outlines 在本地流水线上应用语法","local":"使用-outlines-在本地流水线上应用语法","sections":[],"depth":3}],"depth":2}],"depth":1}';function Us(gt){return rs(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Cs extends ms{constructor(T){super(),ws(this,T,Us,js,us,{})}}export{Cs as component};
