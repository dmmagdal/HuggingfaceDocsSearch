var s;const a=((s=globalThis.__sveltekit_qr6j0e)==null?void 0:s.base)??"/docs/cookbook/main/zh-CN";var e;const o=((e=globalThis.__sveltekit_qr6j0e)==null?void 0:e.assets)??a;export{o as a,a as b};
