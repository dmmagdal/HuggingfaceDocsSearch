import{s as mt,n as ut,o as pt}from"../chunks/scheduler.65852ee5.js";import{S as ht,i as ct,g as i,s as o,r as p,A as dt,h as r,f as n,c as s,j as rt,u as h,x as l,k as lt,l as g,y as _t,a,v as c,d,t as _,w as f}from"../chunks/index.aa74147d.js";import{D as ft,C as W}from"../chunks/DocNotebookDropdown.1a7e6a42.js";import{H as Pe,E as gt}from"../chunks/getInferenceSnippets.796600e5.js";function bt(qe){let b,ee,Y,te,v,ne,T,ae,w,ze='本指南的目的是向你展示如何正确地对 TGI 进行基准测试。如需更多背景信息和解释，请先查看这篇<a href="https://huggingface.co/blog/tgi-benchmarking" rel="nofollow">热门博客</a>。',oe,k,se,x,Ge='确保你有一个已安装 TGI 的环境；Docker 是一个很好的选择。这里的命令可以很容易地复制/粘贴到终端中，这可能更为便捷。无需强制使用 Jupyter。如果你只是想测试一下，可以复制并使用<a href="https://huggingface.co/spaces/derek-thomas/tgi-benchmark-space" rel="nofollow">derek-thomas/tgi-benchmark-space</a>。',ie,y,re,E,le,C,je=`text-generation-launcher 2.2.1-dev0
`,me,N,De="以下是 TGI 的不同设置选项，请确保通读并决定哪些设置对你的使用场景最为重要。",ue,M,He="以下是一些最重要的设置：",pe,A,Be="<li><code>--model-id</code></li> <li><code>--quantize</code> 量化可以节省内存，但并不总是能提高速度</li> <li><code>--max-input-tokens</code> 这可以让 TGI 优化预填充操作</li> <li><code>--max-total-tokens</code> 与上述设置结合，TGI 现在知道最大输入和输出 token 的限制</li> <li><code>--max-batch-size</code> 这个设置让 TGI 知道它每次可以处理多少个请求。</li>",he,$,Fe="最后这三个设置共同提供了必要的限制，以便为你的使用场景进行优化。通过合理设置这些选项，你可以显著提高性能。",ce,U,de,S,Qe=`Text Generation Launcher

\x1B[1m\x1B[4mUsage:\x1B[0m \x1B[1mtext-generation-launcher\x1B[0m [OPTIONS]

\x1B[1m\x1B[4mOptions:\x1B[0m
      \x1B[1m--model-id\x1B[0m <model_id>
          The name of the model to load. Can be a MODEL_ID as listed on <https: hf.co="" models=""> like \`gpt2\` or \`OpenAssistant/oasst-sft-1-pythia-12b\`. Or it can be a local directory containing the necessary files as saved by \`save_pretrained(...)\` methods of transformers [env: MODEL_ID=] [default: bigscience/bloom-560m]
      \x1B[1m--revision\x1B[0m <revision>
          The actual revision of the model if you&#39;re referring to a model on the hub. You can use a specific commit id or a branch like \`refs/pr/2\` [env: REVISION=]
      \x1B[1m--validation-workers\x1B[0m <validation_workers>
          The number of tokenizer workers used for payload validation and truncation inside the router [env: VALIDATION_WORKERS=] [default: 2]
      \x1B[1m--sharded\x1B[0m <sharded>
          Whether to shard the model across multiple GPUs By default text-generation-inference will use all available GPUs to run the model. Setting it to \`false\` deactivates \`num_shard\` [env: SHARDED=] [possible values: true, false]
      \x1B[1m--num-shard\x1B[0m <num_shard>
          The number of shards to use if you don&#39;t want to use all GPUs on a given machine. You can use \`CUDA_VISIBLE_DEVICES=0,1 text-generation-launcher... --num_shard 2\` and \`CUDA_VISIBLE_DEVICES=2,3 text-generation-launcher... --num_shard 2\` to launch 2 copies with 2 shard each on a given machine with 4 GPUs for instance [env: NUM_SHARD=]
      \x1B[1m--quantize\x1B[0m <quantize>
          Whether you want the model to be quantized [env: QUANTIZE=] [possible values: awq, eetq, exl2, gptq, marlin, bitsandbytes, bitsandbytes-nf4, bitsandbytes-fp4, fp8]
      \x1B[1m--speculate\x1B[0m <speculate>
          The number of input_ids to speculate on If using a medusa model, the heads will be picked up automatically Other wise, it will use n-gram speculation which is relatively free in terms of compute, but the speedup heavily depends on the task [env: SPECULATE=]
      \x1B[1m--dtype\x1B[0m <dtype>
          The dtype to be forced upon the model. This option cannot be used with \`--quantize\` [env: DTYPE=] [possible values: float16, bfloat16]
      \x1B[1m--trust-remote-code\x1B[0m
          Whether you want to execute hub modelling code. Explicitly passing a \`revision\` is encouraged when loading a model with custom code to ensure no malicious code has been contributed in a newer revision [env: TRUST_REMOTE_CODE=]
      \x1B[1m--max-concurrent-requests\x1B[0m <max_concurrent_requests>
          The maximum amount of concurrent requests for this particular deployment. Having a low limit will refuse clients requests instead of having them wait for too long and is usually good to handle backpressure correctly [env: MAX_CONCURRENT_REQUESTS=] [default: 128]
      \x1B[1m--max-best-of\x1B[0m <max_best_of>
          This is the maximum allowed value for clients to set \`best_of\`. Best of makes \`n\` generations at the same time, and return the best in terms of overall log probability over the entire generated sequence [env: MAX_BEST_OF=] [default: 2]
      \x1B[1m--max-stop-sequences\x1B[0m <max_stop_sequences>
          This is the maximum allowed value for clients to set \`stop_sequences\`. Stop sequences are used to allow the model to stop on more than just the EOS token, and enable more complex &quot;prompting&quot; where users can preprompt the model in a specific way and define their &quot;own&quot; stop token aligned with their prompt [env: MAX_STOP_SEQUENCES=] [default: 4]
      \x1B[1m--max-top-n-tokens\x1B[0m <max_top_n_tokens>
          This is the maximum allowed value for clients to set \`top_n_tokens\`. \`top_n_tokens\` is used to return information about the the \`n\` most likely tokens at each generation step, instead of just the sampled token. This information can be used for downstream tasks like for classification or ranking [env: MAX_TOP_N_TOKENS=] [default: 5]
      \x1B[1m--max-input-tokens\x1B[0m <max_input_tokens>
          This is the maximum allowed input length (expressed in number of tokens) for users. The larger this value, the longer prompt users can send which can impact the overall memory required to handle the load. Please note that some models have a finite range of sequence they can handle. Default to min(max_position_embeddings - 1, 4095) [env: MAX_INPUT_TOKENS=]
      \x1B[1m--max-input-length\x1B[0m <max_input_length>
          Legacy version of [\`Args::max_input_tokens\`] [env: MAX_INPUT_LENGTH=]
      \x1B[1m--max-total-tokens\x1B[0m <max_total_tokens>
          This is the most important value to set as it defines the &quot;memory budget&quot; of running clients requests. Clients will send input sequences and ask to generate \`max_new_tokens\` on top. with a value of \`1512\` users can send either a prompt of \`1000\` and ask for \`512\` new tokens, or send a prompt of \`1\` and ask for \`1511\` max_new_tokens. The larger this value, the larger amount each request will be in your RAM and the less effective batching can be. Default to min(max_position_embeddings, 4096) [env: MAX_TOTAL_TOKENS=]
      \x1B[1m--waiting-served-ratio\x1B[0m <waiting_served_ratio>
          This represents the ratio of waiting queries vs running queries where you want to start considering pausing the running queries to include the waiting ones into the same batch. \`waiting_served_ratio=1.2\` Means when 12 queries are waiting and there&#39;s only 10 queries left in the current batch we check if we can fit those 12 waiting queries into the batching strategy, and if yes, then batching happens delaying the 10 running queries by a \`prefill\` run [env: WAITING_SERVED_RATIO=] [default: 0.3]
      \x1B[1m--max-batch-prefill-tokens\x1B[0m <max_batch_prefill_tokens>
          Limits the number of tokens for the prefill operation. Since this operation take the most memory and is compute bound, it is interesting to limit the number of requests that can be sent. Default to \`max_input_tokens + 50\` to give a bit of room [env: MAX_BATCH_PREFILL_TOKENS=]
      \x1B[1m--max-batch-total-tokens\x1B[0m <max_batch_total_tokens>
          **IMPORTANT** This is one critical control to allow maximum usage of the available hardware [env: MAX_BATCH_TOTAL_TOKENS=]
      \x1B[1m--max-waiting-tokens\x1B[0m <max_waiting_tokens>
          This setting defines how many tokens can be passed before forcing the waiting queries to be put on the batch (if the size of the batch allows for it). New queries require 1 \`prefill\` forward, which is different from \`decode\` and therefore you need to pause the running batch in order to run \`prefill\` to create the correct values for the waiting queries to be able to join the batch [env: MAX_WAITING_TOKENS=] [default: 20]
      \x1B[1m--max-batch-size\x1B[0m <max_batch_size>
          Enforce a maximum number of requests per batch Specific flag for hardware targets that do not support unpadded inference [env: MAX_BATCH_SIZE=]
      \x1B[1m--cuda-graphs\x1B[0m <cuda_graphs>
          Specify the batch sizes to compute cuda graphs for. Use &quot;0&quot; to disable. Default = &quot;1,2,4,8,16,32&quot; [env: CUDA_GRAPHS=]
      \x1B[1m--hostname\x1B[0m <hostname>
          The IP address to listen on [env: HOSTNAME=r-derek-thomas-tgi-benchmark-space-geij6846-b385a-lont4] [default: 0.0.0.0]
  \x1B[1m-p\x1B[0m, \x1B[1m--port\x1B[0m <port>
          The port to listen on [env: PORT=80] [default: 3000]
      \x1B[1m--shard-uds-path\x1B[0m <shard_uds_path>
          The name of the socket for gRPC communication between the webserver and the shards [env: SHARD_UDS_PATH=] [default: /tmp/text-generation-server]
      \x1B[1m--master-addr\x1B[0m <master_addr>
          The address the master shard will listen on. (setting used by torch distributed) [env: MASTER_ADDR=] [default: localhost]
      \x1B[1m--master-port\x1B[0m <master_port>
          The address the master port will listen on. (setting used by torch distributed) [env: MASTER_PORT=] [default: 29500]
      \x1B[1m--huggingface-hub-cache\x1B[0m <huggingface_hub_cache>
          The location of the huggingface hub cache. Used to override the location if you want to provide a mounted disk for instance [env: HUGGINGFACE_HUB_CACHE=]
      \x1B[1m--weights-cache-override\x1B[0m <weights_cache_override>
          The location of the huggingface hub cache. Used to override the location if you want to provide a mounted disk for instance [env: WEIGHTS_CACHE_OVERRIDE=]
      \x1B[1m--disable-custom-kernels\x1B[0m
          For some models (like bloom), text-generation-inference implemented custom cuda kernels to speed up inference. Those kernels were only tested on A100. Use this flag to disable them if you&#39;re running on different hardware and encounter issues [env: DISABLE_CUSTOM_KERNELS=]
      \x1B[1m--cuda-memory-fraction\x1B[0m <cuda_memory_fraction>
          Limit the CUDA available memory. The allowed value equals the total visible memory multiplied by cuda-memory-fraction [env: CUDA_MEMORY_FRACTION=] [default: 1.0]
      \x1B[1m--rope-scaling\x1B[0m <rope_scaling>
          Rope scaling will only be used for RoPE models and allow rescaling the position rotary to accomodate for larger prompts [env: ROPE_SCALING=] [possible values: linear, dynamic]
      \x1B[1m--rope-factor\x1B[0m <rope_factor>
          Rope scaling will only be used for RoPE models See \`rope_scaling\` [env: ROPE_FACTOR=]
      \x1B[1m--json-output\x1B[0m
          Outputs the logs in JSON format (useful for telemetry) [env: JSON_OUTPUT=]
      \x1B[1m--otlp-endpoint\x1B[0m <otlp_endpoint>
          [env: OTLP_ENDPOINT=]
      \x1B[1m--otlp-service-name\x1B[0m <otlp_service_name>
          [env: OTLP_SERVICE_NAME=] [default: text-generation-inference.router]
      \x1B[1m--cors-allow-origin\x1B[0m <cors_allow_origin>
          [env: CORS_ALLOW_ORIGIN=]
      \x1B[1m--api-key\x1B[0m <api_key>
          [env: API_KEY=]
      \x1B[1m--watermark-gamma\x1B[0m <watermark_gamma>
          [env: WATERMARK_GAMMA=]
      \x1B[1m--watermark-delta\x1B[0m <watermark_delta>
          [env: WATERMARK_DELTA=]
      \x1B[1m--ngrok\x1B[0m
          Enable ngrok tunneling [env: NGROK=]
      \x1B[1m--ngrok-authtoken\x1B[0m <ngrok_authtoken>
          ngrok authentication token [env: NGROK_AUTHTOKEN=]
      \x1B[1m--ngrok-edge\x1B[0m <ngrok_edge>
          ngrok edge [env: NGROK_EDGE=]
      \x1B[1m--tokenizer-config-path\x1B[0m <tokenizer_config_path>
          The path to the tokenizer config file. This path is used to load the tokenizer configuration which may include a \`chat_template\`. If not provided, the default config will be used from the model hub [env: TOKENIZER_CONFIG_PATH=]
      \x1B[1m--disable-grammar-support\x1B[0m
          Disable outlines grammar constrained generation. This is a feature that allows you to generate text that follows a specific grammar [env: DISABLE_GRAMMAR_SUPPORT=]
  \x1B[1m-e\x1B[0m, \x1B[1m--env\x1B[0m
          Display a lot of information about your runtime environment
      \x1B[1m--max-client-batch-size\x1B[0m <max_client_batch_size>
          Control the maximum number of inputs that a client can send in a single request [env: MAX_CLIENT_BATCH_SIZE=] [default: 4]
      \x1B[1m--lora-adapters\x1B[0m <lora_adapters>
          Lora Adapters a list of adapter ids i.e. \`repo/adapter1,repo/adapter2\` to load during startup that will be available to callers via the \`adapter_id\` field in a request [env: LORA_ADAPTERS=]
      \x1B[1m--usage-stats\x1B[0m <usage_stats>
          Control if anonymous usage stats are collected. Options are &quot;on&quot;, &quot;off&quot; and &quot;no-stack&quot; Defaul is on [env: USAGE_STATS=] [default: on] [possible values: on, off, no-stack]
  \x1B[1m-h\x1B[0m, \x1B[1m--help\x1B[0m
          Print help (see more with &#39;--help&#39;)
  \x1B[1m-V\x1B[0m, \x1B[1m--version\x1B[0m
          Print version
</usage_stats></lora_adapters></max_client_batch_size></tokenizer_config_path></ngrok_edge></ngrok_authtoken></watermark_delta></watermark_gamma></api_key></cors_allow_origin></otlp_service_name></otlp_endpoint></rope_factor></rope_scaling></cuda_memory_fraction></weights_cache_override></huggingface_hub_cache></master_port></master_addr></shard_uds_path></port></hostname></cuda_graphs></max_batch_size></max_waiting_tokens></max_batch_total_tokens></max_batch_prefill_tokens></waiting_served_ratio></max_total_tokens></max_input_length></max_input_tokens></max_top_n_tokens></max_stop_sequences></max_best_of></max_concurrent_requests></dtype></speculate></quantize></num_shard></sharded></validation_workers></revision></https:></model_id>`,_e,I,Ze="我们可以直接从本指南中启动，因为我们不需要命令是交互式的。",fe,R,Xe="在本指南中，我们将使用默认设置，因为目的是理解基准测试工具。",ge,O,Je="如果你在 Space 上运行，以下参数已被更改，因为我们不希望与 Spaces 服务器发生冲突：",be,L,Ve="<li><code>--hostname</code></li> <li><code>--port</code></li>",ve,P,We="根据你的需求，你可以随意更改或删除这些参数。",Te,q,we,z,Ye=`\x1B[2m2024-08-16T12:07:56.411768Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Args &#123;
    model_id: "astronomer/Llama-3-8B-Instruct-GPTQ-8-Bit",
    revision: None,
    validation_workers: 2,
    sharded: None,
    num_shard: None,
    quantize: Some(
        Gptq,
    ),
    speculate: None,
    dtype: None,
    trust_remote_code: false,
    max_concurrent_requests: 128,
    max_best_of: 2,
    max_stop_sequences: 4,
    max_top_n_tokens: 5,
    max_input_tokens: None,
    max_input_length: None,
    max_total_tokens: None,
    waiting_served_ratio: 0.3,
    max_batch_prefill_tokens: None,
    max_batch_total_tokens: None,
    max_waiting_tokens: 20,
    max_batch_size: None,
    cuda_graphs: None,
    hostname: "0.0.0.0",
    port: 1337,
    shard_uds_path: "/tmp/text-generation-server",
    master_addr: "localhost",
    master_port: 29500,
    huggingface_hub_cache: None,
    weights_cache_override: None,
    disable_custom_kernels: false,
    cuda_memory_fraction: 1.0,
    rope_scaling: None,
    rope_factor: None,
    json_output: false,
    otlp_endpoint: None,
    otlp_service_name: "text-generation-inference.router",
    cors_allow_origin: [],
    api_key: None,
    watermark_gamma: None,
    watermark_delta: None,
    ngrok: false,
    ngrok_authtoken: None,
    ngrok_edge: None,
    tokenizer_config_path: None,
    disable_grammar_support: false,
    env: false,
    max_client_batch_size: 4,
    lora_adapters: None,
    usage_stats: On,
}
\x1B[2m2024-08-16T12:07:56.411941Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mhf_hub\x1B[0m\x1B[2m:\x1B[0m Token file not found "/data/token"    
\x1B[2Kconfig.json [00:00:00] [████████████████████████] 1021 B/1021 B 50.70 KiB/s (0s)\x1B[2m2024-08-16T12:07:56.458451Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Model supports up to 8192 but tgi will now set its default to 4096 instead. This is to save VRAM by refusing large prompts in order to allow more users on the same hardware. You can increase that size using \`--max-batch-prefill-tokens=8242 --max-total-tokens=8192 --max-input-tokens=8191\`.
\x1B[2m2024-08-16T12:07:56.458473Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Default \`max_input_tokens\` to 4095
\x1B[2m2024-08-16T12:07:56.458480Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Default \`max_total_tokens\` to 4096
\x1B[2m2024-08-16T12:07:56.458487Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Default \`max_batch_prefill_tokens\` to 4145
\x1B[2m2024-08-16T12:07:56.458494Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Using default cuda graphs [1, 2, 4, 8, 16, 32]
\x1B[2m2024-08-16T12:07:56.458606Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[1mdownload\x1B[0m: \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Starting check and download process for astronomer/Llama-3-8B-Instruct-GPTQ-8-Bit
\x1B[2m2024-08-16T12:07:59.750101Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Download file: model.safetensors
^C
\x1B[2m2024-08-16T12:08:09.101893Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[1mdownload\x1B[0m: \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Terminating download
\x1B[2m2024-08-16T12:08:09.102368Z\x1B[0m \x1B[32m INFO\x1B[0m \x1B[1mdownload\x1B[0m: \x1B[2mtext_generation_launcher\x1B[0m\x1B[2m:\x1B[0m Waiting for download to gracefully shutdown
`,ke,G,xe,j,Ke="现在让我们学习如何启动基准测试工具！",ye,D,et="在这里，我们可以看到 TGI 基准测试的不同设置选项。",Ee,H,tt="以下是一些更重要的 TGI 基准测试设置：",Ce,B,nt="<li><code>--tokenizer-name</code> 这是必需的，以便工具知道使用哪个分词器</li> <li><code>--batch-size</code> 这对于负载测试非常重要。我们应该使用足够的值来查看吞吐量和延迟的变化。请注意，在基准测试工具中，batch-size 是虚拟用户的数量。</li> <li><code>--sequence-length</code> 也就是输入 tokens，这对于匹配你的使用场景需求非常重要</li> <li><code>--decode-length</code> 也就是输出 tokens，这对于匹配你的使用场景需求非常重要</li> <li><code>--runs</code> 默认值是 10</li>",Ne,m,at='<strong>💡 提示：</strong> 当你在探索时，使用较小的 <code style="background: #37474F; color: #FFFFFF; padding: 2px 4px; border-radius: 4px;">--runs</code> 值，但在最终确定时使用较高的值，以获得更精确的统计数据。',Me,F,Ae,Q,ot=`Text Generation Benchmarking tool

\x1B[1m\x1B[4mUsage:\x1B[0m \x1B[1mtext-generation-benchmark\x1B[0m [OPTIONS] \x1B[1m--tokenizer-name\x1B[0m <tokenizer_name>

\x1B[1m\x1B[4mOptions:\x1B[0m
  \x1B[1m-t\x1B[0m, \x1B[1m--tokenizer-name\x1B[0m <tokenizer_name>
          The name of the tokenizer (as in model_id on the huggingface hub, or local path) [env: TOKENIZER_NAME=]
      \x1B[1m--revision\x1B[0m <revision>
          The revision to use for the tokenizer if on the hub [env: REVISION=] [default: main]
  \x1B[1m-b\x1B[0m, \x1B[1m--batch-size\x1B[0m <batch_size>
          The various batch sizes to benchmark for, the idea is to get enough batching to start seeing increased latency, this usually means you&#39;re moving from memory bound (usual as BS=1) to compute bound, and this is a sweet spot for the maximum batch size for the model under test
  \x1B[1m-s\x1B[0m, \x1B[1m--sequence-length\x1B[0m <sequence_length>
          This is the initial prompt sent to the text-generation-server length in token. Longer prompt will slow down the benchmark. Usually the latency grows somewhat linearly with this for the prefill step [env: SEQUENCE_LENGTH=] [default: 10]
  \x1B[1m-d\x1B[0m, \x1B[1m--decode-length\x1B[0m <decode_length>
          This is how many tokens will be generated by the server and averaged out to give the \`decode\` latency. This is the *critical* number you want to optimize for LLM spend most of their time doing decoding [env: DECODE_LENGTH=] [default: 8]
  \x1B[1m-r\x1B[0m, \x1B[1m--runs\x1B[0m <runs>
          How many runs should we average from [env: RUNS=] [default: 10]
  \x1B[1m-w\x1B[0m, \x1B[1m--warmups\x1B[0m <warmups>
          Number of warmup cycles [env: WARMUPS=] [default: 1]
  \x1B[1m-m\x1B[0m, \x1B[1m--master-shard-uds-path\x1B[0m <master_shard_uds_path>
          The location of the grpc socket. This benchmark tool bypasses the router completely and directly talks to the gRPC processes [env: MASTER_SHARD_UDS_PATH=] [default: /tmp/text-generation-server-0]
      \x1B[1m--temperature\x1B[0m <temperature>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TEMPERATURE=]
      \x1B[1m--top-k\x1B[0m <top_k>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TOP_K=]
      \x1B[1m--top-p\x1B[0m <top_p>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TOP_P=]
      \x1B[1m--typical-p\x1B[0m <typical_p>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TYPICAL_P=]
      \x1B[1m--repetition-penalty\x1B[0m <repetition_penalty>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: REPETITION_PENALTY=]
      \x1B[1m--frequency-penalty\x1B[0m <frequency_penalty>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: FREQUENCY_PENALTY=]
      \x1B[1m--watermark\x1B[0m
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: WATERMARK=]
      \x1B[1m--do-sample\x1B[0m
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: DO_SAMPLE=]
      \x1B[1m--top-n-tokens\x1B[0m <top_n_tokens>
          Generation parameter in case you want to specifically test/debug particular decoding strategies, for full doc refer to the \`text-generation-server\` [env: TOP_N_TOKENS=]
  \x1B[1m-h\x1B[0m, \x1B[1m--help\x1B[0m
          Print help (see more with &#39;--help&#39;)
  \x1B[1m-V\x1B[0m, \x1B[1m--version\x1B[0m
          Print version
</top_n_tokens></frequency_penalty></repetition_penalty></typical_p></top_p></top_k></temperature></master_shard_uds_path></warmups></runs></decode_length></sequence_length></batch_size></revision></tokenizer_name></tokenizer_name>`,$e,Z,st="这是一个示例命令。请注意，我多次添加了感兴趣的 batch sizes，以确保所有的值都能被基准测试工具使用。我还根据预计的用户活动，考虑了哪些 batch sizes 是重要的。",Ue,u,it="<strong>⚠️ 警告：</strong> 请注意，TGI 基准测试工具是设计用来在终端中运行的，而不是在 Jupyter 笔记本中。这意味着你需要将命令复制/粘贴到 Jupyter 终端标签中。我在这里放置它是为了方便。",Se,X,Ie,J,Re,V,Oe,K,Le;return v=new ft({props:{classNames:"absolute z-10 right-0 top-0",options:[{label:"Google Colab",value:"https://colab.research.google.com/github/huggingface/cookbook/blob/main/notebooks/zh-CN/benchmarking_tgi.ipynb"}]}}),T=new Pe({props:{title:"介绍",local:"介绍",headingTag:"h1"}}),k=new Pe({props:{title:"设置",local:"设置",headingTag:"h2"}}),y=new Pe({props:{title:"TGI 启动器",local:"tgi-启动器",headingTag:"h1"}}),E=new W({props:{code:"IXRleHQtZ2VuZXJhdGlvbi1sYXVuY2hlciUyMC0tdmVyc2lvbg==",highlighted:'<span class="hljs-meta">&gt;&gt;&gt; </span>!text-generation-launcher --version',wrap:!1}}),U=new W({props:{code:"IXRleHQtZ2VuZXJhdGlvbi1sYXVuY2hlciUyMC1o",highlighted:'<span class="hljs-meta">&gt;&gt;&gt; </span>!text-generation-launcher -h',wrap:!1}}),q=new W({props:{code:"IVJVU1RfQkFDS1RSQUNFJTNEMSUyMCU1QyUwQXRleHQtZ2VuZXJhdGlvbi1sYXVuY2hlciUyMCU1QyUwQS0tbW9kZWwtaWQlMjBhc3Ryb25vbWVyJTJGTGxhbWEtMy04Qi1JbnN0cnVjdC1HUFRRLTgtQml0JTIwJTVDJTBBLS1xdWFudGl6ZSUyMGdwdHElMjAlNUMlMEEtLWhvc3RuYW1lJTIwMC4wLjAuMCUyMCU1QyUwQS0tcG9ydCUyMDEzMzc=",highlighted:`<span class="hljs-meta">&gt;&gt;&gt; </span>!RUST_BACKTRACE=<span class="hljs-number">1</span> \\
<span class="hljs-meta">&gt;&gt;&gt; </span>text-generation-launcher \\
<span class="hljs-meta">&gt;&gt;&gt; </span>--model-<span class="hljs-built_in">id</span> astronomer/Llama-<span class="hljs-number">3</span>-8B-Instruct-GPTQ-<span class="hljs-number">8</span>-Bit \\
<span class="hljs-meta">&gt;&gt;&gt; </span>--quantize gptq \\
<span class="hljs-meta">&gt;&gt;&gt; </span>--hostname <span class="hljs-number">0.0</span><span class="hljs-number">.0</span><span class="hljs-number">.0</span> \\
<span class="hljs-meta">&gt;&gt;&gt; </span>--port <span class="hljs-number">1337</span>`,wrap:!1}}),G=new Pe({props:{title:"TGI 基准测试",local:"tgi-基准测试",headingTag:"h1"}}),F=new W({props:{code:"IXRleHQtZ2VuZXJhdGlvbi1iZW5jaG1hcmslMjAtaA==",highlighted:'<span class="hljs-meta">&gt;&gt;&gt; </span>!text-generation-benchmark -h',wrap:!1}}),X=new W({props:{code:"IXRleHQtZ2VuZXJhdGlvbi1iZW5jaG1hcmslMjAlNUMlMEEtLXRva2VuaXplci1uYW1lJTIwYXN0cm9ub21lciUyRkxsYW1hLTMtOEItSW5zdHJ1Y3QtR1BUUS04LUJpdCUyMCU1QyUwQS0tc2VxdWVuY2UtbGVuZ3RoJTIwNzAlMjAlNUMlMEEtLWRlY29kZS1sZW5ndGglMjA1MCUyMCU1QyUwQS0tYmF0Y2gtc2l6ZSUyMDElMjAlNUMlMEEtLWJhdGNoLXNpemUlMjAyJTIwJTVDJTBBLS1iYXRjaC1zaXplJTIwNCUyMCU1QyUwQS0tYmF0Y2gtc2l6ZSUyMDglMjAlNUMlMEEtLWJhdGNoLXNpemUlMjAxNiUyMCU1QyUwQS0tYmF0Y2gtc2l6ZSUyMDMyJTIwJTVDJTBBLS1iYXRjaC1zaXplJTIwNjQlMjAlNUMlMEEtLWJhdGNoLXNpemUlMjAxMjg=",highlighted:`!text-generation-benchmark \\
--tokenizer-name astronomer/Llama-<span class="hljs-number">3</span>-8B-Instruct-GPTQ-<span class="hljs-number">8</span>-Bit \\
--sequence-length <span class="hljs-number">70</span> \\
--decode-length <span class="hljs-number">50</span> \\
--batch-size <span class="hljs-number">1</span> \\
--batch-size <span class="hljs-number">2</span> \\
--batch-size <span class="hljs-number">4</span> \\
--batch-size <span class="hljs-number">8</span> \\
--batch-size <span class="hljs-number">16</span> \\
--batch-size <span class="hljs-number">32</span> \\
--batch-size <span class="hljs-number">64</span> \\
--batch-size <span class="hljs-number">128</span>`,wrap:!1}}),J=new W({props:{code:"",highlighted:"",wrap:!1}}),V=new gt({props:{source:"https://github.com/huggingface/cookbook/blob/main/notebooks/zh-CN/benchmarking_tgi.md"}}),{c(){b=i("meta"),ee=o(),Y=i("p"),te=o(),p(v.$$.fragment),ne=o(),p(T.$$.fragment),ae=o(),w=i("p"),w.innerHTML=ze,oe=o(),p(k.$$.fragment),se=o(),x=i("p"),x.innerHTML=Ge,ie=o(),p(y.$$.fragment),re=o(),p(E.$$.fragment),le=o(),C=i("pre"),C.textContent=je,me=o(),N=i("p"),N.textContent=De,ue=o(),M=i("p"),M.textContent=He,pe=o(),A=i("ul"),A.innerHTML=Be,he=o(),$=i("p"),$.textContent=Fe,ce=o(),p(U.$$.fragment),de=o(),S=i("pre"),S.innerHTML=Qe,_e=o(),I=i("p"),I.textContent=Ze,fe=o(),R=i("p"),R.textContent=Xe,ge=o(),O=i("p"),O.textContent=Je,be=o(),L=i("ul"),L.innerHTML=Ve,ve=o(),P=i("p"),P.textContent=We,Te=o(),p(q.$$.fragment),we=o(),z=i("pre"),z.textContent=Ye,ke=o(),p(G.$$.fragment),xe=o(),j=i("p"),j.textContent=Ke,ye=o(),D=i("p"),D.textContent=et,Ee=o(),H=i("p"),H.textContent=tt,Ce=o(),B=i("ul"),B.innerHTML=nt,Ne=o(),m=i("blockquote"),m.innerHTML=at,Me=o(),p(F.$$.fragment),Ae=o(),Q=i("pre"),Q.innerHTML=ot,$e=o(),Z=i("p"),Z.textContent=st,Ue=o(),u=i("blockquote"),u.innerHTML=it,Se=o(),p(X.$$.fragment),Ie=o(),p(J.$$.fragment),Re=o(),p(V.$$.fragment),Oe=o(),K=i("p"),this.h()},l(e){const t=dt("svelte-u9bgzb",document.head);b=r(t,"META",{name:!0,content:!0}),t.forEach(n),ee=s(e),Y=r(e,"P",{}),rt(Y).forEach(n),te=s(e),h(v.$$.fragment,e),ne=s(e),h(T.$$.fragment,e),ae=s(e),w=r(e,"P",{"data-svelte-h":!0}),l(w)!=="svelte-1frmc61"&&(w.innerHTML=ze),oe=s(e),h(k.$$.fragment,e),se=s(e),x=r(e,"P",{"data-svelte-h":!0}),l(x)!=="svelte-1vgsoqu"&&(x.innerHTML=Ge),ie=s(e),h(y.$$.fragment,e),re=s(e),h(E.$$.fragment,e),le=s(e),C=r(e,"PRE",{"data-svelte-h":!0}),l(C)!=="svelte-5uago"&&(C.textContent=je),me=s(e),N=r(e,"P",{"data-svelte-h":!0}),l(N)!=="svelte-heukeo"&&(N.textContent=De),ue=s(e),M=r(e,"P",{"data-svelte-h":!0}),l(M)!=="svelte-1lbz8ww"&&(M.textContent=He),pe=s(e),A=r(e,"UL",{"data-svelte-h":!0}),l(A)!=="svelte-zgfnyl"&&(A.innerHTML=Be),he=s(e),$=r(e,"P",{"data-svelte-h":!0}),l($)!=="svelte-14cluov"&&($.textContent=Fe),ce=s(e),h(U.$$.fragment,e),de=s(e),S=r(e,"PRE",{"data-svelte-h":!0}),l(S)!=="svelte-1sc2cl"&&(S.innerHTML=Qe),_e=s(e),I=r(e,"P",{"data-svelte-h":!0}),l(I)!=="svelte-1h3zte4"&&(I.textContent=Ze),fe=s(e),R=r(e,"P",{"data-svelte-h":!0}),l(R)!=="svelte-1xul5uz"&&(R.textContent=Xe),ge=s(e),O=r(e,"P",{"data-svelte-h":!0}),l(O)!=="svelte-68g9fr"&&(O.textContent=Je),be=s(e),L=r(e,"UL",{"data-svelte-h":!0}),l(L)!=="svelte-1ko3p04"&&(L.innerHTML=Ve),ve=s(e),P=r(e,"P",{"data-svelte-h":!0}),l(P)!=="svelte-17viiyu"&&(P.textContent=We),Te=s(e),h(q.$$.fragment,e),we=s(e),z=r(e,"PRE",{"data-svelte-h":!0}),l(z)!=="svelte-50c5je"&&(z.textContent=Ye),ke=s(e),h(G.$$.fragment,e),xe=s(e),j=r(e,"P",{"data-svelte-h":!0}),l(j)!=="svelte-1r1tbrz"&&(j.textContent=Ke),ye=s(e),D=r(e,"P",{"data-svelte-h":!0}),l(D)!=="svelte-ai1t7s"&&(D.textContent=et),Ee=s(e),H=r(e,"P",{"data-svelte-h":!0}),l(H)!=="svelte-164jva0"&&(H.textContent=tt),Ce=s(e),B=r(e,"UL",{"data-svelte-h":!0}),l(B)!=="svelte-pckk5h"&&(B.innerHTML=nt),Ne=s(e),m=r(e,"BLOCKQUOTE",{style:!0,"data-svelte-h":!0}),l(m)!=="svelte-1w1k5y4"&&(m.innerHTML=at),Me=s(e),h(F.$$.fragment,e),Ae=s(e),Q=r(e,"PRE",{"data-svelte-h":!0}),l(Q)!=="svelte-1nepnpv"&&(Q.innerHTML=ot),$e=s(e),Z=r(e,"P",{"data-svelte-h":!0}),l(Z)!=="svelte-1ynasyn"&&(Z.textContent=st),Ue=s(e),u=r(e,"BLOCKQUOTE",{style:!0,"data-svelte-h":!0}),l(u)!=="svelte-yy1mxm"&&(u.innerHTML=it),Se=s(e),h(X.$$.fragment,e),Ie=s(e),h(J.$$.fragment,e),Re=s(e),h(V.$$.fragment,e),Oe=s(e),K=r(e,"P",{}),rt(K).forEach(n),this.h()},h(){lt(b,"name","hf:doc:metadata"),lt(b,"content",vt),g(m,"border-left","5px solid #80CBC4"),g(m,"background","#263238"),g(m,"color","#CFD8DC"),g(m,"padding","0.5em 1em"),g(m,"margin","1em 0"),g(u,"border-left","5px solid #FFAB91"),g(u,"background","#37474F"),g(u,"color","#FFCCBC"),g(u,"padding","0.5em 1em"),g(u,"margin","1em 0")},m(e,t){_t(document.head,b),a(e,ee,t),a(e,Y,t),a(e,te,t),c(v,e,t),a(e,ne,t),c(T,e,t),a(e,ae,t),a(e,w,t),a(e,oe,t),c(k,e,t),a(e,se,t),a(e,x,t),a(e,ie,t),c(y,e,t),a(e,re,t),c(E,e,t),a(e,le,t),a(e,C,t),a(e,me,t),a(e,N,t),a(e,ue,t),a(e,M,t),a(e,pe,t),a(e,A,t),a(e,he,t),a(e,$,t),a(e,ce,t),c(U,e,t),a(e,de,t),a(e,S,t),a(e,_e,t),a(e,I,t),a(e,fe,t),a(e,R,t),a(e,ge,t),a(e,O,t),a(e,be,t),a(e,L,t),a(e,ve,t),a(e,P,t),a(e,Te,t),c(q,e,t),a(e,we,t),a(e,z,t),a(e,ke,t),c(G,e,t),a(e,xe,t),a(e,j,t),a(e,ye,t),a(e,D,t),a(e,Ee,t),a(e,H,t),a(e,Ce,t),a(e,B,t),a(e,Ne,t),a(e,m,t),a(e,Me,t),c(F,e,t),a(e,Ae,t),a(e,Q,t),a(e,$e,t),a(e,Z,t),a(e,Ue,t),a(e,u,t),a(e,Se,t),c(X,e,t),a(e,Ie,t),c(J,e,t),a(e,Re,t),c(V,e,t),a(e,Oe,t),a(e,K,t),Le=!0},p:ut,i(e){Le||(d(v.$$.fragment,e),d(T.$$.fragment,e),d(k.$$.fragment,e),d(y.$$.fragment,e),d(E.$$.fragment,e),d(U.$$.fragment,e),d(q.$$.fragment,e),d(G.$$.fragment,e),d(F.$$.fragment,e),d(X.$$.fragment,e),d(J.$$.fragment,e),d(V.$$.fragment,e),Le=!0)},o(e){_(v.$$.fragment,e),_(T.$$.fragment,e),_(k.$$.fragment,e),_(y.$$.fragment,e),_(E.$$.fragment,e),_(U.$$.fragment,e),_(q.$$.fragment,e),_(G.$$.fragment,e),_(F.$$.fragment,e),_(X.$$.fragment,e),_(J.$$.fragment,e),_(V.$$.fragment,e),Le=!1},d(e){e&&(n(ee),n(Y),n(te),n(ne),n(ae),n(w),n(oe),n(se),n(x),n(ie),n(re),n(le),n(C),n(me),n(N),n(ue),n(M),n(pe),n(A),n(he),n($),n(ce),n(de),n(S),n(_e),n(I),n(fe),n(R),n(ge),n(O),n(be),n(L),n(ve),n(P),n(Te),n(we),n(z),n(ke),n(xe),n(j),n(ye),n(D),n(Ee),n(H),n(Ce),n(B),n(Ne),n(m),n(Me),n(Ae),n(Q),n($e),n(Z),n(Ue),n(u),n(Se),n(Ie),n(Re),n(Oe),n(K)),n(b),f(v,e),f(T,e),f(k,e),f(y,e),f(E,e),f(U,e),f(q,e),f(G,e),f(F,e),f(X,e),f(J,e),f(V,e)}}}const vt='{"title":"介绍","local":"介绍","sections":[{"title":"设置","local":"设置","sections":[],"depth":2}],"depth":1}';function Tt(qe){return pt(()=>{new URLSearchParams(window.location.search).get("fw")}),[]}class Et extends ht{constructor(b){super(),ct(this,b,Tt,bt,mt,{})}}export{Et as component};
