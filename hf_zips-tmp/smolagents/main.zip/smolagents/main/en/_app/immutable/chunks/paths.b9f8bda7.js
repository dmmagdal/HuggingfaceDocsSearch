var s;const e=((s=globalThis.__sveltekit_12oo2l3)==null?void 0:s.base)??"/docs/smolagents/main/en";var a;const o=((a=globalThis.__sveltekit_12oo2l3)==null?void 0:a.assets)??e;export{o as a,e as b};
