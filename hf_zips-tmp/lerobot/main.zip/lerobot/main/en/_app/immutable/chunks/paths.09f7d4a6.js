var s;const e=((s=globalThis.__sveltekit_ixxtzt)==null?void 0:s.base)??"/docs/lerobot/main/en";var t;const a=((t=globalThis.__sveltekit_ixxtzt)==null?void 0:t.assets)??e;export{a,e as b};
