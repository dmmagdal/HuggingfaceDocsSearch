var s;const e=((s=globalThis.__sveltekit_xvwjhs)==null?void 0:s.base)??"/docs/course/main/ru";var a;const t=((a=globalThis.__sveltekit_xvwjhs)==null?void 0:a.assets)??e;export{t as a,e as b};
