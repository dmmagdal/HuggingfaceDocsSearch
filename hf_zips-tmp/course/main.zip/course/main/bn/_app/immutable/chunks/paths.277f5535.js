var s;const e=((s=globalThis.__sveltekit_1yuly1r)==null?void 0:s.base)??"/docs/course/main/bn";var a;const t=((a=globalThis.__sveltekit_1yuly1r)==null?void 0:a.assets)??e;export{t as a,e as b};
