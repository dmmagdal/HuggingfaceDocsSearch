var s;const e=((s=globalThis.__sveltekit_1w4yosf)==null?void 0:s.base)??"/docs/course/main/pl";var a;const o=((a=globalThis.__sveltekit_1w4yosf)==null?void 0:a.assets)??e;export{o as a,e as b};
